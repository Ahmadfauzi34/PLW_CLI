"""F140 execution-backed proof-obligation projection and verification.

Extracted from ``fullstack.proof_obligations`` to break the F140 <-> F139 <-> F138
module cycle and keep F130/F131 proof obligations strictly layered beneath F139
execution-backed scenario evidence.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Dict

from fullstack.execution_backed_evidence import (
    ExecutionBackedEvidenceError,
    verify_execution_backed_scenario_evidence,
)
from fullstack.proof_obligations import (
    EXECUTION_COVERAGE_DIGEST_POLICY,
    EXECUTION_COVERAGE_SCHEMA_VERSION,
    ProofObligationError,
    _check_observed,
    _consistent_outcome,
    _execution_verified_provenance,
    _finalize_coverage_results,
    _prepare_obligation_projection,
    _scenario_observed,
    _verified_provenance,
    execution_proof_obligation_coverage_digest,
    verify_execution_backed_proof_coverage_integrity,
)


def project_execution_backed_proof_obligations(
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
) -> Dict[str, Any]:
    """F140: re-derive obligations from verified F139 execution-backed evidence.

    This reuses the F130/F131 obligation evaluators and witness-group semantics,
    but provenance requirements are explicitly F137/F138 execution provenance,
    never silently relabeled as F123 provenance.
    """
    try:
        by_scenario = verify_execution_backed_scenario_evidence(binding)
    except ExecutionBackedEvidenceError as exc:
        raise ProofObligationError(f"F139 execution-backed evidence rejected: {exc}") from exc
    plan_digest = str(binding["validation_plan_digest"])
    obligations, results = _prepare_obligation_projection(plan_digest, obligation_set)
    for obligation in obligations["obligations"]:
        scenario_id = obligation["scenario_id"]
        row = by_scenario.get(scenario_id)
        if row is None:
            raise ProofObligationError(
                f"obligation {obligation['obligation_id']} targets scenario_id not selected by F128/F139 binding"
            )
        requirement = obligation["requirement"]
        if requirement == "SCENARIO_OBSERVED":
            coverage = _scenario_observed(row)
        elif requirement == "CHECK_OBSERVED":
            coverage = _check_observed(row, str(obligation["check_id"]))
        elif requirement == "F123_RECEIPT_VERIFIED":
            coverage = _verified_provenance(row, receipt_only=True)
        elif requirement == "F123_PROVENANCE_VERIFIED":
            coverage = _verified_provenance(row, receipt_only=False)
        elif requirement == "EXECUTION_RECEIPT_VERIFIED":
            coverage = _execution_verified_provenance(row, receipt_only=True)
        elif requirement == "EXECUTION_PROVENANCE_VERIFIED":
            coverage = _execution_verified_provenance(row, receipt_only=False)
        else:
            coverage = _consistent_outcome(row)
        results.append({
            **obligation,
            **coverage,
            "evidence_authority": "F139_EXECUTION_BACKED_SCENARIO_EVIDENCE",
            "claim_truth_proven": False,
            "postcondition_proven": False,
        })

    next_evidence_requests, summary = _finalize_coverage_results(results)
    result: Dict[str, Any] = {
        "schema_version": EXECUTION_COVERAGE_SCHEMA_VERSION,
        "coverage_digest_policy": EXECUTION_COVERAGE_DIGEST_POLICY,
        "validation_plan_digest": plan_digest,
        "execution_backed_evidence_binding_digest": binding["execution_backed_evidence_binding_digest"],
        "F138_acceptance_id": binding["F138_acceptance_id"],
        "runtime_observation_id": binding["runtime_observation_id"],
        "proof_obligation_set_digest": obligations["proof_obligation_set_digest"],
        "obligation_results": results,
        "next_evidence_requests": next_evidence_requests,
        "summary": summary,
        "authority": {
            "F139_binding_digest_verified": True,
            "F138_acceptance_receipt_verified_by_F139": True,
            "execution_lineage_bound_by_F139": True,
            "proof_obligations_caller_declared": True,
            "validator_executed_by_projector": False,
            "runtime_dispatched_by_projector": False,
            "source_mutated": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "coverage_is_fresh_re_derivation": True,
            "F139_execution_backed_evidence_is_postcondition_proof": False,
            "covered_obligation_is_claim_truth": False,
            "complete_coverage_is_postcondition_proof": False,
            "validator_PASS_is_claim_truth": False,
            "validator_FAIL_is_runtime_failure": False,
            "legacy_F123_requirement_is_satisfied_by_F139_provenance": False,
            "execution_provenance_is_external_side_effect_truth": False,
        },
        "recovery": {
            "missing_or_partial": "follow next_evidence_requests using the exact F128/F139 scenario identity and witness scope",
            "conflicting": "preserve all execution-backed evidence and obtain independent/adjudicating evidence; no winner is chosen here",
            "legacy_F123_requirement": "do not silently reinterpret an F123-specific obligation as F137/F138 execution provenance; declare an execution provenance obligation explicitly when intended",
        },
        "next_boundary": "POSTCONDITION_PROOF_ASSEMBLY",
    }
    result["proof_obligation_coverage_digest"] = execution_proof_obligation_coverage_digest(result)
    return result


def verify_execution_backed_proof_coverage(
    coverage: Mapping[str, Any],
    *,
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
) -> bool:
    """Freshly re-derive F140 semantics; checksum alone is never authority."""
    verify_execution_backed_proof_coverage_integrity(coverage)
    expected = project_execution_backed_proof_obligations(binding, obligation_set)
    if coverage["proof_obligation_coverage_digest"] != expected["proof_obligation_coverage_digest"]:
        raise ProofObligationError(
            "execution-backed coverage is checksum-valid but does not match fresh semantic derivation"
        )
    return True


__all__ = [
    "project_execution_backed_proof_obligations",
    "verify_execution_backed_proof_coverage",
]
