"""
Topology Analyzers — HoTT Kernel
Schema Version: 3.0.0-kernel

Migrated dari file_scanner.py:
- Circular dependency detection  → topo.circular  (global, registry)
- Change risk advisory           → topo.risk      (global, registry)
- Impact analysis                → query_impact   (targeted, kernel)
- File outline extraction        → query_outline  (targeted, kernel)
- Brief (outline + impact)       → query_brief    (targeted, kernel)

Semua fungsi mengonsumsi SharedGraph. Tidak ada os.walk() di sini.
"""

import os
import re
from typing import Any, Dict, List, Optional, Set, Tuple

from language_semantics import is_tool_config_file as _is_tool_config_file, normalize_path as _normalize_path, strip_js_comments as _strip_comments


# ============================================================
# Regex patterns untuk outline extraction
# ============================================================

_IMPORT_RE = re.compile(
    r"import\s+(?:\{([^}]*)\}\s+from\s+)?"
    r"(?:\*\s+as\s+\w+\s+from\s+)?"
    r"(?:\w+\s*,\s*)?"
    r"['\"]([^'\"]+)['\"]"
)
_EXPORT_INTERFACE_RE = re.compile(r"(?:export\s+)?interface\s+(\w+)")
_EXPORT_TYPE_RE = re.compile(r"(?:export\s+)?type\s+(\w+)\s*=")
_EXPORT_CLASS_RE = re.compile(r"(?:export\s+)?(?:abstract\s+)?class\s+(\w+)")
_EXPORT_FUNCTION_RE = re.compile(r"(?:export\s+)?(?:async\s+)?function\s+(\w+)")
_EXPORT_CONST_RE = re.compile(r"(?:export\s+)?const\s+(\w+)\s*[=:]")
_EXPORT_ENUM_RE = re.compile(r"(?:export\s+)?enum\s+(\w+)")
_DECORATOR_RE = re.compile(r"^\s*@(\w+)", re.MULTILINE)
_EXPORT_DEFAULT_RE = re.compile(r"export\s+default")
_EXPORT_NAMED_RE = re.compile(r"export\s+\{([^}]*)\}")



# ============================================================
# topo.circular — Circular Dependency Detection (GLOBAL)
# ============================================================

def analyze_circular(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deteksi circular dependency dalam graph menggunakan Iterative Tarjan SCC +
    Bounded Iterative Johnson elementary cycle enumeration.
    """
    from codebase.cycle_break import (
        _build_directed_adjacency,
        compute_cycle_break_advisory,
        find_cyclic_sccs,
        find_directed_cycles_with_metadata,
    )

    edge_natures = shared_graph.get("edge_natures", {})
    cycle_meta = find_directed_cycles_with_metadata(shared_graph)
    detected_cycles: List[List[str]] = cycle_meta["cycles"]
    cyclic_sccs: List[Dict[str, Any]] = cycle_meta["cyclic_sccs"]
    files_in_cycles: List[str] = cycle_meta["files_in_cycles"]
    truncated: bool = bool(cycle_meta["truncated"])

    findings: List[Dict[str, Any]] = []
    for cycle_nodes in detected_cycles:
        normalized = cycle_nodes[:-1]
        if not normalized:
            continue

        # Determine cycle nature based on constituent edges.
        # An edge is marked "type_only" only when 100% of imports on that edge are
        # compiler-elided (TS `import type` / Python `if TYPE_CHECKING:`). Thus if
        # ANY edge in the cycle is type_only, the runtime import graph is acyclic
        # along this cycle (no runtime circular execution risk).
        cycle_edge_natures = [
            edge_natures.get(f"{cycle_nodes[i]} -> {cycle_nodes[i + 1]}", "runtime")
            for i in range(len(cycle_nodes) - 1)
        ]
        type_only_edge_count = sum(1 for n in cycle_edge_natures if n == "type_only")
        runtime_edge_count = len(cycle_edge_natures) - type_only_edge_count
        is_type_only = bool(cycle_edge_natures) and type_only_edge_count > 0
        severity = "low" if is_type_only else "high"
        cycle_nature = "type_only" if is_type_only else "runtime"

        findings.append({
            "type": "circular_dependency",
            "severity": severity,
            "cycle_nature": cycle_nature,
            "is_type_only": is_type_only,
            "type_only_edge_count": type_only_edge_count,
            "runtime_edge_count": runtime_edge_count,
            "cycle": cycle_nodes,
            "cycle_length": len(normalized),
            "files": normalized,
            "observation": (
                (
                    f"Type-only circular dependency ({len(normalized)} files): "
                    f"{' -> '.join(cycle_nodes)} [compiler-elided, no runtime crash risk]"
                ) if is_type_only else (
                    f"Circular dependency ({len(normalized)} files): "
                    f"{' -> '.join(cycle_nodes)}"
                )
            ),
        })

    findings.sort(key=lambda f: (f["cycle_length"], tuple(f["files"])))

    # Cycle-Break Advisory
    ordered_cycles = [f["cycle"] for f in findings]
    break_advisory_data = compute_cycle_break_advisory(shared_graph, ordered_cycles)
    cycle_advisories = break_advisory_data.get("advisories_by_cycle", [])

    for idx, f in enumerate(findings):
        if idx < len(cycle_advisories):
            adv = cycle_advisories[idx]
            f["break_advisory"] = adv.get("recommended_cut")
            f["candidate_edges"] = adv.get("candidate_edges", [])

    summary: Dict[str, Any] = {
        "total_cycles": len(findings),
        "runtime_cycles": sum(1 for f in findings if f.get("cycle_nature") == "runtime"),
        "type_only_cycles": sum(1 for f in findings if f.get("cycle_nature") == "type_only"),
        "files_in_cycles": len(files_in_cycles),
        "cyclic_scc_count": len(cyclic_sccs),
        "truncated": truncated,
        "cyclic_sccs": cyclic_sccs,
        "cycle_break_plan": break_advisory_data.get("cycle_break_plan", {}),
    }
    if truncated:
        rec_cuts = {
            (c["source"], c["target"])
            for c in summary["cycle_break_plan"].get("recommended_cuts", [])
            if c.get("source") and c.get("target")
        }
        res_v, res_adj, res_loops = _build_directed_adjacency(
            shared_graph,
            excluded_edges=rec_cuts,
            excluded_edge_natures={"same_package", "type_only"},
        )
        residual_sccs = find_cyclic_sccs(res_v, res_adj, res_loops)
        summary["covers_all_graph_cycles"] = len(residual_sccs) == 0
        summary["residual_cyclic_scc_count"] = len(residual_sccs)

    return {
        "analyzer": "topo.circular",
        "findings": findings,
        "summary": summary,
    }


# ============================================================
# topo.risk — Change Risk Advisory (GLOBAL)
# ============================================================

def analyze_risk(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Hitung change risk level untuk semua file.
    Menggunakan fan_in, entrypoint status, dan proximity ke entrypoint.
    """
    findings: List[Dict[str, Any]] = []
    node_metadata = shared_graph.get("node_metadata", {})
    edges = shared_graph.get("edges", [])

    # Build reverse adjacency (who imports this file)
    importers: Dict[str, List[str]] = {}
    for src, tgt in edges:
        importers.setdefault(tgt, []).append(src)

    # Get entrypoints
    entrypoints = {
        fp for fp, meta in node_metadata.items()
        if meta.get("is_entrypoint")
    }

    for fp in sorted(node_metadata.keys()):
        meta = node_metadata[fp]

        if meta.get("is_test"):
            continue

        fan_in = meta.get("fan_in", 0)
        fan_out = meta.get("fan_out", 0)
        is_ep = meta.get("is_entrypoint", False)

        risk_score = 0
        reasons: List[str] = []

        if is_ep:
            risk_score += 3
            reasons.append("is_entrypoint")

        if fan_in >= 3:
            risk_score += 2
            reasons.append("high_fan_in")
        elif fan_in >= 1:
            risk_score += 1
            reasons.append("has_dependents")

        # Check apakah entrypoint mengimpor file ini langsung
        direct_importers = importers.get(fp, [])
        ep_importers = [i for i in direct_importers if i in entrypoints]
        if ep_importers:
            risk_score += 2
            reasons.append("imported_by_entrypoint")

        # Classify
        if risk_score >= 5:
            level = "high"
        elif risk_score >= 2:
            level = "medium"
        else:
            level = "low"

        if risk_score > 0:
            findings.append({
                "type": "change_risk",
                "severity": level,
                "file": fp,
                "risk_level": level,
                "risk_score": risk_score,
                "reasons": reasons,
                "fan_in": fan_in,
                "fan_out": fan_out,
                "is_entrypoint": is_ep,
                "observation": (
                    f"File '{fp}': {level} change risk "
                    f"(score={risk_score}, {', '.join(reasons)})."
                ),
            })

    findings.sort(key=lambda f: (-f["risk_score"], f["file"]))

    return {
        "analyzer": "topo.risk",
        "findings": findings,
        "summary": {
            "total_assessed": len([
                m for m in node_metadata.values() if not m.get("is_test")
            ]),
            "high_risk": sum(1 for f in findings if f["risk_level"] == "high"),
            "medium_risk": sum(1 for f in findings if f["risk_level"] == "medium"),
            "low_risk": sum(1 for f in findings if f["risk_level"] == "low"),
        },
    }


# ============================================================
# topo.test_reachability — Static Test Import Topology
# ============================================================

def _reconstruct_path(parents: Dict[str, Optional[str]], target: str) -> List[str]:
    path: List[str] = []
    current: Optional[str] = target
    while current is not None:
        path.append(current)
        current = parents.get(current)
    path.reverse()
    return path


def analyze_test_reachability(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Map static import reachability from test files into production files.

    This is intentionally not called runtime coverage: a resolved import path is
    evidence that a test can reach a source file statically, not that statements
    or branches execute at runtime.
    """
    vertices = sorted(shared_graph.get("vertices", []))
    edges = list(map(tuple, shared_graph.get("edges", [])))
    metadata = shared_graph.get("node_metadata", {})
    tests = sorted(vertex for vertex in vertices if metadata.get(vertex, {}).get("is_test"))
    production = sorted(set(vertices) - set(tests))
    production_set = set(production)

    forward: Dict[str, Set[str]] = {vertex: set() for vertex in vertices}
    undirected: Dict[str, Set[str]] = {vertex: set() for vertex in vertices}
    for source, target in edges:
        forward.setdefault(source, set()).add(target)
        undirected.setdefault(source, set()).add(target)
        undirected.setdefault(target, set()).add(source)

    coverage_by_test: Dict[str, Dict[str, Any]] = {}
    source_test_witnesses: Dict[str, List[Dict[str, Any]]] = {}
    reachable_sources: Set[str] = set()
    directly_tested_sources: Set[str] = set()
    findings: List[Dict[str, Any]] = []

    for test_file in tests:
        parents: Dict[str, Optional[str]] = {test_file: None}
        queue = [test_file]
        cursor = 0
        while cursor < len(queue):
            node = queue[cursor]
            cursor += 1
            for neighbor in sorted(forward.get(node, set())):
                if neighbor not in parents:
                    parents[neighbor] = node
                    queue.append(neighbor)

        direct_targets = sorted(forward.get(test_file, set()) & production_set)
        reachable = sorted(set(parents) & production_set)
        directly_tested_sources.update(direct_targets)
        reachable_sources.update(reachable)
        coverage_by_test[test_file] = {
            "direct_targets": direct_targets,
            "reachable_sources": reachable,
            "reachable_count": len(reachable),
        }

        for source_file in reachable:
            source_test_witnesses.setdefault(source_file, []).append({
                "test": test_file,
                "path": _reconstruct_path(parents, source_file),
            })

        if not reachable:
            findings.append({
                "type": "isolated_test",
                "severity": "medium",
                "file": test_file,
                "observation": (
                    f"Test '{test_file}' has no direct or transitive resolved "
                    "relative import path to a production source file."
                ),
                "model": "static_test_import_reachability",
            })

    unreachable_sources = sorted(production_set - reachable_sources)

    for source_file in unreachable_sources:
        meta = metadata.get(source_file, {})
        if _is_tool_config_file(source_file) and meta.get("fan_in", 0) < 2:
            continue
        if meta.get("is_entrypoint") or meta.get("fan_in", 0) >= 2:
            reasons = []
            if meta.get("is_entrypoint"):
                reasons.append("is_entrypoint")
            if meta.get("fan_in", 0) >= 2:
                reasons.append("high_fan_in")
            findings.append({
                "type": "high_influence_without_test_path",
                "severity": "medium",
                "file": source_file,
                "fan_in": meta.get("fan_in", 0),
                "reasons": reasons,
                "observation": (
                    f"Influential source '{source_file}' has no static import path "
                    f"from a test ({', '.join(reasons)})."
                ),
                "model": "static_test_import_reachability",
            })

    # Connected components are computed on the undirected graph only to group
    # islands. Reachability above remains directional.
    seen: Set[str] = set()
    components: List[List[str]] = []
    for vertex in vertices:
        if vertex in seen:
            continue
        stack = [vertex]
        seen.add(vertex)
        component: List[str] = []
        while stack:
            node = stack.pop()
            component.append(node)
            for neighbor in sorted(undirected.get(node, set()), reverse=True):
                if neighbor not in seen:
                    seen.add(neighbor)
                    stack.append(neighbor)
        components.append(sorted(component))

    testless_components: List[Dict[str, Any]] = []
    for component in sorted(components, key=lambda item: item[0] if item else ""):
        component_tests = sorted(set(component) & set(tests))
        component_sources = sorted(set(component) & production_set)
        if component_sources and not component_tests:
            component_data = {
                "component_id": f"testless_{len(testless_components) + 1}",
                "source_files": component_sources,
                "source_count": len(component_sources),
            }
            testless_components.append(component_data)
            findings.append({
                "type": "testless_component",
                "severity": "low",
                **component_data,
                "observation": (
                    f"Undirected source component with {len(component_sources)} file(s) "
                    "contains no test file."
                ),
                "model": "static_test_import_reachability",
            })

    if not tests and production:
        findings.append({
            "type": "no_test_files",
            "severity": "high",
            "source_count": len(production),
            "observation": "No supported .spec/.test source files were found.",
            "model": "static_test_import_reachability",
        })

    severity_order = {"high": 0, "medium": 1, "low": 2, "info": 3}
    findings.sort(key=lambda item: (
        severity_order.get(item.get("severity", "info"), 4),
        item.get("type", ""),
        item.get("file", item.get("component_id", "")),
    ))

    ratio = round(len(reachable_sources) / len(production), 4) if production else 1.0
    return {
        "analyzer": "topo.test_reachability",
        "model": {
            "name": "static_test_import_reachability",
            "edge_semantics": "resolved relative import",
            "direction": "test or source file to imported dependency",
            "not_runtime_coverage": True,
            "interpretation": (
                "Reachability is structural evidence for LLM context and must not "
                "be reported as executed statements or branch coverage."
            ),
        },
        "findings": findings,
        "coverage_by_test": coverage_by_test,
        "source_test_witnesses": source_test_witnesses,
        "unreachable_sources": unreachable_sources,
        "testless_components": testless_components,
        "summary": {
            "total_tests": len(tests),
            "total_production_files": len(production),
            "directly_tested_files": len(directly_tested_sources),
            "statically_reachable_files": len(reachable_sources),
            "statically_unreachable_files": len(unreachable_sources),
            "static_test_reachability_ratio": ratio,
            "testless_component_count": len(testless_components),
            "high_influence_without_test_path": sum(
                1 for item in findings
                if item.get("type") == "high_influence_without_test_path"
            ),
            "isolated_test_count": sum(
                1 for item in findings if item.get("type") == "isolated_test"
            ),
        },
    }


# ============================================================
# TARGETED QUERY: Impact Analysis
# ============================================================

def _resolve_query_target(
    target_file: str,
    candidate_paths: Set[str],
    scan_root: Optional[str] = None,
) -> Tuple[Optional[str], List[str], str]:
    """Resolve a targeted-query path without guessing between duplicate suffixes.

    SharedGraph preserves the caller's root representation, so an absolute scan
    root produces absolute vertices even when an agent naturally supplies a
    root-relative target such as ``src/app.ts``. Exact identity remains first,
    including exact root-relative resolution against ``scan_root``; one unique
    suffix is a valid representation bridge; multiple suffix matches are
    returned as explicit ambiguity evidence.
    """
    requested = _normalize_path(str(target_file))
    candidates = {_normalize_path(str(path)) for path in candidate_paths}
    if requested in candidates:
        return requested, [], "exact"
    if os.path.isabs(requested):
        return None, [], "unresolved"
    if scan_root:
        rooted = _normalize_path(os.path.join(str(scan_root), requested))
        if rooted in candidates:
            return rooted, [], "root_relative_exact"

    suffix = "/" + requested.lstrip("/")
    matches = sorted(path for path in candidates if path.endswith(suffix))
    if len(matches) == 1:
        return matches[0], [], "unique_root_relative_suffix"
    if not matches and os.path.splitext(os.path.basename(requested))[1] == "":
        if "/" in requested:
            stem_matches = sorted(
                path for path in candidates
                if os.path.splitext(path)[0].endswith(suffix) or path.endswith(suffix)
            )
        elif len(requested) >= 2:
            req_l = requested.lower()
            req_collapsed = re.sub(r"[._-]+", "", req_l)
            exact_stem = sorted(
                path for path in candidates
                if os.path.splitext(os.path.basename(path))[0].lower() == req_l
            )
            if exact_stem:
                stem_matches = exact_stem
            elif len(req_collapsed) >= 4:
                stem_matches = sorted(
                    path for path in candidates
                    if re.sub(r"[._-]+", "", os.path.splitext(os.path.basename(path))[0].lower()) == req_collapsed
                )
            else:
                stem_matches = []
        else:
            stem_matches = []
        if len(stem_matches) == 1:
            return stem_matches[0], [], "unique_stem_match"
        if len(stem_matches) > 1:
            return None, stem_matches, "ambiguous"
    return None, matches, "ambiguous" if matches else "unresolved"


def _missing_query_target(
    field: str,
    target_file: str,
    candidates: List[str],
    resolution: str,
) -> Dict[str, Any]:
    requested = _normalize_path(str(target_file))
    return {
        field: requested,
        "requested_target": requested,
        "target_resolution": resolution,
        "candidate_targets": candidates,
        "exists": False,
        "error": "ambiguous_file_target" if candidates else "file_not_found_in_graph",
    }

def query_impact(shared_graph: Dict[str, Any], target_file: str) -> Dict[str, Any]:
    """
    Analisis dampak perubahan untuk satu file spesifik.
    Migrated dari file_scanner.py get_impacted_files().
    """
    requested_target = _normalize_path(target_file)
    vertices = shared_graph.get("vertices", [])
    edges = shared_graph.get("edges", [])
    node_metadata = shared_graph.get("node_metadata", {})
    target, candidates, resolution = _resolve_query_target(
        requested_target,
        set(vertices),
        scan_root=shared_graph.get("scan_root"),
    )

    if target is None:
        return _missing_query_target(
            "target", requested_target, candidates, resolution,
        )

    # Build adjacency
    adj_upstream: Dict[str, List[str]] = {}    # node -> what it imports
    adj_downstream: Dict[str, List[str]] = {}  # node -> who imports it

    for src, tgt in edges:
        adj_upstream.setdefault(src, []).append(tgt)
        adj_downstream.setdefault(tgt, []).append(src)

    # Deterministik
    for k in adj_upstream:
        adj_upstream[k] = sorted(set(adj_upstream[k]))
    for k in adj_downstream:
        adj_downstream[k] = sorted(set(adj_downstream[k]))

    # Transitive traversal with cycle safety
    def _traverse(start: str, adj: Dict[str, List[str]]) -> Tuple[List[str], List[str]]:
        visited: Set[str] = set()
        rec_stack: Set[str] = set()
        result: List[str] = []
        cycles: List[str] = []

        def _dfs(node: str) -> None:
            if node in rec_stack:
                cycles.append(node)
                return
            if node in visited:
                return
            rec_stack.add(node)
            visited.add(node)
            if node != start:
                result.append(node)
            for neighbor in adj.get(node, []):
                _dfs(neighbor)
            rec_stack.discard(node)

        _dfs(start)
        return result, cycles

    upstream_nodes, upstream_cycles = _traverse(target, adj_upstream)
    downstream_nodes, downstream_cycles = _traverse(target, adj_downstream)

    # Extract semantic usages targeting this file
    direct_downstream = sorted(set(adj_downstream.get(target, [])))
    semantic_usages = []
    edge_details = shared_graph.get("edge_details", [])
    for ed in edge_details:
        if ed.get("target") == target and ed.get("semantic_usages"):
            for usage in ed.get("semantic_usages"):
                semantic_usages.append(f"{ed.get('source')} -> {usage}")
    semantic_usages = sorted(list(set(semantic_usages)))

    # Affected entrypoints
    entrypoint_ids = {
        fp for fp, meta in node_metadata.items()
        if meta.get("is_entrypoint")
    }
    downstream_set = set(downstream_nodes)
    affected_entrypoints = sorted(entrypoint_ids & (downstream_set | {target}))
    target_is_entrypoint = target in entrypoint_ids

    # Metadata
    meta = node_metadata.get(target, {})
    target_fan_in = meta.get("fan_in", 0)
    target_fan_out = meta.get("fan_out", 0)
    target_is_test = meta.get("is_test", False)

    # Risk level
    risk_score = 0
    risk_reasons: List[str] = []

    if target_is_entrypoint:
        risk_score += 3
        risk_reasons.append("is_entrypoint")
    if len(affected_entrypoints) > 0 and not target_is_entrypoint:
        risk_score += 3
        risk_reasons.append("affects_entrypoints")
    if target_fan_in >= 3:
        risk_score += 2
        risk_reasons.append("high_fan_in")
    elif target_fan_in >= 1:
        risk_score += 1
        risk_reasons.append("has_dependents")
    if target_is_test:
        risk_score = max(0, risk_score - 2)
        risk_reasons.append("test_file")

    if risk_score >= 5:
        risk_level = "high"
    elif risk_score >= 2:
        risk_level = "medium"
    else:
        risk_level = "low"

    circular_refs = sorted(set(upstream_cycles + downstream_cycles))
    cycle_break_advisory = None
    if circular_refs:
        from codebase.cycle_break import (
            compute_cycle_break_advisory,
            find_directed_cycles_with_metadata,
        )
        cycle_meta = find_directed_cycles_with_metadata(shared_graph)
        circ_nodes = set(cycle_meta.get("files_in_cycles", []))
        circular_refs = [ref for ref in circular_refs if ref in circ_nodes]
        relevant_cycles = [
            cyc for cyc in cycle_meta.get("cycles", [])
            if target in cyc[:-1]
        ]
        if relevant_cycles:
            adv_data = compute_cycle_break_advisory(shared_graph, relevant_cycles)
            cycle_break_advisory = adv_data.get("cycle_break_plan")

    return {
        "target": target,
        "requested_target": requested_target,
        "target_resolution": resolution,
        "candidate_targets": [],
        "exists": True,
        "upstream": sorted(set(upstream_nodes)),
        "downstream": sorted(set(downstream_nodes)),
        "direct_upstream": sorted(set(adj_upstream.get(target, []))),
        "direct_downstream": direct_downstream,
        "semantic_usages": semantic_usages,
        "circular_references": circular_refs,
        "cycle_break_advisory": cycle_break_advisory,
        "target_is_entrypoint": target_is_entrypoint,
        "target_is_test": target_is_test,
        "affected_entrypoints": affected_entrypoints,
        "target_fan_in": target_fan_in,
        "target_fan_out": target_fan_out,
        "change_risk_level": risk_level,
        "change_risk_reasons": risk_reasons,
        "upstream_count": len(set(upstream_nodes)),
        "downstream_count": len(set(downstream_nodes)),
    }


# ============================================================
# TARGETED QUERY: File Outline Extraction
# ============================================================

def query_outline(shared_graph: Dict[str, Any], target_file: str) -> Dict[str, Any]:
    """
    Ekstrak outline ringkas dari satu file spesifik.
    Migrated dari file_scanner.py get_file_outline().
    """
    import bisect

    requested_target = _normalize_path(target_file)
    file_map = shared_graph.get("file_map", {})
    if requested_target in file_map:
        target, candidates, resolution = requested_target, [], "exact"
    else:
        target, candidates, resolution = _resolve_query_target(
            requested_target,
            set(file_map),
            scan_root=shared_graph.get("scan_root"),
        )

    if target is None:
        return _missing_query_target(
            "file", requested_target, candidates, resolution,
        )

    content = file_map[target]
    lines = content.splitlines()
    imports: List[str] = []
    internal_imports: List[str] = []
    external_imports: List[str] = []
    declarations: List[Dict[str, Any]] = []
    decorators: List[str] = []
    exports: List[str] = []

    from language_semantics import (
        source_language,
        parse_rust_imports,
        parse_kotlin_imports,
        kotlin_strip_comments_and_strings,
        kotlin_package_of,
        _KOTLIN_SAME_PKG_DECL_REGEX,
    )
    lang = source_language(target)

    if lang == "python":
        import ast as _py_ast
        try:
            tree = _py_ast.parse(content)
        except (SyntaxError, ValueError):
            tree = None
        if tree is not None:
            explicit_all: Optional[Set[str]] = None
            for node in tree.body:
                if isinstance(node, (_py_ast.Assign, _py_ast.AnnAssign)):
                    targets = node.targets if isinstance(node, _py_ast.Assign) else [node.target]
                    val = getattr(node, "value", None)
                    for t in targets:
                        if isinstance(t, _py_ast.Name) and t.id == "__all__" and isinstance(val, (_py_ast.List, _py_ast.Tuple, _py_ast.Set)):
                            explicit_all = {
                                elt.value for elt in val.elts
                                if isinstance(elt, _py_ast.Constant) and isinstance(elt.value, str)
                            }
            for node in _py_ast.walk(tree):
                if isinstance(node, _py_ast.Import):
                    for alias in node.names:
                        mod_name = alias.name
                        imports.append(mod_name)
                        rel_py = mod_name.replace(".", "/") + ".py"
                        if any(k == rel_py or k.endswith("/" + rel_py) for k in file_map):
                            internal_imports.append(mod_name)
                        else:
                            external_imports.append(mod_name)
                elif isinstance(node, _py_ast.ImportFrom):
                    mod_base = ("." * (node.level or 0)) + (node.module or "")
                    if not mod_base and node.names:
                        mod_base = "." + node.names[0].name
                    if mod_base:
                        imports.append(mod_base)
                        if (node.level or 0) > 0:
                            internal_imports.append(mod_base)
                        else:
                            rel_py = (node.module or "").replace(".", "/") + ".py"
                            if any(k == rel_py or k.endswith("/" + rel_py) for k in file_map):
                                internal_imports.append(mod_base)
                            else:
                                external_imports.append(mod_base)
            for node in tree.body:
                if isinstance(node, (_py_ast.FunctionDef, _py_ast.AsyncFunctionDef, _py_ast.ClassDef)):
                    kind = "class" if isinstance(node, _py_ast.ClassDef) else "function"
                    name = node.name
                    line_no = getattr(node, "lineno", 1)
                    sig_line = lines[line_no - 1].strip() if 1 <= line_no <= len(lines) else f"{kind} {name}"
                    is_exported = (name in explicit_all) if explicit_all is not None else (not name.startswith("_"))
                    declarations.append({
                        "line": line_no,
                        "kind": kind,
                        "name": name,
                        "exported": is_exported,
                        "signature": sig_line[:220],
                    })
                    for dec in getattr(node, "decorator_list", []):
                        dec_name = None
                        if isinstance(dec, _py_ast.Name):
                            dec_name = dec.id
                        elif isinstance(dec, _py_ast.Attribute):
                            dec_name = dec.attr
                        elif isinstance(dec, _py_ast.Call):
                            func = dec.func
                            if isinstance(func, _py_ast.Name):
                                dec_name = func.id
                            elif isinstance(func, _py_ast.Attribute):
                                dec_name = func.attr
                        if dec_name and dec_name not in decorators:
                            decorators.append(dec_name)
                elif isinstance(node, (_py_ast.Assign, _py_ast.AnnAssign)):
                    targets = node.targets if isinstance(node, _py_ast.Assign) else [node.target]
                    line_no = getattr(node, "lineno", 1)
                    sig_line = lines[line_no - 1].strip() if 1 <= line_no <= len(lines) else ""
                    for t in targets:
                        if isinstance(t, _py_ast.Name) and t.id != "__all__" and t.id[:1].isupper():
                            is_exported = (t.id in explicit_all) if explicit_all is not None else (not t.id.startswith("_"))
                            declarations.append({
                                "line": line_no,
                                "kind": "const",
                                "name": t.id,
                                "exported": is_exported,
                                "signature": sig_line[:220],
                            })
            for decl in declarations:
                if decl["exported"] and decl["name"] not in exports:
                    exports.append(decl["name"])
            if explicit_all:
                for item in sorted(explicit_all):
                    if item not in exports:
                        exports.append(item)
    elif lang == "rust":
        stripped = _strip_comments(content)
        stripped_lines = stripped.split("\n")
        line_starts = [0]
        for ln in stripped_lines[:-1]:
            line_starts.append(line_starts[-1] + len(ln) + 1)
        for imp in parse_rust_imports(content):
            raw = imp.get("raw_import", "")
            if raw:
                imports.append(raw)
                if (
                    imp.get("rust_mod")
                    or raw in ("crate", "self", "super")
                    or raw.startswith(("crate::", "self::", "super::"))
                ):
                    internal_imports.append(raw)
                else:
                    external_imports.append(raw)
        rust_decl_re = re.compile(
            r"^(?:(?P<macro>macro_rules!)\s+(?P<mname>[A-Za-z_][\w]*)|"
            r"(?:(?P<pub>pub(?:\([^)]*\))?)\s+)?"
            r'(?:async\s+|unsafe\s+|const\s+|extern\s+"[^"]*"\s+|default\s+)*'
            r"(?P<kw>fn|struct|enum|union|trait|type|const|static|mod)\s+(?P<name>[A-Za-z_][\w]*))",
            re.MULTILINE,
        )
        for match in rust_decl_re.finditer(stripped):
            line_no = bisect.bisect_right(line_starts, match.start())
            sig_line = lines[line_no - 1].strip() if 1 <= line_no <= len(lines) else ""
            if match.group("macro"):
                kind = "macro"
                name = match.group("mname")
                is_exported = True
            else:
                kw = match.group("kw")
                kind = "function" if kw == "fn" else kw
                name = match.group("name")
                is_exported = bool(match.group("pub"))
            declarations.append({
                "line": line_no,
                "kind": kind,
                "name": name,
                "exported": is_exported,
                "signature": sig_line[:220],
            })
            if is_exported and name not in exports:
                exports.append(name)
        for attr_m in re.finditer(r"#\[([A-Za-z_][\w:]*)", stripped):
            attr_name = attr_m.group(1)
            if attr_name not in decorators:
                decorators.append(attr_name)
    elif lang == "kotlin":
        clean = kotlin_strip_comments_and_strings(content)
        clean_lines = clean.split("\n")
        line_starts = [0]
        for ln in clean_lines[:-1]:
            line_starts.append(line_starts[-1] + len(ln) + 1)
        pkg = kotlin_package_of(content)
        pkg_root = ".".join(pkg.split(".")[:2]) if pkg else ""
        for imp in parse_kotlin_imports(content):
            raw = imp.get("raw_import", "")
            if raw:
                imports.append(raw)
                if pkg_root and raw.startswith(pkg_root + "."):
                    internal_imports.append(raw)
                else:
                    external_imports.append(raw)

        # Anchor line_no on the declaration itself (modifiers or keyword), not leading `@Composable` annotations.
        seen_kt_decl_keys: Set[Tuple[int, str]] = set()
        for match in _KOTLIN_SAME_PKG_DECL_REGEX.finditer(clean):
            mods = set((match.group("mods") or "").split())
            kw = match.group("kw")
            kind = "function" if kw == "fun" else ("const" if kw in ("val", "var") else kw)
            name = match.group("name")
            decl_pos = match.start("mods") if match.group("mods") else match.start("kw")
            line_no = bisect.bisect_right(line_starts, decl_pos)
            sig_line = lines[line_no - 1].strip() if 1 <= line_no <= len(lines) else ""
            is_exported = "private" not in mods
            seen_kt_decl_keys.add((line_no, name))
            declarations.append({
                "line": line_no,
                "kind": kind,
                "name": name,
                "exported": is_exported,
                "signature": sig_line[:220],
            })
            if is_exported and name not in exports:
                exports.append(name)

        # Also extract direct non-local member declarations inside `class` / `object` / `interface` bodies
        # using brace+paren depth tracking so constructor params and local `val`s inside functions are excluded.
        kt_member_re = re.compile(
            r"^\s*(?:@[\w.]+(?:\([^)]*\))?\s+)*"
            r"(?P<mods>(?:(?:public|internal|private|protected|open|abstract|data|sealed|final|"
            r"expect|actual|inline|value|external|override|crossinline|noinline|tailrec|"
            r"suspend|operator|infix|lateinit|const|companion|annotation)\s+)*)"
            r"(?P<kw>class|interface|object|fun|val|var|typealias|enum)"
            r"(?:\s+(?:class|interface))?\s+"
            r"(?:<[^>]*>\s+)?"
            r"(?:[\w]+(?:<[^>]*>)?\??\.)?"
            r"(?P<name>[A-Za-z_][\w]*)"
        )
        brace_depth = 0
        paren_depth = 0
        block_stack: List[Tuple[int, str]] = []
        pending_type_body = False
        for idx_ln, cln in enumerate(clean_lines, start=1):
            in_type_body = (
                paren_depth == 0
                and bool(block_stack)
                and block_stack[-1][0] == brace_depth
                and block_stack[-1][1] == "type"
            )
            if in_type_body:
                m_mem = kt_member_re.match(cln)
                if m_mem:
                    mods = set((m_mem.group("mods") or "").split())
                    kw = m_mem.group("kw")
                    kind = "function" if kw == "fun" else ("const" if kw in ("val", "var") else kw)
                    name = m_mem.group("name")
                    if (idx_ln, name) not in seen_kt_decl_keys:
                        seen_kt_decl_keys.add((idx_ln, name))
                        sig_line = lines[idx_ln - 1].strip() if 1 <= idx_ln <= len(lines) else ""
                        declarations.append({
                            "line": idx_ln,
                            "kind": kind,
                            "name": name,
                            "exported": ("private" not in mods and "protected" not in mods),
                            "signature": sig_line[:220],
                        })
            elif paren_depth == 0 and brace_depth == 0:
                m_top = _KOTLIN_SAME_PKG_DECL_REGEX.match(cln)
                if m_top and m_top.group("kw") in ("class", "interface", "object", "enum"):
                    pending_type_body = True

            if in_type_body:
                m_nested_type = kt_member_re.match(cln)
                if m_nested_type and m_nested_type.group("kw") in ("class", "interface", "object", "enum"):
                    pending_type_body = True
                elif re.match(r"^\s*(?:companion\s+object)\b", cln):
                    pending_type_body = True

            for ch in cln:
                if ch == "(":
                    paren_depth += 1
                elif ch == ")" and paren_depth > 0:
                    paren_depth -= 1
                elif ch == "{":
                    brace_depth += 1
                    bkind = "type" if pending_type_body else "code"
                    block_stack.append((brace_depth, bkind))
                    pending_type_body = False
                elif ch == "}" and brace_depth > 0:
                    if block_stack and block_stack[-1][0] == brace_depth:
                        block_stack.pop()
                    brace_depth -= 1
            if pending_type_body and not re.search(r"(?:class|interface|object|enum)\b", cln) and ":" not in cln and "(" not in cln and cln.strip():
                pending_type_body = False

        for dec_m in _DECORATOR_RE.finditer(_strip_comments(content)):
            dec_name = dec_m.group(1)
            if dec_name not in decorators:
                decorators.append(dec_name)
    else:
        stripped = _strip_comments(content)
        stripped_lines = stripped.split("\n")
        line_starts = [0]
        for ln in stripped_lines[:-1]:
            line_starts.append(line_starts[-1] + len(ln) + 1)
        n_stripped_lines = len(stripped_lines)

        for match in _IMPORT_RE.finditer(stripped):
            import_path = match.group(2)
            if import_path:
                imports.append(import_path)
                if import_path.startswith("."):
                    internal_imports.append(import_path)
                else:
                    external_imports.append(import_path)

        decl_patterns = [
            ("interface", _EXPORT_INTERFACE_RE),
            ("type", _EXPORT_TYPE_RE),
            ("class", _EXPORT_CLASS_RE),
            ("function", _EXPORT_FUNCTION_RE),
            ("const", _EXPORT_CONST_RE),
            ("enum", _EXPORT_ENUM_RE),
        ]

        for kind, pattern in decl_patterns:
            for match in pattern.finditer(stripped):
                name = match.group(1)
                line_no = bisect.bisect_right(line_starts, match.start())
                match_line = stripped_lines[line_no - 1].strip() if line_no <= n_stripped_lines else ""
                is_exported = match_line.startswith("export")

                declarations.append({
                    "line": line_no,
                    "kind": kind,
                    "name": name,
                    "exported": is_exported,
                    "signature": match_line[:220],
                })

        for match in _DECORATOR_RE.finditer(stripped):
            dec_name = match.group(1)
            if dec_name not in decorators:
                decorators.append(dec_name)

        for decl in declarations:
            if decl["exported"] and decl["name"] not in exports:
                exports.append(decl["name"])

        if _EXPORT_DEFAULT_RE.search(stripped):
            if "default" not in exports:
                exports.append("default")

        for match in _EXPORT_NAMED_RE.finditer(stripped):
            for item in match.group(1).split(","):
                item = item.strip()
                if " as " in item:
                    item = item.split(" as ")[-1].strip()
                if item and item not in exports:
                    exports.append(item)

    declarations.sort(key=lambda d: d["line"])

    return {
        "file": target,
        "requested_target": requested_target,
        "target_resolution": resolution,
        "candidate_targets": [],
        "exists": True,
        "imports": sorted(set(imports)),
        "internal_imports": sorted(set(internal_imports)),
        "external_imports": sorted(set(external_imports)),
        "exports": exports,
        "decorators": decorators,
        "declarations": declarations,
        "stats": {
            "total_lines": len(lines),
            "outline_entries": len(declarations),
            "export_count": len(exports),
            "import_count": len(set(imports)),
        },
    }


# ============================================================
# TARGETED QUERY: Brief (Outline + Impact)
# ============================================================

def query_brief(shared_graph: Dict[str, Any], target_file: str) -> Dict[str, Any]:
    """
    Gabungan outline + impact untuk satu file spesifik.
    Migrated dari file_scanner.py get_file_brief().
    """
    outline = query_outline(shared_graph, target_file)
    impact = query_impact(shared_graph, target_file)

    if not outline.get("exists") or not impact.get("exists"):
        failed = outline if not outline.get("exists") else impact
        return {
            "file": failed.get("file", failed.get("target", target_file)),
            "requested_target": failed.get("requested_target", _normalize_path(target_file)),
            "target_resolution": failed.get("target_resolution", "unresolved"),
            "candidate_targets": failed.get("candidate_targets", []),
            "exists": False,
            "error": failed.get("error"),
        }

    return {
        "file": outline["file"],
        "requested_target": outline.get("requested_target", _normalize_path(target_file)),
        "target_resolution": outline.get("target_resolution", "exact"),
        "candidate_targets": [],
        "exists": True,
        "outline": {
            "imports": outline["imports"],
            "internal_imports": outline["internal_imports"],
            "external_imports": outline["external_imports"],
            "exports": outline["exports"],
            "decorators": outline["decorators"],
            "declarations": outline["declarations"],
            "stats": outline["stats"],
        },
        "impact": {
            "target_is_entrypoint": impact["target_is_entrypoint"],
            "target_is_test": impact["target_is_test"],
            "affected_entrypoints": impact["affected_entrypoints"],
            "direct_downstream": impact["direct_downstream"],
            "semantic_usages": impact.get("semantic_usages", []),
            "downstream_count": impact["downstream_count"],
            "upstream_count": impact["upstream_count"],
            "target_fan_in": impact["target_fan_in"],
            "target_fan_out": impact["target_fan_out"],
            "change_risk_level": impact["change_risk_level"],
            "change_risk_reasons": impact["change_risk_reasons"],
            "circular_references": impact["circular_references"],
            "cycle_break_advisory": impact.get("cycle_break_advisory"),
        },
    }


from codebase.cycle_break import analyze_cycle_breaks, compute_cycle_break_advisory
