"""
Cycle-Break Advisor — Codebase Topology Domain
Schema Version: 3.0.0-kernel

Provides code-aware, deterministic Feedback Arc Set (FAS) computation
and prescriptive refactoring advice to break circular dependencies.
"""

from collections import deque
from typing import Callable, Dict, List, Any, Optional, Sequence, Set, Tuple
import ast
import os
import re

from language_semantics import (
    _python_relative_module,
    candidate_targets as _candidate_targets,
    is_python_type_checking_guard as _is_type_checking_guard,
    kotlin_package_of as _kotlin_package_of,
    kotlin_same_package_declarations as _kotlin_same_package_declarations,
    normalize_path as _normalize_path,
    parse_kotlin_imports as _parse_kotlin_imports,
    parse_rust_imports as _parse_rust_imports,
    python_module_candidates as _python_module_candidates,
    resolve_relative_import_path as _resolve_import_path,
)

# Architectural layer ranking (higher number = higher abstraction layer)
LAYER_RANK = {
    "Helper": 1,
    "Module": 2,
    "Service": 3,
    "Component": 4,
    "Entrypoint": 5,
    "Other": 2,
}

IMPORT_REGEX = re.compile(
    r"""(?:import\s+(?P<type_kw>type\s+)?(?:(?P<clause>[^"';]+?)\s+from\s+)?|export\s+(?P<export_type>type\s+)?(?:(?P<export_clause>[^"';]+?)\s+from\s+)?|import\s*\(\s*)["'](?P<path>[^"']+)["']""",
    re.MULTILINE,
)



def _extract_imported_symbols(clause: str) -> List[str]:
    """Extract individual imported symbols from import clause."""
    if not clause:
        return []
    clause = clause.strip()
    symbols = []
    # Check for named imports inside { ... }
    named_match = re.search(r"\{([^}]+)\}", clause)
    if named_match:
        raw_named = named_match.group(1)
        for item in raw_named.split(","):
            cleaned = item.strip()
            if not cleaned:
                continue
            # Handle 'type Foo' inside named import
            if cleaned.startswith("type "):
                cleaned = cleaned[5:].strip()
            # Handle 'as alias'
            if " as " in cleaned:
                cleaned = cleaned.split(" as ")[0].strip()
            if cleaned:
                symbols.append(cleaned)
    else:
        # Default, namespace, or wildcard import/re-export (e.g. `import Foo`, `import * as Foo`, `export *`)
        default_name = clause.split(",")[0].strip()
        if default_name == "*":
            return []
        if default_name.startswith("* as "):
            default_name = default_name[5:].strip()
        if default_name and default_name != "*":
            symbols.append(default_name)
    return symbols


def _is_all_inline_type_clause(clause: str) -> bool:
    """Return True when clause only has inline `type` specifiers inside `{ ... }` (and no non-type default import)."""
    if not clause:
        return False
    named_match = re.search(r"\{([^}]+)\}", clause)
    if not named_match:
        return False
    prefix = clause[:named_match.start()].strip()
    if prefix and prefix != "type":
        return False
    specifiers = [item.strip() for item in named_match.group(1).split(",") if item.strip()]
    return bool(specifiers) and all(re.match(r"^type\s+[A-Za-z0-9_$]", item) for item in specifiers)


def _inspect_python_edge_import(
    source: str,
    target: str,
    content: str,
    parse_cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    no_import = {
        "has_import": False,
        "is_type_only": False,
        "is_already_type_only": False,
        "is_dynamic": False,
        "symbols": [],
        "raw_statement": "",
    }
    tree = None
    if parse_cache is not None:
        ast_cache = parse_cache.setdefault("py_ast", {})
        if source in ast_cache:
            tree = ast_cache[source]
            if tree is None:
                return no_import
    if tree is None:
        try:
            tree = ast.parse(content)
        except (SyntaxError, ValueError):
            if parse_cache is not None:
                parse_cache.setdefault("py_ast", {})[source] = None
            return no_import
        if parse_cache is not None:
            parse_cache.setdefault("py_ast", {})[source] = tree

    source_norm = _normalize_path(source)
    target_norm = _normalize_path(target)
    target_base = os.path.splitext(target_norm)[0]
    if os.path.basename(target_norm) == "__init__.py":
        target_pkg = os.path.dirname(target_norm)
    else:
        target_pkg = target_base

    def _matches_target(raw_import: str, is_relative: bool) -> bool:
        if is_relative:
            resolved_base = _resolve_import_path(source_norm, raw_import)
            for cand in _candidate_targets(resolved_base, "python"):
                if cand == target_norm or os.path.splitext(cand)[0] == target_base:
                    return True
            return False
        for cand in _python_module_candidates(raw_import, ["."]):
            cand_base = os.path.splitext(cand)[0]
            if (
                cand == target_norm
                or cand_base == target_base
                or target_norm.endswith("/" + cand)
                or target_base.endswith("/" + cand_base)
                or target_pkg.endswith("/" + cand_base)
                or target_pkg == cand_base
            ):
                return True
        return False

    matched_import: Optional[Dict[str, Any]] = None

    def _visit(node: ast.AST, in_func: bool, in_type_checking: bool) -> Optional[Dict[str, Any]]:
        nonlocal matched_import
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for child in node.body:
                res = _visit(child, True, in_type_checking)
                if res is not None:
                    return res
            return None
        if isinstance(node, ast.If):
            child_tc = in_type_checking or _is_type_checking_guard(node.test)
            for child in node.body:
                res = _visit(child, in_func, child_tc)
                if res is not None:
                    return res
            for child in node.orelse:
                res = _visit(child, in_func, in_type_checking)
                if res is not None:
                    return res
            return None
        if isinstance(node, ast.Import):
            for alias in node.names:
                raw_import = alias.name.replace(".", "/")
                if _matches_target(raw_import, False):
                    candidate = {
                        "has_import": True,
                        "is_type_only": in_type_checking,
                        "is_already_type_only": in_type_checking,
                        "is_dynamic": in_func,
                        "symbols": [alias.asname or alias.name.split(".")[0]],
                        "raw_statement": f"import {alias.name}",
                    }
                    if not in_func and not in_type_checking:
                        return candidate
                    if matched_import is None:
                        matched_import = candidate
        elif isinstance(node, ast.ImportFrom):
            symbols = [alias.asname or alias.name for alias in node.names]
            if node.level:
                module_base = _python_relative_module(node.level, node.module)
                raw_list = [module_base] if node.module else [
                    module_base.rstrip("/") + "/" + alias.name.replace(".", "/")
                    for alias in node.names
                    if alias.name != "*"
                ]
                if not raw_list:
                    raw_list = [module_base]
                is_rel = True
            else:
                module = (node.module or "").replace(".", "/")
                raw_list = [module] if module else []
                if module:
                    for alias in node.names:
                        if alias.name != "*":
                            raw_list.append(f"{module}/{alias.name.replace('.', '/')}")
                is_rel = False
            for raw_import in raw_list:
                if raw_import and _matches_target(raw_import, is_rel):
                    candidate = {
                        "has_import": True,
                        "is_type_only": in_type_checking,
                        "is_already_type_only": in_type_checking,
                        "is_dynamic": in_func,
                        "symbols": symbols,
                        "raw_statement": f"from {'.' * node.level}{node.module or ''} import {', '.join(symbols)}",
                    }
                    if not in_func and not in_type_checking:
                        return candidate
                    if matched_import is None:
                        matched_import = candidate
        for child in ast.iter_child_nodes(node):
            if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.If)):
                res = _visit(child, in_func, in_type_checking)
                if res is not None:
                    return res
        return None

    immediate = _visit(tree, False, False)
    if immediate is not None:
        return immediate
    if matched_import is not None:
        return matched_import
    return no_import


def _inspect_rust_edge_import(
    source: str,
    target: str,
    content: str,
    parse_cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    target_norm = _normalize_path(target)
    target_dir = os.path.dirname(target_norm)
    target_stem = os.path.splitext(os.path.basename(target_norm))[0]
    target_mod_name = os.path.basename(target_dir) if target_stem == "mod" else target_stem
    source_dir = os.path.dirname(_normalize_path(source))

    if parse_cache is not None:
        rust_cache = parse_cache.setdefault("rust_imports", {})
        parsed = rust_cache.get(source)
        if parsed is None:
            parsed = _parse_rust_imports(content)
            rust_cache[source] = parsed
    else:
        parsed = _parse_rust_imports(content)

    matched_syms: List[str] = []
    matched_stmts: List[str] = []
    mod_syms: List[str] = []
    mod_stmts: List[str] = []
    for imp in parsed:
        raw = imp.get("raw_import", "")
        if imp.get("rust_mod"):
            cand_rs = _normalize_path(os.path.join(source_dir, raw + ".rs"))
            cand_mod = _normalize_path(os.path.join(source_dir, raw, "mod.rs"))
            if target_norm in (cand_rs, cand_mod):
                if raw not in mod_syms:
                    mod_syms.append(raw)
                stmt = imp.get("statement", "")
                if stmt and stmt not in mod_stmts:
                    mod_stmts.append(stmt)
            continue
        segs = raw.split("::")
        if not target_mod_name:
            continue
        is_mod_match = (
            target_mod_name in segs[:-1]
            or (imp.get("wildcard") and segs[-1] == target_mod_name)
            or (segs[-1] == target_mod_name)
        )
        # Also match `use super::*;` when source lives directly under target's dir (`mod.rs`).
        if not is_mod_match and imp.get("wildcard") and raw in ("super", "crate") and target_stem == "mod":
            if source_dir == target_dir or source_dir.startswith(target_dir + "/"):
                is_mod_match = True
        if is_mod_match:
            if not imp.get("wildcard"):
                for sym in imp.get("symbols", []):
                    if sym and sym != "*" and sym not in matched_syms:
                        matched_syms.append(sym)
            stmt = imp.get("statement", "")
            if stmt and stmt not in matched_stmts:
                matched_stmts.append(stmt)

    if not matched_stmts and not matched_syms:
        matched_syms = mod_syms
        matched_stmts = mod_stmts

    if matched_stmts or matched_syms:
        return {
            "has_import": True,
            "is_type_only": False,
            "is_already_type_only": False,
            "is_dynamic": False,
            "is_reexport": False,
            "is_wildcard_reexport": False,
            "symbols": matched_syms,
            "raw_statement": matched_stmts[0] if matched_stmts else "",
        }
    return {
        "has_import": False,
        "is_type_only": False,
        "is_already_type_only": False,
        "is_dynamic": False,
        "is_reexport": False,
        "is_wildcard_reexport": False,
        "symbols": [],
        "raw_statement": "",
    }


def _inspect_kotlin_edge_import(
    source: str,
    target: str,
    content: str,
    file_map: Dict[str, str],
    parse_cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    target_norm = _normalize_path(target)
    target_base_no_ext = os.path.splitext(target_norm)[0]
    target_stem = os.path.splitext(os.path.basename(target_norm))[0]

    if parse_cache is not None:
        kt_cache = parse_cache.setdefault("kotlin_imports", {})
        parsed = kt_cache.get(source)
        if parsed is None:
            parsed = _parse_kotlin_imports(content)
            kt_cache[source] = parsed
    else:
        parsed = _parse_kotlin_imports(content)

    target_content = file_map.get(target, "") or file_map.get(target_norm, "")
    target_pkg = _kotlin_package_of(target_content) if target_content else ""
    target_decls = set(_kotlin_same_package_declarations(target_content).keys()) if target_content else set()
    matched_syms: List[str] = []
    matched_stmts: List[str] = []
    for imp in parsed:
        raw = imp.get("raw_import", "")
        if raw.endswith(".R") and raw[:-2] == target_pkg:
            continue
        rel_path = raw.replace(".", "/")
        pkg_match = bool(target_pkg and raw.startswith(target_pkg + "."))
        sub_after_pkg = raw[len(target_pkg) + 1 :] if pkg_match else ""
        top_part = sub_after_pkg.split(".", 1)[0] if sub_after_pkg else ""
        if (
            target_base_no_ext.endswith("/" + rel_path)
            or target_base_no_ext == rel_path
            or (pkg_match and (top_part == target_stem or top_part in target_decls))
        ):
            for sym in imp.get("symbols", []):
                if sym and sym != "*" and sym not in matched_syms:
                    matched_syms.append(sym)
            stmt = imp.get("statement", "")
            if stmt and stmt not in matched_stmts:
                matched_stmts.append(stmt)

    if not matched_syms and target_content:
        source_pkg = _kotlin_package_of(content)
        if source_pkg and source_pkg == target_pkg:
            tokens = set(re.findall(r"\b[A-Za-z_][A-Za-z0-9_]*\b", content))
            for sym in _kotlin_same_package_declarations(target_content):
                if sym in tokens and sym not in matched_syms:
                    matched_syms.append(sym)

    if matched_stmts or matched_syms:
        return {
            "has_import": True,
            "is_type_only": False,
            "is_already_type_only": False,
            "is_dynamic": False,
            "is_reexport": False,
            "is_wildcard_reexport": False,
            "symbols": matched_syms,
            "raw_statement": matched_stmts[0] if matched_stmts else "",
        }
    return {
        "has_import": False,
        "is_type_only": False,
        "is_already_type_only": False,
        "is_dynamic": False,
        "is_reexport": False,
        "is_wildcard_reexport": False,
        "symbols": [],
        "raw_statement": "",
    }


def _inspect_edge_import(
    source: str,
    target: str,
    file_map: Dict[str, str],
    type_shapes: Dict[str, Dict[str, Any]],
    parse_cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Inspect code in source file to find how target is imported,
    which symbols are used, and whether it is type-only.
    """
    content = file_map.get(source, "")
    if not content:
        disk_cache = parse_cache.setdefault("disk_content", {}) if parse_cache is not None else None
        if disk_cache is not None and source in disk_cache:
            content = disk_cache[source]
        elif os.path.isfile(source):
            try:
                with open(source, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
            except OSError:
                content = ""
            if disk_cache is not None:
                disk_cache[source] = content
        elif disk_cache is not None:
            disk_cache[source] = ""
    no_import = {
        "has_import": False,
        "is_type_only": False,
        "is_already_type_only": False,
        "is_dynamic": False,
        "is_reexport": False,
        "is_wildcard_reexport": False,
        "symbols": [],
        "raw_statement": "",
    }
    if not content:
        return no_import

    if source.endswith(".py"):
        return _inspect_python_edge_import(source, target, content, parse_cache=parse_cache)
    if source.endswith(".rs"):
        return _inspect_rust_edge_import(source, target, content, parse_cache=parse_cache)
    if source.endswith(".kt"):
        return _inspect_kotlin_edge_import(source, target, content, file_map, parse_cache=parse_cache)

    target_norm = _normalize_path(target)
    target_base = os.path.splitext(target_norm)[0]
    target_filename = os.path.basename(target_norm)
    target_filebase = os.path.splitext(target_filename)[0]

    source_dir = os.path.dirname(_normalize_path(source))

    target_types = set(type_shapes.get(target_norm, {}).keys())

    if parse_cache is not None:
        regex_cache = parse_cache.setdefault("import_matches", {})
        matches = regex_cache.get(source)
        if matches is None:
            matches = list(IMPORT_REGEX.finditer(content))
            regex_cache[source] = matches
    else:
        matches = IMPORT_REGEX.finditer(content)

    matched_candidates: List[Dict[str, Any]] = []
    for match in matches:
        raw_path = match.group("path")
        if not raw_path:
            continue

        # Resolve path relative to source
        if raw_path.startswith("."):
            resolved = _normalize_path(os.path.join(source_dir, raw_path))
        else:
            resolved = _normalize_path(raw_path)

        resolved_base = os.path.splitext(resolved)[0]

        # Check if this import matches target (including directory barrel `./dir` -> `./dir/index.ts`)
        target_parent = os.path.dirname(target_norm)
        is_index_barrel = target_filebase == "index" and bool(target_parent) and (
            resolved == target_parent or resolved_base == target_parent
        )
        is_match = (
            resolved == target_norm
            or resolved_base == target_base
            or resolved.endswith("/" + target_filename)
            or resolved.endswith("/" + target_filebase)
            or is_index_barrel
        )

        if is_match:
            clause = match.group("clause") or match.group("export_clause") or ""
            is_type_kw = bool(match.group("type_kw") or match.group("export_type"))
            is_inline_type = _is_all_inline_type_clause(clause)
            is_already_type_only = is_type_kw or is_inline_type
            is_reexport = bool(
                match.group("export_clause") is not None
                or match.group(0).lstrip().startswith("export")
            )
            clause_stripped = clause.strip()
            is_wildcard_reexport = is_reexport and (
                clause_stripped == "*" or clause_stripped.startswith("* as ")
            )
            symbols = [] if is_wildcard_reexport else _extract_imported_symbols(clause)
            raw_stmt = match.group(0)

            # Detect dynamic import: e.g. import(...) or await import(...)
            is_dynamic = bool(
                re.match(r"""^\s*import\s*\(""", raw_stmt.strip())
                or "await import(" in content[max(0, match.start() - 25) : match.end()]
            )

            # Check if all symbols are interfaces/types defined in target
            all_types_in_target = bool(
                symbols and target_types and all(s in target_types for s in symbols)
            )
            is_type_only = is_already_type_only or all_types_in_target

            matched_candidates.append({
                "has_import": True,
                "is_type_only": is_type_only,
                "is_already_type_only": is_already_type_only,
                "is_dynamic": is_dynamic,
                "is_reexport": is_reexport,
                "is_wildcard_reexport": is_wildcard_reexport,
                "symbols": symbols,
                "raw_statement": raw_stmt,
            })

    if not matched_candidates:
        return no_import

    # Prefer static non-type-only imports first, then static imports with symbols, then any static, then dynamic.
    def _cand_rank(cand: Dict[str, Any]) -> Tuple[int, int, int]:
        return (
            1 if cand["is_dynamic"] else 0,
            1 if cand["is_already_type_only"] else 0,
            0 if cand["symbols"] else 1,
        )

    matched_candidates.sort(key=_cand_rank)
    best = dict(matched_candidates[0])
    # If multiple static imports exist, combine symbols while keeping runtime status if any candidate is non-type-only.
    combined_syms: List[str] = []
    for cand in matched_candidates:
        for sym in cand["symbols"]:
            if sym not in combined_syms:
                combined_syms.append(sym)
    best["symbols"] = combined_syms
    static_cands = [c for c in matched_candidates if not c["is_dynamic"]]
    if static_cands:
        best["is_already_type_only"] = all(c["is_already_type_only"] for c in static_cands)
        best["is_type_only"] = all(c["is_type_only"] for c in static_cands)
    return best


def _suggest_leaf_module(target: str, symbols: List[str], is_type_only: bool) -> str:
    """Generate a clean, deterministic path for extracting shared code."""
    directory = os.path.dirname(target)
    basename = os.path.splitext(os.path.basename(target))[0]
    if basename.endswith(".service"):
        prefix = basename[:-8]
    elif basename.endswith(".component"):
        prefix = basename[:-10]
    else:
        prefix = basename

    ext = os.path.splitext(target)[1] or ".ts"
    suffix = "types" if is_type_only or any("type" in s.lower() or "interface" in s.lower() for s in symbols) else "shared"
    if ext == ".rs":
        if basename == "mod":
            new_filename = "shared_types.rs" if suffix == "types" else "shared.rs"
        else:
            clean_prefix = re.sub(r"[^A-Za-z0-9_]", "_", prefix).strip("_") or "module"
            new_filename = f"{clean_prefix}_{suffix}.rs"
    elif ext == ".kt":
        clean_prefix = re.sub(r"[^A-Za-z0-9]", "", prefix) or "Module"
        new_filename = f"{clean_prefix}{suffix.capitalize()}.kt"
    else:
        sep = "_" if ext == ".py" else "."
        new_filename = f"{prefix}{sep}{suffix}{ext}"
    return os.path.join(directory, new_filename).replace("\\", "/")


def evaluate_edge_cut(
    source: Any,
    target: Any,
    shared_graph: Optional[Dict[str, Any]] = None,
    cycle_overlap_count: int = 1,
) -> Dict[str, Any]:
    """
    Evaluate the cost, feasibility, and prescriptive strategy for cutting an edge.
    Supports both (source, target, shared_graph) and (shared_graph, source, target).
    Lower cut_cost means easier, cleaner, and more recommended to sever.
    """
    if isinstance(source, dict) and isinstance(target, str):
        graph = source
        actual_source = target
        actual_target = str(shared_graph) if shared_graph else ""
        return _evaluate_edge_cut_impl(actual_source, actual_target, graph, cycle_overlap_count)

    return _evaluate_edge_cut_impl(str(source), str(target), shared_graph or {}, cycle_overlap_count)


def _evaluate_edge_cut_impl(
    source: str,
    target: str,
    shared_graph: Dict[str, Any],
    cycle_overlap_count: int = 1,
    parse_cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    node_metadata = shared_graph.get("node_metadata", {})
    file_map = shared_graph.get("file_map") or shared_graph.get("file_contents") or {}
    type_shapes = shared_graph.get("type_shapes", {})

    u_meta = node_metadata.get(source, {})
    v_meta = node_metadata.get(target, {})

    u_type = u_meta.get("type", "Other")
    v_type = v_meta.get("type", "Other")
    u_rank = LAYER_RANK.get(u_type, 2)
    v_rank = LAYER_RANK.get(v_type, 2)

    u_is_ep = u_meta.get("is_entrypoint", False)
    v_is_ep = v_meta.get("is_entrypoint", False)

    target_fan_in = v_meta.get("fan_in", 1)
    source_fan_out = u_meta.get("fan_out", 1)

    import_info = _inspect_edge_import(source, target, file_map, type_shapes, parse_cache=parse_cache)
    edge_natures = shared_graph.get("edge_natures", {})
    edge_nature = edge_natures.get(f"{source} -> {target}")
    is_already_type_only = bool(
        edge_nature == "type_only" or import_info.get("is_already_type_only", False)
    )
    if is_already_type_only:
        is_type_only = True
    else:
        is_type_only = bool(import_info.get("is_type_only", False))
    is_dynamic = import_info.get("is_dynamic", False)
    is_wildcard_reexport = bool(import_info.get("is_wildcard_reexport", False))
    symbols = import_info.get("symbols", [])

    # Base cost calibration
    cost = 60

    # Multi-cycle leverage discount: breaking this edge eliminates multiple cycles
    if cycle_overlap_count > 1:
        cost -= min(30, (cycle_overlap_count - 1) * 15)

    # Fan-in adjustment: lower target fan-in = more isolated = easier to refactor
    # Only discount if this is a static import with concrete symbols or type-only.
    # Dynamic imports and wildcard barrel re-exports must not receive a fan-in discount.
    if target_fan_in <= 1:
        if not is_dynamic and not is_wildcard_reexport and (symbols or is_type_only):
            cost -= 15
        elif is_dynamic:
            cost += 25
    elif target_fan_in >= 5:
        cost += 15

    # Concrete symbols discount: having specific identified symbols to extract
    # makes extract_shared_module concrete, targeted, and lower risk.
    if symbols and not is_dynamic and not is_wildcard_reexport:
        cost -= 15

    # Strategy determination
    strategy = "extract_shared_module"
    estimated_effort = "medium"
    rationale = ""
    actionable_steps: List[str] = []
    suggested_leaf = _suggest_leaf_module(target, symbols, is_type_only)

    if v_is_ep:
        # Internal file imports entrypoint -> severe anti-pattern, top priority to break
        strategy = "remove_entrypoint_dependency"
        estimated_effort = "low"
        cost -= 35
        rationale = (
            f"Internal module '{source}' imports entrypoint '{target}', violating "
            f"inversion of control. Entrypoints should orchestrate modules, not be imported."
        )
        actionable_steps = [
            f"Remove import of entrypoint '{target}' from '{source}'.",
            f"Move any reusable logic or configuration from '{target}' into a dedicated service or configuration file.",
            f"Pass runtime parameters or instances into '{source}' at startup.",
        ]
    elif is_already_type_only:
        # Already compiler-elided (import type / export type / inline type / TYPE_CHECKING):
        # zero runtime circularity; offer optional extract_types_leaf cleanup without
        # advising another conversion to `import type`.
        strategy = "extract_types_leaf"
        estimated_effort = "trivial"
        cost -= 35
        sym_str = f" ({', '.join(symbols)})" if symbols else ""
        rationale = (
            f"Edge from '{source}' to '{target}'{sym_str} is already compiler-elided "
            f"(type-only / TYPE_CHECKING) with zero runtime circularity. Optionally "
            f"extract shared type definitions into a leaf module for cleaner layering."
        )
        actionable_steps = [
            f"No runtime cut required: '{source}' already imports '{target}' as type-only.",
            f"Optional cleanup: extract shared type definitions{sym_str} from '{target}' into '{suggested_leaf}' and update type-only imports.",
        ]
    elif is_type_only:
        # Unannotated runtime import that only references type definitions -> convert to `import type`
        strategy = "type_only_import"
        estimated_effort = "trivial"
        cost -= 35
        sym_str = f" ({', '.join(symbols)})" if symbols else ""
        rationale = (
            f"File '{source}' only references type definitions{sym_str} from '{target}'. "
            f"Converting to 'import type' or isolated declarations eliminates runtime circularity."
        )
        actionable_steps = [
            f"Change import in '{source}' to: import type {{ {', '.join(symbols) if symbols else '...'} }} from '{target}'.",
            f"Ensure TypeScript compiler option 'isolatedDeclarations' or 'verbatimModuleSyntax' is satisfied.",
        ]
    elif is_dynamic:
        # Dynamic import (e.g. await import()) — already deferred at runtime
        strategy = "dynamic_dispatch"
        estimated_effort = "low"
        cost += 20
        rationale = (
            f"Edge from '{source}' to '{target}' is a dynamic import (await import()). "
            f"It does not cause module load-time deadlock. To remove topological circularity, "
            f"inject '{target}' via a runtime registry, factory, or callback, or extract "
            f"the static definitions imported by '{target}' on the reverse edge."
        )
        actionable_steps = [
            f"Pass '{target}' instance or factory into '{source}' at initialization rather than using inline dynamic import.",
            f"Alternatively, check if '{target}' statically imports definitions from '{source}' and extract those into a shared leaf module.",
        ]
    elif is_wildcard_reexport:
        # Barrel wildcard re-export (`export * from './target'`) — cannot extract `*`
        strategy = "barrel_reexport"
        estimated_effort = "medium"
        cost += 15
        rationale = (
            f"Module '{source}' is a barrel wildcard re-export ('export *') of '{target}'. "
            f"Internal modules importing from barrel '{source}' pull in '{target}' and create "
            f"a cycle when '{target}' depends back on those modules."
        )
        actionable_steps = [
            f"Update internal callers that import from barrel '{source}' to import directly from the specific submodule they need (or from '{target}').",
            f"Alternatively, replace 'export *' in '{source}' or extract the reverse-imported symbols out of '{target}' into a leaf module.",
        ]
    elif u_rank < v_rank:
        # Layer violation: lower layer imports higher layer (e.g. Helper -> Service or Service -> Component)
        strategy = "architectural_inversion"
        estimated_effort = "low"
        cost -= 25
        rationale = (
            f"Architectural layer violation: {u_type} '{source}' (layer {u_rank}) imports "
            f"higher-level {v_type} '{target}' (layer {v_rank}). Dependencies should flow downward."
        )
        actionable_steps = [
            f"Refactor '{source}' to remove the direct upward dependency on '{target}'.",
            f"Extract shared data structures or callbacks so '{source}' operates on primitives or interfaces.",
            f"Pass '{target}' or its methods to '{source}' via dependency injection or function arguments.",
        ]
    elif u_type == "Service" and v_type == "Service":
        # Mutual service dependency -> Dependency Injection or Interface Segregation
        strategy = "dependency_injection"
        estimated_effort = "medium"
        cost -= 10
        rationale = (
            f"Co-dependent services '{source}' and '{target}' cause module loading coupling. "
            f"Inject the dependency dynamically or abstract behind an interface token."
        )
        actionable_steps = [
            f"Inject '{target}' into '{source}' via constructor parameter instead of static module import.",
            f"Alternatively, introduce a separate event emitter, observer, or state store to decouple their lifecycles.",
        ]
    else:
        # General module circularity -> Extract shared leaf module
        strategy = "extract_shared_module"
        estimated_effort = "medium"
        sym_disp = f" ({', '.join(symbols[:3])})" if symbols else ""
        rationale = (
            f"Extract shared symbols{sym_disp} from '{target}' into an independent leaf module "
            f"to sever the backward edge from '{source}' (target fan-in: {target_fan_in})."
        )
        actionable_steps = [
            f"Create a new leaf module at '{suggested_leaf}'.",
            f"Move shared definitions from '{target}' into '{suggested_leaf}'.",
            f"Update imports in '{source}' and '{target}' to reference '{suggested_leaf}'.",
        ]

    cost = max(5, min(100, cost))

    return {
        "source": source,
        "target": target,
        "cut_cost": cost,
        "strategy": strategy,
        "estimated_effort": estimated_effort,
        "rationale": rationale,
        "actionable_steps": actionable_steps,
        "symbols_involved": symbols,
        "is_type_only": is_type_only,
        "is_already_type_only": is_already_type_only,
        "is_dynamic": is_dynamic,
        "is_wildcard_reexport": is_wildcard_reexport,
        "target_fan_in": target_fan_in,
        "source_fan_out": source_fan_out,
        "suggested_leaf": suggested_leaf,
    }


def compute_cycle_break_advisory(
    shared_graph: Dict[str, Any],
    detected_cycles: List[List[str]],
) -> Dict[str, Any]:
    """
    Computes prescriptive cycle-break advisories and an optimal Feedback Arc Set (FAS)
    for all detected directed cycles in the graph.

    Args:
        shared_graph: The shared graph dictionary.
        detected_cycles: List of normalized cycle paths (e.g. [a, b, c, a]).

    Returns:
        Dictionary containing:
        - cycle_break_plan: global minimal feedback arc set to resolve all cycles
        - advisories_by_cycle: breakdown for each cycle
    """
    if not detected_cycles:
        return {
            "cycle_break_plan": {
                "total_cycles": 0,
                "runtime_cycles": 0,
                "type_only_cycles": 0,
                "total_cuts_required": 0,
                "all_cycles_resolvable": True,
                "recommended_cuts": [],
                "optional_type_only_cuts": [],
            },
            "advisories_by_cycle": [],
        }

    # Extract all edges per cycle
    # Cycle format: [n0, n1, ..., nk-1, n0]
    cycle_edges_list: List[List[Tuple[str, str]]] = []
    edge_to_cycles: Dict[Tuple[str, str], Set[int]] = {}

    for c_idx, cycle in enumerate(detected_cycles):
        edges_in_cycle: List[Tuple[str, str]] = []
        n = len(cycle)
        # If cycle ends with start node, length is n - 1 edges
        edge_count = n - 1 if cycle[0] == cycle[-1] and n > 1 else n
        for i in range(edge_count):
            u = cycle[i]
            v = cycle[(i + 1) % n] if cycle[0] != cycle[-1] else cycle[i + 1]
            edge = (u, v)
            edges_in_cycle.append(edge)
            edge_to_cycles.setdefault(edge, set()).add(c_idx)
        cycle_edges_list.append(edges_in_cycle)

    # Evaluate each unique cycle edge once with shared per-file parse cache
    parse_cache: Dict[str, Any] = {}
    edge_evaluations: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for edge, cycle_indices in edge_to_cycles.items():
        eval_result = _evaluate_edge_cut_impl(
            edge[0],
            edge[1],
            shared_graph,
            cycle_overlap_count=len(cycle_indices),
            parse_cache=parse_cache,
        )
        eval_result["cycles_eliminated_count"] = len(cycle_indices)
        eval_result["cycle_indices"] = sorted(cycle_indices)
        edge_evaluations[edge] = eval_result

    # Partition cycles into runtime cycles (requiring actual cuts) vs compiler-elided
    # type-only cycles (zero runtime circularity; optional extract_types_leaf cleanup only).
    edge_natures = shared_graph.get("edge_natures", {})
    cycle_is_type_only: List[bool] = [
        bool(edges) and any(
            edge_natures.get(f"{u} -> {v}") == "type_only"
            or edge_evaluations[(u, v)].get("is_already_type_only", False)
            for (u, v) in edges
        )
        for edges in cycle_edges_list
    ]
    runtime_cycle_indices = {
        idx for idx, is_to in enumerate(cycle_is_type_only) if not is_to
    }
    type_only_cycle_indices = {
        idx for idx, is_to in enumerate(cycle_is_type_only) if is_to
    }

    def _greedy_fas_cuts(target_cycles: Set[int]) -> Tuple[List[Dict[str, Any]], Set[int]]:
        unresolved = set(target_cycles)
        cuts: List[Dict[str, Any]] = []
        active_edges: List[Tuple[str, str]] = sorted(
            (e for e, cids in edge_to_cycles.items() if cids & unresolved),
            key=lambda e: (e[0], e[1]),
        )
        while unresolved and active_edges:
            best_edge = None
            best_score = -1.0
            best_cycles_covered: Set[int] = set()
            next_active: List[Tuple[str, str]] = []

            for edge in active_edges:
                cycles_covered = edge_to_cycles[edge] & unresolved
                if not cycles_covered:
                    continue
                next_active.append(edge)

                cost = edge_evaluations[edge]["cut_cost"]
                score = len(cycles_covered) / float(cost)
                if (
                    score > best_score
                    or (abs(score - best_score) < 1e-6 and len(cycles_covered) > len(best_cycles_covered))
                ):
                    best_score = score
                    best_edge = edge
                    best_cycles_covered = cycles_covered

            if best_edge is None:
                break

            edge_eval = edge_evaluations[best_edge]
            cuts.append({
                "source": best_edge[0],
                "target": best_edge[1],
                "cycles_eliminated": len(best_cycles_covered),
                "strategy": edge_eval["strategy"],
                "estimated_effort": edge_eval["estimated_effort"],
                "cut_cost": edge_eval["cut_cost"],
                "rationale": edge_eval["rationale"],
                "actionable_steps": edge_eval["actionable_steps"],
                "symbols_involved": edge_eval["symbols_involved"],
                "suggested_leaf": edge_eval.get("suggested_leaf"),
                "is_dynamic": edge_eval.get("is_dynamic", False),
                "is_already_type_only": edge_eval.get("is_already_type_only", False),
            })

            unresolved -= best_cycles_covered
            active_edges = [e for e in next_active if e != best_edge]
        return cuts, unresolved

    # Feedback Arc Set (FAS) Solver — run strictly on runtime cycles for required cuts,
    # and separately on compiler-elided type-only cycles for optional type-leaf cleanup.
    recommended_cuts, unresolved_runtime_cycles = _greedy_fas_cuts(runtime_cycle_indices)
    optional_type_only_cuts, _ = _greedy_fas_cuts(type_only_cycle_indices)

    # Build per-cycle advisories
    advisories_by_cycle: List[Dict[str, Any]] = []
    for c_idx, cycle in enumerate(detected_cycles):
        edges = cycle_edges_list[c_idx]
        is_to_cycle = cycle_is_type_only[c_idx]
        candidates = [edge_evaluations[e] for e in edges]
        # Sort candidates in this cycle by lowest cut_cost
        candidates.sort(key=lambda c: (c["cut_cost"], -c["cycles_eliminated_count"], c["source"], c["target"]))

        top_choice = candidates[0] if candidates else None

        advisories_by_cycle.append({
            "cycle_index": c_idx,
            "cycle": cycle,
            "cycle_length": len(cycle) - 1 if cycle[0] == cycle[-1] else len(cycle),
            "is_type_only": is_to_cycle,
            "cycle_nature": "type_only" if is_to_cycle else "runtime",
            "recommended_cut": {
                "source": top_choice["source"],
                "target": top_choice["target"],
                "strategy": top_choice["strategy"],
                "estimated_effort": top_choice["estimated_effort"],
                "cut_cost": top_choice["cut_cost"],
                "rationale": top_choice["rationale"],
                "actionable_steps": top_choice["actionable_steps"],
                "symbols_involved": top_choice["symbols_involved"],
                "suggested_leaf": top_choice.get("suggested_leaf"),
                "is_dynamic": top_choice.get("is_dynamic", False),
                "is_already_type_only": top_choice.get("is_already_type_only", False),
            } if top_choice else None,
            "candidate_edges": [
                {
                    "source": c["source"],
                    "target": c["target"],
                    "cut_cost": c["cut_cost"],
                    "strategy": c["strategy"],
                    "estimated_effort": c["estimated_effort"],
                    "cycles_broken": c["cycles_eliminated_count"],
                    "rationale": c["rationale"],
                    "is_dynamic": c.get("is_dynamic", False),
                    "is_already_type_only": c.get("is_already_type_only", False),
                }
                for c in candidates
            ],
        })

    return {
        "cycle_break_plan": {
            "total_cycles": len(detected_cycles),
            "runtime_cycles": len(runtime_cycle_indices),
            "type_only_cycles": len(type_only_cycle_indices),
            "total_cuts_required": len(recommended_cuts),
            "all_cycles_resolvable": len(unresolved_runtime_cycles) == 0,
            "recommended_cuts": recommended_cuts,
            "optional_type_only_cuts": optional_type_only_cuts,
        },
        "advisories_by_cycle": advisories_by_cycle,
    }


DEFAULT_MAX_CYCLES_PER_SCC = 64
DEFAULT_MAX_TOTAL_CYCLES = 256
_DENSE_SCC_EXCESS_EDGE_THRESHOLD = 6


def _non_cyclic_rust_mod_edges(shared_graph: Dict[str, Any]) -> Set[Tuple[str, str]]:
    """Return Rust structural module-mount edges excluded from directed cycle detection.

    Includes `#[cfg(test)] mod <child>;` and pure `mod <child>;` declarations that
    carry no symbol-level `use` or inline `<child>::` path reference.
    """
    excluded: Set[Tuple[str, str]] = set()
    for ed in shared_graph.get("edge_details") or ():
        if not isinstance(ed, dict):
            continue
        usages = set(ed.get("semantic_usages") or ())
        if "cfg_test_mod" in usages or usages == {"rust_mod"}:
            excluded.add((str(ed.get("source", "")), str(ed.get("target", ""))))
    return excluded


def _build_directed_adjacency(
    shared_graph: Dict[str, Any],
    excluded_edges: Optional[Set[Tuple[str, str]]] = None,
    excluded_edge_natures: Optional[Set[str]] = None,
) -> Tuple[List[str], Dict[str, List[str]], Set[str]]:
    """Build deduplicated, deterministically sorted adjacency lists excluding non-cyclic structural edges and specified edge natures."""
    skip_natures = excluded_edge_natures if excluded_edge_natures is not None else {"same_package"}
    raw_vertices: List[str] = [str(v) for v in shared_graph.get("vertices", [])]
    edges = shared_graph.get("edges")
    edge_natures = shared_graph.get("edge_natures", {})
    non_cyclic_mod_edges = _non_cyclic_rust_mod_edges(shared_graph)

    adj_sets: Dict[str, Set[str]] = {v: set() for v in raw_vertices}
    self_loops: Set[str] = set()

    if edges is not None:
        for edge in edges:
            if len(edge) != 2:
                continue
            src, tgt = str(edge[0]), str(edge[1])
            if excluded_edges and (src, tgt) in excluded_edges:
                continue
            if edge_natures.get(f"{src} -> {tgt}", "runtime") in skip_natures:
                continue
            if (src, tgt) in non_cyclic_mod_edges:
                continue
            adj_sets.setdefault(src, set()).add(tgt)
            adj_sets.setdefault(tgt, set())
            if src == tgt:
                self_loops.add(src)
    else:
        raw_adj = shared_graph.get("adjacency", {}) or {}
        for src_raw, targets in raw_adj.items():
            src = str(src_raw)
            adj_sets.setdefault(src, set())
            for tgt_raw in targets:
                tgt = str(tgt_raw)
                if excluded_edges and (src, tgt) in excluded_edges:
                    continue
                if edge_natures.get(f"{src} -> {tgt}", "runtime") in skip_natures:
                    continue
                if (src, tgt) in non_cyclic_mod_edges:
                    continue
                adj_sets[src].add(tgt)
                adj_sets.setdefault(tgt, set())
                if src == tgt:
                    self_loops.add(src)

    vertices = sorted(adj_sets.keys())
    adj: Dict[str, List[str]] = {v: sorted(adj_sets[v]) for v in vertices}
    return vertices, adj, self_loops


def find_cyclic_sccs(
    vertices: Sequence[str],
    adj: Dict[str, List[str]],
    self_loops: Optional[Set[str]] = None,
) -> List[List[str]]:
    """Iterative Tarjan SCC decomposition (O(V + E), zero Python recursion limit).

    Returns only cyclic SCCs (size > 1, or size == 1 with a self-loop), sorted
    deterministically by (-len(component), component[0]).
    """
    inferred_loops = set(self_loops) if self_loops is not None else {
        u for u, nbrs in adj.items() if u in nbrs
    }
    ordered_vertices = sorted(set(vertices) | set(adj.keys()))

    index_counter = 0
    indices: Dict[str, int] = {}
    lowlink: Dict[str, int] = {}
    on_stack: Set[str] = set()
    tarjan_stack: List[str] = []
    result: List[List[str]] = []

    for start in ordered_vertices:
        if start in indices:
            continue
        # Call stack frame: [node, neighbor_idx]
        call_stack: List[List[Any]] = [[start, 0]]
        indices[start] = index_counter
        lowlink[start] = index_counter
        index_counter += 1
        tarjan_stack.append(start)
        on_stack.add(start)

        while call_stack:
            frame = call_stack[-1]
            v = frame[0]
            nbr_idx = frame[1]
            nbrs = adj.get(v, ())

            if nbr_idx < len(nbrs):
                w = nbrs[nbr_idx]
                frame[1] = nbr_idx + 1
                if w not in indices:
                    indices[w] = index_counter
                    lowlink[w] = index_counter
                    index_counter += 1
                    tarjan_stack.append(w)
                    on_stack.add(w)
                    call_stack.append([w, 0])
                elif w in on_stack:
                    if indices[w] < lowlink[v]:
                        lowlink[v] = indices[w]
            else:
                call_stack.pop()
                if call_stack:
                    parent = call_stack[-1][0]
                    if lowlink[v] < lowlink[parent]:
                        lowlink[parent] = lowlink[v]
                if lowlink[v] == indices[v]:
                    component: List[str] = []
                    while tarjan_stack:
                        cur = tarjan_stack.pop()
                        on_stack.remove(cur)
                        component.append(cur)
                        if cur == v:
                            break
                    component.sort()
                    if len(component) > 1 or (component and component[0] in inferred_loops):
                        result.append(component)

    result.sort(key=lambda comp: (-len(comp), comp[0] if comp else ""))
    return result


def _canonicalize_cycle_core(core: Sequence[str]) -> Tuple[Tuple[str, ...], List[str]]:
    """Rotate cycle core so the lexicographically smallest node comes first."""
    min_node = min(core)
    min_idx = core.index(min_node)
    rotated = tuple(core[min_idx:]) + tuple(core[:min_idx])
    return rotated, list(rotated) + [rotated[0]]


def _seed_shortest_scc_cycles(
    scc_nodes: List[str],
    scc_adj: Dict[str, List[str]],
    scc_adj_sets: Dict[str, Set[str]],
    budget: int,
    seen_cores: Set[Tuple[str, ...]],
) -> List[List[str]]:
    """Prioritize shortest actionable cycles (2-cycles, then shortest BFS witness per node) on dense SCCs."""
    seeded: List[List[str]] = []
    covered_nodes: Set[str] = set()

    # 1. Harvest all direct 2-cycles (u <-> v) in O(E_scc)
    for u in scc_nodes:
        if len(seeded) >= budget:
            return seeded
        for v in scc_adj[u]:
            if u < v and u in scc_adj_sets[v]:
                core_key = (u, v)
                if core_key not in seen_cores:
                    seen_cores.add(core_key)
                    seeded.append([u, v, u])
                    covered_nodes.add(u)
                    covered_nodes.add(v)
                    if len(seeded) >= budget:
                        return seeded

    # 2. Shortest BFS cycle witness for any SCC node not yet covered
    for start in scc_nodes:
        if len(seeded) >= budget:
            break
        if start in covered_nodes:
            continue
        parent: Dict[str, Optional[str]] = {}
        q: deque[str] = deque()
        for nbr in scc_adj[start]:
            if nbr == start:
                continue
            if nbr not in parent:
                parent[nbr] = start
                q.append(nbr)
        found_core: Optional[List[str]] = None
        while q and found_core is None:
            cur = q.popleft()
            for nxt in scc_adj[cur]:
                if nxt == start:
                    path: List[str] = [cur]
                    p = parent.get(cur)
                    while p is not None and p != start:
                        path.append(p)
                        p = parent.get(p)
                    path.append(start)
                    path.reverse()
                    found_core = path
                    break
                if nxt not in parent and nxt != start:
                    parent[nxt] = cur
                    q.append(nxt)
        if found_core:
            core_key, closed = _canonicalize_cycle_core(found_core)
            if core_key not in seen_cores:
                seen_cores.add(core_key)
                seeded.append(closed)
                covered_nodes.update(core_key)

    return seeded


def _enumerate_scc_elementary_cycles(
    scc_nodes: List[str],
    adj: Dict[str, List[str]],
    self_loops: Set[str],
    max_cycles: int,
) -> Tuple[List[List[str]], bool, int]:
    """Iterative Johnson elementary cycle enumeration inside a single cyclic SCC.

    Guarantees:
    - Zero Python recursion (safe on 1,000+ node rings).
    - Complete elementary cycle extraction whenever count <= max_cycles.
    - Shortest-cycle seeding on dense SCCs so bounded results stay compact and actionable.
    """
    scc_set = set(scc_nodes)
    scc_adj: Dict[str, List[str]] = {}
    scc_adj_sets: Dict[str, Set[str]] = {}
    scc_edge_count = 0
    for u in scc_nodes:
        nbrs = [v for v in adj.get(u, ()) if v in scc_set and v != u]
        scc_adj[u] = nbrs
        scc_adj_sets[u] = set(nbrs)
        scc_edge_count += len(nbrs)

    seen_cores: Set[Tuple[str, ...]] = set()
    found_cycles: List[List[str]] = []
    truncated = False

    # Self-loops inside this SCC
    for u in scc_nodes:
        if u in self_loops:
            scc_edge_count += 1
            if len(found_cycles) < max_cycles:
                seen_cores.add((u,))
                found_cycles.append([u, u])
            else:
                truncated = True

    if len(scc_nodes) < 2 or max_cycles <= 0:
        return found_cycles, truncated, scc_edge_count

    non_loop_edges = sum(len(v) for v in scc_adj.values())
    # Pure directed ring fast-path: in an SCC with |E| == |V|, every node has out-degree 1
    # so there is mathematically exactly ONE elementary cycle (O(|V|) instead of O(|V|^2)).
    if non_loop_edges == len(scc_nodes):
        ring_core: List[str] = []
        cur = scc_nodes[0]
        visited_ring: Set[str] = set()
        while cur not in visited_ring:
            visited_ring.add(cur)
            ring_core.append(cur)
            cur = scc_adj[cur][0]
        core_key = tuple(ring_core)
        if core_key not in seen_cores:
            if len(found_cycles) < max_cycles:
                seen_cores.add(core_key)
                found_cycles.append(ring_core + [ring_core[0]])
            else:
                truncated = True
        return found_cycles, truncated, scc_edge_count

    # On dense SCCs (high cyclomatic excess), seed shortest cycles first so caps
    # prioritize 2-cycles & minimal witnesses over deep Hamiltonian paths.
    if non_loop_edges > len(scc_nodes) + _DENSE_SCC_EXCESS_EDGE_THRESHOLD and len(found_cycles) < max_cycles:
        seeded = _seed_shortest_scc_cycles(
            scc_nodes,
            scc_adj,
            scc_adj_sets,
            max_cycles - len(found_cycles),
            seen_cores,
        )
        found_cycles.extend(seeded)

    # Iterative Johnson (1975) with SCC-decomposition worklist:
    # After enumerating cycles rooted at least-vertex `s` in a cyclic component,
    # decompose `component \ {s}` into its remaining cyclic sub-SCCs so acyclic
    # tails/chords are pruned immediately in O(V + E) instead of O(V^2).
    worklist: List[List[str]] = [list(scc_nodes)]
    while worklist:
        # Always process the component with the smallest minimum vertex first
        worklist.sort(key=lambda comp: comp[0])
        comp = worklist.pop(0)
        if len(comp) < 2:
            continue
        s = comp[0]
        sub_scc = set(comp)
        sub_adj: Dict[str, List[str]] = {
            u: [v for v in scc_adj[u] if v in sub_scc]
            for u in comp
        }

        blocked: Set[str] = {s}
        block_map: Dict[str, Set[str]] = {}
        path: List[str] = [s]
        # Stack frame: [node, neighbor_idx, found_cycle_in_subtree]
        frames: List[List[Any]] = [[s, 0, False]]

        def _unblock(node: str) -> None:
            ub_stack = [node]
            while ub_stack:
                cur_u = ub_stack.pop()
                if cur_u in blocked:
                    blocked.remove(cur_u)
                    deps = block_map.pop(cur_u, None)
                    if deps:
                        ub_stack.extend(deps)

        while frames:
            frame = frames[-1]
            v = frame[0]
            nbr_idx = frame[1]
            nbrs = sub_adj[v]

            if nbr_idx < len(nbrs):
                w = nbrs[nbr_idx]
                frame[1] = nbr_idx + 1
                if w == s:
                    core_key = tuple(path)
                    if core_key not in seen_cores:
                        if len(found_cycles) >= max_cycles:
                            truncated = True
                            frames.clear()
                            break
                        seen_cores.add(core_key)
                        found_cycles.append(list(core_key) + [s])
                    frame[2] = True
                elif w not in blocked:
                    blocked.add(w)
                    path.append(w)
                    frames.append([w, 0, False])
            else:
                frames.pop()
                path.pop()
                if frame[2]:
                    _unblock(v)
                    if frames:
                        frames[-1][2] = True
                else:
                    for w in nbrs:
                        block_map.setdefault(w, set()).add(v)

        if truncated:
            break

        # Remove `s` and push any remaining cyclic sub-SCCs of `comp \ {s}`
        rem_nodes = comp[1:]
        if len(rem_nodes) >= 2:
            rem_set = set(rem_nodes)
            rem_adj: Dict[str, List[str]] = {
                u: [v for v in sub_adj[u] if v in rem_set]
                for u in rem_nodes
            }
            sub_comps = find_cyclic_sccs(rem_nodes, rem_adj, self_loops=set())
            for sc in sub_comps:
                if len(sc) >= 2:
                    worklist.append(sc)

    return found_cycles, truncated, scc_edge_count


def find_directed_cycles_with_metadata(
    shared_graph: Dict[str, Any],
    *,
    max_cycles_per_scc: int = DEFAULT_MAX_CYCLES_PER_SCC,
    max_total_cycles: int = DEFAULT_MAX_TOTAL_CYCLES,
) -> Dict[str, Any]:
    """Detect directed elementary cycles using Iterative Tarjan SCC + Bounded Iterative Johnson.

    Returns:
      - cycles: deterministically sorted list of canonical closed cycle paths [n0, ..., n0]
      - cyclic_sccs: per-SCC metadata (node_count, edge_count, truncated, sample_nodes)
      - files_in_cycles: exact sorted list of all vertices belonging to any cyclic SCC
      - truncated: True iff any SCC or global cycle budget cap was hit
    """
    vertices, adj, self_loops = _build_directed_adjacency(shared_graph)
    cyclic_sccs = find_cyclic_sccs(vertices, adj, self_loops)

    if not cyclic_sccs:
        return {
            "cycles": [],
            "cyclic_sccs": [],
            "files_in_cycles": [],
            "truncated": False,
        }

    all_cycles: List[List[str]] = []
    scc_summaries: List[Dict[str, Any]] = []
    files_in_cycles_set: Set[str] = set()
    any_truncated = False

    for comp in cyclic_sccs:
        files_in_cycles_set.update(comp)
        remaining = max_total_cycles - len(all_cycles)
        if remaining <= 0:
            any_truncated = True
            comp_set = set(comp)
            edge_cnt = sum(
                1 for u in comp for v in adj.get(u, ()) if v in comp_set
            )
            scc_summaries.append({
                "node_count": len(comp),
                "edge_count": edge_cnt,
                "truncated": True,
                "sample_nodes": comp[:5],
            })
            continue

        cap = min(max_cycles_per_scc, remaining)
        comp_cycles, comp_truncated, edge_cnt = _enumerate_scc_elementary_cycles(
            comp, adj, self_loops, max_cycles=cap,
        )
        all_cycles.extend(comp_cycles)
        if comp_truncated:
            any_truncated = True
        scc_summaries.append({
            "node_count": len(comp),
            "edge_count": edge_cnt,
            "truncated": comp_truncated,
            "sample_nodes": comp[:5],
        })

    # Canonical deterministic sort: shortest cycle first, then full tuple order
    all_cycles.sort(key=lambda cyc: (len(cyc) - 1, tuple(cyc[:-1])))
    return {
        "cycles": all_cycles,
        "cyclic_sccs": scc_summaries,
        "files_in_cycles": sorted(files_in_cycles_set),
        "truncated": any_truncated,
    }


def _find_directed_cycles_from_graph(shared_graph: Dict[str, Any]) -> List[List[str]]:
    """Find deduplicated directed cycles in shared_graph using Iterative Tarjan + Johnson."""
    return find_directed_cycles_with_metadata(shared_graph)["cycles"]


def analyze_cycle_breaks(
    shared_graph: Dict[str, Any],
    cycles: Optional[List[List[str]]] = None,
    *,
    cycle_finder: Optional[Callable[[Dict[str, Any]], List[List[str]]]] = None,
) -> Dict[str, Any]:
    """
    Public entrypoint to analyze cycles and generate cycle-break advisories.
    If cycles are not provided, runs DFS cycle detection on shared_graph
    (or uses an injected cycle_finder).
    """
    if cycles is None:
        finder = cycle_finder if cycle_finder is not None else _find_directed_cycles_from_graph
        cycles = finder(shared_graph)

    advisory_data = compute_cycle_break_advisory(shared_graph, cycles)

    return {
        "analyzer": "topo.cycle_break",
        "summary": advisory_data["cycle_break_plan"],
        "advisories": advisory_data["advisories_by_cycle"],
    }
