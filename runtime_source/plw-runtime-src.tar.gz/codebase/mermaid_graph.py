"""
Mermaid Architecture & Dependency Diagram Generator — Codebase Topology Domain
Schema Version: 1.0.0-mermaid-graph

Extracted from hott_kernel.py to honor Single Responsibility (SRP) and
Dependency Inversion (DIP): diagram rendering accepts injectable graph,
orientation, outline, and impact providers so it can run deterministically
in tests or against any SharedGraph backend.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import os
import shlex
from typing import Any, Callable, Dict, List, Optional


MERMAID_DIRECTIONS = ("LR", "TD", "TB", "RL", "BT")
MERMAID_DEPTH_NAMES = {
    1: "subsystem_overview",
    2: "module_dependency_flow",
    3: "file_architecture_graph",
    4: "file_micro_neighborhood",
}


def mermaid_escape(text: Any) -> str:
    """Sanitize a string for safe inclusion inside a Mermaid ["..."] node/edge label."""
    s = str(text or "")
    s = s.replace("\\", "/")
    s = s.replace('"', "'").replace("`", "'")
    s = s.replace("<", "‹").replace(">", "›")
    s = s.replace("{", "(").replace("}", ")")
    return s


def mermaid_build_path_trie(rel_paths: List[str]) -> Dict[str, Any]:
    """Build directory children and direct-file counts for path-trie compaction."""
    dir_children: Dict[str, set] = defaultdict(set)
    dir_direct_files: Dict[str, int] = defaultdict(int)
    dir_total_files: Dict[str, int] = defaultdict(int)

    for rel in rel_paths:
        parts = [p for p in rel.split("/") if p]
        if not parts:
            continue
        dir_total_files[""] += 1
        if len(parts) == 1:
            dir_direct_files[""] += 1
            continue
        dirs = parts[:-1]
        cur = ""
        for seg in dirs:
            nxt = f"{cur}/{seg}" if cur else seg
            dir_children[cur].add(nxt)
            dir_total_files[nxt] += 1
            cur = nxt
        dir_direct_files[cur] += 1

    return {
        "dir_children": dir_children,
        "dir_direct_files": dir_direct_files,
        "dir_total_files": dir_total_files,
    }


def mermaid_is_passthrough_dir(cur: str, trie: Dict[str, Any]) -> bool:
    """Return True when `cur` has a single child directory that holds nearly all files."""
    children = trie["dir_children"].get(cur, ())
    if len(children) != 1:
        return False
    direct = trie["dir_direct_files"].get(cur, 0)
    total = trie["dir_total_files"].get(cur, 0)
    return direct == 0 or (direct <= 1 and total > 4)


def mermaid_compact_group(
    rel_path: str,
    trie: Dict[str, Any],
    *,
    target_splits: int = 1,
) -> str:
    """Derive a compacted directory group key by collapsing single-child pass-through dirs."""
    parts = [p for p in rel_path.split("/") if p]
    if len(parts) <= 1:
        return "(root)"
    dirs = parts[:-1]
    dir_children = trie["dir_children"]
    dir_direct_files = trie["dir_direct_files"]

    # Refine depth=1 for nested sub-roots like android/host/src/pi-extensions
    if target_splits == 1:
        if "pi-extensions" in dirs:
            pi_idx = dirs.index("pi-extensions")
            return "/".join(dirs[: pi_idx + 1])
        if len(dirs) >= 2 and dirs[0] == "android":
            if dirs[1] == "host" and len(dirs) >= 3 and dirs[2] == "src":
                return "android/host/src"
            return f"android/{dirs[1]}"

    splits_seen = 0
    cur = ""
    chosen = dirs[0]
    for idx, seg in enumerate(dirs):
        nxt = f"{cur}/{seg}" if cur else seg
        parent_branches = (
            len(dir_children.get(cur, ())) > 1
            or (dir_direct_files.get(cur, 0) > 0 and not mermaid_is_passthrough_dir(cur, trie))
        )
        is_boundary_seg = seg in ("pi-extensions", "packages", "apps", "crates", "plugins", "services")
        if (idx == 0 and not mermaid_is_passthrough_dir("", trie)) or parent_branches or is_boundary_seg:
            splits_seen += 1
        chosen = nxt
        cur = nxt
        if splits_seen >= target_splits:
            collapsed_steps = 0
            while mermaid_is_passthrough_dir(cur, trie):
                only_child = next(iter(dir_children[cur]))
                cur = only_child
                chosen = cur
                collapsed_steps += 1
            # If we collapsed a deep package chain (e.g. src/main/kotlin/io/jeph/pipkin)
            # during module-level grouping (target_splits >= 2), step one level into
            # the domain package under that namespace root if available.
            if target_splits >= 2 and collapsed_steps >= 2:
                rem_idx = len([p for p in cur.split("/") if p])
                if rem_idx < len(dirs):
                    chosen = f"{cur}/{dirs[rem_idx]}"
                    cur = chosen
            break

    return chosen


def mermaid_short_module_label(group_key: str) -> str:
    """Shorten long pass-through prefixes (e.g. src/main/kotlin/io/jeph/pipkin/...) for display."""
    markers = ("/kotlin/io/jeph/", "/java/io/jeph/", "/src/main/kotlin/", "/src/main/java/")
    for m in markers:
        if m in group_key:
            tail = group_key.split(m, 1)[1]
            prefix = group_key.split("/src/", 1)[0]
            if "/src/" in group_key:
                after_src = group_key.split("/src/", 1)[1]
                flavor = after_src.split("/", 1)[0]
                if flavor and flavor != "main":
                    prefix = f"{prefix}({flavor})" if prefix else flavor
            return f"{prefix}: {tail}" if prefix else tail
    return group_key


def _default_error(error_code: str, message: str, **details: Any) -> Dict[str, Any]:
    return {
        "error": error_code,
        "error_code": error_code,
        "message": message,
        **details,
    }


def _read_only_authority() -> Dict[str, bool]:
    return {
        "read_only": True,
        "selects_PLW_capability": False,
        "mutate_source": False,
        "execute_runtime": False,
        "commit_truth": False,
    }


def _render_depth_1_subsystems(
    *,
    scan_root: str,
    root_arg: str,
    graph_sig: Any,
    norm_dir: str,
    focus: Optional[str],
    focus_norm: str,
    max_nodes: int,
    include_tests: bool,
    inv: Dict[str, Any],
    vertices: List[str],
    raw_edges: List[Any],
    edge_natures: Dict[str, str],
    node_meta: Dict[str, Dict[str, Any]],
    active_abs: List[str],
    active_set: set,
    rel_by_abs: Dict[str, str],
    trie: Dict[str, Any],
    sccs: List[Dict[str, Any]],
) -> Dict[str, Any]:
    sub_by_rel = {
        rel: mermaid_compact_group(rel, trie, target_splits=1)
        for rel in rel_by_abs.values()
    }
    # If total subsystems is 1 and there are multiple files, split one level deeper
    if len(set(sub_by_rel.values())) == 1 and len(rel_by_abs) > 1:
        sub_by_rel = {
            rel: mermaid_compact_group(rel, trie, target_splits=2)
            for rel in rel_by_abs.values()
        }

    sub_files: Dict[str, List[str]] = defaultdict(list)
    sub_langs: Dict[str, Counter] = defaultdict(Counter)
    sub_entrypoints: Counter = Counter()
    sub_cycles: Counter = Counter()
    for v_abs, rel in rel_by_abs.items():
        grp = sub_by_rel[rel]
        sub_files[grp].append(rel)
        meta = node_meta.get(v_abs) or {}
        ext = os.path.splitext(rel)[1].lstrip(".") or str(meta.get("language") or "src")
        sub_langs[grp][ext] += 1
        if meta.get("is_entrypoint"):
            sub_entrypoints[grp] += 1
    for scc in sccs:
        members = [str(m).replace("\\", "/") for m in (scc.get("members") or [])]
        touched = {sub_by_rel[m] for m in members if m in sub_by_rel}
        for grp in touched:
            sub_cycles[grp] += 1

    internal_edges: Counter = Counter()
    cross_edges: Dict[tuple, Counter] = defaultdict(Counter)
    for u_abs, v_abs in raw_edges:
        if u_abs not in active_set or v_abs not in active_set:
            continue
        u_rel, v_rel = rel_by_abs[u_abs], rel_by_abs[v_abs]
        gu, gv = sub_by_rel[u_rel], sub_by_rel[v_rel]
        nat = edge_natures.get(f"{u_abs} -> {v_abs}", "runtime")
        if gu == gv:
            internal_edges[gu] += 1
        else:
            cross_edges[(gu, gv)][nat] += 1

    all_subsystems = sorted(
        sub_files.keys(),
        key=lambda g: (-len(sub_files[g]), -internal_edges[g], g),
    )
    if focus_norm:
        matched_subs = {
            g for g in all_subsystems
            if focus_norm.lower() in g.lower()
            or any(focus_norm.lower() in f.lower() for f in sub_files[g])
        }
        if not matched_subs:
            return {
                "schema_version": "1.0.0-mermaid-graph",
                "mode": "mermaid",
                "decision": "FOCUS_NOT_FOUND",
                "scan_root": scan_root,
                "graph_signature": graph_sig,
                "depth": 1,
                "depth_name": MERMAID_DEPTH_NAMES[1],
                "direction": norm_dir,
                "focus": focus,
                "available_subsystems": all_subsystems[:20],
                "mermaid_source": "",
                "nodes": [],
                "edges": [],
                "next_zoom_hints": [
                    {
                        "description": f"Explore subsystem {g} at depth 2",
                        "command": f"plw mermaid {shlex.quote(root_arg)} --depth 2 --focus {shlex.quote(g)}",
                    }
                    for g in all_subsystems[:5]
                ],
                "authority": _read_only_authority(),
            }
        neighbor_subs = set(matched_subs)
        for (gu, gv), cnts in cross_edges.items():
            if sum(cnts.values()) > 0 and (gu in matched_subs or gv in matched_subs):
                neighbor_subs.add(gu)
                neighbor_subs.add(gv)
        selected_subs = [g for g in all_subsystems if g in neighbor_subs][:max_nodes]
    else:
        selected_subs = all_subsystems[:max_nodes]

    selected_set = set(selected_subs)
    lines = [
        f"flowchart {norm_dir}",
        "    classDef subsystem fill:#1e293b,stroke:#38bdf8,stroke-width:2px,color:#f8fafc;",
        "    classDef cyclic fill:#3b1d2e,stroke:#f43f5e,stroke-width:2px,color:#ffe4e6;",
    ]
    node_ids: Dict[str, str] = {}
    nodes_out: List[Dict[str, Any]] = []
    for idx, grp in enumerate(selected_subs):
        nid = f"S{idx}"
        node_ids[grp] = nid
        f_cnt = len(sub_files[grp])
        lang_str = ", ".join(f"{k}:{v}" for k, v in sub_langs[grp].most_common(3))
        ep_cnt = sub_entrypoints[grp]
        int_cnt = internal_edges[grp]
        cyc_cnt = sub_cycles[grp]
        cyc_tag = f" | cycles: {cyc_cnt}" if cyc_cnt else ""
        label = (
            f"{mermaid_escape(grp)}\\n"
            f"{f_cnt} files ({mermaid_escape(lang_str)})\\n"
            f"entrypoints: {ep_cnt} | internal edges: {int_cnt}{cyc_tag}"
        )
        cls = "cyclic" if cyc_cnt > 0 else "subsystem"
        lines.append(f'    {nid}["{label}"]:::{cls}')
        nodes_out.append({
            "id": nid,
            "subsystem": grp,
            "files": f_cnt,
            "languages": dict(sub_langs[grp]),
            "entrypoints": ep_cnt,
            "internal_edges": int_cnt,
            "cyclic_sccs": cyc_cnt,
        })

    edges_out: List[Dict[str, Any]] = []
    for (gu, gv), cnts in sorted(
        cross_edges.items(),
        key=lambda kv: (-sum(kv[1].values()), kv[0][0], kv[0][1]),
    ):
        if gu not in selected_set or gv not in selected_set:
            continue
        tot = sum(cnts.values())
        rt = cnts.get("runtime", 0)
        sp = cnts.get("same_package", 0)
        to = cnts.get("type_only", 0)
        parts = []
        if rt:
            parts.append(f"rt:{rt}")
        if sp:
            parts.append(f"pkg:{sp}")
        if to:
            parts.append(f"type:{to}")
        edge_lbl = f"{tot} edges ({', '.join(parts)})"
        lines.append(f'    {node_ids[gu]} -->|"{edge_lbl}"| {node_ids[gv]}')
        edges_out.append({
            "from": gu,
            "to": gv,
            "total": tot,
            "natures": dict(cnts),
        })

    zoom_hints = [
        {
            "target": grp,
            "target_kind": "subsystem",
            "reason": f"{len(sub_files[grp])} files, {internal_edges[grp]} internal edges, {sub_entrypoints[grp]} entrypoints",
            "command": f"plw mermaid {shlex.quote(root_arg)} --depth 2 --focus {shlex.quote(grp)}",
        }
        for grp in selected_subs[:6]
    ]
    zoom_hints.append({
        "target": selected_subs[0] if selected_subs else ".",
        "target_kind": "file_architecture",
        "reason": "Inspect top entrypoints, hubs, and cyclic files across the repository",
        "command": f"plw mermaid {shlex.quote(root_arg)} --depth 3",
    })

    return {
        "schema_version": "1.0.0-mermaid-graph",
        "mode": "mermaid",
        "decision": "MERMAID_GRAPH_READY",
        "scan_root": scan_root,
        "graph_signature": graph_sig,
        "depth": 1,
        "depth_name": MERMAID_DEPTH_NAMES[1],
        "direction": norm_dir,
        "focus": focus,
        "include_tests": bool(include_tests),
        "summary": {
            "total_repo_files": inv.get("files", len(vertices)),
            "active_files": len(active_abs),
            "total_subsystems": len(all_subsystems),
            "rendered_nodes": len(nodes_out),
            "rendered_edges": len(edges_out),
            "internal_import_edges": inv.get("internal_import_edges", len(raw_edges)),
            "entrypoints": inv.get("entrypoints", 0),
            "cyclic_sccs": inv.get("cyclic_sccs", len(sccs)),
        },
        "mermaid_source": "\n".join(lines),
        "nodes": nodes_out,
        "edges": edges_out,
        "next_zoom_hints": zoom_hints,
        "authority": _read_only_authority(),
    }


def _render_depth_2_modules(
    *,
    scan_root: str,
    root_arg: str,
    graph_sig: Any,
    norm_dir: str,
    focus: Optional[str],
    focus_norm: str,
    max_nodes: int,
    include_tests: bool,
    inv: Dict[str, Any],
    vertices: List[str],
    raw_edges: List[Any],
    edge_natures: Dict[str, str],
    node_meta: Dict[str, Dict[str, Any]],
    active_abs: List[str],
    active_set: set,
    rel_by_abs: Dict[str, str],
    abs_by_rel: Dict[str, str],
    trie: Dict[str, Any],
) -> Dict[str, Any]:
    sub_by_rel = {
        rel: mermaid_compact_group(rel, trie, target_splits=1)
        for rel in rel_by_abs.values()
    }
    mod_by_rel = {
        rel: mermaid_compact_group(rel, trie, target_splits=2)
        for rel in rel_by_abs.values()
    }
    if len(set(mod_by_rel.values())) <= len(set(sub_by_rel.values())):
        mod_by_rel = {
            rel: mermaid_compact_group(rel, trie, target_splits=3)
            for rel in rel_by_abs.values()
        }

    mod_files: Dict[str, List[str]] = defaultdict(list)
    mod_parent_sub: Dict[str, str] = {}
    for _, rel in rel_by_abs.items():
        m = mod_by_rel[rel]
        mod_files[m].append(rel)
        mod_parent_sub[m] = sub_by_rel[rel]

    mod_internal: Counter = Counter()
    mod_cross: Dict[tuple, Counter] = defaultdict(Counter)
    mod_traffic: Counter = Counter()
    for u_abs, v_abs in raw_edges:
        if u_abs not in active_set or v_abs not in active_set:
            continue
        u_rel, v_rel = rel_by_abs[u_abs], rel_by_abs[v_abs]
        mu, mv = mod_by_rel[u_rel], mod_by_rel[v_rel]
        nat = edge_natures.get(f"{u_abs} -> {v_abs}", "runtime")
        if mu == mv:
            mod_internal[mu] += 1
        else:
            mod_cross[(mu, mv)][nat] += 1
            mod_traffic[mu] += 1
            mod_traffic[mv] += 1

    all_modules = sorted(
        mod_files.keys(),
        key=lambda m: (-(mod_traffic[m] + mod_internal[m] * 2 + len(mod_files[m])), m),
    )
    if focus_norm:
        matched_mods = {
            m for m in all_modules
            if focus_norm.lower() in m.lower()
            or focus_norm.lower() in mod_parent_sub.get(m, "").lower()
            or any(focus_norm.lower() in f.lower() for f in mod_files[m])
        }
        if not matched_mods:
            return {
                "schema_version": "1.0.0-mermaid-graph",
                "mode": "mermaid",
                "decision": "FOCUS_NOT_FOUND",
                "scan_root": scan_root,
                "graph_signature": graph_sig,
                "depth": 2,
                "depth_name": MERMAID_DEPTH_NAMES[2],
                "direction": norm_dir,
                "focus": focus,
                "available_modules": all_modules[:25],
                "mermaid_source": "",
                "nodes": [],
                "edges": [],
                "next_zoom_hints": [
                    {
                        "description": f"Zoom into module {m}",
                        "command": f"plw mermaid {shlex.quote(root_arg)} --depth 2 --focus {shlex.quote(m)}",
                    }
                    for m in all_modules[:5]
                ],
                "authority": _read_only_authority(),
            }
        # Include direct cross-module neighbors of matched modules
        expanded_mods = set(matched_mods)
        for (mu, mv), _cnts in sorted(
            mod_cross.items(), key=lambda kv: -sum(kv[1].values())
        ):
            if len(expanded_mods) >= max_nodes:
                break
            if mu in matched_mods or mv in matched_mods:
                expanded_mods.add(mu)
                expanded_mods.add(mv)
        selected_mods = [
            m for m in all_modules if m in matched_mods
        ][:max_nodes]
        for m in all_modules:
            if len(selected_mods) >= max_nodes:
                break
            if m in expanded_mods and m not in selected_mods:
                selected_mods.append(m)
    else:
        selected_mods = all_modules[:max_nodes]

    selected_set = set(selected_mods)
    by_sub: Dict[str, List[str]] = defaultdict(list)
    for m in selected_mods:
        by_sub[mod_parent_sub.get(m, "(root)")].append(m)

    lines = [
        f"flowchart {norm_dir}",
        "    classDef mod fill:#0f172a,stroke:#38bdf8,stroke-width:1.5px,color:#f1f5f9;",
        "    classDef hubmod fill:#1e1b4b,stroke:#818cf8,stroke-width:2px,color:#e0e7ff;",
    ]
    node_ids: Dict[str, str] = {}
    nodes_out: List[Dict[str, Any]] = []
    idx = 0
    top_hub_files_for_hints: List[tuple] = []

    for sub_name, mods in sorted(by_sub.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        sg_id = f"SG_{abs(hash(sub_name)) % 100000}"
        lines.append(f'    subgraph {sg_id} ["{mermaid_escape(sub_name)}"]')
        for m in sorted(mods):
            nid = f"M{idx}"
            idx += 1
            node_ids[m] = nid
            files_in_m = mod_files[m]
            scored_files = []
            for f_rel in files_in_m:
                v_abs = abs_by_rel.get(f_rel, "")
                meta = node_meta.get(v_abs) or {}
                fi = int(meta.get("fan_in", 0))
                fo = int(meta.get("fan_out", 0))
                ep = bool(meta.get("is_entrypoint", False))
                scored_files.append((fi + fo + (10 if ep else 0), fi, fo, ep, f_rel))
            scored_files.sort(reverse=True)
            if scored_files:
                top_hub_files_for_hints.append(scored_files[0])
            top_names = []
            for t in scored_files[:2]:
                if (t[1] + t[2]) > 0 or t[3]:
                    f_rel = t[4]
                    base_name = os.path.basename(f_rel)
                    parent_name = os.path.basename(os.path.dirname(f_rel))
                    disp_name = (
                        f"{parent_name}/{base_name}"
                        if parent_name and (
                            base_name in ("mod.rs", "__init__.py")
                            or os.path.splitext(base_name)[0] in ("index", "mod")
                        )
                        else base_name
                    )
                    top_names.append(f"{disp_name} ({t[1] + t[2]})")
            hub_line = f"\\nhubs: {mermaid_escape(', '.join(top_names))}" if top_names else ""
            short_lbl = mermaid_short_module_label(m)
            lbl = f"{mermaid_escape(short_lbl)}\\n{len(files_in_m)} files | int:{mod_internal[m]}{hub_line}"
            cls = "hubmod" if (mod_traffic[m] + mod_internal[m]) >= 12 else "mod"
            lines.append(f'        {nid}["{lbl}"]:::{cls}')
            nodes_out.append({
                "id": nid,
                "module": m,
                "subsystem": sub_name,
                "files": len(files_in_m),
                "internal_edges": mod_internal[m],
                "cross_module_traffic": mod_traffic[m],
                "top_files": [t[4] for t in scored_files[:3]],
            })
        lines.append("    end")

    edges_out: List[Dict[str, Any]] = []
    ranked_edges = sorted(
        [
            ((mu, mv), cnts)
            for (mu, mv), cnts in mod_cross.items()
            if mu in selected_set and mv in selected_set
        ],
        key=lambda kv: (-sum(kv[1].values()), kv[0][0], kv[0][1]),
    )
    for (mu, mv), cnts in ranked_edges[: max_nodes * 3]:
        tot = sum(cnts.values())
        rt = cnts.get("runtime", 0)
        sp = cnts.get("same_package", 0)
        to = cnts.get("type_only", 0)
        if rt > 0:
            lines.append(f'    {node_ids[mu]} -->|"{tot}"| {node_ids[mv]}')
        elif sp > 0:
            lines.append(f'    {node_ids[mu]} -. "pkg:{sp}" .-> {node_ids[mv]}')
        else:
            lines.append(f'    {node_ids[mu]} -. "type:{to}" .-> {node_ids[mv]}')
        edges_out.append({
            "from": mu,
            "to": mv,
            "total": tot,
            "natures": dict(cnts),
        })

    top_hub_files_for_hints.sort(reverse=True)
    zoom_hints = [
        {
            "target": m,
            "target_kind": "module_files",
            "reason": f"Inspect file-to-file connections inside module {m} ({len(mod_files[m])} files)",
            "command": f"plw mermaid {shlex.quote(root_arg)} --depth 3 --focus {shlex.quote(m)}",
        }
        for m in selected_mods[:4]
    ]
    for _score, fi, fo, _ep, f_rel in top_hub_files_for_hints[:3]:
        zoom_hints.append({
            "target": f_rel,
            "target_kind": "file_micro_neighborhood",
            "reason": f"Inspect symbol declarations & blast radius of hub {os.path.basename(f_rel)} (in={fi}, out={fo})",
            "command": f"plw mermaid {shlex.quote(root_arg)} --depth 4 --focus {shlex.quote(f_rel)}",
        })

    return {
        "schema_version": "1.0.0-mermaid-graph",
        "mode": "mermaid",
        "decision": "MERMAID_GRAPH_READY",
        "scan_root": scan_root,
        "graph_signature": graph_sig,
        "depth": 2,
        "depth_name": MERMAID_DEPTH_NAMES[2],
        "direction": norm_dir,
        "focus": focus,
        "include_tests": bool(include_tests),
        "summary": {
            "total_repo_files": inv.get("files", len(vertices)),
            "active_files": len(active_abs),
            "total_modules": len(all_modules),
            "rendered_nodes": len(nodes_out),
            "rendered_edges": len(edges_out),
        },
        "mermaid_source": "\n".join(lines),
        "nodes": nodes_out,
        "edges": edges_out,
        "next_zoom_hints": zoom_hints,
        "authority": _read_only_authority(),
    }


def _render_depth_3_files(
    *,
    scan_root: str,
    root_arg: str,
    graph_sig: Any,
    norm_dir: str,
    focus: Optional[str],
    focus_norm: str,
    max_nodes: int,
    include_tests: bool,
    inv: Dict[str, Any],
    vertices: List[str],
    raw_edges: List[Any],
    edge_natures: Dict[str, str],
    node_meta: Dict[str, Dict[str, Any]],
    active_abs: List[str],
    active_set: set,
    rel_by_abs: Dict[str, str],
    abs_by_rel: Dict[str, str],
    trie: Dict[str, Any],
    cyclic_files: set,
) -> Dict[str, Any]:
    mod_by_rel = {
        rel: mermaid_compact_group(rel, trie, target_splits=2)
        for rel in rel_by_abs.values()
    }
    scored_all: List[tuple] = []
    for v_abs, rel in rel_by_abs.items():
        meta = node_meta.get(v_abs) or {}
        fi = int(meta.get("fan_in", 0))
        fo = int(meta.get("fan_out", 0))
        ep = bool(meta.get("is_entrypoint", False))
        in_cyc = rel in cyclic_files
        score = (fi * 2) + fo + (25 if ep else 0) + (20 if in_cyc else 0)
        scored_all.append((score, fi, fo, ep, in_cyc, rel, v_abs))
    scored_all.sort(reverse=True)

    if focus_norm:
        seed_rels = {
            item[5] for item in scored_all
            if focus_norm.lower() in item[5].lower()
            or focus_norm.lower() in mod_by_rel.get(item[5], "").lower()
        }
        if not seed_rels:
            return {
                "schema_version": "1.0.0-mermaid-graph",
                "mode": "mermaid",
                "decision": "FOCUS_NOT_FOUND",
                "scan_root": scan_root,
                "graph_signature": graph_sig,
                "depth": 3,
                "depth_name": MERMAID_DEPTH_NAMES[3],
                "direction": norm_dir,
                "focus": focus,
                "mermaid_source": "",
                "nodes": [],
                "edges": [],
                "next_zoom_hints": [
                    {
                        "target": item[5],
                        "target_kind": "file",
                        "command": f"plw mermaid {shlex.quote(root_arg)} --depth 3 --focus {shlex.quote(os.path.dirname(item[5]) or item[5])}",
                    }
                    for item in scored_all[:5]
                ],
                "authority": _read_only_authority(),
            }
        selected_rels: List[str] = [
            item[5] for item in scored_all if item[5] in seed_rels
        ][:max_nodes]
        # Add 1-hop neighbors if room remains
        if len(selected_rels) < max_nodes:
            neighbor_rels: set = set()
            for u_abs, v_abs in raw_edges:
                if u_abs not in active_set or v_abs not in active_set:
                    continue
                ur, vr = rel_by_abs[u_abs], rel_by_abs[v_abs]
                if ur in seed_rels:
                    neighbor_rels.add(vr)
                if vr in seed_rels:
                    neighbor_rels.add(ur)
            for item in scored_all:
                if len(selected_rels) >= max_nodes:
                    break
                if item[5] in neighbor_rels and item[5] not in selected_rels:
                    selected_rels.append(item[5])
    else:
        selected_rels = [item[5] for item in scored_all[:max_nodes]]

    selected_rel_set = set(selected_rels)
    by_mod: Dict[str, List[str]] = defaultdict(list)
    for rel in selected_rels:
        by_mod[mod_by_rel.get(rel, "(root)")].append(rel)

    lines = [
        f"flowchart {norm_dir}",
        "    classDef entrypoint fill:#064e3b,stroke:#10b981,stroke-width:2px,color:#ecfdf5;",
        "    classDef hub fill:#1e1b4b,stroke:#6366f1,stroke-width:2px,color:#e0e7ff;",
        "    classDef cycle fill:#4c0519,stroke:#f43f5e,stroke-width:2.5px,color:#ffe4e6;",
        "    classDef file fill:#0f172a,stroke:#475569,stroke-width:1px,color:#f1f5f9;",
    ]
    node_ids: Dict[str, str] = {}
    nodes_out: List[Dict[str, Any]] = []
    idx = 0
    for mod_name, rels in sorted(by_mod.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        sg_id = f"FG_{abs(hash(mod_name)) % 100000}"
        short_mod = mermaid_short_module_label(mod_name)
        lines.append(f'    subgraph {sg_id} ["{mermaid_escape(short_mod)}"]')
        for rel in sorted(rels):
            nid = f"F{idx}"
            idx += 1
            node_ids[rel] = nid
            v_abs = abs_by_rel[rel]
            meta = node_meta.get(v_abs) or {}
            fi = int(meta.get("fan_in", 0))
            fo = int(meta.get("fan_out", 0))
            ep = bool(meta.get("is_entrypoint", False))
            ep_kind = str(meta.get("entrypoint_kind") or "")
            in_cyc = rel in cyclic_files
            badges = []
            if ep:
                badges.append(f"ENTRYPOINT:{ep_kind}" if ep_kind else "ENTRYPOINT")
            if in_cyc:
                badges.append("CYCLE")
            if fi >= 6 or fo >= 8:
                badges.append("HUB")
            badge_line = f"[{mermaid_escape(', '.join(badges))}]\\n" if badges else ""
            bname = os.path.basename(rel)
            lbl = f"{badge_line}{mermaid_escape(bname)}\\nin={fi} out={fo}"
            if in_cyc:
                cls = "cycle"
            elif ep:
                cls = "entrypoint"
            elif fi >= 6 or fo >= 8:
                cls = "hub"
            else:
                cls = "file"
            lines.append(f'        {nid}["{lbl}"]:::{cls}')
            nodes_out.append({
                "id": nid,
                "file": rel,
                "module": mod_name,
                "fan_in": fi,
                "fan_out": fo,
                "is_entrypoint": ep,
                "entrypoint_kind": ep_kind or None,
                "in_cycle": in_cyc,
            })
        lines.append("    end")

    edges_out: List[Dict[str, Any]] = []
    for u_abs, v_abs in raw_edges:
        if u_abs not in active_set or v_abs not in active_set:
            continue
        ur, vr = rel_by_abs[u_abs], rel_by_abs[v_abs]
        if ur not in selected_rel_set or vr not in selected_rel_set or ur == vr:
            continue
        nat = edge_natures.get(f"{u_abs} -> {v_abs}", "runtime")
        if nat == "same_package":
            lines.append(f"    {node_ids[ur]} -. same_pkg .-> {node_ids[vr]}")
        elif nat == "type_only":
            lines.append(f"    {node_ids[ur]} -. type .-> {node_ids[vr]}")
        else:
            lines.append(f"    {node_ids[ur]} --> {node_ids[vr]}")
        edges_out.append({
            "from": ur,
            "to": vr,
            "nature": nat,
        })

    zoom_hints = [
        {
            "target": n["file"],
            "target_kind": "file_micro_neighborhood",
            "reason": f"Inspect internal symbols and blast radius of {os.path.basename(n['file'])} (in={n['fan_in']}, out={n['fan_out']})",
            "command": f"plw mermaid {shlex.quote(root_arg)} --depth 4 --focus {shlex.quote(n['file'])}",
        }
        for n in sorted(
            nodes_out,
            key=lambda x: (-(x["fan_in"] * 2 + x["fan_out"] + (20 if x["in_cycle"] else 0)), x["file"]),
        )[:6]
    ]

    return {
        "schema_version": "1.0.0-mermaid-graph",
        "mode": "mermaid",
        "decision": "MERMAID_GRAPH_READY",
        "scan_root": scan_root,
        "graph_signature": graph_sig,
        "depth": 3,
        "depth_name": MERMAID_DEPTH_NAMES[3],
        "direction": norm_dir,
        "focus": focus,
        "include_tests": bool(include_tests),
        "summary": {
            "total_repo_files": inv.get("files", len(vertices)),
            "active_files": len(active_abs),
            "rendered_nodes": len(nodes_out),
            "rendered_edges": len(edges_out),
            "cyclic_files_rendered": sum(1 for n in nodes_out if n["in_cycle"]),
            "entrypoints_rendered": sum(1 for n in nodes_out if n["is_entrypoint"]),
        },
        "mermaid_source": "\n".join(lines),
        "nodes": nodes_out,
        "edges": edges_out,
        "next_zoom_hints": zoom_hints,
        "authority": _read_only_authority(),
    }


def _render_depth_4_neighborhood(
    *,
    scan_root: str,
    root_arg: str,
    graph: Dict[str, Any],
    graph_sig: Any,
    norm_dir: str,
    focus: Optional[str],
    focus_norm: str,
    max_nodes: int,
    include_tests: bool,
    vertices: List[str],
    edge_natures: Dict[str, str],
    node_meta: Dict[str, Dict[str, Any]],
    rel_by_abs: Dict[str, str],
    abs_by_rel: Dict[str, str],
    rel_fn: Callable[[str], str],
    impact_querier: Optional[Callable[[Dict[str, Any], str], Dict[str, Any]]],
    outline_querier: Optional[Callable[[Dict[str, Any], str], Dict[str, Any]]],
) -> Dict[str, Any]:
    all_rel_files = {rel_fn(v): v for v in vertices}
    target_rel: Optional[str] = None
    auto_selected = False

    if focus_norm:
        # 1. Exact relative path match
        if focus_norm in all_rel_files:
            target_rel = focus_norm
        else:
            # 2. Suffix or basename match
            suffix_matches = sorted(
                r for r in all_rel_files
                if r.endswith("/" + focus_norm) or os.path.basename(r) == focus_norm
            )
            if len(suffix_matches) == 1:
                target_rel = suffix_matches[0]
            elif len(suffix_matches) > 1:
                # Pick highest fan_in + fan_out among suffix matches
                suffix_matches.sort(
                    key=lambda r: -(
                        int((node_meta.get(all_rel_files[r]) or {}).get("fan_in", 0))
                        + int((node_meta.get(all_rel_files[r]) or {}).get("fan_out", 0))
                    )
                )
                target_rel = suffix_matches[0]
            else:
                # 3. Substring match (file or directory)
                sub_matches = sorted(
                    r for r in all_rel_files if focus_norm.lower() in r.lower()
                )
                if sub_matches:
                    sub_matches.sort(
                        key=lambda r: -(
                            int((node_meta.get(all_rel_files[r]) or {}).get("fan_in", 0)) * 2
                            + int((node_meta.get(all_rel_files[r]) or {}).get("fan_out", 0))
                        )
                    )
                    target_rel = sub_matches[0]
                    auto_selected = len(sub_matches) > 1

        if target_rel is None:
            return {
                "schema_version": "1.0.0-mermaid-graph",
                "mode": "mermaid",
                "decision": "FOCUS_NOT_FOUND",
                "scan_root": scan_root,
                "graph_signature": graph_sig,
                "depth": 4,
                "depth_name": MERMAID_DEPTH_NAMES[4],
                "direction": norm_dir,
                "focus": focus,
                "mermaid_source": "",
                "nodes": [],
                "edges": [],
                "next_zoom_hints": [
                    {
                        "target": r,
                        "target_kind": "file",
                        "command": f"plw mermaid {shlex.quote(root_arg)} --depth 4 --focus {shlex.quote(r)}",
                    }
                    for r in sorted(
                        rel_by_abs.values(),
                        key=lambda r: -(
                            int((node_meta.get(abs_by_rel[r]) or {}).get("fan_in", 0)) * 2
                            + int((node_meta.get(abs_by_rel[r]) or {}).get("fan_out", 0))
                        ),
                    )[:5]
                ],
                "authority": _read_only_authority(),
            }
    else:
        # Auto-select top hub/entrypoint file in repo
        auto_selected = True
        ranked_rels = sorted(
            rel_by_abs.values(),
            key=lambda r: -(
                int((node_meta.get(abs_by_rel[r]) or {}).get("fan_in", 0)) * 2
                + int((node_meta.get(abs_by_rel[r]) or {}).get("fan_out", 0))
                + (15 if (node_meta.get(abs_by_rel[r]) or {}).get("is_entrypoint") else 0)
            ),
        )
        target_rel = ranked_rels[0]

    target_abs = all_rel_files[target_rel]
    t_meta = node_meta.get(target_abs) or {}
    outline_data = outline_querier(graph, target_abs) if callable(outline_querier) else {}
    impact_data = impact_querier(graph, target_abs) if callable(impact_querier) else {}

    decls = list(outline_data.get("declarations") or [])
    decorators = list(outline_data.get("decorators") or [])
    stats = dict(outline_data.get("stats") or {})
    upstreams = [rel_fn(p) for p in (impact_data.get("direct_upstream") or [])]
    downstreams = [rel_fn(p) for p in (impact_data.get("direct_downstream") or [])]
    aff_eps = [rel_fn(p) for p in (impact_data.get("affected_entrypoints") or [])]
    circ_refs = [rel_fn(p) for p in (impact_data.get("circular_references") or [])]
    risk_level = str(impact_data.get("change_risk_level") or "unknown")

    neighbor_cap = max(4, (max_nodes - 2) // 2)
    shown_up = upstreams[:neighbor_cap]
    shown_down = downstreams[:neighbor_cap]
    shown_eps = [ep for ep in aff_eps if ep != target_rel and ep not in shown_down][:4]
    shown_decls = decls[:10]

    lines = [
        f"flowchart {norm_dir}",
        "    classDef target fill:#7c2d12,stroke:#f97316,stroke-width:3px,color:#ffedd5;",
        "    classDef sym fill:#1e293b,stroke:#94a3b8,stroke-width:1px,color:#f8fafc;",
        "    classDef upstream fill:#0f172a,stroke:#38bdf8,stroke-width:1.5px,color:#e0f2fe;",
        "    classDef downstream fill:#064e3b,stroke:#34d399,stroke-width:1.5px,color:#d1fae5;",
        "    classDef entrypoint fill:#3b0764,stroke:#c084fc,stroke-width:2px,color:#f3e8ff;",
    ]

    lines.append(f'    subgraph TARGET_BOX ["Focused Target: {mermaid_escape(target_rel)}"]')
    t_lines = stats.get("total_lines", t_meta.get("lines", "?"))
    t_fi = impact_data.get("target_fan_in", t_meta.get("fan_in", 0))
    t_fo = impact_data.get("target_fan_out", t_meta.get("fan_out", 0))
    dec_str = f"\\ndecorators: {mermaid_escape(', '.join(decorators[:3]))}" if decorators else ""
    t_lbl = (
        f"[TARGET] {mermaid_escape(os.path.basename(target_rel))}\\n"
        f"lines={t_lines} | in={t_fi} out={t_fo} | risk={mermaid_escape(risk_level)}{dec_str}"
    )
    lines.append(f'        T0["{t_lbl}"]:::target')
    for idx, d in enumerate(shown_decls):
        sid = f"SYM{idx}"
        kind = mermaid_escape(d.get("kind", "symbol"))
        name = mermaid_escape(d.get("name", "?"))
        lineno = d.get("line", "?")
        exp_tag = " [export]" if d.get("exported") else ""
        lines.append(f'        {sid}["{kind}: {name} (L{lineno}){exp_tag}"]:::sym')
        lines.append(f"        T0 --- {sid}")
    lines.append("    end")

    nodes_out = [{
        "id": "T0",
        "role": "target",
        "file": target_rel,
        "lines": t_lines,
        "fan_in": t_fi,
        "fan_out": t_fo,
        "change_risk_level": risk_level,
        "declarations_count": len(decls),
        "declarations_preview": shown_decls,
    }]
    edges_out = []

    if shown_up:
        lines.append(f'    subgraph UPSTREAM ["Direct Dependencies Imported by Target ({len(shown_up)}/{len(upstreams)})"]')
        for idx, u_rel in enumerate(shown_up):
            uid = f"U{idx}"
            lines.append(f'        {uid}["{mermaid_escape(os.path.basename(u_rel))}\\n{mermaid_escape(os.path.dirname(u_rel))}"]:::upstream')
            u_abs = all_rel_files.get(u_rel, "")
            nat = edge_natures.get(f"{target_abs} -> {u_abs}", "runtime")
            if u_rel in circ_refs:
                lines.append(f'        T0 <-->|"cycle ({nat})"| {uid}')
            elif nat == "same_package":
                lines.append(f"        T0 -. same_pkg .-> {uid}")
            elif nat == "type_only":
                lines.append(f"        T0 -. type .-> {uid}")
            else:
                lines.append(f"        T0 -->|imports| {uid}")
            nodes_out.append({"id": uid, "role": "direct_upstream", "file": u_rel})
            edges_out.append({"from": target_rel, "to": u_rel, "relation": "imports", "nature": nat})
        lines.append("    end")

    if shown_down:
        lines.append(f'    subgraph DOWNSTREAM ["Direct Dependents Importing Target ({len(shown_down)}/{len(downstreams)})"]')
        for idx, d_rel in enumerate(shown_down):
            did = f"D{idx}"
            lines.append(f'        {did}["{mermaid_escape(os.path.basename(d_rel))}\\n{mermaid_escape(os.path.dirname(d_rel))}"]:::downstream')
            d_abs = all_rel_files.get(d_rel, "")
            nat = edge_natures.get(f"{d_abs} -> {target_abs}", "runtime")
            if d_rel in circ_refs:
                lines.append(f'        {did} <-->|"cycle ({nat})"| T0')
            elif nat == "same_package":
                lines.append(f"        {did} -. same_pkg .-> T0")
            elif nat == "type_only":
                lines.append(f"        {did} -. type .-> T0")
            else:
                lines.append(f"        {did} -->|imports| T0")
            nodes_out.append({"id": did, "role": "direct_downstream", "file": d_rel})
            edges_out.append({"from": d_rel, "to": target_rel, "relation": "imported_by", "nature": nat})
        lines.append("    end")

    if shown_eps:
        lines.append('    subgraph ENTRYPOINTS ["Affected Entrypoints (Transitive Blast Radius)"]')
        for idx, ep_rel in enumerate(shown_eps):
            eid = f"EP{idx}"
            lines.append(f'        {eid}["[ENTRYPOINT] {mermaid_escape(os.path.basename(ep_rel))}\\n{mermaid_escape(os.path.dirname(ep_rel))}"]:::entrypoint')
            lines.append(f"        {eid} -. reaches .-> T0")
            nodes_out.append({"id": eid, "role": "affected_entrypoint", "file": ep_rel})
            edges_out.append({"from": ep_rel, "to": target_rel, "relation": "reaches_transitively"})
        lines.append("    end")

    zoom_hints = []
    seen_hint_rels: set = set()
    for n_rel in (shown_down[:4] + shown_up[:4]):
        if n_rel in seen_hint_rels or len(seen_hint_rels) >= 5:
            continue
        seen_hint_rels.add(n_rel)
        zoom_hints.append({
            "target": n_rel,
            "target_kind": "neighbor_file",
            "reason": f"Pivot micro-neighborhood to connected file {os.path.basename(n_rel)}",
            "command": f"plw mermaid {shlex.quote(root_arg)} --depth 4 --focus {shlex.quote(n_rel)}",
        })
    zoom_hints.append({
        "target": target_rel,
        "target_kind": "impact_projection",
        "reason": "Run full transitive topological impact projection on this target",
        "command": f"plw impact {shlex.quote(target_rel)} {shlex.quote(root_arg)} --json",
    })

    return {
        "schema_version": "1.0.0-mermaid-graph",
        "mode": "mermaid",
        "decision": "MERMAID_GRAPH_READY",
        "scan_root": scan_root,
        "graph_signature": graph_sig,
        "depth": 4,
        "depth_name": MERMAID_DEPTH_NAMES[4],
        "direction": norm_dir,
        "focus": target_rel,
        "requested_focus": focus,
        "auto_selected_focus": auto_selected,
        "include_tests": bool(include_tests),
        "summary": {
            "target_file": target_rel,
            "lines": t_lines,
            "declarations_count": len(decls),
            "direct_upstream_count": len(upstreams),
            "direct_downstream_count": len(downstreams),
            "affected_entrypoints_count": len(aff_eps),
            "circular_references_count": len(circ_refs),
            "change_risk_level": risk_level,
            "rendered_nodes": len(nodes_out),
            "rendered_edges": len(edges_out),
        },
        "mermaid_source": "\n".join(lines),
        "nodes": nodes_out,
        "edges": edges_out,
        "next_zoom_hints": zoom_hints,
        "authority": _read_only_authority(),
    }


def generate_mermaid_diagram(
    scan_root: str = ".",
    *,
    depth: int = 1,
    focus: Optional[str] = None,
    direction: str = "LR",
    max_nodes: int = 24,
    include_tests: bool = False,
    graph: Optional[Dict[str, Any]] = None,
    graph_builder: Optional[Callable[[str], Dict[str, Any]]] = None,
    orientation_builder: Optional[Callable[..., Dict[str, Any]]] = None,
    impact_querier: Optional[Callable[[Dict[str, Any], str], Dict[str, Any]]] = None,
    outline_querier: Optional[Callable[[Dict[str, Any], str], Dict[str, Any]]] = None,
    signature_fn: Optional[Callable[[Dict[str, Any]], Optional[str]]] = None,
    error_factory: Optional[Callable[..., Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Generate a multi-depth Mermaid architecture & dependency diagram from SharedGraph."""
    err_fn = error_factory if callable(error_factory) else _default_error

    if isinstance(depth, bool) or not isinstance(depth, int) or depth not in (1, 2, 3, 4):
        return err_fn(
            "invalid_mermaid_depth",
            "Mermaid depth must be an integer between 1 and 4.",
            depth=depth,
            supported_depths=[1, 2, 3, 4],
        )
    norm_dir = str(direction or "LR").strip().upper()
    if norm_dir not in MERMAID_DIRECTIONS:
        return err_fn(
            "invalid_mermaid_direction",
            f"Mermaid direction must be one of {', '.join(MERMAID_DIRECTIONS)}.",
            direction=direction,
            supported_directions=list(MERMAID_DIRECTIONS),
        )
    if isinstance(max_nodes, bool) or not isinstance(max_nodes, int) or not 4 <= max_nodes <= 120:
        return err_fn(
            "invalid_mermaid_max_nodes",
            "Mermaid max_nodes must be an integer between 4 and 120.",
            max_nodes=max_nodes,
            minimum=4,
            maximum=120,
        )

    if graph is None:
        if graph_builder is None:
            from core.shared_graph import build_shared_graph
            graph_builder = build_shared_graph
        graph = graph_builder(scan_root)

    if signature_fn is None:
        try:
            from core.shared_graph import graph_content_signature as _default_sig
            signature_fn = _default_sig
        except ImportError:
            signature_fn = None

    if orientation_builder is None:
        from core.target_topology import build_target_topology_orientation as _default_orient
        orientation_builder = _default_orient

    if impact_querier is None or outline_querier is None:
        try:
            from codebase.targeted_queries import query_impact as _default_impact, query_outline as _default_outline
            if impact_querier is None:
                impact_querier = _default_impact
            if outline_querier is None:
                outline_querier = _default_outline
        except ImportError:
            pass

    root_abs = os.path.abspath(scan_root)
    graph_sig = (graph.get("cache", {}) or {}).get("graph_content_signature")
    if not graph_sig and callable(signature_fn):
        try:
            graph_sig = signature_fn(graph)
        except Exception:
            graph_sig = None

    orientation = orientation_builder(
        graph, top_n=min(50, max(12, max_nodes)), include_edges=True
    )
    inv = orientation.get("inventory") or {}
    vertices: List[str] = list(graph.get("vertices") or [])
    raw_edges = list(graph.get("edges") or [])
    edge_natures: Dict[str, str] = dict(graph.get("edge_natures") or {})
    node_meta: Dict[str, Dict[str, Any]] = dict(graph.get("node_metadata") or {})

    def _rel(p: str) -> str:
        try:
            return os.path.relpath(p, root_abs).replace("\\", "/")
        except Exception:
            return str(p).replace("\\", "/")

    active_abs = [
        v for v in vertices
        if include_tests or not (node_meta.get(v) or {}).get("is_test", False)
    ]
    active_set = set(active_abs)
    rel_by_abs = {v: _rel(v) for v in active_abs}
    abs_by_rel = {rel_by_abs[v]: v for v in active_abs}

    if not active_abs:
        empty_mmd = f"flowchart {norm_dir}\n    EMPTY[\"No supported source files found in {mermaid_escape(scan_root)}\"]"
        return {
            "schema_version": "1.0.0-mermaid-graph",
            "mode": "mermaid",
            "decision": "EMPTY_OR_UNRESOLVED_REPOSITORY",
            "scan_root": scan_root,
            "graph_signature": graph_sig,
            "depth": depth,
            "depth_name": MERMAID_DEPTH_NAMES[depth],
            "direction": norm_dir,
            "focus": focus,
            "include_tests": bool(include_tests),
            "summary": {
                "total_repo_files": len(vertices),
                "active_files": 0,
                "rendered_nodes": 0,
                "rendered_edges": 0,
            },
            "mermaid_source": empty_mmd,
            "nodes": [],
            "edges": [],
            "next_zoom_hints": [],
            "authority": _read_only_authority(),
        }

    trie = mermaid_build_path_trie(list(rel_by_abs.values()))
    sccs = list(orientation.get("strongly_connected_components") or [])
    cyclic_files: set = set()
    for scc in sccs:
        for member in (scc.get("members") or []):
            cyclic_files.add(str(member).replace("\\", "/"))

    focus_norm = str(focus or "").strip().replace("\\", "/").strip("/")
    if focus_norm and not any(focus_norm.lower() in r.lower() for r in rel_by_abs.values()):
        try:
            from codebase.topology_analyzers import _resolve_query_target
            resolved_rel, _, _ = _resolve_query_target(
                focus_norm,
                set(rel_by_abs.values()),
                scan_root=None,
            )
            if resolved_rel:
                focus_norm = resolved_rel
        except Exception:
            pass
    root_arg = scan_root if scan_root != "." else "."

    if depth == 1:
        return _render_depth_1_subsystems(
            scan_root=scan_root,
            root_arg=root_arg,
            graph_sig=graph_sig,
            norm_dir=norm_dir,
            focus=focus,
            focus_norm=focus_norm,
            max_nodes=max_nodes,
            include_tests=include_tests,
            inv=inv,
            vertices=vertices,
            raw_edges=raw_edges,
            edge_natures=edge_natures,
            node_meta=node_meta,
            active_abs=active_abs,
            active_set=active_set,
            rel_by_abs=rel_by_abs,
            trie=trie,
            sccs=sccs,
        )

    if depth == 2:
        return _render_depth_2_modules(
            scan_root=scan_root,
            root_arg=root_arg,
            graph_sig=graph_sig,
            norm_dir=norm_dir,
            focus=focus,
            focus_norm=focus_norm,
            max_nodes=max_nodes,
            include_tests=include_tests,
            inv=inv,
            vertices=vertices,
            raw_edges=raw_edges,
            edge_natures=edge_natures,
            node_meta=node_meta,
            active_abs=active_abs,
            active_set=active_set,
            rel_by_abs=rel_by_abs,
            abs_by_rel=abs_by_rel,
            trie=trie,
        )

    if depth == 3:
        return _render_depth_3_files(
            scan_root=scan_root,
            root_arg=root_arg,
            graph_sig=graph_sig,
            norm_dir=norm_dir,
            focus=focus,
            focus_norm=focus_norm,
            max_nodes=max_nodes,
            include_tests=include_tests,
            inv=inv,
            vertices=vertices,
            raw_edges=raw_edges,
            edge_natures=edge_natures,
            node_meta=node_meta,
            active_abs=active_abs,
            active_set=active_set,
            rel_by_abs=rel_by_abs,
            abs_by_rel=abs_by_rel,
            trie=trie,
            cyclic_files=cyclic_files,
        )

    return _render_depth_4_neighborhood(
        scan_root=scan_root,
        root_arg=root_arg,
        graph=graph,
        graph_sig=graph_sig,
        norm_dir=norm_dir,
        focus=focus,
        focus_norm=focus_norm,
        max_nodes=max_nodes,
        include_tests=include_tests,
        vertices=vertices,
        edge_natures=edge_natures,
        node_meta=node_meta,
        rel_by_abs=rel_by_abs,
        abs_by_rel=abs_by_rel,
        rel_fn=_rel,
        impact_querier=impact_querier,
        outline_querier=outline_querier,
    )
