"""Source-only Angular UI discovery, with explicit runtime evidence gaps."""
from __future__ import annotations

import hashlib
import json
import re
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Dict, List, Optional

from codebase.angular_semantics import (
    _object_properties,
    _string_literal,
    analyze_angular_ownership,
)
from codebase.template_control_flow import condition_for_offset, template_branches
from codebase.static_style_reference import style_reference

SCHEMA_VERSION = "plw-static-ui-reference-v1"
MAX_TEMPLATE_BYTES = 1024 * 1024
INTERACTIVE_TAGS = {"a", "button", "input", "label", "select", "textarea"}
VISIBLE_ATTRIBUTES = {"href", "routerlink", "[routerlink]", "type", "name",
                      "formcontrolname", "aria-label", "placeholder", "id", "class"}
QUERY_STOPWORDS = {
    "the", "for", "and", "with", "from", "where", "which", "what",
    "this", "that", "these", "those", "between", "into", "onto", "about",
    "above", "below", "under", "over", "after", "before", "through", "during",
    "without", "within", "across", "against", "among", "around", "behind",
    "beside", "beyond", "near", "since", "until", "upon", "via", "are", "was",
    "were", "been", "being", "have", "has", "had", "does", "did", "will",
    "would", "should", "could", "can", "may", "might", "must", "shall", "not",
    "but", "all", "any", "each", "every", "some", "such", "only", "own",
    "same", "than", "too", "very", "just", "also", "now", "here", "there",
    "when", "why", "how", "who", "whom", "whose", "its", "our", "your",
    "their", "his", "her",
    "to", "of", "is", "be", "by", "as", "at", "or", "an", "if", "it",
    "no", "so", "we", "he", "me", "my", "us", "do", "go", "am",
    "ts", "js", "py", "kt", "rs",
    "find", "locate", "check", "assess", "audit", "refactor", "fix", "break",
    "debug", "test", "tests", "repo", "repository", "codebase", "project",
    "file", "files", "module", "modules", "cycle", "cycles", "architecture",
    "remove", "extract", "split", "cleanup", "dependency", "dependencies",
    "circular", "circularity", "coupling", "scc", "sccs", "function",
    "functions", "class", "classes", "method", "methods", "symbol", "symbols",
    "import", "imports", "export", "exports", "tsconfig", "schema", "cache",
    "receipt", "topology", "mermaid", "graph",
    "investigate", "inspect", "analyze", "analyzer", "analyzers",
    "src", "app", "core", "services", "service", "tools", "tool",
    "implementations", "agent", "agents", "executor", "worker",
    "sandbox", "pyodide", "perf", "gc", "async", "deopt", "loop",
    "unbounded", "memory", "leak", "error", "errors", "line", "lines",
    "json", "html", "css", "scss", "mjs", "cjs", "tsx", "jsx",
    "angular", "ui", "page", "link", "button", "component", "mobile",
    "responsive", "overlap", "layout", "navigation", "element",
    "tautan", "tombol", "yang", "dan", "di", "ke", "ya", "ini", "itu",
    "atau", "dari", "untuk", "pada", "dengan",
}


def _sha(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _words(value: str) -> List[str]:
    return re.findall(r"[a-z0-9]+", value.casefold())


class _Elements(HTMLParser):
    def __init__(self, content: str, label_mask: List[tuple[int, int]]) -> None:
        super().__init__(convert_charrefs=False)
        self.line_starts = [0] + [match.end() for match in re.finditer("\n", content)]
        self.label_mask = label_mask
        self.stack: List[Dict[str, Any]] = []
        self.elements: List[Dict[str, Any]] = []

    def handle_starttag(self, tag: str, attrs: List[tuple[str, Optional[str]]]) -> None:
        line, column = self.getpos()
        guards = list(self.stack[-1]["guards"]) if self.stack else []
        for name, value in attrs:
            if name in {"*ngif", "*ngfor", "[hidden]"}:
                guards.append({"kind": name, "expression": value[:240] if value else None,
                               "expression_truncated": len(value or "") > 240,
                               "source_location": {"line": line, "column": column + 1}})
        row = {"tag": tag, "line": self.getpos()[0],
               "column": column + 1, "offset": self.line_starts[line - 1] + column,
               "guards": guards,
               "attributes": {k: v for k, v in attrs if k in VISIBLE_ATTRIBUTES and v is not None},
               "text_parts": [], "label_sources": []}
        if tag in {"input", "br", "img", "hr", "meta", "link"}:
            self.elements.append(row)
        else:
            self.stack.append(row)

    def handle_startendtag(self, tag: str, attrs: List[tuple[str, Optional[str]]]) -> None:
        self.handle_starttag(tag, attrs)
        if self.stack and self.stack[-1]["tag"] == tag:
            self.elements.append(self.stack.pop())

    def handle_data(self, data: str) -> None:
        line, column = self.getpos()
        offset = self.line_starts[line - 1] + column
        if self.label_mask:
            chars = list(data)
            for start, end in self.label_mask:
                for index in range(max(0, start - offset), min(len(chars), end - offset)):
                    chars[index] = " "
            data = "".join(chars)
        self._record_text(data)

    def handle_entityref(self, name: str) -> None:
        self._record_text(unescape("&" + name + ";"))

    def handle_charref(self, name: str) -> None:
        self._record_text(unescape("&#" + name + ";"))

    def _record_text(self, data: str) -> None:
        if not self.stack or not data.strip():
            return
        # A nested span contributes to its nearest link/button label. Other
        # text belongs to its immediate element, not every enclosing layout.
        owner = next((row for row in reversed(self.stack) if row["tag"] in INTERACTIVE_TAGS),
                     self.stack[-1])
        owner["text_parts"].append(data)
        owner["label_sources"].append("direct" if owner is self.stack[-1] else "nested")

    def handle_endtag(self, tag: str) -> None:
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index]["tag"] == tag:
                self.elements.extend(reversed(self.stack[index:]))
                del self.stack[index:]
                return


def _template(component: Dict[str, Any], file_map: Dict[str, str], root: Path) -> tuple[Optional[str], Optional[str], str]:
    anchor = component.get("template", {})
    kind = anchor.get("kind")
    if kind == "external":
        resource = anchor.get("resource", {})
        path = anchor.get("resolved_path")
        if resource.get("proof_class") != "EXACT" or not path:
            return None, None, "TEMPLATE_RESOURCE_UNRESOLVED"
        candidate = Path(path).resolve()
        if not candidate.is_relative_to(root):
            return None, None, "TEMPLATE_OUTSIDE_TARGET"
        try:
            if candidate.stat().st_size > MAX_TEMPLATE_BYTES:
                return None, None, "TEMPLATE_TOO_LARGE"
            raw = candidate.read_bytes()
            if _sha(raw) != resource.get("sha256"):
                return None, None, "TEMPLATE_CHANGED_DURING_QUERY"
            return raw.decode("utf-8"), str(candidate), "EXACT"
        except (OSError, UnicodeError):
            return None, None, "TEMPLATE_UNREADABLE"
    if kind == "inline" and anchor.get("proof_class") == "EXACT":
        source = file_map.get(component.get("file"), "")
        span = component.get("decorator", {}).get("span", {})
        snippet = source[span.get("start", 0):span.get("end", 0)]
        open_brace = snippet.find("{")
        close_brace = snippet.rfind("}")
        if open_brace >= 0 and close_brace > open_brace:
            metadata = _object_properties(snippet[open_brace:close_brace + 1])
            value = _string_literal(metadata.get("template", "")) if metadata else None
            if value is not None and _sha(value.encode("utf-8")) == anchor.get("sha256"):
                return value, component["file"], "EXACT_INLINE"
        return None, None, "INLINE_TEMPLATE_UNRESOLVED"
    return None, None, "TEMPLATE_NOT_STATIC"


def _query_ui_words(query: str) -> List[str]:
    cleaned = re.sub(
        r"\b(?:\S*[\\/]\S+|\w+_\w+|\w+\.(?:ts|js|mjs|cjs|py|kt|rs|go|java|cpp|c|h|sh|md|yml|yaml|toml|lock)\b)",
        " ",
        query,
        flags=re.IGNORECASE,
    )
    words = _words(cleaned)
    return words if words else _words(query)


def _score(query: str, tag: str, label: str, attrs: Dict[str, str]) -> tuple[int, List[str], Dict[str, Any]]:
    ui_words = _query_ui_words(query)
    tokens = {word for word in ui_words if len(word) >= 2 and word not in QUERY_STOPWORDS}
    label_words = _words(label)
    label_matches = sorted(tokens.intersection(label_words))
    # Short words may distinguish short labels such as "Sign in" and "Sign up", but
    # a 2-char token alone on a multi-word label (without a >=3-char match) is weak evidence.
    if len(label_words) > 1 and not any(len(word) >= 3 for word in label_matches):
        label_matches = []
    attribute_tokens = {word for word in tokens if len(word) >= 3}
    attribute_matches = {name: sorted(attribute_tokens.intersection(_words(value)))
                         for name, value in sorted(attrs.items())}
    attribute_matches = {name: matches for name, matches in attribute_matches.items() if matches}
    matched = sorted(set(label_matches).union(*(set(values) for values in attribute_matches.values())))
    if not matched:
        return 0, [], {}
    score = 2 * len(matched) + (3 if tag in INTERACTIVE_TAGS else 0)
    query_words = _words(query)
    phrase_match = False
    if label_words and len(label_words) <= 6 and len(label_words) > 1:
        needle = " ".join(label_words)
        if needle in " ".join(query_words):
            score += 12
            phrase_match = True
    elif label_words and label_words[0] in query_words and len(label_words) == 1:
        score += 4
        phrase_match = True
    return score, matched, {"label_terms": label_matches,
                             "attribute_terms": attribute_matches,
                             "label_phrase_in_query": phrase_match}


def _global_styles(root: Path) -> List[Dict[str, Any]]:
    config = root / "angular.json"
    try:
        if config.stat().st_size > MAX_TEMPLATE_BYTES:
            return [{"status": "CONFIG_TOO_LARGE"}]
        raw_config = config.read_bytes()
        if len(raw_config) > MAX_TEMPLATE_BYTES:
            return [{"status": "CONFIG_TOO_LARGE"}]
        projects = json.loads(raw_config).get("projects", {})
    except (OSError, UnicodeError, ValueError, AttributeError):
        return [{"status": "CONFIG_UNAVAILABLE"}]
    rows: List[Dict[str, Any]] = []
    for project_name, project in sorted(projects.items()):
        if not isinstance(project, dict):
            continue
        build = (project.get("architect") or project.get("targets") or {}).get("build", {})
        for item in build.get("options", {}).get("styles", []):
            path = item if isinstance(item, str) else item.get("input") if isinstance(item, dict) else None
            if not isinstance(path, str):
                continue
            absolute = (root / path).resolve()
            if not absolute.is_relative_to(root):
                rows.append({"project": project_name, "declared_path": path,
                             "config_sha256": _sha(raw_config), "status": "OUTSIDE_TARGET"})
                continue
            try:
                raw = absolute.read_bytes() if absolute.stat().st_size <= MAX_TEMPLATE_BYTES else None
            except OSError:
                raw = None
            rows.append({"project": project_name, "declared_path": path,
                         "config_sha256": _sha(raw_config),
                         "status": "EXACT" if raw is not None else "UNAVAILABLE",
                         "sha256": _sha(raw) if raw is not None else None})
    return rows


def static_ui_reference(query: str, graph: Dict[str, Any], *, selector: Optional[str] = None,
                        max_candidates: int = 8) -> Dict[str, Any]:
    if not query.strip():
        raise ValueError("query must not be empty")
    if not 1 <= max_candidates <= 100:
        raise ValueError("max_candidates must be between 1 and 100")
    ownership = analyze_angular_ownership(graph, selector_filter=selector, read_resources=True)
    root = Path(graph.get("scan_root") or ".").resolve()
    global_styles = _global_styles(root)
    candidates: List[Dict[str, Any]] = []
    unresolved: List[Dict[str, str]] = []
    for component in ownership["components"]:
        content, path, proof = _template(component, graph.get("file_map", {}), root)
        if content is None:
            unresolved.append({"component_file": component["file"], "reason": proof})
            continue
        control_flow = template_branches(content)
        elements = _Elements(content, control_flow["label_mask"])
        elements.feed(content)
        lines = content.splitlines()
        for element in elements.elements:
            full_label = " ".join(" ".join(element["text_parts"]).split())
            label = full_label[:160]
            attrs = element["attributes"]
            score, matches, match_evidence = _score(query, element["tag"], label, attrs)
            if not score:
                continue
            line = element["line"]
            candidates.append({
                "component_file": component["file"],
                "component_class": component["class_name"],
                "component_selector": component.get("selector", {}).get("value"),
                "template_file": path,
                "template_sha256": _sha(content.encode("utf-8")),
                "template_proof": proof,
                "template_line": line if proof == "EXACT" else None,
                "template_declaration_line": component["decorator"]["span"]["start_position"]["line"] if proof == "EXACT_INLINE" else None,
                "source_line": lines[line - 1] if proof == "EXACT" and 0 < line <= len(lines) and len(lines[line - 1]) <= 480 else None,
                "source_line_omitted": proof == "EXACT" and 0 < line <= len(lines) and len(lines[line - 1]) > 480,
                "element": {"tag": element["tag"], "label": label,
                            "label_truncated": len(full_label) > 160, "attributes": attrs,
                            "label_provenance": ("NESTED_TEXT_IN_INTERACTIVE_CONTROL"
                                                 if "nested" in element["label_sources"] else
                                                 "DIRECT_ELEMENT_TEXT" if label else "NO_TEXT_LABEL")},
                "declared_component_styles": component.get("styles", []),
                "style_reference": style_reference(component, global_styles, element, root, graph.get("file_map", {})),
                "matched_terms": matches,
                "match_evidence": match_evidence,
                "score": score,
                "render_condition": "UNPROVEN",
                "template_condition": condition_for_offset(control_flow, element["offset"], element["guards"]),
                "geometry": "UNOBSERVED",
            })
    candidates.sort(key=lambda row: (-row["score"],
                row["component_file"], row["template_line"] or 0, row["element"]["tag"]))
    top = candidates[0]["score"] if candidates else None
    ties = sum(1 for row in candidates if row["score"] == top)
    status = "RESOLVED" if candidates and ties == 1 and not unresolved else ("AMBIGUOUS" if candidates else "UNRESOLVED")
    reason = ("unique_source_match" if status == "RESOLVED" else
              "unresolved_templates_may_contain_candidate" if candidates and unresolved else
              "equally_ranked_source_matches" if candidates else "no_verified_template_match")
    return {
        "schema_version": SCHEMA_VERSION,
        "query": query,
        "scan_root": str(root),
        "graph_content_signature": ownership.get("graph_content_signature"),
        "angular_ownership_digest": ownership.get("ownership_digest"),
        "decision": {"status": status, "reason": reason,
                     "selected": candidates[0] if status == "RESOLVED" else None,
                     "selection_policy": "unique_highest_source_score_without_unresolved_templates",
                     "top_score_tie_count": ties,
                     "matching_candidate_count": len(candidates),
                     "omitted_candidate_count": max(0, len(candidates) - max_candidates)},
        "candidates": candidates[:max_candidates],
        "declared_global_styles": global_styles,
        "unresolved_templates": unresolved[:max_candidates],
        "unresolved_templates_omitted": max(0, len(unresolved) - max_candidates),
        "next_evidence": {
            "source": "inspect the matched template and declared styles or global stylesheet for a proposed edit",
            "conditional_rendering": "inspect template_condition source branches, then establish route, UI state, and active branch externally",
            "geometry": "obtain a real scenario-bound browser or host geometry capture before any overlap claim",
        },
        "authority": {"source_only": True, "browser_executed": False, "rendered_dom_observed": False,
                      "geometry_observed": False, "runtime_behavior_proven": False,
                      "overlap_proven": False, "mutation_authority": False, "task_postcondition_proven": False},
    }
