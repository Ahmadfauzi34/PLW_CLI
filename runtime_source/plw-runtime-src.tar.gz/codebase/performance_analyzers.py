"""
Performance Analyzers — HoTT Kernel
Schema Version: 3.0.0-kernel

Migrated dari standalone tools:
- async_waterfall_detector.py  → perf.async
- deopt_checker.py             → perf.deopt
- gc_pressure_analyzer.py      → perf.gc
- cache_auditor.py             → perf.cache

Semua analyzer mengonsumsi SharedGraph. Tidak ada os.walk() di sini.
"""

import os
import re
from typing import Any, Dict, List, Optional, Set, Tuple

from language_semantics import (
    has_cli_shebang as _has_cli_shebang,
    is_tool_config_file as _is_tool_config_file,
    normalize_path as _normalize_path,
    strip_js_comments as _strip_comments,
)

_TEST_FILE_RE = re.compile(
    r"(?:^|/)(?:tests?|__tests__|spec)/|"
    r"(?:^|/)src/(?:test|androidTest)/|"
    r"(?:\.(?:spec|test)\.[A-Za-z0-9]+$)|"
    r"(?:^|/)(?:test_[^/]+|[^/]+_test)\.py$",
    re.IGNORECASE,
)

# Case-sensitive suffix patterns so Kotlin identifiers like `Contest.kt` are not
# misclassified as tests while `*Test.kt` / `*Tests.kt` / `*Spec.kt` and Rust
# `*_test.rs` are recognized accurately.
_TEST_BASENAME_CASE_RE = re.compile(
    r"(?:(?:Test|Tests|Spec)\.kt|_test\.rs)$"
)


def _is_test_file(file_path: str) -> bool:
    norm = _normalize_path(file_path)
    base = os.path.basename(norm)
    return bool(_TEST_FILE_RE.search(norm) or _TEST_BASENAME_CASE_RE.search(base))


# ============================================================
# Shared Helpers
# ============================================================

def _strip_strings(content: str) -> str:
    content = re.sub(r"'[^']*'", "''", content)
    content = re.sub(r'"[^"]*"', '""', content)
    return re.sub(r"`[^`]*`", "``", content)


def _blank_multiline_template_literals(content: str) -> str:
    """Blank contents of multi-line JS/TS backtick template literals while preserving newlines and single-line quote safety."""
    if "`" not in content:
        return content
    out: List[str] = []
    n = len(content)
    i = 0
    while i < n:
        ch = content[i]
        if ch in ('"', "'"):
            quote = ch
            out.append(ch)
            i += 1
            while i < n:
                c = content[i]
                out.append(c)
                i += 1
                if c == "\\" and i < n:
                    out.append(content[i])
                    i += 1
                elif c == quote or c == "\n":
                    break
        elif ch == "`":
            start = i
            i += 1
            while i < n:
                c = content[i]
                i += 1
                if c == "\\" and i < n:
                    i += 1
                elif c == "`":
                    break
            segment = content[start:i]
            if "\n" in segment:
                out.append("`" + ("\n" * segment.count("\n")) + "`")
            else:
                out.append(segment)
        else:
            out.append(ch)
            i += 1
    return "".join(out)


LOOP_HEADER_REGEX = re.compile(
    r"^\s*(?:for\s*(?:await\s*)?\(|"
    r"for\s+(?:const|let|var)\s+\w+\s+(?:of|in)|while\s*\()"
)

_RETRY_COUNTER_NAME_REGEX = re.compile(
    r"\b(?:attempt|attempts|retry|retries|tryCount|tries)\b",
    re.IGNORECASE,
)
_FOR_CLAUSE_REGEX = re.compile(r"^\s*for\s*\(([^;]*);([^;]*);([^)]*)\)")
_WHILE_CLAUSE_REGEX = re.compile(r"^\s*while\s*\(([^)]*)\)")
_CLI_ENTRYPOINT_KINDS = frozenset({
    "package_script",
    "package_bin",
    "cli_shebang",
    "tool_config_entry",
})


def _find_enclosing_loop(
    lines: List[str],
    target_idx: int,
    target_column: Optional[int] = None,
) -> Optional[Tuple[int, int]]:
    """Return (header_idx, end_idx) for the innermost loop enclosing target_idx."""
    previous_idx = target_idx - 1
    while previous_idx >= 0 and not lines[previous_idx].strip():
        previous_idx -= 1
    if previous_idx >= 0:
        previous = _strip_strings(lines[previous_idx])
        if "{" not in previous and LOOP_HEADER_REGEX.match(previous):
            return previous_idx, target_idx

    unmatched_closing_braces = 0
    for i in range(target_idx, -1, -1):
        line = _strip_strings(lines[i])
        if i == target_idx and target_column is not None:
            line = line[:target_column]

        for column in range(len(line) - 1, -1, -1):
            token = line[column]
            if token == "}":
                unmatched_closing_braces += 1
            elif token == "{":
                if unmatched_closing_braces:
                    unmatched_closing_braces -= 1
                elif re.search(r"\.\s*map\s*\(\s*async\b", line[:column]):
                    return None
                elif LOOP_HEADER_REGEX.match(line[:column]):
                    depth = 0
                    for j in range(i, len(lines)):
                        scan = _strip_strings(lines[j])
                        start_col = column if j == i else 0
                        for ch in scan[start_col:]:
                            if ch == "{":
                                depth += 1
                            elif ch == "}":
                                depth -= 1
                                if depth == 0:
                                    return i, j
                    return i, len(lines) - 1
    return None


def _is_in_loop(lines: List[str], target_idx: int, target_column: Optional[int] = None) -> bool:
    """Return True only when the target is lexically enclosed by a loop body."""
    return _find_enclosing_loop(lines, target_idx, target_column) is not None


def _is_small_retry_bound(limit_token: str) -> bool:
    if limit_token.isdigit():
        return int(limit_token) <= 10
    # Uppercase constant such as ATTEMPTS / MAX_RETRIES or camelCase retry bound like maxRetries
    return bool(
        re.match(r"^[A-Z][A-Z0-9_]+$", limit_token)
        or re.search(r"(?:retry|retries|attempt|attempts|limit|bound)", limit_token, re.IGNORECASE)
    )


def _is_bounded_retry_loop(lines: List[str], header_idx: int, end_idx: int) -> bool:
    """Return True when the enclosing loop is a small bounded retry loop."""
    header_clean = _strip_strings(lines[header_idx]).strip()
    block_clean = _strip_strings("\n".join(lines[header_idx : end_idx + 1]))

    for_match = _FOR_CLAUSE_REGEX.match(header_clean)
    if for_match:
        init_clause, cond_clause, update_clause = (
            for_match.group(1),
            for_match.group(2),
            for_match.group(3),
        )
        counter_match = (
            _RETRY_COUNTER_NAME_REGEX.search(init_clause)
            or _RETRY_COUNTER_NAME_REGEX.search(cond_clause)
            or _RETRY_COUNTER_NAME_REGEX.search(update_clause)
        )
        if counter_match:
            counter_name = counter_match.group(0)
            cond_clean = cond_clause.strip()
            if cond_clean:
                if ".length" in cond_clean:
                    return False
                bound_match = re.search(
                    rf"\b{re.escape(counter_name)}\b\s*(<=?|>=?|!==?)\s*(\d+|[A-Za-z_$][\w$]*)\b|"
                    rf"\b(\d+|[A-Za-z_$][\w$]*)\s*(<=?|>=?)\s*\b{re.escape(counter_name)}\b",
                    cond_clean,
                )
                if bound_match:
                    limit_tok = bound_match.group(2) or bound_match.group(3)
                    if limit_tok and _is_small_retry_bound(limit_tok):
                        return True
            else:
                # Pattern: `for (let attempt = 0; ; attempt++) { ... if (... || attempt === 2) throw ...; }`
                body_bound = re.search(
                    rf"\b{re.escape(counter_name)}\b\s*(===?|>=?|<=|<)\s*(\d+|[A-Za-z_$][\w$]*)\b",
                    block_clean,
                )
                has_exit = bool(re.search(r"\b(?:break|throw|return)\b", block_clean))
                if body_bound and has_exit and _is_small_retry_bound(body_bound.group(2)):
                    return True

        # Generic small numeric try/catch retry loop (e.g. `for (let i = 0; i < 3; i++) { try { ... break; } catch {} }`)
        small_loop = re.search(
            r"(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*([01])\s*;\s*"
            r"\1\s*(<=?)\s*(\d+)\s*;",
            header_clean,
        )
        if small_loop and re.search(r"\bcatch\b", block_clean) and re.search(
            r"\b(?:break|throw|return)\b", block_clean
        ):
            start_val = int(small_loop.group(2))
            op = small_loop.group(3)
            limit_val = int(small_loop.group(4))
            iterations = (limit_val - start_val) + (1 if op == "<=" else 0)
            if 1 <= iterations <= 5:
                return True
        return False

    if re.match(r"^\s*for\s+await\s*\(", header_clean):
        return True
    if re.search(
        r"\b(?:maxToolLoops|maxTurns|maxSteps|maxIterations|maxRetries|maxAttempts)\b",
        block_clean,
    ) and re.search(r"\b(?:break|return|throw)\b", block_clean):
        return True
    while_match = _WHILE_CLAUSE_REGEX.match(header_clean)
    if while_match:
        cond_clean = while_match.group(1)
        if re.search(r"\.length\s*>\s*0\b", cond_clean) and re.search(
            r"\.(?:shift|pop)\s*\(", block_clean
        ):
            return True
        if re.search(r"\breader\.read\s*\(", block_clean) and re.search(
            r"\bif\s*\(\s*done\s*\)\s*break\b", block_clean
        ):
            return True
        counter_match = _RETRY_COUNTER_NAME_REGEX.search(cond_clean)
        if counter_match and ".length" not in cond_clean:
            counter_name = counter_match.group(0)
            bound_match = re.search(
                rf"\b{re.escape(counter_name)}\b\s*(?:<=?|>=?)\s*(\d+|[A-Za-z_$][\w$]*)\b",
                cond_clean,
            )
            if bound_match and _is_small_retry_bound(bound_match.group(1)):
                return True
    return False


def _is_sequential_or_stream_await(
    lines: List[str], header_idx: int, end_idx: int, line_idx: int, line: str
) -> bool:
    """Return True when an await inside a loop is inherently sequential (stream read, serial executor, or state reducer)."""
    if re.search(r"\bawait\s+[\w$.]+\.(?:read|next|shift)\s*\(", line):
        return True
    if re.search(r"\bexecuteToolsSerial\b|\bexecutePhase\b", line):
        return True
    header_clean = _strip_strings(lines[header_idx]).strip()
    block_clean = _strip_strings("\n".join(lines[header_idx : end_idx + 1]))
    # Enclosing function explicitly named *Serial / *Sequential
    fn_window = "\n".join(lines[max(0, header_idx - 8) : header_idx + 1])
    if re.search(r"\basync\s+\w*(?:Serial|Sequential)\w*\s*\(", fn_window):
        return True
    # State-threading pipeline loop: `for (const step of this.steps) { const res = await step(current); ... current = res.value; }`
    m_call = re.search(r"\bawait\s+[\w$.]+\(\s*([A-Za-z_$][\w$]*)\s*[,)]", line)
    if m_call:
        state_var = m_call.group(1)
        if re.search(rf"\b{re.escape(state_var)}\s*=", block_clean):
            return True
    if re.search(r"\bfor\s+await\s*\(", "\n".join(lines[max(0, line_idx - 40) : line_idx + 1])):
        return True
    return False


def _is_cli_or_tooling_context(
    file_path: str,
    raw_content: str,
    node_meta: Dict[str, Any],
) -> bool:
    """Return True when file executes in a CLI script or tooling/build context."""
    ep_kind = str(node_meta.get("entrypoint_kind") or "")
    if ep_kind in _CLI_ENTRYPOINT_KINDS:
        return True
    if _has_cli_shebang(raw_content):
        return True
    if _is_tool_config_file(file_path):
        return True
    if _is_test_file(file_path) or bool(node_meta.get("is_test")):
        return True
    norm = _normalize_path(file_path).lower()
    wrapped = f"/{norm.lstrip('/')}"
    if "/scripts/" in wrapped or "/bin/" in wrapped:
        return True
    return False


def _extract_paren_call_and_args(
    text: str,
    open_paren_idx: int,
    max_chars: int = 4096,
) -> Tuple[str, List[str]]:
    """Extract balanced `(...)` call substring and top-level comma arguments."""
    if open_paren_idx < 0 or open_paren_idx >= len(text) or text[open_paren_idx] != "(":
        return "", []
    limit = min(len(text), open_paren_idx + max_chars)
    paren_depth = 0
    brace_depth = 0
    bracket_depth = 0
    quote: Optional[str] = None
    escaped = False
    args: List[str] = []
    arg_start = open_paren_idx + 1

    for idx in range(open_paren_idx, limit):
        ch = text[idx]
        if quote is not None:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            continue
        if ch in ("'", '"', "`"):
            quote = ch
            continue
        if ch == "(":
            paren_depth += 1
        elif ch == ")":
            paren_depth -= 1
            if paren_depth == 0:
                last_arg = text[arg_start:idx].strip()
                if last_arg or args:
                    args.append(last_arg)
                return text[open_paren_idx : idx + 1], args
        elif paren_depth == 1:
            if ch == "{":
                brace_depth += 1
            elif ch == "}":
                brace_depth = max(0, brace_depth - 1)
            elif ch == "[":
                bracket_depth += 1
            elif ch == "]":
                bracket_depth = max(0, bracket_depth - 1)
            elif ch == "," and brace_depth == 0 and bracket_depth == 0:
                args.append(text[arg_start:idx].strip())
                arg_start = idx + 1
    return text[open_paren_idx:limit], args


def _brace_depth_at(content: str, pos: int) -> int:
    """Compute `{` minus `}` depth before character index *pos*, skipping strings."""
    depth = 0
    quote: Optional[str] = None
    escaped = False
    for ch in content[:pos]:
        if quote is not None:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            continue
        if ch in ("'", '"', "`"):
            quote = ch
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth = max(0, depth - 1)
    return depth


def _is_non_escaping_local_container(
    content: str,
    var_name: str,
    *,
    is_member: bool = False,
) -> bool:
    """Return True when *var_name* is declared inside a function/method block and does not escape."""
    if is_member or not var_name:
        return False
    decl_re = re.compile(
        rf"(?:^|[;{{\n])\s*((?:const|let|var)\s+{re.escape(var_name)}\b"
        rf"(?:\s*:[^=;\n]+)?\s*=\s*new\s+(?:Map|Set|WeakMap|WeakSet)\b)",
        re.MULTILINE,
    )
    decls = list(decl_re.finditer(content))
    if not decls:
        return False
    if any(_brace_depth_at(content, match.start(1)) == 0 for match in decls):
        return False
    if re.search(rf"\bexport\b[^\n;]*\b{re.escape(var_name)}\b", content):
        return False
    for ret_match in re.finditer(r"\breturn\b([^;\n]*)", content):
        ret_expr = ret_match.group(1)
        if re.search(
            rf"\b{re.escape(var_name)}\b(?!\s*\.(?:has|get|set|delete|clear|size|keys|values|entries|forEach)\b)",
            ret_expr,
        ):
            return False
    if re.search(rf"[\w$.\]]+\s*=\s*{re.escape(var_name)}\s*(?:[;,\n]|$)", content):
        return False
    return True


def _has_cache_eviction_guard(content: str, var_name: str, is_member: bool) -> bool:
    """Return True when *content* bounds *var_name* by size and deletes/clears entries or uses an LRU container."""
    target_pat = rf"(?:this\.)?{re.escape(var_name)}" if is_member else re.escape(var_name)
    if re.search(
        rf"\b{re.escape(var_name)}\b\s*(?::[^=;\n]+)?=\s*new\s+\w*LRU\w*\s*(?:<[^>]*>)?\s*\(",
        content,
        re.IGNORECASE,
    ):
        return True
    has_size_bound = bool(re.search(
        rf"\b{target_pat}\s*\.\s*size\s*(?:>=|>|<=|<|===?|!==?)\s*[\w$.]+|"
        rf"[\w$.]+\s*(?:<=|<|>=|>)\s*{target_pat}\s*\.\s*size\b|"
        rf"\b{target_pat}\s*\.\s*forEach\s*\([\s\S]{{0,240}}?\b{target_pat}\s*\.\s*delete\s*\(",
        content,
    ))
    if not has_size_bound:
        return False
    return bool(re.search(rf"\b{target_pat}\s*\.\s*(?:delete|clear)\s*\(", content))


# ============================================================
# perf.async — Async Waterfall Detector
# ============================================================

SEQUENTIAL_AWAIT_REGEX = re.compile(
    r"^\s*(?:const|let|var)\s+(\w+)\s*=\s*await\s+"
)

SYNC_IO_REGEX = re.compile(
    r"\b(readFileSync|writeFileSync|existsSync|mkdirSync|readdirSync|"
    r"statSync|unlinkSync|rmdirSync|renameSync|copyFileSync|"
    r"execSync|spawnSync)\s*\("
)

AWAIT_INSIDE_REGEX = re.compile(r"await\s+[\w.$]+\(")

# Variable dependency check: apakah await berikutnya bergantung pada hasil sebelumnya
DEPENDENCY_REGEX = re.compile(
    r"(?:const|let|var)\s+(\w+)\s*=\s*await\s+.*\b({deps})\b"
)


def analyze_async_waterfall(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Migrated dari async_waterfall_detector.py.
    Deteksi: sequential_await, await_in_loop, sync_io.
    """
    findings: List[Dict[str, Any]] = []
    file_map = shared_graph.get("file_map", {})
    node_metadata = shared_graph.get("node_metadata") or {}

    for file_path, raw_content in sorted(file_map.items()):
        if os.path.splitext(file_path)[1].lower() not in _JS_TS_EXTENSIONS:
            continue
        content = _blank_multiline_template_literals(_strip_comments(raw_content))
        lines = content.split("\n")
        node_meta = node_metadata.get(file_path) or {}
        is_test = _is_test_file(file_path) or bool(node_meta.get("is_test"))
        is_cli_context = _is_cli_or_tooling_context(file_path, raw_content, node_meta)

        # --- sequential_await (with dependency check) ---
        await_lines = []
        for i, line in enumerate([] if is_test else lines):
            match = SEQUENTIAL_AWAIT_REGEX.match(line)
            if match:
                await_lines.append({
                    "line": i + 1,
                    "variable": match.group(1),
                    "content": line.strip(),
                })

        # Group consecutive awaits, filter out dependent chains
        if len(await_lines) >= 2:
            groups: List[List[Dict]] = []
            current_group = [await_lines[0]]

            for i in range(1, len(await_lines)):
                prev = await_lines[i - 1]
                curr = await_lines[i]

                # Check apakah curr bergantung pada prev
                prev_var = prev["variable"]
                dep_pattern = re.compile(
                    rf"(?:const|let|var)\s+{re.escape(curr['variable'])}\s*=\s*await\s+.*\b{re.escape(prev_var)}\b"
                )
                is_dependent = dep_pattern.search(curr["content"])
                intervening = lines[prev["line"] - 1 : curr["line"] - 1]
                has_scope_or_branch = (
                    curr["variable"] == prev["variable"]
                    or any(
                        "{" in ln or "}" in ln or "=>" in ln
                        or re.search(r"\b(?:if|else|return|throw|for|while|switch|try|catch)\b", ln)
                        for ln in intervening
                    )
                )

                if curr["line"] - prev["line"] <= 3 and not is_dependent and not has_scope_or_branch:
                    current_group.append(curr)
                else:
                    if len(current_group) >= 2:
                        groups.append(current_group)
                    current_group = [curr]

            if len(current_group) >= 2:
                groups.append(current_group)

            for group in groups:
                findings.append({
                    "type": "sequential_await",
                    "severity": "medium",
                    "file": file_path,
                    "line_start": group[0]["line"],
                    "line_end": group[-1]["line"],
                    "count": len(group),
                    "variables": [item["variable"] for item in group],
                    "observation": (
                        f"{len(group)} independent sequential await statements "
                        f"(lines {group[0]['line']}-{group[-1]['line']}) "
                        f"could potentially be parallelized."
                    ),
                })

        # --- await_in_loop ---
        for i, line in enumerate([] if is_test else lines):
            stripped = line.strip()
            match = AWAIT_INSIDE_REGEX.search(line)
            if not match:
                continue
            if re.search(r"\bawait\s+Promise\.(?:all|allSettled)\s*\(", line):
                continue
            loop_span = _find_enclosing_loop(lines, i, match.start())
            if loop_span is None:
                continue
            header_idx, end_idx = loop_span
            if _is_bounded_retry_loop(lines, header_idx, end_idx) or _is_sequential_or_stream_await(
                lines, header_idx, end_idx, i, line
            ):
                findings.append({
                    "type": "await_in_loop",
                    "severity": "info",
                    "file": file_path,
                    "line": i + 1,
                    "content": stripped,
                    "bounded_retry_guard": True,
                    "observation": (
                        f"await inside bounded retry loop at line {i + 1} "
                        f"(sequential execution guarded by bounded retry)."
                    ),
                })
            else:
                findings.append({
                    "type": "await_in_loop",
                    "severity": "high",
                    "file": file_path,
                    "line": i + 1,
                    "content": stripped,
                    "observation": (
                        f"await inside loop at line {i + 1} — "
                        f"sequential execution per iteration."
                    ),
                })

        # --- sync_io ---
        for i, line in enumerate(lines):
            match = SYNC_IO_REGEX.search(line)
            if match:
                if is_cli_context:
                    findings.append({
                        "type": "sync_io",
                        "severity": "info",
                        "execution_context": "cli_or_tooling_script",
                        "file": file_path,
                        "line": i + 1,
                        "sync_method": match.group(1),
                        "content": line.strip(),
                        "observation": (
                            f"Synchronous I/O '{match.group(1)}' at line {i + 1} "
                            f"in CLI/tooling script context."
                        ),
                    })
                else:
                    findings.append({
                        "type": "sync_io",
                        "severity": "high",
                        "file": file_path,
                        "line": i + 1,
                        "sync_method": match.group(1),
                        "content": line.strip(),
                        "observation": (
                            f"Synchronous I/O '{match.group(1)}' at line {i + 1} "
                            f"blocks the event loop."
                        ),
                    })

    severity_order = {"high": 0, "medium": 1, "low": 2, "info": 3}
    findings.sort(key=lambda f: (severity_order.get(f["severity"], 4), f["file"], f.get("line", 0)))

    return {
        "analyzer": "perf.async",
        "findings": findings,
        "summary": {
            "total_findings": len(findings),
            "by_type": {
                "sequential_await": sum(1 for f in findings if f["type"] == "sequential_await"),
                "await_in_loop": sum(1 for f in findings if f["type"] == "await_in_loop"),
                "sync_io": sum(1 for f in findings if f["type"] == "sync_io"),
            },
        },
    }


# ============================================================
# perf.deopt — V8 Deoptimization Checker
# ============================================================

DELETE_REGEX = re.compile(r"\bdelete\s+[\w.$\[\]'\"]+")
EVAL_REGEX = re.compile(r"(?<![.\w$])(?<!def\s)(?<!function\s)\beval\s*\(")
NEW_FUNC_REGEX = re.compile(r"\bnew\s+Function\s*\(")

# perf.deopt patterns are V8/JavaScript constructs (G4): the `delete`
# operator, `eval()` and `new Function()` do not exist in Kotlin, Rust or
# Python, so this analyzer only reads JS/TS files. Without the gate a
# Kotlin `file.delete()` call — and the English word "delete" inside a
# string literal on the same line — was reported as a V8 deoptimization
# (HelperPairing.kt, oopbot-trial audit).
# Performance analyzers (perf.async, perf.deopt, perf.gc, perf.cache) encode
# V8 / DOM / JS-TS patterns (const/let/var, Promise.all, delete, eval,
# JSON.parse, addEventListener, new Map/WeakMap). Gate all four analyzers to
# JS/TS files so Rust/Kotlin/Python codebases never receive JS-biased drift.
_JS_TS_EXTENSIONS = frozenset({
    ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".mts", ".cts",
})
_DEOPT_JS_TS_EXTENSIONS = _JS_TS_EXTENSIONS


def analyze_deopt(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Migrated dari deopt_checker.py.
    Deteksi: delete_operator, eval_usage, new_function.

    Scope (G4): JS/TS files only (see _DEOPT_JS_TS_EXTENSIONS). String
    literals are blanked per line before the regexes run (see
    _strip_strings): the word "delete" inside a string such as
    "Can't delete $FILE" is not the `delete` operator. Blanking is
    per-line on purpose — a whole-content blank would let an apostrophe
    inside a double-quoted string hide real code on later lines.
    """
    findings: List[Dict[str, Any]] = []
    file_map = shared_graph.get("file_map", {})

    for file_path, raw_content in sorted(file_map.items()):
        if os.path.splitext(file_path)[1].lower() not in _DEOPT_JS_TS_EXTENSIONS:
            continue
        if _is_test_file(file_path):
            continue
        content = _blank_multiline_template_literals(_strip_comments(raw_content))
        lines = content.split("\n")

        for i, line in enumerate(lines):
            stripped = line.strip()
            # Detection runs on the string-blanked line; the finding
            # still records the original line as evidence.
            probe = _strip_strings(line).strip()

            if DELETE_REGEX.search(probe):
                findings.append({
                    "type": "delete_operator",
                    "severity": "high",
                    "file": file_path,
                    "line": i + 1,
                    "content": stripped,
                    "observation": (
                        f"delete operator at line {i + 1} forces V8 into "
                        f"dictionary mode (slow properties)."
                    ),
                })

            if EVAL_REGEX.search(probe):
                findings.append({
                    "type": "eval_usage",
                    "severity": "high",
                    "file": file_path,
                    "line": i + 1,
                    "content": stripped,
                    "observation": (
                        f"eval() at line {i + 1} disables optimization "
                        f"in the enclosing scope."
                    ),
                })

            if NEW_FUNC_REGEX.search(probe):
                findings.append({
                    "type": "new_function",
                    "severity": "high",
                    "file": file_path,
                    "line": i + 1,
                    "content": stripped,
                    "observation": (
                        f"new Function() at line {i + 1} creates "
                        f"unoptimizable dynamic code."
                    ),
                })

    findings.sort(key=lambda f: (f["file"], f.get("line", 0)))

    return {
        "analyzer": "perf.deopt",
        "findings": findings,
        "summary": {
            "total_findings": len(findings),
            "by_type": {
                "delete_operator": sum(1 for f in findings if f["type"] == "delete_operator"),
                "eval_usage": sum(1 for f in findings if f["type"] == "eval_usage"),
                "new_function": sum(1 for f in findings if f["type"] == "new_function"),
            },
        },
    }


# ============================================================
# perf.gc — GC Pressure Analyzer
# ============================================================

JSON_PARSE_REGEX = re.compile(r"JSON\.parse\s*\(")
JSON_STRINGIFY_REGEX = re.compile(r"JSON\.stringify\s*\(")
SET_INTERVAL_REGEX = re.compile(r"(?:const|let|var)\s+(\w+)\s*=\s*setInterval\s*\(")
CLEAR_INTERVAL_REGEX = re.compile(r"clearInterval\s*\(\s*(\w+)\s*\)")
MAP_SET_REGEX = re.compile(
    r"(?:const|let|var|private|public|protected|readonly)\s+"
    r"(\w*(?:cache|Cache|pool|Pool|registry|Registry|store|Store)\w*)\s*"
    r"(?::[^=;\n]+)?=\s*new\s+(Map|Set)\b"
)
OBJ_ALLOC_REGEX = re.compile(r"(?:const|let|var)\s+\w+\s*=\s*\{")
ADD_EVENT_LISTENER_REGEX = re.compile(r"\.addEventListener\s*\(")
REMOVE_EVENT_LISTENER_REGEX = re.compile(r"\.removeEventListener\s*\(")
_LISTENER_AUTO_CLEANUP_REGEX = re.compile(
    r"\bonce\s*:\s*true\b|\bsignal\b(?:\s*[:,}]|\s*$)"
)


def analyze_gc_pressure(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Migrated dari gc_pressure_analyzer.py.
    Deteksi: json_in_loop, allocation_in_loop, uncleared_timer,
             unbounded_collection, unclosed_event_listener.
    """
    findings: List[Dict[str, Any]] = []
    file_map = shared_graph.get("file_map", {})
    node_metadata = shared_graph.get("node_metadata") or {}

    for file_path, raw_content in sorted(file_map.items()):
        if os.path.splitext(file_path)[1].lower() not in _JS_TS_EXTENSIONS:
            continue
        node_meta = node_metadata.get(file_path) or {}
        if _is_test_file(file_path) or bool(node_meta.get("is_test")):
            continue
        is_cli_context = _is_cli_or_tooling_context(file_path, raw_content, node_meta)
        content = _blank_multiline_template_literals(_strip_comments(raw_content))
        lines = content.split("\n")

        # --- json_in_loop & allocation_in_loop ---
        for i, line in enumerate(lines):
            stripped = line.strip()
            json_parse = JSON_PARSE_REGEX.search(line)
            json_stringify = JSON_STRINGIFY_REGEX.search(line)
            allocation = OBJ_ALLOC_REGEX.search(line)
            first_match = min(
                (match for match in (json_parse, json_stringify, allocation) if match),
                key=lambda match: match.start(),
                default=None,
            )
            if first_match is None:
                continue
            loop_span = _find_enclosing_loop(lines, i, first_match.start())
            if loop_span is None:
                continue
            header_idx, end_idx = loop_span
            is_retry_loop = _is_bounded_retry_loop(lines, header_idx, end_idx)

            if json_parse or json_stringify:
                if re.search(r"\b(?:return|throw)\s+.*\bJSON\.(?:parse|stringify)\b", line):
                    continue
                method = "JSON.parse" if json_parse else "JSON.stringify"
                near_window = "\n".join(lines[max(0, header_idx - 6) : min(len(lines), end_idx + 2)])
                is_stream_or_try_json = bool(
                    re.search(
                        r"\bdecoder\.decode\b|\.split\(\s*['\"]\\n['\"]\s*\)|\bfor\s+await\s*\(|\.write\s*\(\s*JSON\.stringify",
                        near_window,
                    )
                    or (
                        json_parse is not None
                        and re.search(r"\btry\s*\{", "\n".join(lines[max(0, i - 6) : i + 1]))
                    )
                )
                if is_cli_context or is_retry_loop or is_stream_or_try_json:
                    findings.append({
                        "type": "json_in_loop",
                        "severity": "info",
                        "execution_context": "cli_or_tooling_script",
                        "file": file_path,
                        "line": i + 1,
                        "content": stripped,
                        "observation": f"{method} inside loop at line {i + 1} in CLI/tooling script context.",
                    })
                else:
                    findings.append({
                        "type": "json_in_loop",
                        "severity": "high",
                        "file": file_path,
                        "line": i + 1,
                        "content": stripped,
                        "observation": f"{method} inside loop at line {i + 1}.",
                    })

            if allocation:
                findings.append({
                    "type": "allocation_in_loop",
                    "severity": "medium",
                    "file": file_path,
                    "line": i + 1,
                    "content": stripped,
                    "observation": f"Object allocation inside loop at line {i + 1}.",
                })

        # --- uncleared_timer ---
        interval_vars: List[Tuple[str, int]] = []
        cleared_vars: Set[str] = set()

        for i, line in enumerate(lines):
            stripped = line.strip()
            match = SET_INTERVAL_REGEX.search(stripped)
            if match:
                interval_vars.append((match.group(1), i + 1))
            clear_match = CLEAR_INTERVAL_REGEX.search(stripped)
            if clear_match:
                cleared_vars.add(clear_match.group(1))

        for var_name, line_num in interval_vars:
            if var_name not in cleared_vars:
                findings.append({
                    "type": "uncleared_timer",
                    "severity": "high",
                    "file": file_path,
                    "line": line_num,
                    "variable": var_name,
                    "observation": (
                        f"setInterval '{var_name}' at line {line_num} "
                        f"without clearInterval (timer leak)."
                    ),
                })

        # --- unbounded_collection ---
        for i, line in enumerate(lines):
            match = MAP_SET_REGEX.search(line.strip())
            if match:
                var_name = match.group(1)
                coll_type = match.group(2)
                if _is_non_escaping_local_container(content, var_name, is_member=False):
                    continue
                has_cleanup = bool(re.search(
                    rf"{re.escape(var_name)}\.(?:delete|clear)\s*\(|"
                    rf"{re.escape(var_name)}\.size\s*[<>]",
                    content
                ))
                if not has_cleanup:
                    findings.append({
                        "type": "unbounded_collection",
                        "severity": "medium",
                        "file": file_path,
                        "line": i + 1,
                        "variable": var_name,
                        "collection_type": coll_type,
                        "observation": (
                            f"new {coll_type}() '{var_name}' at line {i + 1} "
                            f"without apparent size limit or cleanup."
                        ),
                    })

        # --- unclosed_event_listener ---
        norm_gc_path = _normalize_path(file_path).lower()
        is_sw_file = bool(re.search(r"(?:^|/)(?:sw|service-worker|ngsw-worker)\.[jt]s$", norm_gc_path))
        if not is_sw_file and ADD_EVENT_LISTENER_REGEX.search(content) and not REMOVE_EVENT_LISTENER_REGEX.search(content):
            for match in ADD_EVENT_LISTENER_REGEX.finditer(content):
                _, call_args = _extract_paren_call_and_args(content, match.end() - 1)
                if (
                    len(call_args) >= 1
                    and content[max(0, match.start() - 4) : match.start()] == "self"
                    and re.match(
                        r"^['\"](?:install|activate|fetch|message|push|sync|notificationclick)['\"]$",
                        call_args[0].strip(),
                    )
                ):
                    continue
                if len(call_args) >= 3:
                    opts_arg = _strip_strings(call_args[2])
                    if _LISTENER_AUTO_CLEANUP_REGEX.search(opts_arg):
                        continue
                line_num = content[: match.start()].count("\n") + 1
                line_content = lines[line_num - 1].strip() if 0 <= line_num - 1 < len(lines) else ""
                findings.append({
                    "type": "unclosed_event_listener",
                    "severity": "high",
                    "file": file_path,
                    "line": line_num,
                    "content": line_content,
                    "observation": (
                        f"addEventListener at line {line_num} without "
                        f"corresponding removeEventListener (memory leak)."
                    ),
                })
                break  # satu finding per file cukup

    severity_order = {"high": 0, "medium": 1, "low": 2, "info": 3}
    findings.sort(key=lambda f: (severity_order.get(f["severity"], 4), f["file"], f.get("line", 0)))

    return {
        "analyzer": "perf.gc",
        "findings": findings,
        "summary": {
            "total_findings": len(findings),
            "by_type": {
                "json_in_loop": sum(1 for f in findings if f["type"] == "json_in_loop"),
                "allocation_in_loop": sum(1 for f in findings if f["type"] == "allocation_in_loop"),
                "uncleared_timer": sum(1 for f in findings if f["type"] == "uncleared_timer"),
                "unbounded_collection": sum(1 for f in findings if f["type"] == "unbounded_collection"),
                "unclosed_event_listener": sum(1 for f in findings if f["type"] == "unclosed_event_listener"),
            },
        },
    }


# ============================================================
# perf.cache — Cache Auditor
# ============================================================

CACHE_SET_REGEX = re.compile(
    r"(\w*(?:cache|Cache)\w*)\s*\.\s*set\s*\("
)
NONDETERMINISTIC_KEY_REGEX = re.compile(
    r"(?:key|Key|cacheKey|cache_key)\s*=.*"
    r"(Date\.now\s*\(\)|Math\.random\s*\(\)|crypto\.randomUUID\s*\(\))"
)
KEY_CONCAT_REGEX = re.compile(
    r"(?:key|Key|cacheKey|cache_key)\s*=\s*[\w.'\"\[\]]+\s*\+\s*[\w.'\"\[\]]+"
)
TTL_MECHANISM_REGEX = re.compile(
    r"(?:ttl|TTL|expire|expiry|expiration|maxAge|max_age|timeToLive|"
    r"setTimeout.*(?:delete|remove|clear|evict))",
    re.IGNORECASE
)


def analyze_cache(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Migrated dari cache_auditor.py.
    Deteksi: nondeterministic_cache_key, key_collision_risk, missing_ttl, unbounded_cache.
    """
    findings: List[Dict[str, Any]] = []
    file_map = shared_graph.get("file_map", {})
    node_metadata = shared_graph.get("node_metadata") or {}

    for file_path, raw_content in sorted(file_map.items()):
        if os.path.splitext(file_path)[1].lower() not in _JS_TS_EXTENSIONS:
            continue
        node_meta = node_metadata.get(file_path) or {}
        if _is_test_file(file_path) or bool(node_meta.get("is_test")):
            continue
        content = _blank_multiline_template_literals(_strip_comments(raw_content))
        lines = content.split("\n")

        # Skip file yang tidak punya cache context
        if not CACHE_SET_REGEX.search(content):
            continue

        has_ttl = bool(TTL_MECHANISM_REGEX.search(content))
        local_cache: Dict[Tuple[str, bool], bool] = {}
        eviction_cache: Dict[Tuple[str, bool], bool] = {}

        for i, line in enumerate(lines):
            stripped = line.strip()

            # --- nondeterministic_cache_key ---
            nondet_match = NONDETERMINISTIC_KEY_REGEX.search(stripped)
            if nondet_match:
                findings.append({
                    "type": "nondeterministic_cache_key",
                    "severity": "high",
                    "file": file_path,
                    "line": i + 1,
                    "value_used": nondet_match.group(1),
                    "content": stripped,
                    "observation": (
                        f"Non-deterministic value in cache key at line {i + 1}: "
                        f"{nondet_match.group(1)}."
                    ),
                })

            # --- key_collision_risk ---
            if KEY_CONCAT_REGEX.search(stripped):
                has_delimiter = bool(re.search(r"['\"][\-:_|.]+['\"]", stripped))
                if not has_delimiter:
                    findings.append({
                        "type": "key_collision_risk",
                        "severity": "medium",
                        "file": file_path,
                        "line": i + 1,
                        "content": stripped,
                        "observation": (
                            f"Cache key concatenation without delimiter "
                            f"at line {i + 1} (collision risk)."
                        ),
                    })

            # --- missing_ttl & unbounded_cache ---
            cache_match = CACHE_SET_REGEX.search(stripped)
            if cache_match and not has_ttl:
                var_name = cache_match.group(1)
                prefix = stripped[: cache_match.start()]
                is_member = prefix.endswith(".")
                if re.search(
                    rf"\b{re.escape(var_name)}\b\s*(?::[^=;\n]+)?=\s*new\s+Weak(?:Map|Set)\b",
                    content,
                ):
                    continue
                key = (var_name, is_member)
                if key not in local_cache:
                    local_cache[key] = _is_non_escaping_local_container(
                        content, var_name, is_member=is_member
                    )
                if local_cache[key]:
                    continue
                if key not in eviction_cache:
                    eviction_cache[key] = _has_cache_eviction_guard(content, var_name, is_member)
                if eviction_cache[key]:
                    findings.append({
                        "type": "missing_ttl",
                        "severity": "low",
                        "eviction_guard": True,
                        "file": file_path,
                        "line": i + 1,
                        "variable": var_name,
                        "content": stripped,
                        "observation": (
                            f"cache.set() on '{var_name}' at line {i + 1} "
                            f"has capacity eviction guard without TTL/expiration mechanism."
                        ),
                    })
                else:
                    findings.append({
                        "type": "missing_ttl",
                        "severity": "medium",
                        "file": file_path,
                        "line": i + 1,
                        "variable": var_name,
                        "content": stripped,
                        "observation": (
                            f"cache.set() on '{var_name}' at line {i + 1} "
                            f"without TTL/expiration mechanism."
                        ),
                    })
                    findings.append({
                        "type": "unbounded_cache",
                        "severity": "medium",
                        "file": file_path,
                        "line": i + 1,
                        "variable": var_name,
                        "content": stripped,
                        "observation": (
                            f"Unbounded cache collection '{var_name}' at line {i + 1}."
                        ),
                    })

    severity_order = {"high": 0, "medium": 1, "low": 2, "info": 3}
    findings.sort(key=lambda f: (severity_order.get(f["severity"], 4), f["file"], f.get("line", 0)))

    return {
        "analyzer": "perf.cache",
        "findings": findings,
        "summary": {
            "total_findings": len(findings),
            "by_type": {
                "nondeterministic_cache_key": sum(1 for f in findings if f["type"] == "nondeterministic_cache_key"),
                "key_collision_risk": sum(1 for f in findings if f["type"] == "key_collision_risk"),
                "missing_ttl": sum(1 for f in findings if f["type"] == "missing_ttl"),
                "unbounded_cache": sum(1 for f in findings if f["type"] == "unbounded_cache"),
            },
        },
    }
