"""
HoTT Analyzers — HoTT Kernel
Schema Version: 3.0.0-kernel

Migrated dari Proto-HoTT standalone tools:
- type_isomorphism_observer.py    → hott.isomorphism
- boundary_sheaf_checker.py       → hott.sheaf
- homotopy_path_observer.py       → hott.homotopy
- topological_manifold_builder.py → hott.manifold

Semua analyzer mengonsumsi SharedGraph. Tidak ada os.walk() di sini.
"""

import os
import re
from typing import Any, Dict, List, Optional, Set, Tuple

from language_semantics import strip_js_comments as _strip_comments


# ============================================================
# Shared Helpers
# ============================================================

class _UnionFind:
    """Union-Find untuk connected components."""
    def __init__(self, items: List[str]):
        self.parent = {x: x for x in items}
        self.rank = {x: 0 for x in items}

    def find(self, x: str) -> str:
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x: str, y: str) -> bool:
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return False
        if self.rank[rx] < self.rank[ry]:
            rx, ry = ry, rx
        self.parent[ry] = rx
        if self.rank[rx] == self.rank[ry]:
            self.rank[rx] += 1
        return True


def _saturate(x: float, half_point: float) -> float:
    if x <= 0:
        return 0.0
    if half_point <= 0:
        return 1.0
    return x / (x + half_point)


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def _tree_path(
    adjacency: Dict[str, Set[str]],
    start: str,
    target: str,
) -> List[str]:
    """Return the deterministic path between two nodes in a forest."""
    parents: Dict[str, Optional[str]] = {start: None}
    queue = [start]
    cursor = 0

    while cursor < len(queue):
        node = queue[cursor]
        cursor += 1
        if node == target:
            break
        for neighbor in sorted(adjacency.get(node, set())):
            if neighbor not in parents:
                parents[neighbor] = node
                queue.append(neighbor)

    if target not in parents:
        return []

    path: List[str] = []
    current: Optional[str] = target
    while current is not None:
        path.append(current)
        current = parents[current]
    path.reverse()
    return path


def _build_undirected_cycle_basis(
    vertices: List[str],
    edges: List[Tuple[str, str]],
    edge_natures: Optional[Dict[str, str]] = None,
    non_cyclic_edges: Optional[Set[Tuple[str, str]]] = None,
) -> List[Dict[str, Any]]:
    """
    Build deterministic fundamental-cycle witnesses for the undirected graph.

    Betti-1 ignores import orientation. Each non-tree edge closes exactly one
    basis cycle; orientation is then restored as evidence for interpretation.
    """
    if not vertices:
        return []

    natures = edge_natures or {}
    non_cyclic = non_cyclic_edges or set()
    union_find = _UnionFind(vertices)
    tree: Dict[str, Set[str]] = {vertex: set() for vertex in vertices}
    directed_edges = set(map(tuple, edges))
    # Prefer runtime edges in the spanning tree before type_only/same_package edges
    # so basis cycles do not artificially route through compiler-elided edges.
    undirected_edges = sorted(
        (
            0 if natures.get(f"{source} -> {target}", natures.get((source, target), "runtime")) == "runtime" else 1,
            min(source, target),
            max(source, target),
            source,
            target,
        )
        for source, target in directed_edges
    )
    basis: List[Dict[str, Any]] = []

    for _, source, target, directed_source, directed_target in undirected_edges:
        if source != target and union_find.union(source, target):
            tree[source].add(target)
            tree[target].add(source)
            continue

        if source == target:
            closed_path = [source, source]
        else:
            path = _tree_path(tree, source, target)
            if not path:
                continue
            closed_path = path + [source]

        witness_edges: List[Dict[str, Any]] = []
        forward_runtime_aligned = True
        reverse_runtime_aligned = True
        forward_syntactic_aligned = True
        reverse_syntactic_aligned = True
        for left, right in zip(closed_path, closed_path[1:]):
            observed_directions: List[List[str]] = []
            if (left, right) in directed_edges:
                observed_directions.append([left, right])
                fwd_nature = natures.get(f"{left} -> {right}", natures.get((left, right), "runtime"))
                if fwd_nature == "same_package" or (left, right) in non_cyclic:
                    forward_syntactic_aligned = False
                    forward_runtime_aligned = False
                elif fwd_nature == "type_only":
                    forward_runtime_aligned = False
            else:
                forward_syntactic_aligned = False
                forward_runtime_aligned = False
            if (right, left) in directed_edges:
                observed_directions.append([right, left])
                rev_nature = natures.get(f"{right} -> {left}", natures.get((right, left), "runtime"))
                if rev_nature == "same_package" or (right, left) in non_cyclic:
                    reverse_syntactic_aligned = False
                    reverse_runtime_aligned = False
                elif rev_nature == "type_only":
                    reverse_runtime_aligned = False
            else:
                reverse_syntactic_aligned = False
                reverse_runtime_aligned = False
            witness_edges.append({
                "undirected_edge": [left, right],
                "observed_directions": observed_directions,
            })

        if forward_runtime_aligned or reverse_runtime_aligned:
            orientation = "directed"
            interpretation = "directed_import_cycle_witness"
        elif forward_syntactic_aligned or reverse_syntactic_aligned:
            orientation = "type_only_directed"
            interpretation = "type_only_cycle_witness"
        else:
            orientation = "mixed"
            interpretation = "reconvergent_dependency_cycle_witness"
        basis.append({
            "basis_index": len(basis) + 1,
            "vertices": closed_path[:-1],
            "closed_path": closed_path,
            "length": len(closed_path) - 1,
            "closing_edge": [directed_source, directed_target],
            "orientation": orientation,
            "interpretation": interpretation,
            "witness_edges": witness_edges,
        })

    return basis


# ============================================================
# hott.isomorphism — Type Isomorphism Observer
# ============================================================

def analyze_isomorphism(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Migrated dari type_isomorphism_observer.py.
    Mendeteksi pasangan type/interface yang secara struktural isomorfik.

    Menggunakan shared_graph["type_shapes"] yang sudah di-extract
    oleh SharedGraph builder. Tidak perlu parse file lagi.
    """
    findings: List[Dict[str, Any]] = []
    type_shapes = shared_graph.get("type_shapes", {})

    # Kumpulkan semua type entries: (file, type_name, properties)
    all_types: List[Tuple[str, str, List[str]]] = []
    for file_path, shapes in sorted(type_shapes.items()):
        for type_name, props in sorted(shapes.items()):
            all_types.append((file_path, type_name, props))

    # Bandingkan setiap pair
    for i in range(len(all_types)):
        for j in range(i + 1, len(all_types)):
            file_a, name_a, props_a = all_types[i]
            file_b, name_b, props_b = all_types[j]

            # Skip jika di file yang sama dan nama sama (diri sendiri)
            if file_a == file_b and name_a == name_b:
                continue

            # Isomorfik jika property sets identik dan tidak kosong
            if props_a == props_b and len(props_a) > 0:
                findings.append({
                    "type": "structural_isomorphism",
                    "severity": "low",
                    "file": file_a,
                    "file_b": file_b,
                    "space_a": {
                        "name": name_a,
                        "file": file_a,
                        "property_count": len(props_a),
                        "properties": props_a,
                    },
                    "space_b": {
                        "name": name_b,
                        "file": file_b,
                        "property_count": len(props_b),
                        "properties": props_b,
                    },
                    "isomorphism_confidence": 0.95,
                    "observation": (
                        f"Type spaces '{name_a}' ({file_a}) and '{name_b}' ({file_b}) "
                        f"are structurally isomorphic ({len(props_a)} properties: {', '.join(props_a[:5])}{'...' if len(props_a) > 5 else ''})."
                    ),
                    "invariant": "univalence_candidate",
                })

    findings.sort(key=lambda f: (f["file"], f["space_a"]["name"]))

    return {
        "analyzer": "hott.isomorphism",
        "findings": findings,
        "summary": {
            "total_shapes": len(all_types),
            "isomorphic_pair_count": len(findings),
        },
    }


# ============================================================
# hott.sheaf — Boundary Sheaf Checker
# ============================================================

def analyze_sheaf(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Migrated dari boundary_sheaf_checker.py.
    Mendeteksi boundary obstructions:
    - boundary_without_public_api
    - boundary_violation (bypass barrel)
    - circular_boundary
    """
    findings: List[Dict[str, Any]] = []
    boundaries = shared_graph.get("boundaries", {})
    file_to_boundary = shared_graph.get("file_to_boundary", {})
    resolved_imports = shared_graph.get("resolved_imports", {})
    edge_natures = shared_graph.get("edge_natures", {})
    node_metadata = shared_graph.get("node_metadata") or {}
    _JS_TS_EXTENSIONS = frozenset({
        ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".mts", ".cts",
    })
    test_re = re.compile(
        r"(?:^|/)(?:tests?|__tests__|spec)/|"
        r"(?:^|/)src/(?:test|androidTest)/|"
        r"(?:\.(?:spec|test)\.[A-Za-z0-9]+$)|"
        r"(?:^|/)(?:test_[^/]+|[^/]+_test)\.py$",
        re.IGNORECASE,
    )
    test_case_re = re.compile(r"(?:(?:Test|Tests|Spec)\.kt|_test\.rs)$")

    def _is_sheaf_test_file(fpath: str) -> bool:
        if bool((node_metadata.get(fpath) or {}).get("is_test")):
            return True
        norm = str(fpath).replace("\\", "/")
        return bool(test_re.search(norm) or test_case_re.search(os.path.basename(norm)))

    def _is_nested_boundary_pair(b_a: str, b_b: str) -> bool:
        na = str(b_a).replace("\\", "/").rstrip("/")
        nb = str(b_b).replace("\\", "/").rstrip("/")
        return na.startswith(nb + "/") or nb.startswith(na + "/")

    # Build set of barrel files untuk quick lookup
    barrel_files: Set[str] = set()
    for bpath, bdata in boundaries.items():
        if bdata.get("barrel"):
            barrel_files.add(bdata["barrel"])

    # Track boundaries yang diimpor cross-boundary
    cross_boundary_targets: Dict[str, Set[str]] = {}  # target_boundary -> set of source_boundaries

    # --- Deteksi boundary_violation dan kumpulkan cross-boundary info ---
    for src_file, targets in sorted(resolved_imports.items()):
        if _is_sheaf_test_file(src_file) or src_file in barrel_files:
            continue
        src_boundary = file_to_boundary.get(src_file)
        if not src_boundary:
            continue

        for tgt_file in targets:
            if edge_natures.get(f"{src_file} -> {tgt_file}", "runtime") == "same_package":
                continue
            tgt_boundary = file_to_boundary.get(tgt_file)
            if not tgt_boundary or tgt_boundary == src_boundary:
                continue
            if _is_nested_boundary_pair(src_boundary, tgt_boundary):
                continue

            # Cross-boundary import terdeteksi
            if tgt_boundary not in cross_boundary_targets:
                cross_boundary_targets[tgt_boundary] = set()
            cross_boundary_targets[tgt_boundary].add(src_boundary)

            # Check apakah import bypass barrel
            tgt_barrel = boundaries.get(tgt_boundary, {}).get("barrel")
            if tgt_barrel:
                barrel_no_ext = tgt_barrel.rsplit(".", 1)[0] if "." in tgt_barrel else tgt_barrel
                is_via_barrel = (
                    tgt_file == tgt_barrel
                    or tgt_file == barrel_no_ext
                    or tgt_file == tgt_boundary
                )
                if not is_via_barrel:
                    findings.append({
                        "type": "boundary_violation",
                        "severity": "high",
                        "file": src_file,
                        "source_boundary": src_boundary,
                        "target_file": tgt_file,
                        "target_boundary": tgt_boundary,
                        "observation": (
                            f"Import from '{src_boundary}' bypasses barrel of "
                            f"'{tgt_boundary}' — accesses '{tgt_file}' directly."
                        ),
                        "invariant": "H1_encapsulation_leak",
                    })

    # --- Deteksi boundary_without_public_api ---
    # JS/TS barrel files (index.ts / public-api.ts) do not exist in Kotlin and
    # are optional in Rust 2018+/Python namespace packages. Only emit
    # boundary_without_public_api when the boundary contains JS/TS files (or
    # has an empty/synthetic file list without language metadata).
    for tgt_boundary, src_boundaries in sorted(cross_boundary_targets.items()):
        b_meta = boundaries.get(tgt_boundary, {})
        tgt_barrel = b_meta.get("barrel")
        b_files = b_meta.get("files") or []
        if b_files and not any(
            os.path.splitext(p)[1].lower() in _JS_TS_EXTENSIONS for p in b_files
        ):
            continue
        if not tgt_barrel:
            findings.append({
                "type": "boundary_without_public_api",
                "severity": "low",
                "boundary": tgt_boundary,
                "observation": (
                    f"Boundary '{tgt_boundary}' is imported cross-boundary "
                    f"but has no barrel file. No explicit public API surface declared."
                ),
                "invariant": "H0_missing_public_api",
            })

    # --- Deteksi circular_boundary ---
    # Build boundary-level adjacency
    boundary_graph: Dict[str, Set[str]] = {}
    for src_file, targets in resolved_imports.items():
        if _is_sheaf_test_file(src_file):
            continue
        src_boundary = file_to_boundary.get(src_file)
        if not src_boundary:
            continue
        for tgt_file in targets:
            if edge_natures.get(f"{src_file} -> {tgt_file}", "runtime") == "same_package":
                continue
            tgt_boundary = file_to_boundary.get(tgt_file)
            if tgt_boundary and tgt_boundary != src_boundary and not _is_nested_boundary_pair(src_boundary, tgt_boundary):
                if src_boundary not in boundary_graph:
                    boundary_graph[src_boundary] = set()
                boundary_graph[src_boundary].add(tgt_boundary)

    # DFS cycle detection
    visited: Set[str] = set()
    rec_stack: Set[str] = set()
    cycles_found: List[List[str]] = []

    def _dfs(node: str, path: List[str]) -> None:
        visited.add(node)
        rec_stack.add(node)
        path.append(node)

        for neighbor in sorted(boundary_graph.get(node, set())):
            if neighbor not in visited:
                _dfs(neighbor, path)
            elif neighbor in rec_stack:
                cycle_start = path.index(neighbor)
                cycle = path[cycle_start:] + [neighbor]
                cycles_found.append(cycle)

        path.pop()
        rec_stack.discard(node)

    for node in sorted(boundary_graph.keys()):
        if node not in visited:
            _dfs(node, [])

    seen_cycles: Set[str] = set()
    for cycle in cycles_found:
        min_idx = cycle.index(min(cycle[:-1]))
        normalized = cycle[min_idx:] + cycle[1:min_idx + 1]
        cycle_key = " -> ".join(normalized)
        if cycle_key not in seen_cycles:
            seen_cycles.add(cycle_key)
            findings.append({
                "type": "circular_boundary",
                "severity": "high",
                "cycle": normalized,
                "cycle_length": len(normalized) - 1,
                "observation": (
                    f"Circular dependency across {len(normalized) - 1} boundaries: "
                    f"{cycle_key}"
                ),
                "invariant": "H1_coboundary_cycle",
            })

    severity_order = {"high": 0, "medium": 1, "low": 2}
    findings.sort(key=lambda f: (severity_order.get(f["severity"], 3), f.get("type", "")))

    return {
        "analyzer": "hott.sheaf",
        "findings": findings,
        "summary": {
            "total_boundaries": len(boundaries),
            "total_obstructions": len(findings),
            "total_findings": len(findings),
            "by_type": {
                "boundary_violation": sum(1 for f in findings if f["type"] == "boundary_violation"),
                "boundary_without_public_api": sum(1 for f in findings if f["type"] == "boundary_without_public_api"),
                "circular_boundary": sum(1 for f in findings if f["type"] == "circular_boundary"),
            },
        },
    }


# ============================================================
# hott.homotopy — Homotopy Path Observer
# ============================================================

def analyze_homotopy(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Migrated dari homotopy_path_observer.py.
    Mendeteksi:
    - diamond_dependency (dua jalur homotopic)
    - multi_importer_hub (node dengan banyak jalur masuk)
    - mergeable_import (multiple imports dari specifier yang sama dalam satu file)
    """
    findings: List[Dict[str, Any]] = []
    vertices = shared_graph.get("vertices", [])
    edges = shared_graph.get("edges", [])
    file_map = shared_graph.get("file_map", {})

    # Build adjacency
    forward: Dict[str, Set[str]] = {}   # src -> targets
    reverse: Dict[str, Set[str]] = {}   # tgt -> sources

    for src, tgt in edges:
        forward.setdefault(src, set()).add(tgt)
        reverse.setdefault(tgt, set()).add(src)

    # --- mergeable_import ---
    import_stmt_regex = re.compile(r"""(?:import\s+(?:(?:\{[^}]*\}|[\w$*]+|\*\s+as\s+[\w$]+)\s+from\s+)?['"]([^'"]+)['"]|import\s+['"]([^'"]+)['"])""")
    for file_path, content in sorted(file_map.items()):
        specifier_counts: Dict[str, List[int]] = {}
        for idx, line in enumerate(content.splitlines(), start=1):
            m = import_stmt_regex.search(line)
            if m:
                spec = m.group(1) or m.group(2)
                if spec:
                    specifier_counts.setdefault(spec, []).append(idx)
        for spec, lines in sorted(specifier_counts.items()):
            if len(lines) > 1:
                findings.append({
                    "type": "mergeable_import",
                    "severity": "low",
                    "file": file_path,
                    "specifier": spec,
                    "lines": lines,
                    "observation": f"Multiple imports from '{spec}' in {file_path} at lines {lines}.",
                    "invariant": "homotopy_mergeable",
                })

    # --- diamond_dependency ---
    # One finding per (source, convergence) group, not one per path
    # pair: a shared foundation imported by N modules otherwise
    # explodes combinatorially (46 findings for 16 groups on the
    # reference project). Barrel files (index.*) and test files are
    # not diamond sources: a barrel only re-exports, it adds no
    # design information of its own.
    # Severity is "info" by default: in a layered DAG, reconverging
    # on a shared foundation is normal modularity, not a defect.
    # It escalates to "medium" only when the convergence file
    # exports mutable shared state (mechanical check below), the
    # one case where two paths can couple implicitly.
    _BARREL_BASENAMES = {
        "index.ts", "index.js", "index.tsx", "index.jsx",
        "index.mts", "index.cts",
    }
    _MUTABLE_REASSIGNABLE_EXPORT_RE = re.compile(
        r"^\s*export\s+(?:declare\s+)?(?:let|var)\s+[A-Za-z_$][\w$]*",
        re.MULTILINE,
    )
    _MUTABLE_INSTANCE_EXPORT_RE = re.compile(
        r"^\s*export\s+(?:default\s+|const\s+[A-Za-z_$][\w$]*(?:\s*:[^=;\n]+)?\s*=\s*)new\s+([A-Za-z_$][\w$.]*)\s*\(",
        re.MULTILINE,
    )
    _IMMUTABLE_EXPORT_CTOR_NAMES = frozenset({
        "RegExp", "URL", "URLSearchParams", "Error", "TypeError", "RangeError",
        "SyntaxError", "TextEncoder", "TextDecoder", "Date",
    })
    _IMMUTABLE_EXPORT_GUARD_RE = re.compile(
        r"\bas\s+const\b|\bObject\.freeze\s*\(|:\s*(?:readonly\b|Readonly(?:Array)?\s*<)"
    )

    node_metadata = shared_graph.get("node_metadata") or {}

    def _is_barrel_or_test(path: str) -> bool:
        if bool((node_metadata.get(path) or {}).get("is_test")):
            return True
        norm = path.replace("\\", "/")
        base = norm.rsplit("/", 1)[-1]
        if base in _BARREL_BASENAMES or base in ("mod.rs", "lib.rs"):
            return True
        if ".spec." in base or ".test." in base:
            return True
        if base.endswith(("Test.kt", "Tests.kt", "Spec.kt", "_test.rs")):
            return True
        wrapped = "/" + norm.lstrip("/")
        return (
            "/tests/" in wrapped
            or "/__tests__/" in wrapped
            or "/src/test/" in wrapped
            or "/src/androidTest/" in wrapped
        )

    def _convergence_has_mutable_state(path: str) -> bool:
        content = _strip_comments(file_map.get(path, ""))
        if not content:
            return False
        if _MUTABLE_REASSIGNABLE_EXPORT_RE.search(content):
            return True
        for match in _MUTABLE_INSTANCE_EXPORT_RE.finditer(content):
            ctor_name = (match.group(1) or "").rsplit(".", 1)[-1]
            if ctor_name in _IMMUTABLE_EXPORT_CTOR_NAMES:
                continue
            stmt_end = content.find(";", match.start())
            stmt = content[match.start() : (stmt_end + 1 if stmt_end != -1 else match.start() + 512)]
            if _IMMUTABLE_EXPORT_GUARD_RE.search(stmt):
                continue
            return True
        return False

    diamond_groups: Dict[Tuple[str, str], List[Tuple[str, str]]] = {}

    for node_d, importers in sorted(reverse.items()):
        if len(importers) < 2:
            continue

        importer_list = sorted(importers)
        for i in range(len(importer_list)):
            for j in range(i + 1, len(importer_list)):
                node_b = importer_list[i]
                node_c = importer_list[j]

                # Cari common dependents (A yang mengimpor B dan C)
                dependents_b = reverse.get(node_b, set())
                dependents_c = reverse.get(node_c, set())
                common_a = dependents_b & dependents_c

                for node_a in sorted(common_a):
                    if _is_barrel_or_test(node_a):
                        continue
                    key = (node_a, node_d)
                    pair = (min(node_b, node_c), max(node_b, node_c))
                    pairs = diamond_groups.setdefault(key, [])
                    if pair not in pairs:
                        pairs.append(pair)

    for (node_a, node_d), pairs in sorted(diamond_groups.items()):
        pairs = sorted(pairs)
        intermediates = sorted({x for pair in pairs for x in pair})
        first_b, first_c = pairs[0]
        severity = "medium" if _convergence_has_mutable_state(node_d) else "info"
        findings.append({
            "type": "diamond_dependency",
            "severity": severity,
            "source": node_a,
            "path_one": [node_a, first_b, node_d],
            "path_two": [node_a, first_c, node_d],
            "intermediate_nodes": intermediates,
            "diamond_count": len(pairs),
            "convergence": node_d,
            "observation": (
                f"{len(pairs)} reconvergent path pair(s) from '{node_a}' to '{node_d}' "
                f"via {', '.join(repr(x) for x in intermediates)}. "
                + (
                    "Convergence exports mutable shared state: treat as implicit coupling."
                    if severity == "medium" else
                    "Shared foundation in a layered DAG: normal modularity, not a defect."
                )
            ),
            "invariant": "H1_multiple_paths",
        })

    # --- multi_importer_hub ---
    HUB_THRESHOLD = 4
    for node, importers in sorted(reverse.items()):
        if len(importers) >= HUB_THRESHOLD:
            findings.append({
                "type": "multi_importer_hub",
                "severity": "low",
                "node": node,
                "importer_count": len(importers),
                "observation": (
                    f"Node '{node}' is a path-concentration hub with "
                    f"{len(importers)} incoming import paths."
                ),
                "invariant": "H0_path_concentration",
            })

    severity_order = {"high": 0, "medium": 1, "low": 2}
    findings.sort(key=lambda f: (severity_order.get(f["severity"], 3), f.get("type", "")))

    return {
        "analyzer": "hott.homotopy",
        "findings": findings,
        "summary": {
            "total_files": len(vertices),
            "total_edges": len(edges),
            "total_obstructions": len(findings),
            "total_findings": len(findings),
            "by_type": {
                "diamond_dependency": sum(1 for f in findings if f["type"] == "diamond_dependency"),
                "multi_importer_hub": sum(1 for f in findings if f["type"] == "multi_importer_hub"),
                "mergeable_import": sum(1 for f in findings if f["type"] == "mergeable_import"),
            },
        },
    }


# ============================================================
# hott.manifold — Topological Manifold Builder
# ============================================================

def _classify_archetype(
    beta_0: int, beta_1: int, beta_2: int,
    average_degree: float, vertex_count: int,
    directed_cycles: int = 0,
) -> Tuple[str, str, float]:
    """Archetype classification TERKALIBRASI (avg_degree + fragmentasi).

    directed_cycles counts basis cycles with directed orientation
    (topo.circular == 0 implies 0 here). beta_1 counts INDEPENDENT
    cycles of the UNDERLYING UNDIRECTED graph, so a healthy layered
    DAG full of diamonds has beta_1 > 0 with directed_cycles == 0:
    labelling that "mixed_cyclic" misleads agents into breaking
    cycles that do not exist. Pure reconvergence gets its own
    labels (no "cyclic" in the name, so steer_decoder does not
    pick cycle_breaking_and_layering for it).
    """
    if vertex_count == 0:
        return "empty", "No topological structure", 1.0
    if vertex_count == 1:
        return "trivial", "Single isolated node", 1.0

    is_fragmented = beta_0 > 1
    has_cycles = beta_1 > 0 or beta_2 > 0

    if not has_cycles:
        if not is_fragmented:
            return "tree_like", "Connected acyclic (hierarchical tree)", 0.95
        else:
            return "modular", f"{beta_0} disconnected acyclic components", 0.90

    # Pure undirected reconvergence (diamonds): a DAG, not a cycle.
    if directed_cycles == 0:
        if is_fragmented:
            return (
                "fragmented_reconvergent_dag",
                f"{beta_0} components with {beta_1} reconvergent path(s), no directed cycles",
                0.85,
            )
        return (
            "reconvergent_dag",
            f"Connected DAG with {beta_1} reconvergent path(s), no directed cycles (avg degree {average_degree:.2f})",
            0.90,
        )

    if is_fragmented:
        if average_degree < 2.5:
            return (
                "fragmented_sparse_cyclic",
                f"{beta_0} components with {beta_1} cycles; sparse (avg degree {average_degree:.2f})",
                0.80,
            )
        else:
            return (
                "fragmented_cyclic",
                f"{beta_0} components with {beta_1} cycles; moderate (avg degree {average_degree:.2f})",
                0.75,
            )
    else:
        if average_degree < 2.5:
            return "sparse_cyclic", f"Connected with cycles, sparse (avg degree {average_degree:.2f})", 0.80
        elif average_degree < 5.0:
            return "mixed_cyclic", f"Connected with moderate cycles (avg degree {average_degree:.2f})", 0.70
        else:
            return "dense_mesh", f"Highly interconnected with cycles (avg degree {average_degree:.2f})", 0.75


def analyze_manifold(shared_graph: Dict[str, Any]) -> Dict[str, Any]:
    """
    Migrated dari topological_manifold_builder.py.
    Menghitung Betti numbers, archetype, dan complexity score.

    Menggunakan shared_graph["vertices"] dan shared_graph["edges"].
    """
    vertices = shared_graph.get("vertices", [])
    edges = shared_graph.get("edges", [])

    n_vertices = len(vertices)
    n_edges = len(edges)
    edge_natures = shared_graph.get("edge_natures", {})
    non_cyclic_mod_edges: Set[Tuple[str, str]] = {
        (str(ed.get("source", "")), str(ed.get("target", "")))
        for ed in (shared_graph.get("edge_details") or ())
        if isinstance(ed, dict)
        and (
            "cfg_test_mod" in (ed.get("semantic_usages") or ())
            or set(ed.get("semantic_usages") or ()) == {"rust_mod"}
        )
    }
    cycle_basis = _build_undirected_cycle_basis(
        vertices,
        edges,
        edge_natures=edge_natures,
        non_cyclic_edges=non_cyclic_mod_edges,
    )

    # --- β₀ via union-find ---
    if n_vertices == 0:
        beta_0, beta_1, beta_2 = 0, 0, 0
        average_degree = 0.0
    else:
        uf = _UnionFind(vertices)
        for src, tgt in edges:
            uf.union(src, tgt)
        beta_0 = len(set(uf.find(v) for v in vertices))

        # β₁ = cyclomatic number = E - V + β₀
        beta_1 = max(0, n_edges - n_vertices + beta_0)

        # β₂ simplified: count triangles yang membentuk enclosed void
        # (versi lengkap ada di standalone topological_manifold_builder.py)
        beta_2 = 0

        average_degree = (2.0 * n_edges / n_vertices) if n_vertices > 0 else 0.0

    # --- Runtime vs Type-Level Betti & SCC Decomposition ---
    runtime_edges = [
        (u, v) for (u, v) in edges
        if edge_natures.get(f"{u} -> {v}", edge_natures.get((u, v), "runtime")) == "runtime"
        and (str(u), str(v)) not in non_cyclic_mod_edges
    ]
    n_runtime_edges = len(runtime_edges)
    if n_vertices == 0:
        beta_0_runtime = 0
        beta_1_runtime = 0
    else:
        uf_rt = _UnionFind(vertices)
        for src, tgt in runtime_edges:
            uf_rt.union(src, tgt)
        beta_0_runtime = len(set(uf_rt.find(v) for v in vertices))
        beta_1_runtime = max(0, n_runtime_edges - n_vertices + beta_0_runtime)

    beta_1_type_level = max(0, beta_1 - beta_1_runtime)

    try:
        from codebase.cycle_break import _build_directed_adjacency, find_cyclic_sccs
    except ImportError:
        from cycle_break import _build_directed_adjacency, find_cyclic_sccs

    rt_v, rt_adj, rt_loops = _build_directed_adjacency(
        shared_graph,
        excluded_edge_natures={"same_package", "type_only"},
    )
    runtime_cyclic_sccs = find_cyclic_sccs(rt_v, rt_adj, rt_loops)
    all_v, all_adj, all_loops = _build_directed_adjacency(
        shared_graph,
        excluded_edge_natures={"same_package"},
    )
    all_cyclic_sccs = find_cyclic_sccs(all_v, all_adj, all_loops)
    runtime_scc_sets = [frozenset(c) for c in runtime_cyclic_sccs]
    type_only_cyclic_sccs = [
        c for c in all_cyclic_sccs
        if not any(r.issubset(c) for r in runtime_scc_sets)
    ]

    cycle_orientation_counts = {
        "directed": sum(1 for item in cycle_basis if item["orientation"] == "directed"),
        "type_only_directed": sum(1 for item in cycle_basis if item["orientation"] == "type_only_directed"),
        "mixed": sum(1 for item in cycle_basis if item["orientation"] == "mixed"),
    }
    topological_model = {
        "name": "dependency_multigraph_1_complex",
        "vertices": "supported source files",
        "edges": "resolved relative imports",
        "edge_orientation_for_betti": "ignored",
        "beta_0_interpretation": "connected components of the underlying undirected multigraph",
        "beta_1_interpretation": "independent cycles of the underlying undirected multigraph",
        "beta_2_interpretation": "zero by construction for this one-dimensional model",
        "formal_scope": "graph invariant used as semantic context; not a formal HoTT proof",
    }

    # --- Archetype classification (TERKALIBRASI) ---
    # Gate *_cyclic strictly on genuine runtime cyclic SCCs so compiler-elided
    # type_only cycles (import type / export type) never lock TypeScript repos
    # into cycle_breaking_and_layering.
    archetype, archetype_desc, archetype_conf = _classify_archetype(
        beta_0, beta_1, beta_2, average_degree, n_vertices,
        directed_cycles=len(runtime_cyclic_sccs),
    )

    # --- Invariant vector (normalized) ---
    invariant_vector = {
        "beta_0": float(beta_0),
        "beta_1": float(beta_1),
        "beta_2": float(beta_2),
        "beta_0_normalized": round(_clamp01(_saturate(beta_0, 4.0)), 4),
        "beta_1_normalized": round(_clamp01(_saturate(beta_1, 8.0)), 4),
        "beta_2_normalized": round(_clamp01(_saturate(beta_2, 4.0)), 4),
        "n_vertex_scale": round(_clamp01(_saturate(n_vertices, 100.0)), 4),
        "n_edge_scale": round(_clamp01(_saturate(n_edges, 200.0)), 4),
        "n_avg_degree": round(_clamp01(_saturate(average_degree, 5.0)), 4),
    }

    # --- Complexity score (TERKALIBRASI dengan n_avg_degree) ---
    weights = {
        "beta_1_normalized": 0.30,
        "beta_0_normalized": 0.10,
        "beta_2_normalized": 0.10,
        "n_avg_degree": 0.25,
        "n_edge_scale": 0.10,
    }
    complexity = sum(weights[k] * invariant_vector.get(k, 0.0) for k in weights)
    complexity = round(_clamp01(complexity), 4)

    # --- Findings: laporkan obstructions topologis ---
    findings: List[Dict[str, Any]] = []

    if beta_1 > 0:
        findings.append({
            "type": "independent_cycles",
            "severity": "low" if beta_1_runtime == 0 else "medium",
            "count": beta_1,
            "runtime_count": beta_1_runtime,
            "type_level_count": beta_1_type_level,
            "observation": (
                (
                    f"{beta_1} independent cycle(s) detected, all at type level "
                    "(runtime beta_1 = 0; compiler-elided, no runtime crash risk)."
                ) if beta_1_runtime == 0 else (
                    f"{beta_1} independent undirected cycle(s) detected in the dependency graph "
                    f"({beta_1_runtime} runtime, {beta_1_type_level} type-level). "
                    "This does not by itself imply circular imports."
                )
            ),
            "invariant": "beta_1",
            "cycle_basis": cycle_basis,
            "orientation_counts": cycle_orientation_counts,
        })

    if beta_0 > 1:
        findings.append({
            "type": "disconnected_components",
            "severity": "low",
            "count": beta_0,
            "observation": f"{beta_0} disconnected components detected (knowledge fragmentation).",
            "invariant": "beta_0",
        })

    if beta_2 > 0:
        findings.append({
            "type": "enclosed_voids",
            "severity": "medium",
            "count": beta_2,
            "observation": f"{beta_2} enclosed void(s) detected (missing higher-order structure).",
            "invariant": "beta_2",
        })

    return {
        "analyzer": "hott.manifold",
        "findings": findings,
        "invariant_vector": invariant_vector,
        "topological_model": topological_model,
        "cycle_basis": cycle_basis,
        "manifold": {
            "vertex_count": n_vertices,
            "edge_count": n_edges,
            "betti_numbers": {
                "beta_0": beta_0,
                "beta_1": beta_1,
                "beta_2": beta_2,
                "beta_1_runtime": beta_1_runtime,
                "beta_1_type_level": beta_1_type_level,
                "beta_0_runtime": beta_0_runtime,
            },
            "cycle_basis": cycle_basis,
            "cycle_basis_complete": len(cycle_basis) == beta_1,
            "cycle_orientation_counts": cycle_orientation_counts,
            "topological_model": topological_model,
            "average_degree": round(average_degree, 4),
            "invariant_vector": invariant_vector,
            "complexity_score": complexity,
            "runtime_cyclic_sccs": len(runtime_cyclic_sccs),
            "type_only_cyclic_sccs": len(type_only_cyclic_sccs),
            "structural_archetype": archetype,
            "archetype_description": archetype_desc,
            "archetype_confidence": archetype_conf,
        },
        "summary": {
            "connected_components": beta_0,
            "independent_cycles": beta_1,
            "independent_cycles_runtime": beta_1_runtime,
            "independent_cycles_type_level": beta_1_type_level,
            "runtime_cyclic_sccs": len(runtime_cyclic_sccs),
            "type_only_cyclic_sccs": len(type_only_cyclic_sccs),
            "undirected_cycle_rank": beta_1,
            "cycle_basis_witnesses": len(cycle_basis),
            "cycle_orientation_counts": cycle_orientation_counts,
            "enclosed_voids": beta_2,
            "complexity_score": complexity,
            "structural_archetype": archetype,
        },
    }
