"""codesearch-go as PLW's tree-sitter engine (codesearch-engine-v1).

PLW has no tree-sitter: its Python parsing is stdlib ``ast.parse`` and
its JS/TS parsing is the hand-written ``js_structural_v2`` frontend,
which PLW itself declares is not a full parser, and its topology
outline is regex.  codesearch-go already carries a real tree-sitter
engine (gotreesitter v0.55.1, pure Go, no cgo) with AST chunking for
Go, Rust, Python, JS, TS, TSX and JSX, plus structural queries
(``--defs-only``, ``--callers``, ``--related``).

Contract
--------
* Read-only.  Nothing is written into the target root.  codesearch
  keeps its own gob index cache under the cache dir (G9): by default
  PLW's own cache root (``cache_path("codebase", "codesearch")``),
  overridable with ``--cache-dir`` or ``CODESEARCH_CACHE_DIR``.
  The engine's standalone default (``$HOME/.cache/codesearch-go``)
  is only used when the engine runs without PLW.
* Subprocess only, list argv, no shell.  stdout is parsed as JSON;
  codesearch writes its proof lines and summaries to stderr, so
  stdout stays machine-readable.
* Fail-closed.  A missing binary, an unparsable version, a schema
  not listed in ``SUPPORTED_SCHEMAS`` (known-good ``go15``), a timeout,
  a non-zero exit, or an unparsable JSON response all raise
  ``EngineError``.  No partial result is ever presented as success.
* Discovery.  Explicit path, then the ``CODESEARCH_BIN``
  environment variable, then ``PATH`` — where the engine is looked
  up under each of ``PATH_CANDIDATES`` in order (``codesearch``,
  then ``codesearch-go``, then ``codesearch-go-linux-x86_64``), so
  a release-asset binary works without a symlink or env var (F1).
  The engine is an external binary supplied by the agent harness,
  like any other external tool: it is never bundled into the PLW
  executable and there is no fallback to a build-machine path.
* Authority.  codesearch ``--callers`` is name-based (callee
  normalised to its trailing identifier), not type-resolved.  Its
  rows are leads: PLW must still read the cited file before
  treating a call as proven.  That is stated in every envelope as
  ``authority_note``.
* Version contract (G13).  The adapter accepts exactly the schemas
  listed in ``SUPPORTED_SCHEMAS``; the engine's schema is reported
  by ``codesearch --version``.  What each schema guarantees is
  written in ``codesearch-go/ENGINE_CONTRACT.md``.  A mismatch is
  reported with its direction (engine newer vs older), and the CI
  script ``scripts/check_engine_contract.sh`` fails the build when
  the engine's ``schemaV`` and this module's ``KNOWN_SCHEMA``
  disagree — so the mismatch is caught at push time, not at
  runtime.
* Digest pin (G2).  The binary itself is verified by SHA256, not
  just its self-reported ``--version`` line: ``version_info``
  rejects any binary whose digest is not in
  ``PINNED_ENGINE_DIGESTS`` (rejection order: parse → schema →
  digest, so an unsupported newer engine still fails with the schema message).
  The pin covers the reproducible ``build.sh`` output (same source
  + toolchain = byte-identical, ``built=unknown``) and the v0.2.5
  release asset.  An unpinned binary can only run with the
  explicit opt-out ``CODESEARCH_ALLOW_UNPINNED=1``, which is
  recorded in every envelope as ``pinned: false`` — never silent.
* Limit (F3).  ``--limit`` is enforced by the adapter, not the
  engine — except ``search``, where it is passed through to the
  engine's own ``--limit``.  ``run_query`` and
  ``run_batch_query`` slice every row list (``hits``/``calls``/
  ``related``, and every ``grouped`` list in a batch) to at most
  ``limit`` rows; ``summary.total`` is the count before slicing
  and ``summary.shown`` the count after, so a caller can tell a
  truncated answer from a complete one.  A negative limit is
  rejected (fail-closed).
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    from core.runtime_paths import cache_path
except ImportError:  # type: ignore
    from runtime_paths import cache_path  # type: ignore

CODESEARCH_ENGINE_VERSION = "codesearch-engine-v1"
SCHEMA_VERSION = "plw-codesearch-engine-v1"
KNOWN_SCHEMA = "go15"
# G13: the adapter accepts exactly these schemas. The value names the
# contract each schema implements (see ENGINE_CONTRACT.md); a schema
# bump means a new entry here AND a new contract section, plus the
# black-box suite and the G9/G13 battery re-run — never a bare
# constant change.
SUPPORTED_SCHEMAS = {
    "go9": "plw-codesearch-engine-v1",
    "go10": "plw-codesearch-engine-v1",
    "go11": "plw-codesearch-engine-v1",
    "go12": "plw-codesearch-engine-v1",
    "go13": "plw-codesearch-engine-v1",
    "go14": "plw-codesearch-engine-v1",
    "go15": "plw-codesearch-engine-v1",
}
# G2: digest pin. Keys are SHA256 hex digests of engine binaries PLW
# trusts, values name what each digest is. A binary whose digest is
# not listed here is refused by version_info unless the explicit
# opt-out CODESEARCH_ALLOW_UNPINNED=1 is set (recorded as
# pinned: false, never silent). The pin only works because build.sh
# builds reproducibly (-trimpath, no wall-clock build date): the same
# source + toolchain is byte-identical, so the digest is computable
# locally before pushing. Rotating the pin: rebuild with build.sh,
# take the sha256, REPLACE the reproducible-build line here IN THE
# SAME COMMIT as the engine change; the CI pin check fails the build
# otherwise. The reproducible-build line tracks the current engine
# source — an older build is no longer the shipped engine, so its
# digest leaves the pin (the fail-closed doctor then refuses it
# unless the opt-out is set). Release-asset lines stay: the v0.2.5
# entry pins the published release asset (verified against its
# published .sha256), so an old released engine keeps working.
PINNED_ENGINE_DIGESTS = {
    # Rust pub use & JNI polish (2026-11-21, go15): bare super/crate/self
    # resolution, comments + self as alias in pub use, @JvmStatic & named
    # companion JNI base keys, comment-safe Kotlin package, qualified
    # Rust JNI queries + coarse detail + #[cfg] line dedup, explicit
    # Kind "wasm". Supersedes 26a05e30…. The v0.2.5 release-asset stays.
    "2d5e950b08c7e3ffb3fcba6d77397cc0741a2461802f08708cfc28e55497c63c":
        "go15 0fbc4fb4c390 (reproducible build.sh, -s -w, -mod=vendor)",
    "f8bab7d8306d3e0af5be2db061672af597826328c8baa57f8fc041650d447c4a":
        "go9 8c5d6ffe8685 (v0.2.5 release asset)",
}
ALLOW_UNPINNED_ENV = "CODESEARCH_ALLOW_UNPINNED"
# F1: PATH lookup tries these names in order. The release asset is
# named codesearch-go-linux-x86_64 (and users commonly rename it to
# codesearch-go); the bare name codesearch stays first so existing
# setups keep working. Explicit paths and CODESEARCH_BIN name an
# exact file and are never expanded to candidates.
PATH_CANDIDATES = ("codesearch", "codesearch-go", "codesearch-go-linux-x86_64")
DEFAULT_TIMEOUT_S = 120

# Track 4 (K5 follow-up): one engine call must stay well under
# DEFAULT_TIMEOUT_S. A defs batch costs ~65ms per name on a slow CPU
# (measured 2026-11-13, warm index: 100 names 8s, 500 names 56s,
# 1880 names 123s — past the 120s timeout), so run_batch_query
# splits a large batch into chunks of at most this many names.
# Each chunk is one engine call; the per-chunk envelopes are merged
# below. The bound is per call, so it holds as the tree grows —
# raising the timeout instead would weaken the fail-closed bound
# for every engine call and break again on the next growth step.
BATCH_CHUNK_SIZE = 500
VERSION_TIMEOUT_S = 10
PROBE_TIMEOUT_S = 5
INDEX_TIMEOUT_S = 120

TREE_SITTER_LANGUAGES = ["go", "rust", "python", "javascript", "typescript", "tsx", "jsx", "kotlin"]

AUTHORITY_NOTE = (
    "codesearch --callers/--related is name-based (trailing identifier), "
    "not type-resolved. Rows are leads: read the cited file before treating "
    "a call or relation as proven. Topology is not causality; candidate is not patch."
)

_VERSION_RE = re.compile(
    r"schema=(?P<schema>\S+)\s+commit=(?P<commit>\S+)"
    r"(?:\s+built=(?P<built>\S+))?(?:\s+go=(?P<go>\S+))?"
)
_SCHEMA_NUM_RE = re.compile(r"^go(\d+)$")


def _schema_number(schema: Any) -> Optional[int]:
    """Extract numeric schema generation from labels like ``go11``."""
    match = _SCHEMA_NUM_RE.match(str(schema or ""))
    return int(match.group(1)) if match else None


def _supports_cached_structural(engine: Dict[str, Any]) -> bool:
    """Whether ``engine`` accepts ``--cached`` on structural queries (go11+)."""
    schema_num = _schema_number(engine.get("schema"))
    return (
        bool(engine.get("cache_dir_supported"))
        and schema_num is not None
        and schema_num >= 11
    )


class EngineError(Exception):
    """Fail-closed engine failure: nothing usable was produced."""


def default_cache_dir() -> Path:
    """Where the engine's gob index lives under PLW's control (G9).

    PLW's own cache root (``PLW_CACHE_HOME`` / ``PLW_HOME`` / XDG /
    ``$HOME/.cache``), segment ``codebase/codesearch`` — the same root
    the graph cache uses, so the index is state PLW owns, not a hidden
    directory the engine chose on its own.
    """
    return Path(cache_path("codebase", "codesearch"))


def resolve_cache_dir(explicit: Optional[str] = None) -> Path:
    """Cache-dir precedence (G9): explicit flag > CODESEARCH_CACHE_DIR
    env > PLW default. The resolved dir is passed to the engine with
    ``--cache-dir`` on every invocation, so the engine never falls
    back to its standalone default while running under PLW.
    """
    if explicit:
        return Path(explicit).expanduser().resolve()
    env = os.environ.get("CODESEARCH_CACHE_DIR")
    if env:
        return Path(env).expanduser().resolve()
    return default_cache_dir()


def discover_codesearch(explicit: Optional[str] = None) -> Tuple[Path, str]:
    """Find the codesearch binary. Returns (path, discovered_via)."""
    if explicit:
        path = Path(explicit)
        if not path.is_file():
            raise EngineError(f"codesearch binary not found at explicit path: {explicit}")
        return path, "explicit"
    env = os.environ.get("CODESEARCH_BIN")
    if env:
        path = Path(env)
        if not path.is_file():
            raise EngineError(f"codesearch binary not found at CODESEARCH_BIN: {env}")
        return path, "CODESEARCH_BIN"
    for name in PATH_CANDIDATES:
        on_path = shutil.which(name)
        if on_path:
            return Path(on_path), "PATH"
    raise EngineError(
        "codesearch binary not found: set CODESEARCH_BIN or put it on PATH "
        f"(looked for {', '.join(repr(n) for n in PATH_CANDIDATES)}; "
        "the engine is supplied by the agent harness, not bundled with PLW)"
    )


_DIGEST_CACHE: Dict[Tuple[str, int, int], Optional[str]] = {}


def _engine_digest(binary: Path) -> Optional[str]:
    """SHA256 hex digest of the engine binary file (G2).

    Cached per process by (path, mtime_ns, size): the binary is
    ~36 MB and version_info runs on every engine call, so hashing
    it every time would be pure waste. Returns None when the file
    cannot be read (e.g. executable without read permission) —
    callers treat that as unpinned, never as pinned.
    """
    # Track 4 (H3): accept a str path too — a str has no .stat(),
    # and the audit showed _engine_digest('/usr/local/bin/codesearch')
    # crashing with AttributeError instead of hashing the file.
    binary = Path(binary)
    try:
        st = binary.stat()
    except OSError:
        return None
    key = (str(binary), st.st_mtime_ns, st.st_size)
    if key in _DIGEST_CACHE:
        return _DIGEST_CACHE[key]
    try:
        h = hashlib.sha256()
        with open(binary, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        digest = h.hexdigest()
    except OSError:
        digest = None
    _DIGEST_CACHE[key] = digest
    return digest


def version_info(binary: Path) -> Dict[str, Any]:
    """Run `codesearch --version` and parse it. Fail-closed on anything odd.

    Rejection order (G2/G13): unparsable output → schema mismatch →
    digest not pinned. The schema check comes first so an unsupported
    schema still fails with the schema message (G9 W5), and the digest
    check is what closes G2: a binary that merely *claims* a supported
    schema — a stub printing a pinned commit included — is refused unless
    its bytes match a pinned digest or the explicit opt-out is set.
    """
    try:
        proc = subprocess.run(
            [str(binary), "--version"],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=VERSION_TIMEOUT_S,
            shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise EngineError(f"codesearch --version failed to run: {exc}") from exc
    if proc.returncode != 0:
        raise EngineError(
            f"codesearch --version exited {proc.returncode}: "
            f"{proc.stderr.strip()[:300]}"
        )
    match = _VERSION_RE.search(proc.stdout)
    if not match:
        raise EngineError(
            f"codesearch --version output unparsable: {proc.stdout.strip()[:300]!r}"
        )
    info: Dict[str, Any] = {"raw": proc.stdout.strip(), **match.groupdict()}
    if info["schema"] not in SUPPORTED_SCHEMAS:
        # G13: say which direction the mismatch goes, when the label
        # carries a number (go<N>). A newer engine means this PLW build
        # is behind; an older engine means the binary is stale. An
        # unnumbered label falls back to the generic message.
        direction = ""
        got = _schema_number(info["schema"])
        known = _schema_number(KNOWN_SCHEMA)
        if got is not None and known is not None:
            if got > known:
                direction = (
                    f" (engine is newer than this PLW build: {info['schema']!r} > "
                    f"{KNOWN_SCHEMA!r}; upgrade PLW or pin the engine)"
                )
            else:
                direction = (
                    f" (engine is older than this PLW build: {info['schema']!r} < "
                    f"{KNOWN_SCHEMA!r}; rebuild the engine)"
                )
        raise EngineError(
            f"codesearch index schema {info['schema']!r} is not the known-good "
            f"{KNOWN_SCHEMA!r}; refusing to use this engine build{direction}"
        )
    # G2: digest pin. The --version line is self-reported — a stub can
    # print any commit, including a pinned one — so the bytes are what
    # is trusted. An unpinned binary runs only with the explicit
    # opt-out, and that fact is recorded on the returned info.
    digest = _engine_digest(binary)
    info["digest"] = digest
    if digest is not None and digest in PINNED_ENGINE_DIGESTS:
        info["pinned"] = True
        info["pin_label"] = PINNED_ENGINE_DIGESTS[digest]
        return info
    if os.environ.get(ALLOW_UNPINNED_ENV) == "1":
        info["pinned"] = False
        info["pin_warning"] = (
            "engine binary digest is not pinned "
            f"({(digest or 'unreadable')[:12]}...); running only because "
            f"{ALLOW_UNPINNED_ENV}=1 is set"
        )
        return info
    raise EngineError(
        "codesearch binary digest "
        f"{(digest or 'unreadable')[:12]}... is not pinned; refusing to use "
        "this engine build (a stub or a build from other sources has this "
        "digest). Rebuild the engine with codesearch-go/build.sh and add "
        f"its digest to PINNED_ENGINE_DIGESTS, or set {ALLOW_UNPINNED_ENV}=1 "
        "to run an unpinned engine explicitly"
    )


def _cache_dir_supported(binary: Path, cache_dir: Path) -> bool:
    """Probe whether the engine accepts --cache-dir (G9).

    Runs ``--version`` with the flag: new engines answer 0, engines
    that predate the flag exit non-zero. Never raises: any failure —
    non-zero exit, timeout, or spawn error — means 'not supported',
    and the engine is used without the flag (its pre-G9 behaviour).
    The query itself still fail-closes if the engine is genuinely
    broken. Raising here would break minimal engines that only answer
    a bare ``--version`` (the G6 V6 stub: ``$1`` is ``--cache-dir``,
    not ``--version``) and timeout stubs (G6 V7: the probe would burn
    the full version timeout before the query ever runs).
    """
    try:
        proc = subprocess.run(
            [str(binary), "--cache-dir", str(cache_dir), "--version"],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=PROBE_TIMEOUT_S,
            shell=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return proc.returncode == 0


def engine_status(
    binary: Path,
    discovered_via: str,
    cache_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Provenance block carried by every envelope.

    Also resolves the cache dir (G9) and probes whether the engine
    accepts --cache-dir. Old engines (before G9) do not: they keep
    answering queries with their standalone default location, exactly
    as before G9 — the index commands are the only thing that
    requires the new engine.
    """
    resolved_cache = resolve_cache_dir(cache_dir)
    info = version_info(binary)
    return {
        "name": "codesearch-go",
        "binary": str(binary),
        "discovered_via": discovered_via,
        "version": info,
        "schema": info["schema"],
        "pinned": info.get("pinned", False),
        "engine_digest": (info.get("digest") or "")[:12] or None,
        "pin_label": info.get("pin_label"),
        # Track 4 (H3): forward the opt-out warning — version_info sets
        # it, but this dict used to drop it, so doctor_status never saw it.
        "pin_warning": info.get("pin_warning"),
        "tree_sitter_ready": True,
        "tree_sitter_languages": list(TREE_SITTER_LANGUAGES),
        "tree_sitter_library": "gotreesitter v0.55.1 (pure Go, no cgo)",
        "cache_dir": str(resolved_cache),
        "cache_dir_supported": _cache_dir_supported(binary, resolved_cache),
    }


def doctor_status(
    explicit: Optional[str] = None,
    root: Optional[Path] = None,
    cache_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Engine availability for `plw doctor`. Never raises.

    With a root, also probes the index (G9): where it lives and
    whether it exists for that root. Without a root (portable-agent
    doctor, topology layer) the index probe is skipped — the engine
    is a per-root state, and doctor without a target has none.
    """
    resolved_cache = resolve_cache_dir(cache_dir)
    try:
        binary, discovered_via = discover_codesearch(explicit)
        status = engine_status(binary, discovered_via, cache_dir)
        out: Dict[str, Any] = {
            "available": True,
            "tree_sitter_ready": True,
            "binary": str(binary),
            "discovered_via": discovered_via,
            "schema": status["schema"],
            "commit": status["version"].get("commit"),
            "pinned": status["pinned"],
            "engine_digest": status["engine_digest"],
            "pin_label": status["pin_label"],
            # Track 4 (H3): the opt-out warning, None when pinned.
            "pin_warning": status.get("pin_warning"),
            "languages": list(TREE_SITTER_LANGUAGES),
            "cache_dir": str(resolved_cache),
            "cache_dir_supported": status["cache_dir_supported"],
        }
        if root is not None:
            out["index"] = _probe_index(binary, root, status)
        return out
    except EngineError as exc:
        out = {
            "available": False,
            "tree_sitter_ready": False,
            "binary": None,
            "discovered_via": None,
            "schema": None,
            "commit": None,
            "languages": list(TREE_SITTER_LANGUAGES),
            "cache_dir": str(resolved_cache),
            "reason": str(exc),
        }
        # G13: when the failure is a schema mismatch, report both
        # sides instead of hiding the engine's schema behind None.
        # The message already carries them; the fields make them
        # machine-readable for doctor consumers.
        match = re.search(r"schema '([^']+)' is not the known-good '([^']+)'", str(exc))
        if match:
            out["engine_schema"] = match.group(1)
            out["known_schema"] = match.group(2)
        return out


def _probe_index(
    binary: Path, root: Path, engine: Dict[str, Any],
) -> Dict[str, Any]:
    """Best-effort index summary for doctor (G9). Never raises: a
    probe failure is reported as an error field, not an exception,
    because doctor must not fail over a cache it does not own.
    An engine that predates index management reports that plainly
    instead of a probe error."""
    if not engine.get("cache_dir_supported"):
        return {"error": "engine predates index management (--index-status needs a newer codesearch-go build)"}
    try:
        result = _run_codesearch(
            binary, root, ["--index-status"], INDEX_TIMEOUT_S,
            Path(str(engine["cache_dir"])), True,
        )
        return {
            "exists": bool(result.get("exists")),
            "schema": result.get("schema"),
            "files": result.get("files"),
            "chunks": result.get("chunks"),
            "size_bytes": result.get("size_bytes"),
            "stale": result.get("stale"),
            "index_path": result.get("index_path"),
        }
    except EngineError as exc:
        return {"error": str(exc)}


def _run_codesearch(
    binary: Path, root: Path, argv: List[str], timeout_s: int,
    cache_dir: Optional[Path] = None,
    cache_dir_supported: bool = True,
) -> Dict[str, Any]:
    """Run one codesearch invocation, parse stdout JSON, fail-closed.

    The cache dir is passed explicitly with ``--cache-dir`` (G9) when
    the engine supports it, so the engine never falls back to its
    standalone default while running under PLW. Old engines get the
    flag omitted — they keep their pre-G9 behaviour for queries; the
    index commands check support before calling and refuse plainly.
    """
    if not root.is_dir():
        raise EngineError(f"root is not a directory: {root}")
    cmd = [str(binary), "--root", str(root)]
    if cache_dir_supported and cache_dir is not None:
        cmd += ["--cache-dir", str(cache_dir)]
    cmd += [*argv, "--json"]
    try:
        proc = subprocess.run(
            cmd,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout_s,
            shell=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise EngineError(
            f"codesearch timed out after {timeout_s}s: {' '.join(cmd)}"
        ) from exc
    except OSError as exc:
        raise EngineError(f"codesearch failed to run: {exc}") from exc
    if proc.returncode != 0:
        raise EngineError(
            f"codesearch exited {proc.returncode}: "
            f"{(proc.stderr or proc.stdout).strip()[:500]}"
        )
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise EngineError(
            f"codesearch stdout is not JSON ({exc}): {proc.stdout[:300]!r}"
        ) from exc


def envelope(mode: str, root: Path, query: Any, engine: Dict[str, Any], result: Dict[str, Any]) -> Dict[str, Any]:
    total = result.get("total")
    if total is None and isinstance(result.get("calls"), list):
        total = len(result["calls"])
    if total is None and isinstance(result.get("related"), list):
        total = len(result["related"])
    env: Dict[str, Any] = {
        "ok": True,
        "schema_version": SCHEMA_VERSION,
        "mode": mode,
        "root": str(root),
        "query": query,
        "engine": engine,
        "engine_result": result,
        "summary": {
            "total": total,
            "shown": result.get("shown"),
        },
        "authority_note": AUTHORITY_NOTE,
    }
    if mode == "callers" and total == 0:
        query_str = ", ".join(query) if isinstance(query, (list, tuple)) else str(query)
        env["fallback_hint"] = (
            f"No direct function calls to '{query_str}()' were found (callee name matches trailing identifier). "
            f"If '{query_str}' is an instance/object/namespace whose methods are called (e.g. {query_str}.next()), "
            f"try: plw ast search \"{query_str}\" (finds all occurrences) or plw ast related {query_str} (finds definitions and re-exports)."
        )
    elif mode == "defs" and total == 0:
        query_str = ", ".join(query) if isinstance(query, (list, tuple)) else str(query)
        env["fallback_hint"] = (
            f"No direct function/class/method definitions found for '{query_str}'. "
            f"If '{query_str}' is an exported variable/const/instance (e.g. export const {query_str} = ...), "
            f"try: plw ast related {query_str} (finds variable declarations & re-export chains) or plw ast search \"{query_str}\"."
        )
    return env


def error_envelope(mode: str, root: str, query: str, error: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "schema_version": SCHEMA_VERSION,
        "mode": mode,
        "root": root,
        "query": query,
        "engine": None,
        "engine_result": None,
        "summary": {"total": None, "shown": None},
        "error": error,
        "authority_note": AUTHORITY_NOTE,
    }


def doctor_envelope(root: Path, explicit: Optional[str] = None, cache_dir: Optional[str] = None) -> Dict[str, Any]:
    """Availability envelope for `plw ast doctor`. Never raises."""
    status = doctor_status(explicit, root=root, cache_dir=cache_dir)
    result: Dict[str, Any] = {
        "ok": bool(status.get("available")),
        "schema_version": SCHEMA_VERSION,
        "mode": "doctor",
        "root": str(root),
        "query": "",
        "engine": status,
        "engine_result": {"tree_sitter_ready": bool(status.get("tree_sitter_ready"))},
        "summary": {"total": None, "shown": None},
        "authority_note": AUTHORITY_NOTE,
    }
    if not status.get("available"):
        result["error"] = str(status.get("reason") or "codesearch engine unavailable")
    return result


def _apply_limit(result: Dict[str, Any], mode: str, limit: Optional[int]) -> Tuple[Optional[int], Optional[int]]:
    """Slice the row list of a single-query engine result in place (F3).

    Returns (total, shown): total = rows before slicing, shown = rows
    after. The engine is never asked to slice defs/callers/related:
    PLW owns its CLI contract, and slicing here keeps the engine
    untouched. ``search`` is the exception — its limit is passed to
    the engine (see run_query) — so this helper leaves it alone.
    """
    if limit is None:
        return None, None
    key = {"defs": "hits", "callers": "calls", "related": "related"}.get(mode)
    if key is None:
        return None, None
    rows = result.get(key)
    if not isinstance(rows, list):
        return None, None
    total = len(rows)
    result[key] = rows[:limit]
    return total, len(result[key])


def _apply_batch_limit(
    result: Dict[str, Any], mode: str,
    grouped: Dict[str, List[Dict[str, Any]]], limit: Optional[int],
) -> Tuple[Optional[int], Optional[int]]:
    """Slice every row list of a batch result in place (F3): the flat
    list in the engine result and every per-symbol list in ``grouped``.

    Returns (total, shown) over all grouped rows, same semantics as
    _apply_limit. The fallback path assembles ``grouped`` first, so
    one slice here covers both the batch and the fallback shape.
    """
    if limit is None:
        return None, None
    total = sum(len(rows) for rows in grouped.values())
    for name in grouped:
        grouped[name] = grouped[name][:limit]
    if mode == "defs":
        for entry in result.get("queries") or []:
            if isinstance(entry, dict) and isinstance(entry.get("hits"), list):
                entry["hits"] = entry["hits"][:limit]
    else:
        # The flat list is the union of the per-symbol rows, so it is
        # filtered per symbol — not cut to ``limit`` total. A plain
        # [:limit] here would leave the flat list (3 rows) disagreeing
        # with grouped (3 rows per symbol), and a caller reading
        # engine_result would see a different answer than one reading
        # grouped. Non-dict rows are dropped, as in the grouping above.
        key = "calls" if mode == "callers" else "related"
        field = "callee" if mode == "callers" else "symbol"
        rows = result.get(key)
        if isinstance(rows, list):
            kept: Dict[str, int] = {}
            out_rows: List[Dict[str, Any]] = []
            for row in rows:
                if not isinstance(row, dict):
                    continue
                owner = row.get(field)
                if mode == "callers":
                    owner = _callee_base(owner)
                count = kept.get(str(owner), 0)
                if count < limit:
                    out_rows.append(row)
                    kept[str(owner)] = count + 1
            result[key] = out_rows
    shown = sum(len(rows) for rows in grouped.values())
    return total, shown


def run_query(
    mode: str,
    root: Path,
    query: str,
    binary: Path,
    discovered_via: str,
    timeout_s: int,
    limit: Optional[int] = None,
    cache_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """One engine query end to end: engine check, then the structural call."""
    if limit is not None and limit < 0:
        raise EngineError("limit must be >= 0")
    engine = engine_status(binary, discovered_via, cache_dir)
    if mode == "defs":
        argv = ["--defs-only", query]
    elif mode == "callers":
        argv = ["--callers", query]
        if _supports_cached_structural(engine):
            argv.append("--cached")
    elif mode == "related":
        argv = ["--related", query]
        if _supports_cached_structural(engine):
            argv.append("--cached")
    elif mode == "search":
        argv = [query]
        if limit is not None:
            argv = ["--limit", str(limit), query]
    else:
        raise EngineError(f"unknown mode: {mode}")
    result = _run_codesearch(
        binary, root, argv, timeout_s,
        Path(str(engine["cache_dir"])), bool(engine["cache_dir_supported"]),
    )
    total, shown = _apply_limit(result, mode, limit)
    out = envelope(mode, root, query, engine, result)
    if total is not None:
        out["summary"]["total"] = total
        out["summary"]["shown"] = shown
    return out


def run_index_command(
    operation: str,
    root: Path,
    binary: Path,
    discovered_via: str,
    timeout_s: int,
    cache_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """One index command end to end (G9): status, warm, or clean.

    The engine check runs first; an engine that predates index
    management is refused here with a plain message (fail-closed),
    instead of letting the unknown flag surface as a generic exit-2
    error. The envelope is the ``run_query`` envelope with
    ``mode: "index"`` and an ``"operation"`` key, so callers read the
    status JSON from ``engine_result`` exactly as they read query
    results.
    """
    if operation not in ("status", "warm", "clean"):
        raise EngineError(f"unknown index operation: {operation}")
    engine = engine_status(binary, discovered_via, cache_dir)
    if not engine["cache_dir_supported"]:
        raise EngineError(
            "codesearch engine predates index management "
            f"(--index-{operation} needs a newer codesearch-go build)"
        )
    result = _run_codesearch(
        binary, root, [f"--index-{operation}"], timeout_s,
        Path(str(engine["cache_dir"])), True,
    )
    out = envelope("index", root, operation, engine, result)
    out["operation"] = operation
    return out


def _callee_base(expr: Any) -> str:
    """Trailing identifier of a callee expression, mirroring the engine's
    calleeBase (callers.go): cut at the first '<' or '[', replace '::'
    with '.', return the last non-empty dot segment, or ''.

    The engine's call rows carry the full callee expression
    (``a.Run``), not the queried trailing name (``Run``), so batch
    grouping must reduce it the same way the engine matches it —
    grouping on the raw ``callee`` would strand qualified calls under
    keys no query ever asked for (found by the dup-fixture smoke:
    ``a.Run``/``b.Run`` rows never reached ``grouped["Run"]``).
    """
    if not isinstance(expr, str):
        return ""
    value = expr
    for sep in ("<", "["):
        idx = value.find(sep)
        if idx >= 0:
            value = value[:idx]
    value = value.replace("::", ".")
    for part in reversed(value.split(".")):
        if part:
            return part
    return ""


def run_batch_query(
    mode: str,
    root: Path,
    queries: List[str],
    binary: Path,
    discovered_via: str,
    timeout_s: int,
    cache_dir: Optional[str] = None,
    limit: Optional[int] = None,
) -> Dict[str, Any]:
    """Many engine queries in one scan (G8).

    ``defs`` uses the engine's positional-query batch (one index build,
    envelope ``{"queries": [{query, total, hits}]}``).  ``callers`` and
    ``related`` use the comma-joined flag value: one AST scan (reusing
    the synced gob cache via ``--cached`` when engine schema >= go11),
    one flat envelope carrying a ``"batch": true`` marker, each row
    carrying its symbol (``callee`` for calls, ``symbol`` for related).

    The result envelope is the ``run_query`` envelope plus two keys:
    ``"batch_mode"`` (``"batch"`` or ``"fallback"``) and ``"grouped"``
    (``{name: rows}`` — hits for defs, calls for callers, related rows
    for related), so callers read per-symbol results without regrouping.

    Old engines (before batch) answer a comma-joined ``--callers``
    value as one never-matching name and return zero rows with exit 0
    — a silent empty result.  The ``batch`` marker tells the two apart:
    a multi-name request whose envelope lacks the marker means an old
    engine, and this function falls back to one ``run_query`` per name
    (correct, just slow) instead of presenting the empty batch as truth.

    ``limit`` (F3) slices every row list — flat and grouped — to at
    most that many rows per list; ``summary.total`` is the count
    before slicing and ``summary.shown`` the count after.

    A batch larger than ``BATCH_CHUNK_SIZE`` names is split into
    chunks (Track 4, K5 follow-up): one engine call per chunk, the
    per-chunk envelopes merged — ``result["queries"]`` concatenated
    for defs (a one-name chunk answers with flat ``"hits"``, which
    is re-wrapped as one queries entry so ``_apply_batch_limit``
    sees every name), the flat row list concatenated for callers
    and related. ``batch_mode`` stays ``"batch"`` when every chunk
    answered as a batch; one chunk answering as an old engine flips
    the whole result to ``"fallback"`` and the per-name rebuild
    below covers all names.
    """
    if limit is not None and limit < 0:
        raise EngineError("limit must be >= 0")
    if mode not in ("defs", "callers", "related"):
        raise EngineError(f"run_batch_query does not support mode: {mode}")
    names = list(dict.fromkeys(q for q in queries if q))
    if not names:
        raise EngineError("run_batch_query requires at least one query")
    engine = engine_status(binary, discovered_via, cache_dir)
    use_cached = _supports_cached_structural(engine)
    batch_mode = "batch"
    grouped: Dict[str, List[Dict[str, Any]]] = {name: [] for name in names}
    result: Dict[str, Any] = {}
    chunks = [names[i:i + BATCH_CHUNK_SIZE]
              for i in range(0, len(names), BATCH_CHUNK_SIZE)]
    for chunk in chunks:
        if mode == "defs":
            argv = ["--defs-only", *chunk]
        elif mode == "callers":
            argv = ["--callers", ",".join(chunk)]
            if use_cached:
                argv.append("--cached")
        else:
            argv = ["--related", ",".join(chunk)]
            if use_cached:
                argv.append("--cached")
        chunk_result = _run_codesearch(
            binary, root, argv, timeout_s,
            Path(str(engine["cache_dir"])), bool(engine["cache_dir_supported"]),
        )
        if mode == "defs":
            per_query = chunk_result.get("queries")
            if isinstance(per_query, list):
                result.setdefault("queries", []).extend(per_query)
                for entry in per_query:
                    if isinstance(entry, dict) and entry.get("query") in grouped:
                        grouped[entry["query"]] = list(entry.get("hits") or [])
            elif len(chunk) == 1 and isinstance(chunk_result.get("hits"), list):
                hits = list(chunk_result["hits"])
                result.setdefault("queries", []).append(
                    {"query": chunk[0], "total": len(hits), "hits": hits})
                grouped[chunk[0]] = hits
            else:
                batch_mode = "fallback"
        else:
            key = "calls" if mode == "callers" else "related"
            field = "callee" if mode == "callers" else "symbol"
            if len(chunk) > 1 and not chunk_result.get("batch"):
                batch_mode = "fallback"
            else:
                result.setdefault(key, []).extend(chunk_result.get(key) or [])
                if len(chunk) > 1:
                    result["batch"] = bool(result.get("batch", True)
                                           and chunk_result.get("batch"))
                # Callers rows carry the full callee expression; reduce it
                # to its base and fan the row out to every requested query
                # with that base, so `pkg.Foo` receives its rows instead of
                # stranding them under an orphan `Foo` key (H2). The engine
                # matches by trailing identifier, so one row may fan out to
                # several queries sharing a base (`pkg.Foo`, `other.Foo`).
                base_to_queries: Dict[str, List[str]] = {}
                if mode == "callers":
                    for name in chunk:
                        base_to_queries.setdefault(_callee_base(name), []).append(name)
                for row in chunk_result.get(key) or []:
                    if not isinstance(row, dict):
                        continue
                    owner = row.get(field)
                    if mode == "callers":
                        owner = _callee_base(owner)
                        targets = base_to_queries.get(owner)
                        if targets:
                            for target in targets:
                                grouped[target].append(row)
                            continue
                    if owner in grouped:
                        grouped[owner].append(row)
                    else:
                        grouped.setdefault(str(owner), []).append(row)
    if batch_mode == "fallback":
        # The engine predates batch: rebuild the batch result from one
        # run_query per name, so the envelope keeps exactly the shape a
        # batch engine would have returned (the equivalence W1/W2 prove
        # for batch engines). batch_mode records that it was assembled.
        merged: Dict[str, Any] = {"query": ",".join(names)}
        if mode == "defs":
            merged["queries"] = []
            for name in names:
                single = run_query(mode, root, name, binary, discovered_via, timeout_s, None, cache_dir)
                hits = list(single["engine_result"].get("hits") or [])
                grouped[name] = hits
                merged["queries"].append(
                    {"query": name, "total": len(hits), "hits": hits})
        else:
            key = "calls" if mode == "callers" else "related"
            rows: List[Dict[str, Any]] = []
            for name in names:
                single = run_query(mode, root, name, binary, discovered_via, timeout_s, None, cache_dir)
                batch_rows = list(single["engine_result"].get(key) or [])
                grouped[name] = batch_rows
                rows.extend(batch_rows)
            merged[key] = rows
            merged["total"] = len(rows)
        result = merged
    total, shown = _apply_batch_limit(result, mode, grouped, limit)
    out = envelope(mode, root, names, engine, result)
    out["batch_mode"] = batch_mode
    out["grouped"] = grouped
    out["summary"]["total"] = total if total is not None else sum(len(rows) for rows in grouped.values())
    if shown is not None:
        out["summary"]["shown"] = shown
    return out
