"""Task-grounded candidate selection and internal capability matching.

The module binds selection to one simplification discovery snapshot. Selection
uses explicit symbol/path anchors or multiple unique structural task clauses.
It never authorizes, executes, mutates, validates behavior, or accepts evidence.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import subprocess
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

SCHEMA_VERSION = "candidate-selection-provenance-v1"
POLICY = "task-evidence-to-exact-discovery-candidate-no-authority-v1"

# This registry is intentionally private and is not exported through
# `plw capability list` or `plw capability describe`.
_INTERNAL_CANDIDATE_CAPABILITIES: Dict[str, Dict[str, Any]] = {
    "js_boolean_guard.strict_equality_string.temp_worktree.v1": {
        "capability_id": "js_boolean_guard.strict_equality_string.temp_worktree.v1",
        "rule": "js_boolean_guard_return",
        "source_extensions": [".js", ".ts"],
        "condition": {
            "operator": "===",
            "left_operand_shape": "IDENT_OR_MEMBER_CHAIN_NO_OPTIONAL_CHAINING",
            "right_operand_kind": "STRING_LITERAL",
            "reversed_operand_order_allowed": False,
        },
        "transformations": ["positive", "inverse"],
        "output_authority": "MATCH_ONLY_NO_AUTHORIZATION_OR_EXECUTION",
    }
}

_KIND_PHRASES: Tuple[Tuple[str, str], ...] = (
    ("boolean guard", "js_boolean_guard_return"),
    ("boolean-return guard", "js_boolean_guard_return"),
    ("boolean return guard", "js_boolean_guard_return"),
    ("opposite boolean returns", "js_boolean_guard_return"),
)

_TOKEN_STOP = {
    "a", "an", "the", "and", "or", "to", "for", "from", "with", "in", "on",
    "find", "select", "choose", "review", "explain", "why", "one", "local", "candidate",
    "function", "functions", "predicate", "guard", "return", "returns", "boolean",
    "node", "is", "should", "can", "has", "get", "check", "test", "value",
}


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")


def _digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(_canonical_bytes(value)).hexdigest()


def _digest_candidates(candidates: Sequence[Mapping[str, Any]]) -> str:
    rows = [dict(row) for row in candidates]
    rows.sort(key=lambda row: _candidate_key(row) + (_digest(row),))
    rows.sort(key=lambda row: (str(row.get("candidate_id", "")), str(row.get("candidate_instance_id", ""))))
    return _digest(rows)


def _candidate_key(row: Mapping[str, Any]) -> Tuple[str, str]:
    return (str(row.get("candidate_id") or ""), str(row.get("candidate_instance_id") or ""))


def _dirty_content_evidence(root: Path, status: Optional[str]) -> Dict[str, Any]:
    """Bind Git-visible dirty paths to their worktree bytes, without following links."""
    if status is None:
        return {"dirty_content_digest": None, "dirty_content_complete": False, "dirty_path_count": None}
    if not status:
        return {"dirty_content_digest": _digest([]), "dirty_content_complete": True, "dirty_path_count": 0}

    paths: set[bytes] = set()
    try:
        for command in (
            ("diff", "HEAD", "--name-only", "-z", "--no-ext-diff"),
            ("ls-files", "--others", "--exclude-standard", "-z"),
        ):
            proc = subprocess.run(
                ["git", "-C", str(root), *command], check=False,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=10,
            )
            if proc.returncode:
                raise OSError("dirty path enumeration failed")
            paths.update(path for path in proc.stdout.split(b"\0") if path)
    except (OSError, subprocess.TimeoutExpired):
        return {"dirty_content_digest": None, "dirty_content_complete": False, "dirty_path_count": None}

    rows: List[Dict[str, Any]] = []
    complete = True
    for raw_path in sorted(paths):
        row: Dict[str, Any] = {"path_hex": raw_path.hex()}
        # Git normally emits relative paths. Refuse traversal if a repository
        # adapter ever returns an unexpected name instead of reading outside it.
        if raw_path.startswith(b"/") or b".." in raw_path.split(b"/"):
            row["kind"] = "path_outside_root"
            complete = False
            rows.append(row)
            continue
        path = root / os.fsdecode(raw_path)
        try:
            before = path.lstat()
            if stat.S_ISLNK(before.st_mode):
                data = os.fsencode(os.readlink(path))
                after = path.lstat()
                stable = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
                    after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns
                )
                row.update(kind="symlink", sha256=hashlib.sha256(data).hexdigest(), size=len(data), stable_during_read=stable)
                complete = complete and stable
            elif stat.S_ISREG(before.st_mode):
                h = hashlib.sha256()
                size = 0
                # O_NOFOLLOW prevents a path swapped to an external symlink
                # after lstat from redirecting the byte read outside the repo.
                fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
                with os.fdopen(fd, "rb") as stream:
                    opened = os.fstat(stream.fileno())
                    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                        h.update(chunk)
                        size += len(chunk)
                    after_read = os.fstat(stream.fileno())
                after = path.lstat()
                identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
                stable = (
                    stat.S_ISREG(opened.st_mode)
                    and identity(before) == identity(opened) == identity(after_read) == identity(after)
                    and size == after.st_size
                )
                row.update(kind="file", sha256=h.hexdigest(), size=size, stable_during_read=stable)
                complete = complete and stable
            else:
                row["kind"] = "non_file_unbound"
                complete = False
        except FileNotFoundError:
            row["kind"] = "missing"
        except OSError:
            row["kind"] = "unreadable"
            complete = False
        rows.append(row)
    return {
        "dirty_content_digest": _digest(rows),
        "dirty_content_complete": complete,
        "dirty_path_count": len(rows),
    }


def _revision(root: Path, graph_signature: str) -> Dict[str, Any]:
    def git(*args: str) -> Optional[str]:
        try:
            proc = subprocess.run(
                ["git", "-C", str(root), *args],
                check=False, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, timeout=5, shell=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return None
        return proc.stdout.strip() if proc.returncode == 0 else None

    head = git("rev-parse", "HEAD")
    tree = git("rev-parse", "HEAD^{tree}") if head else None
    origin = git("remote", "get-url", "origin") if head else None
    status = git("status", "--porcelain=v1", "--untracked-files=all") if head else None
    status_text = status or ""
    status_digest = "sha256:" + hashlib.sha256(status_text.encode("utf-8")).hexdigest()
    dirty_content = _dirty_content_evidence(root, status)
    basis = {
        "git_head": head,
        "git_tree": tree,
        "repository_identity_digest": (
            "sha256:" + hashlib.sha256(origin.encode("utf-8")).hexdigest()
            if origin else None
        ),
        "working_tree_status_observed": status is not None,
        "working_tree_clean": status is not None and not bool(status_text),
        "working_tree_status_digest": status_digest,
        **dirty_content,
        "shared_graph_content_signature": graph_signature,
    }
    return {
        **basis,
        "revision_basis": "GIT_REVISION_PLUS_EXACT_GRAPH_CONTENT" if head and tree else "EXACT_GRAPH_CONTENT_ONLY",
        "target_revision_digest": _digest(basis),
    }


def build_discovery_binding(target_root: str, discovery: Mapping[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """Bind a simplification result to the target revision and complete set."""
    candidates_value = discovery.get("candidates")
    bridge = discovery.get("canonical_anatomy_bridge", {}) or {}
    graph_signature = str(bridge.get("shared_graph_content_signature") or "")
    if not isinstance(candidates_value, list) or not graph_signature.startswith("sha256:"):
        raise ValueError("discovery must contain candidates and a shared graph content signature")
    candidates = [dict(row) for row in candidates_value if isinstance(row, Mapping)]
    if len(candidates) != len(candidates_value):
        raise ValueError("candidate set contains a non-object row")
    ids = [str(row.get("candidate_id") or "") for row in candidates]
    if any(not value for value in ids):
        raise ValueError("candidate set contains an empty candidate_id")
    for row in candidates:
        if not row.get("candidate_instance_id"):
            row["candidate_instance_id"] = _digest({
                "candidate_id": row.get("candidate_id"),
                "candidate_row_digest": _digest(row),
            })
    candidates.sort(key=lambda row: _candidate_key(row) + (_digest(row),))

    candidate_set_digest = _digest_candidates(candidates)
    revision = _revision(Path(target_root).expanduser().resolve(), graph_signature)
    by_kind: Dict[str, int] = {}
    for row in candidates:
        kind = str(row.get("kind") or "UNCLASSIFIED")
        by_kind[kind] = by_kind.get(kind, 0) + 1
    snapshot_basis = {
        "schema_version": SCHEMA_VERSION,
        "simplification_schema_version": str(discovery.get("schema_version") or ""),
        "target_root": str(Path(target_root).expanduser().resolve()),
        "target_revision_digest": revision["target_revision_digest"],
        "shared_graph_content_signature": graph_signature,
        "candidate_set_digest": candidate_set_digest,
    }
    binding = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY,
        "target_root": str(Path(target_root).expanduser().resolve()),
        "target_revision": revision,
        "shared_graph_content_signature": graph_signature,
        "candidate_set": {
            "candidate_count": len(candidates),
            "by_kind": dict(sorted(by_kind.items())),
            "candidate_set_digest": candidate_set_digest,
        },
        "discovery_snapshot_digest": _digest(snapshot_basis),
        "discovery_snapshot_basis": snapshot_basis,
        "authority": {
            "source_read_only": True,
            "selects_candidate": False,
            "authorizes_execution": False,
            "executes_capability": False,
            "mutates_source": False,
            "accepts_evidence": False,
        },
    }
    return binding, candidates


def _verify_binding(binding: Mapping[str, Any], candidates: Sequence[Mapping[str, Any]]) -> Optional[str]:
    candidate_set = binding.get("candidate_set", {}) or {}
    actual_set_digest = _digest_candidates(candidates)
    if candidate_set.get("candidate_set_digest") != actual_set_digest:
        return "CANDIDATE_SET_DIGEST_MISMATCH"
    if int(candidate_set.get("candidate_count", -1)) != len(candidates):
        return "CANDIDATE_SET_COUNT_MISMATCH"
    keys = [_candidate_key(row) for row in candidates]
    if any(not cid or not instance for cid, instance in keys) or len(keys) != len(set(keys)):
        return "CANDIDATE_INSTANCE_IDENTITY_MISSING_OR_DUPLICATED"
    basis = dict(binding.get("discovery_snapshot_basis", {}) or {})
    if basis.get("candidate_set_digest") != actual_set_digest:
        return "DISCOVERY_SNAPSHOT_CANDIDATE_BINDING_MISMATCH"
    if binding.get("discovery_snapshot_digest") != _digest(basis):
        return "DISCOVERY_SNAPSHOT_DIGEST_MISMATCH"
    revision = binding.get("target_revision", {}) or {}
    if basis.get("target_revision_digest") != revision.get("target_revision_digest"):
        return "TARGET_REVISION_BINDING_MISMATCH"
    if basis.get("target_root") != binding.get("target_root"):
        return "TARGET_ROOT_BINDING_MISMATCH"
    if basis.get("shared_graph_content_signature") != binding.get("shared_graph_content_signature"):
        return "SOURCE_SNAPSHOT_BINDING_MISMATCH"
    return None


def _task_kind_filter(task: str) -> Optional[str]:
    lowered = re.sub(r"\s+", " ", task.lower().replace("_", " ").replace("-", " ")).strip()
    for phrase, kind in _KIND_PHRASES:
        if phrase in lowered:
            return kind
    return None


def _task_constraints(task: str) -> Dict[str, str]:
    lowered = task.lower()
    result: Dict[str, str] = {}
    if "strict equality" in lowered or "strict-equality" in lowered:
        result["operator"] = "==="
    elif "strict inequality" in lowered or "strict-inequality" in lowered:
        result["operator"] = "!=="
    if "string literal" in lowered or "string-literal" in lowered:
        result["right_operand_kind"] = "STRING_LITERAL"
    if "positive transformation" in lowered or "positive form" in lowered:
        result["transformation"] = "positive"
    elif "inverse transformation" in lowered or "inverse form" in lowered:
        result["transformation"] = "inverse"
    return result


def _has_conflicting_task_constraints(task: str) -> bool:
    lowered = task.lower()
    operator_conflict = (
        ("strict equality" in lowered or "strict-equality" in lowered)
        and ("strict inequality" in lowered or "strict-inequality" in lowered)
    )
    transformation_conflict = (
        ("positive transformation" in lowered or "positive form" in lowered)
        and ("inverse transformation" in lowered or "inverse form" in lowered)
    )
    return operator_conflict or transformation_conflict


def _mentioned_symbols(task: str, candidates: Sequence[Mapping[str, Any]]) -> List[Tuple[Mapping[str, Any], str]]:
    matches: List[Tuple[Mapping[str, Any], str]] = []
    for row in candidates:
        for symbol in row.get("names", []) or []:
            name = str(symbol)
            if (len(name) < 3 or name.lower() in _TOKEN_STOP) and f"`{name}`" not in task and f'"{name}"' not in task and f"'{name}'" not in task:
                continue
            if name and re.search(r"(?<![A-Za-z0-9_$])" + re.escape(name) + r"(?![A-Za-z0-9_$])", task):
                matches.append((row, name))
    return matches


def _mentioned_paths(task: str, candidates: Sequence[Mapping[str, Any]]) -> List[Tuple[Mapping[str, Any], str]]:
    normalized_task = task.replace("\\", "/")
    matches: List[Tuple[Mapping[str, Any], str]] = []
    for row in candidates:
        for raw_path in row.get("files", []) or []:
            path = str(raw_path).replace("\\", "/")
            if path and path in normalized_task:
                matches.append((row, path))
    return matches


def _explicit_path_mentions(task: str) -> List[str]:
    normalized = task.replace("\\", "/")
    pattern = re.compile(
        r"(?<![A-Za-z0-9_.-])(?:[A-Za-z0-9_.-]+/)+[A-Za-z0-9_.-]+\.(?:js|jsx|ts|tsx)(?![A-Za-z0-9_-])"
    )
    return sorted(set(match.group(0).removeprefix("./") for match in pattern.finditer(normalized)))


def _candidate_brief(row: Mapping[str, Any]) -> Dict[str, Any]:
    members = row.get("members", []) or []
    member = members[0] if len(members) == 1 and isinstance(members[0], Mapping) else {}
    witness = row.get("semantic_witness", {}) or {}
    site = witness.get("source_site", {}) or {}
    return {
        "candidate_id": row.get("candidate_id"),
        "candidate_instance_id": row.get("candidate_instance_id"),
        "source_path": (row.get("files", []) or [None])[0],
        "symbol": (row.get("names", []) or [None])[0],
        "candidate_kind": row.get("kind"),
        "site_line_start": site.get("line_start", member.get("line_start")),
        "site_line_end": site.get("line_end", member.get("line_end")),
    }


def _finish_selection(payload: Dict[str, Any]) -> Dict[str, Any]:
    result = dict(payload)
    result["candidate_selection_digest"] = _digest(payload)
    return result


def select_candidate(
    task: str,
    binding: Mapping[str, Any],
    candidates: Sequence[Mapping[str, Any]],
) -> Dict[str, Any]:
    """Select only with an exact symbol/path anchor or multiple structural clauses."""
    rows = [dict(row) for row in candidates]
    invalid = _verify_binding(binding, rows)
    base = {
        "schema_version": "candidate-selection-decision-v1",
        "task": task,
        "discovery_snapshot_digest": binding.get("discovery_snapshot_digest"),
        "candidate_set_digest": (binding.get("candidate_set", {}) or {}).get("candidate_set_digest"),
        "selected_candidate_id": None,
        "selected_candidate_instance_id": None,
        "selected_source_path": None,
        "selected_symbol": None,
        "candidate_kind": None,
        "selection_basis": [],
        "rejected_alternatives": [],
        "ambiguous_candidates": [],
        "selection_confidence_boundary": "INSUFFICIENT_EVIDENCE",
        "authority": {
            "selection_only": True,
            "authorization": False,
            "mutation": False,
            "correctness_proof": False,
            "evidence_acceptance": False,
        },
    }
    if invalid:
        base.update({"resolution": "UNRESOLVED", "reason": invalid})
        return _finish_selection(base)
    if not isinstance(task, str) or not task.strip():
        base.update({"resolution": "UNRESOLVED", "reason": "TASK_EMPTY"})
        return _finish_selection(base)
    if _has_conflicting_task_constraints(task):
        base.update({
            "resolution": "UNRESOLVED",
            "reason": "CONFLICTING_TASK_STRUCTURAL_CONSTRAINTS",
            "selection_confidence_boundary": "CONTRADICTORY_TASK_CONSTRAINTS",
        })
        return _finish_selection(base)

    duplicate_instances: Dict[Tuple[str, str], int] = {}
    for row in rows:
        key = _candidate_key(row)
        duplicate_instances[key] = duplicate_instances.get(key, 0) + 1
    if any(count != 1 for count in duplicate_instances.values()):
        base.update({"resolution": "UNRESOLVED", "reason": "CANDIDATE_INSTANCES_NOT_UNIQUE"})
        return _finish_selection(base)

    symbol_matches = _mentioned_symbols(task, rows)
    path_matches = _mentioned_paths(task, rows)
    explicit_paths = _explicit_path_mentions(task)
    known_paths = {
        str(path).replace("\\", "/")
        for row in rows for path in (row.get("files", []) or [])
    }
    unmatched_paths = [
        path for path in explicit_paths
        if not any(path == known or path.endswith("/" + known) for known in known_paths)
    ]
    symbol_keys = {_candidate_key(row) for row, _ in symbol_matches}
    path_keys = {_candidate_key(row) for row, _ in path_matches}
    if unmatched_paths:
        base.update({
            "resolution": "UNRESOLVED",
            "reason": (
                "CONFLICTING_EXACT_SYMBOL_AND_PATH_HINTS"
                if symbol_matches and explicit_paths
                else "TASK_SOURCE_PATH_NOT_IN_DISCOVERED_CANDIDATE_SET"
            ),
            "selection_basis": [
                {"kind": "EXACT_SYMBOL_MENTION", "values": sorted({name for _, name in symbol_matches})},
                {"kind": "EXACT_SOURCE_PATH_MENTION", "values": explicit_paths},
            ],
            "conflicting_anchor_candidates": {
                "symbol": [_candidate_brief(row) for row, _ in symbol_matches],
                "path": [_candidate_brief(row) for row, _ in path_matches],
            },
            "unmatched_source_paths": unmatched_paths,
            "selection_confidence_boundary": "EXPLICIT_PATH_HAS_NO_DISCOVERED_CANDIDATE",
        })
        return _finish_selection(base)

    if symbol_matches or path_matches or explicit_paths:
        if symbol_matches and path_matches:
            matched_keys = symbol_keys & path_keys
            if not matched_keys:
                base.update({
                    "resolution": "UNRESOLVED",
                    "reason": "CONFLICTING_EXACT_SYMBOL_AND_PATH_HINTS",
                    "selection_basis": [
                        {"kind": "EXACT_SYMBOL_MENTION", "values": sorted({name for _, name in symbol_matches})},
                        {"kind": "EXACT_SOURCE_PATH_MENTION", "values": sorted({path for _, path in path_matches})},
                    ],
                    "conflicting_anchor_candidates": {
                        "symbol": [_candidate_brief(row) for row, _ in symbol_matches],
                        "path": [_candidate_brief(row) for row, _ in path_matches],
                    },
                    "selection_confidence_boundary": "CONTRADICTORY_TASK_ANCHORS",
                })
                return _finish_selection(base)
            basis = [
                {"kind": "EXACT_SYMBOL_MENTION", "values": sorted({name for row, name in symbol_matches if _candidate_key(row) in matched_keys})},
                {"kind": "EXACT_SOURCE_PATH_MENTION", "values": sorted({path for row, path in path_matches if _candidate_key(row) in matched_keys})},
            ]
            reason = "UNIQUE_EXACT_SYMBOL_AND_PATH_ANCHORS"
            confidence = "HIGH_EXACT_SYMBOL_AND_PATH_ANCHORS"
        elif symbol_matches:
            matched_keys = symbol_keys
            basis = [{"kind": "EXACT_SYMBOL_MENTION", "values": sorted({name for _, name in symbol_matches})}]
            reason = "UNIQUE_EXACT_SYMBOL_MENTION"
            confidence = "HIGH_EXACT_SYMBOL_ANCHOR"
        else:
            matched_keys = path_keys
            basis = [{"kind": "EXACT_SOURCE_PATH_MENTION", "values": sorted({path for _, path in path_matches})}]
            reason = "UNIQUE_EXACT_SOURCE_PATH_WITHIN_CANDIDATE_SET"
            confidence = "HIGH_EXACT_PATH_ANCHOR"

        if len(matched_keys) == 1:
            selected_key = next(iter(matched_keys))
            selected = next(row for row in rows if _candidate_key(row) == selected_key)
            brief = _candidate_brief(selected)
            selected_symbols = sorted({name for row, name in symbol_matches if _candidate_key(row) == selected_key})
            base.update({
                "resolution": "RESOLVED",
                "reason": reason,
                "selected_candidate_id": brief["candidate_id"],
                "selected_candidate_instance_id": brief["candidate_instance_id"],
                "selected_source_path": brief["source_path"],
                "selected_symbol": selected_symbols[0] if selected_symbols else brief["symbol"],
                "candidate_kind": brief["candidate_kind"],
                "selected_site_lines": [brief["site_line_start"], brief["site_line_end"]],
                "selection_basis": basis,
                "rejected_alternatives": [
                    {**_candidate_brief(row), "reason": "EXACT_TASK_ANCHORS_NOT_MATCHED"}
                    for row in rows if _candidate_key(row) != selected_key
                ],
                "selection_confidence_boundary": confidence,
            })
            return _finish_selection(base)

        ambiguous_rows = [row for row in rows if _candidate_key(row) in matched_keys]
        base.update({
            "resolution": "AMBIGUOUS",
            "reason": "TASK_EXACT_ANCHORS_MATCH_MULTIPLE_DISCOVERED_CANDIDATES",
            "ambiguous_candidates": [_candidate_brief(row) for row in ambiguous_rows],
            "selection_basis": basis,
            "selection_confidence_boundary": "INSUFFICIENT_EVIDENCE",
        })
        return _finish_selection(base)

    kind_filter = _task_kind_filter(task)
    pool = [row for row in rows if not kind_filter or row.get("kind") == kind_filter]
    constraints = _task_constraints(task)
    matches: List[Dict[str, Any]] = []
    rejected: List[Dict[str, Any]] = []
    for row in pool:
        facts = ((row.get("semantic_witness") or {}).get("condition_facts") or {})
        mismatches = [key for key, expected in constraints.items() if facts.get(key) != expected]
        if not mismatches:
            matches.append(row)
        else:
            rejected.append({**_candidate_brief(row), "reason": "TASK_STRUCTURAL_CONSTRAINT_MISMATCH", "mismatched_constraints": mismatches})

    structural_basis = []
    if kind_filter:
        structural_basis.append({"kind": "CANDIDATE_KIND_CONSTRAINT", "value": kind_filter})
    structural_basis.extend({"kind": "TASK_STRUCTURAL_CONSTRAINT", "field": key, "value": value} for key, value in sorted(constraints.items()))
    if len(matches) == 1 and len(constraints) >= 2:
        selected = matches[0]
        brief = _candidate_brief(selected)
        base.update({
            "resolution": "RESOLVED",
            "reason": "UNIQUE_MATCH_FOR_MULTIPLE_TASK_STRUCTURAL_CONSTRAINTS",
            "selected_candidate_id": brief["candidate_id"],
            "selected_candidate_instance_id": brief["candidate_instance_id"],
            "selected_source_path": brief["source_path"],
            "selected_symbol": brief["symbol"],
            "candidate_kind": brief["candidate_kind"],
            "selected_site_lines": [brief["site_line_start"], brief["site_line_end"]],
            "selection_basis": structural_basis,
            "rejected_alternatives": rejected + [
                {**_candidate_brief(row), "reason": "TASK_KIND_CONSTRAINT_MISMATCH"}
                for row in rows if row not in pool
            ],
            "selection_confidence_boundary": "UNIQUE_STRUCTURAL_MATCH_WITH_TWO_OR_MORE_TASK_CONSTRAINTS",
        })
        return _finish_selection(base)

    if matches:
        base.update({
            "resolution": "AMBIGUOUS",
            "reason": "TASK_EVIDENCE_DOES_NOT_DISCRIMINATE_CANDIDATES",
            "ambiguous_candidates": [_candidate_brief(row) for row in matches],
            "selection_basis": structural_basis,
            "rejected_alternatives": rejected + [
                {**_candidate_brief(row), "reason": "TASK_KIND_CONSTRAINT_MISMATCH"}
                for row in rows if row not in pool
            ],
            "selection_confidence_boundary": "INSUFFICIENT_DISCRIMINATING_TASK_EVIDENCE",
        })
        return _finish_selection(base)

    base.update({
        "resolution": "UNRESOLVED",
        "reason": "NO_DISCOVERED_CANDIDATE_MATCHES_TASK_EVIDENCE",
        "selection_basis": structural_basis,
        "rejected_alternatives": rejected + [
            {**_candidate_brief(row), "reason": "TASK_KIND_CONSTRAINT_MISMATCH"}
            for row in rows if row not in pool
        ],
    })
    return _finish_selection(base)


def _selection_digest_valid(selection: Mapping[str, Any]) -> bool:
    payload = dict(selection)
    supplied = payload.pop("candidate_selection_digest", None)
    return isinstance(supplied, str) and supplied == _digest(payload)


def _raw_source_site_facts(
    binding: Mapping[str, Any], candidate: Mapping[str, Any],
) -> Dict[str, Any]:
    """Re-read the selected exact site and derive its bounded condition facts."""
    files = candidate.get("files", []) or []
    if len(files) != 1:
        return {"valid": False, "reason": "SOURCE_FILE_CARDINALITY_INVALID"}
    root = Path(str(binding.get("target_root") or "")).expanduser().resolve()
    relative = Path(str(files[0]))
    if relative.is_absolute():
        return {"valid": False, "reason": "SOURCE_PATH_MUST_BE_TARGET_RELATIVE"}
    try:
        source_path = (root / relative).resolve()
        source_path.relative_to(root)
    except (OSError, ValueError):
        return {"valid": False, "reason": "SOURCE_PATH_ESCAPES_TARGET_ROOT"}
    try:
        source = source_path.read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        return {"valid": False, "reason": "SOURCE_PATH_UNREADABLE"}

    witness = candidate.get("semantic_witness", {}) or {}
    site = witness.get("source_site", {}) or {}
    start = site.get("char_start")
    end = site.get("char_end")
    if not isinstance(start, int) or not isinstance(end, int) or start < 0 or end <= start or end > len(source):
        return {"valid": False, "reason": "SOURCE_SITE_OFFSETS_INVALID"}
    matched = source[start:end]
    site_digest = "sha256:" + hashlib.sha256(matched.encode("utf-8")).hexdigest()
    pair = re.fullmatch(
        r"(?s)\s*if[ \t]*\((?P<condition>[^\r\n()]*)\)[ \t]*\{[ \t]*\r?\n"
        r"\s*return[ \t]+(?P<first>true|false);?[ \t]*\r?\n"
        r"\s*\}[ \t]*(?:\r?\n[ \t]*)+return[ \t]+(?P<second>true|false);?[ \t]*",
        matched,
    )
    if not pair or pair.group("first") == pair.group("second"):
        return {
            "valid": False,
            "reason": "SOURCE_SITE_NO_LONGER_MATCHES_OPPOSITE_BOOLEAN_PAIR",
            "source_site_sha256": site_digest,
        }
    condition = pair.group("condition").strip()
    condition_pattern = re.compile(
        r"^(?P<left>[A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)*)"
        r"\s*(?P<operator>===|!==|==|!=)\s*"
        r"(?P<right>'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\")$"
    )
    condition_match = condition_pattern.fullmatch(condition)
    if not condition_match:
        return {
            "valid": False,
            "reason": "SOURCE_CONDITION_OUTSIDE_INTERNAL_CAPABILITY_SCOPE",
            "source_site_sha256": site_digest,
        }
    transformation = "inverse" if pair.group("first") == "false" else "positive"
    return {
        "valid": True,
        "source_path": str(relative).replace("\\", "/"),
        "source_site_sha256": site_digest,
        "source_condition_sha256": "sha256:" + hashlib.sha256(condition.encode("utf-8")).hexdigest(),
        "operator": condition_match.group("operator"),
        "left_operand": condition_match.group("left"),
        "left_operand_shape": "IDENT_OR_MEMBER_CHAIN_NO_OPTIONAL_CHAINING",
        "right_operand_kind": "STRING_LITERAL",
        "right_literal": condition_match.group("right"),
        "transformation": transformation,
        "line_start": source.count("\n", 0, start) + 1,
        "line_end": source.count("\n", 0, end) + 1,
    }


def match_internal_candidate_capability(
    selection: Mapping[str, Any],
    binding: Mapping[str, Any],
    candidates: Sequence[Mapping[str, Any]],
) -> Dict[str, Any]:
    """Match selected source facts to an internal contract; return no authority."""
    rows = [dict(row) for row in candidates]
    rows.sort(key=lambda row: _candidate_key(row) + (_digest(row),))
    contract = _INTERNAL_CANDIDATE_CAPABILITIES["js_boolean_guard.strict_equality_string.temp_worktree.v1"]
    contract_digest = _digest(contract)
    base: Dict[str, Any] = {
        "schema_version": "internal-candidate-capability-match-v1",
        "status": "CAPABILITY_NOT_MATCHED",
        "selected_candidate_id": selection.get("selected_candidate_id"),
        "selected_candidate_instance_id": selection.get("selected_candidate_instance_id"),
        "discovery_snapshot_digest": binding.get("discovery_snapshot_digest"),
        "candidate_set_digest": (binding.get("candidate_set", {}) or {}).get("candidate_set_digest"),
        "capability_contract_digest": contract_digest,
        "matched_capability_id": None,
        "match_facts": {},
        "rejection_reasons": [],
        "authority": {
            "capability_match_only": True,
            "authorization": False,
            "execution": False,
            "mutation": False,
            "correctness": False,
            "evidence_acceptance": False,
        },
    }
    invalid = _verify_binding(binding, rows)
    if invalid:
        base["rejection_reasons"] = [invalid]
        return base
    if not _selection_digest_valid(selection):
        base["rejection_reasons"] = ["CANDIDATE_SELECTION_DIGEST_MISMATCH"]
        return base
    try:
        replayed_selection = select_candidate(
            str(selection.get("task") or ""), binding, rows,
        )
        selection_matches_replay = _canonical_bytes(dict(selection)) == _canonical_bytes(replayed_selection)
    except (TypeError, ValueError):
        selection_matches_replay = False
    if not selection_matches_replay:
        base["rejection_reasons"] = ["SELECTION_DECISION_RECOMPUTATION_MISMATCH"]
        return base
    if selection.get("resolution") != "RESOLVED":
        base["rejection_reasons"] = ["CANDIDATE_SELECTION_NOT_RESOLVED"]
        return base
    if selection.get("discovery_snapshot_digest") != binding.get("discovery_snapshot_digest"):
        base["rejection_reasons"] = ["SELECTION_DISCOVERY_SNAPSHOT_MISMATCH"]
        return base
    if selection.get("candidate_set_digest") != (binding.get("candidate_set", {}) or {}).get("candidate_set_digest"):
        base["rejection_reasons"] = ["SELECTION_CANDIDATE_SET_MISMATCH"]
        return base

    selected_id = str(selection.get("selected_candidate_id") or "")
    selected_instance = str(selection.get("selected_candidate_instance_id") or "")
    matches = [
        row for row in rows
        if row.get("candidate_id") == selected_id
        and row.get("candidate_instance_id") == selected_instance
    ]
    if len(matches) != 1:
        base["rejection_reasons"] = ["SELECTED_CANDIDATE_INSTANCE_NOT_UNIQUE_IN_DISCOVERY_SET"]
        return base
    candidate = matches[0]
    witness = candidate.get("semantic_witness", {}) or {}
    site = witness.get("source_site", {}) or {}
    facts = witness.get("condition_facts", {}) or {}
    raw_facts = _raw_source_site_facts(binding, candidate)
    instance_payload = {
        "candidate_id": candidate.get("candidate_id"),
        "source_site_sha256": site.get("matched_source_sha256"),
        "source_char_start": site.get("char_start"),
        "source_char_end": site.get("char_end"),
    }
    computed_instance = "sha256:" + hashlib.sha256(
        json.dumps(instance_payload, sort_keys=True).encode("utf-8")
    ).hexdigest()
    checks = {
        "candidate_instance_id": selected_instance == computed_instance == candidate.get("candidate_instance_id"),
        "rule_kind": candidate.get("kind") == contract["rule"],
        "single_source_file": len(candidate.get("files", []) or []) == 1,
        "single_site_member": len(candidate.get("members", []) or []) == 1,
        "single_bound_source_site": (
            witness.get("type") == "js_boolean_guard_return_v3"
            and isinstance(site.get("char_start"), int)
            and isinstance(site.get("char_end"), int)
            and site.get("char_end") > site.get("char_start")
            and str(site.get("matched_source_sha256", "")).startswith("sha256:")
        ),
        "site_member_binding": (
            len(candidate.get("members", []) or []) == 1
            and isinstance(candidate["members"][0], Mapping)
            and candidate["members"][0].get("file") == (candidate.get("files", []) or [None])[0]
            and candidate["members"][0].get("name") in (candidate.get("names", []) or [])
            and candidate["members"][0].get("line_start") == site.get("line_start")
            and candidate["members"][0].get("line_end") == site.get("line_end")
        ),
        "source_extension": str((candidate.get("files", []) or [""])[0]).endswith(tuple(contract["source_extensions"])),
        "operator": facts.get("operator") == contract["condition"]["operator"],
        "left_operand_shape": facts.get("left_operand_shape") == contract["condition"]["left_operand_shape"],
        "right_operand_kind": facts.get("right_operand_kind") == contract["condition"]["right_operand_kind"],
        "transformation": facts.get("transformation") in contract["transformations"],
        "source_condition_digest": str(facts.get("source_condition_sha256", "")).startswith("sha256:"),
        "source_bytes_match_site_digest": raw_facts.get("valid") is True and raw_facts.get("source_site_sha256") == site.get("matched_source_sha256"),
        "source_facts_match_discovery_witness": raw_facts.get("valid") is True and all(
            raw_facts.get(key) == facts.get(key)
            for key in (
                "source_condition_sha256", "operator", "left_operand", "left_operand_shape",
                "right_operand_kind", "right_literal", "transformation",
            )
        ),
        "source_lines_match_discovery_witness": raw_facts.get("valid") is True and (
            raw_facts.get("line_start") == site.get("line_start")
            and raw_facts.get("line_end") == site.get("line_end")
        ),
    }
    base["match_facts"] = {**checks, "condition": facts, "source_site": site, "raw_source_facts": raw_facts}
    failures = [key for key, passed in checks.items() if not passed]
    if failures:
        base["rejection_reasons"] = ["INTERNAL_CAPABILITY_SCOPE_MISMATCH:" + key for key in failures]
        return base
    base.update({
        "status": "CAPABILITY_MATCHED",
        "matched_capability_id": contract["capability_id"],
        "rejection_reasons": [],
    })
    return base


def run_candidate_provenance(root: str, task: str, *, include_capability_match: bool) -> Dict[str, Any]:
    from core.simplification_analyzer import analyze_simplification

    discovery = analyze_simplification(root)
    binding, candidates = build_discovery_binding(root, discovery)
    selection = select_candidate(task, binding, candidates)
    result: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "stage": "CANDIDATE_SELECTION_" + str(selection.get("resolution")),
        "discovery_snapshot": binding,
        "candidate_selection": selection,
        "authority": {
            "discovery_is_read_only": True,
            "selection_is_authorization": False,
            "capability_match_is_authorization": False,
            "executes_capability": False,
            "mutates_target": False,
            "correctness_proven": False,
            "evidence_accepted": False,
        },
    }
    if include_capability_match:
        route = match_internal_candidate_capability(selection, binding, candidates)
        result["candidate_capability_match"] = route
        result["stage"] = "CANDIDATE_CAPABILITY_" + route["status"]
    return result


__all__ = [
    "SCHEMA_VERSION",
    "POLICY",
    "build_discovery_binding",
    "select_candidate",
    "match_internal_candidate_capability",
    "run_candidate_provenance",
]
