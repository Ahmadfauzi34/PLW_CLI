"""Read-only declarative operation-plan resolution.

This module binds a declarative plan to machine-readable operation contracts.
It never invokes the selected operation and grants no execution authority.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Mapping

from core.semantic_affordance import describe_command

PLAN_SCHEMA_VERSION = "plw-operation-plan-v1"
RESOLUTION_SCHEMA_VERSION = "plw-operation-plan-resolution-v1"


def _canonical_digest(value: Any) -> str:
    serialized = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    try:
        payload = serialized.encode("utf-8")
    except UnicodeEncodeError:
        # An escaped JSON surrogate must still get a stable plan digest so the
        # resolver can reject its positional value with a structured result.
        payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _authority() -> Dict[str, bool]:
    return {
        "invocation_authorized": False,
        "executes_operation": False,
        "mutates_source": False,
        "grants_correctness": False,
        "grants_evidence_acceptance": False,
        "commits_truth": False,
    }


def _type_matches(value: Any, type_name: str) -> bool:
    if type_name in ("string", "path", "path-or-stdin"):
        return isinstance(value, str)
    if type_name == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if type_name == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if type_name == "boolean":
        return isinstance(value, bool)
    if type_name == "object":
        return isinstance(value, Mapping)
    if type_name == "array":
        return isinstance(value, list)
    return False


def _bind_operation(operation: Mapping[str, Any], supplied_inputs: Mapping[str, Any]) -> Dict[str, Any]:
    invocation = operation.get("invocation", {}) or {}
    specs = invocation.get("inputs", []) or []
    known = {str(row.get("name")) for row in specs if row.get("name")}
    unknown = sorted(str(key) for key in supplied_inputs if str(key) not in known)
    errors: list[Dict[str, Any]] = []
    if unknown:
        errors.append({"code": "UNKNOWN_INPUT", "inputs": unknown})

    bound: Dict[str, Any] = {}
    for spec in specs:
        name = str(spec.get("name") or "")
        if not name:
            errors.append({"code": "INVALID_OPERATION_CONTRACT", "detail": "input name missing"})
            continue
        if name in supplied_inputs:
            value = supplied_inputs[name]
        elif "default" in spec:
            value = spec.get("default")
        elif spec.get("required") is True:
            errors.append({"code": "MISSING_REQUIRED_INPUT", "input": name})
            continue
        else:
            continue
        type_name = str(spec.get("type") or "")
        if not _type_matches(value, type_name):
            errors.append({
                "code": "INPUT_TYPE_MISMATCH",
                "input": name,
                "expected_type": type_name,
                "observed_type": type(value).__name__,
            })
            continue
        # POSIX argv cannot contain NUL. A string is not an invokable input
        # merely because it satisfies the operation contract's JSON type.
        if isinstance(value, str):
            try:
                value.encode("utf-8")
            except UnicodeEncodeError:
                errors.append({
                    "code": "INPUT_VALUE_UNREPRESENTABLE_IN_ARGV",
                    "input": name,
                    "detail": "input is not valid UTF-8 process argument text",
                })
                continue
            if "\x00" in value:
                errors.append({
                    "code": "INPUT_VALUE_UNREPRESENTABLE_IN_ARGV",
                    "input": name,
                    "detail": "NUL byte is not representable in a process argument",
                })
                continue
        bound[name] = value

    argv = list(invocation.get("command_prefix", []) or [])
    if not errors:
        json_flag = invocation.get("json_flag")
        if isinstance(json_flag, str) and json_flag:
            argv.append(json_flag)
        # Keep every positional input as data, including -h and --json. The
        # flag must precede the end-of-options delimiter for argparse.
        argv.append("--")
        for spec in specs:
            name = str(spec.get("name") or "")
            if name in bound:
                value = bound[name]
                if isinstance(value, bool):
                    argv.append("true" if value else "false")
                elif isinstance(value, (dict, list)):
                    argv.append(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False))
                else:
                    argv.append(str(value))

    return {
        "operation_id": operation.get("operation_id"),
        "bindable": not errors,
        "bound_inputs": bound,
        "binding_errors": errors,
        "compiled_argv": argv if not errors else None,
        "operation_contract_digest": _canonical_digest(operation),
    }


def _domain_outcomes(operation: Mapping[str, Any]) -> Dict[str, Any]:
    output = operation.get("output", {}) or {}
    return {
        "schema_version": output.get("schema_version"),
        "domain_state_path": output.get("domain_state_path") or output.get("selection_state_path"),
        "domain_states": list(output.get("domain_states") or output.get("selection_states") or []),
        "match_state_path": output.get("match_state_path"),
        "match_states": list(output.get("match_states") or []),
        "domain_outcomes_exit_code": output.get("domain_outcomes_exit_code"),
    }


def resolve_operation_plan(plan: Mapping[str, Any]) -> Dict[str, Any]:
    """Resolve one declarative plan against public operation contracts only."""
    normalized_plan = dict(plan)
    base: Dict[str, Any] = {
        "schema_version": RESOLUTION_SCHEMA_VERSION,
        "plan_schema_version": normalized_plan.get("schema_version"),
        "plan_digest": _canonical_digest(normalized_plan),
        "status": "REJECTED",
        "capability": normalized_plan.get("capability"),
        "requested_operation_id": normalized_plan.get("operation_id"),
        "resolution_scope": "operation_contract_binding_only",
        "executes_operation": False,
        "authority": _authority(),
    }

    if normalized_plan.get("schema_version") != PLAN_SCHEMA_VERSION:
        base["reason"] = "PLAN_SCHEMA_UNSUPPORTED"
        base["expected_plan_schema_version"] = PLAN_SCHEMA_VERSION
        return base

    capability = normalized_plan.get("capability")
    if not isinstance(capability, str) or not capability:
        base["reason"] = "CAPABILITY_REQUIRED"
        return base

    supplied_inputs = normalized_plan.get("inputs", {})
    if not isinstance(supplied_inputs, Mapping):
        base["reason"] = "INPUT_BINDINGS_MUST_BE_OBJECT"
        return base

    contract = describe_command(capability)
    operations = contract.get("operation_contracts", []) or []
    base["capability_known"] = bool(contract.get("known"))
    base["available_operation_ids"] = [row.get("operation_id") for row in operations]
    if not contract.get("known"):
        base["reason"] = "CAPABILITY_UNKNOWN"
        return base
    if not operations:
        base["reason"] = "NO_OPERATION_CONTRACTS"
        return base

    requested = normalized_plan.get("operation_id")
    candidates = operations
    if requested is not None:
        if not isinstance(requested, str) or not requested:
            base["reason"] = "OPERATION_ID_INVALID"
            return base
        candidates = [row for row in operations if row.get("operation_id") == requested]
        if not candidates:
            base["reason"] = "OPERATION_ID_NOT_FOUND_FOR_CAPABILITY"
            return base

    evaluations = [_bind_operation(row, supplied_inputs) for row in candidates]
    bindable = [row for row in evaluations if row.get("bindable")]
    base["candidate_bindings"] = evaluations

    if len(bindable) == 0:
        base["reason"] = "NO_OPERATION_BINDING_ACCEPTS_INPUTS"
        return base
    if len(bindable) > 1:
        base["status"] = "AMBIGUOUS"
        base["reason"] = "MULTIPLE_OPERATION_BINDINGS_ACCEPT_INPUTS"
        base["candidate_operation_ids"] = [row.get("operation_id") for row in bindable]
        base["compiled_argv"] = None
        base["next_gate"] = "SELECT_EXACT_OPERATION_ID"
        return base

    selected_binding = bindable[0]
    selected_operation = next(
        row for row in candidates if row.get("operation_id") == selected_binding.get("operation_id")
    )
    base.update({
        "status": "RESOLVED",
        "reason": "EXACT_OPERATION_BINDING_RESOLVED",
        "resolved_operation_id": selected_binding.get("operation_id"),
        "bound_inputs": selected_binding.get("bound_inputs"),
        "compiled_argv": selected_binding.get("compiled_argv"),
        "operation_contract_digest": selected_binding.get("operation_contract_digest"),
        "possible_domain_outcomes": _domain_outcomes(selected_operation),
        "capacity": dict(selected_operation.get("capacity", {}) or {}),
        "failure_model": dict(selected_operation.get("failure_model", {}) or {}),
        "next_gate": "AGENT_MAY_CHOOSE_INVOCATION",
    })
    return base
