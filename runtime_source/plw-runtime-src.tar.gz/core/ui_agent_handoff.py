"""Bounded source witness from an Angular UI question to a work target hint."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

from codebase.static_ui_reference import static_ui_reference


def build_ui_agent_handoff(task: str, graph: Dict[str, Any], *,
                           selector: Optional[str] = None) -> Dict[str, Any]:
    root = Path(graph.get("scan_root") or ".").resolve()
    vertices = {str(Path(node).resolve()) for node in graph.get("vertices", []) or []}
    has_angular = any("@Component" in str(content)
                      for content in (graph.get("file_map") or {}).values())
    base: Dict[str, Any] = {
        "schema_version": "plw-ui-agent-handoff-v1",
        "status": "NOT_APPLICABLE",
        "selection_scope": "source_declaration_only",
        "authority": {"read_only": True, "target_hint_only": True,
                      "rendered_dom_observed": False, "geometry_observed": False,
                      "execute_runtime": False, "mutate_source": False,
                      "commit_truth": False},
    }
    if not has_angular:
        return base
    reference = static_ui_reference(task, graph, selector=selector, max_candidates=8)
    decision = reference["decision"]
    base.update({
        "status": decision["status"],
        "reason": decision["reason"],
        "query": task,
        "selector": selector,
        "graph_content_signature": reference["graph_content_signature"],
        "angular_ownership_digest": reference["angular_ownership_digest"],
        "matching_candidate_count": decision["matching_candidate_count"],
        "omitted_candidate_count": decision["omitted_candidate_count"],
        "unresolved_templates": reference["unresolved_templates"],
        "unresolved_templates_omitted": reference["unresolved_templates_omitted"],
        "candidates": [{"component_file": row["component_file"],
                        "component_selector": row["component_selector"],
                        "template_file": row["template_file"],
                        "template_sha256": row["template_sha256"],
                        "template_line": row["template_line"],
                        "label": row["element"]["label"],
                        "matched_terms": row["matched_terms"],
                        "score": row["score"]}
                       for row in reference["candidates"]],
        "next_ui_static_argv": ["plw", "ui", "static", task, str(root)]
                               + (["--selector", selector] if selector else []) + ["--json"],
        "next_capability_argv": ["plw", "capability", "describe", "ui-static", "--json"],
        "next_skill_argv": ["plw", "skill", "show", "ui-static", "--json"],
    })
    selected = decision.get("selected")
    if selected:
        component = Path(selected["component_file"]).resolve()
        if str(component) in vertices and component.is_relative_to(root):
            target = component.relative_to(root).as_posix()
            base["source_target_hint"] = {
                "component_file": target,
                "component_selector": selected["component_selector"],
                "template_file": selected["template_file"],
                "template_sha256": selected["template_sha256"],
                "template_line": selected["template_line"],
                "match_evidence": selected["match_evidence"],
                "template_condition": selected["template_condition"],
                "style_status": selected["style_reference"]["status"],
            }
            base["suggested_work_argv"] = ["plw", "work", task, str(root),
                                           "--target", target]
            base["next_reasoning"] = (
                "Inspect the exact UI source reference, then use the hinted component "
                "as an explicit work target if it matches the task. Neither call proves rendering."
            )
        else:
            base["status"] = "AMBIGUOUS"
            base["reason"] = "selected_component_not_in_current_graph"
    if not base.get("source_target_hint"):
        base["next_reasoning"] = (
            "Inspect all source candidates and unresolved templates with ui static; "
            "supply a grounded selector or explicit target only after disambiguation."
        )
    return base
