"""Engine-backed symbol layer for the SharedGraph topology (topology-engine-v2).

The stable topology graph (``core/shared_graph.py``) only sees files and
file->file import edges for TS/JS/Kotlin/Rust (``SOURCE_EXTENSIONS`` in
``language_semantics.py``).  Go/Python files are not vertices at all.
This module adds a second, clearly-marked layer on top of that graph,
built from the ``codesearch-go`` tree-sitter engine (``core/codesearch_engine.py``):

* symbol nodes — definitions verified by the engine AST (``defs``); ``window``
  fallback chunks and generated/declaration assets are excluded;
* symbol edges — ``calls`` / ``related`` rows, which are name-based
  (callee normalised to its trailing identifier) and therefore LEADS,
  never proof;
* file rollup — ``engine_file_edges``, the file->file pairs implied by
  the symbol edges, kept separate from the graph's import ``edges``.

Contract
--------
* Read-only.  Nothing is written into the target root.  Both codesearch's
  gob index and the engine_layer JSON cache live under PLW's own cache root.
* Additive.  This layer never mutates the SharedGraph it is built from
  and never writes into the cached graph: the caller merges it at
  projection time (``core/target_topology.py``).
* Never raises.  ``build_engine_layer`` returns an explicit unavailable
  (or partial) layer on every failure, so topology keeps working without
  an engine.  A per-symbol engine failure is recorded and the remaining
  symbols are still queried.
* Bounded.  When ``target_files`` is provided (target-grounded or
  1-hop neighborhood), all non-noise candidates in scope are queried. In
  whole-repo mode, a relevance-ranked default budget (``300`` symbols)
  keeps agent calls bounded and fast; pass ``full_engine=True`` to lift
  the budget.
* Compact v2 (default).  Layer-level provenance lives in ``engine`` and
  call edges reference ``symbol_nodes`` via ``candidate_ids`` instead of
  repeating full candidate/provenance objects per edge.  Pass
  ``full_engine_edges=True`` for the legacy ``plw-topology-engine-v1`` shape.
* Authority.  Every node/edge carries ``authority`` (``definition`` for
  AST-verified definitions, ``lead-name-based`` for calls/relations).
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from core.codesearch_engine import (
    AUTHORITY_NOTE,
    DEFAULT_TIMEOUT_S,
    EngineError,
    doctor_status,
    run_batch_query,
)
from core.runtime_paths import cache_path, ensure_private_directory
from core.shared_graph import DEFAULT_IGNORE_DIRS, graph_content_signature, parse_imports_with_nature
from language_semantics import (
    is_declaration_file as _is_declaration_file,
    is_generated_or_vendored_asset as _is_generated_or_vendored_asset,
    kotlin_top_level_names as _kotlin_top_level_names,
    normalize_path as _normalize_path,
    rust_top_level_names as _rust_top_level_names,
    strip_js_comments as _strip_js_comments,
)

LEGACY_ENGINE_LAYER_SCHEMA_VERSION = "plw-topology-engine-v1"
ENGINE_LAYER_SCHEMA_VERSION = "plw-topology-engine-v2"
ENGINE_CACHE_SCHEMA_VERSION = "engine-layer-cache-v2"
DEFAULT_WHOLE_REPO_MAX_SYMBOLS = 300
HIGH_CALLER_NOISE_CAP = 80

# Files the stable graph never sees as vertices, but the engine parses.
ENGINE_FILE_EXTENSIONS = {".go": "go", ".rs": "rust", ".py": "python"}

# Extension -> engine language, for definition nodes in any language.
# G2 (2026-11-14): ".kt" -> "kotlin" — without it every Kotlin symbol
# node was labeled "unknown". Modern module extensions (.mjs/.cjs/.mts/.cts)
# map to their respective javascript/typescript languages. ".kts" stays
# out on purpose (out of scope).
FILE_LANGUAGE_BY_EXTENSION = {
    ".go": "go",
    ".rs": "rust",
    ".py": "python",
    ".js": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".jsx": "jsx",
    ".ts": "typescript",
    ".mts": "typescript",
    ".cts": "typescript",
    ".tsx": "tsx",
    ".kt": "kotlin",
}

# Common stdlib / collection / UI primitive identifiers that cause high-fan-out
# query noise across JS/TS, Kotlin Compose, and Rust. Filtered via signal-based
# gating (only suppressed pre-query when no internal definition exists in
# scope, or post-query when caller fan-out exceeds HIGH_CALLER_NOISE_CAP).
COMMON_NOISE_SYMBOLS: Set[str] = {
    "get", "set", "has", "add", "delete", "clear", "map", "filter", "reduce",
    "forEach", "find", "some", "every", "includes", "indexOf", "slice", "splice",
    "push", "pop", "shift", "unshift", "join", "split", "trim", "replace", "match",
    "keys", "values", "entries", "from", "of", "assign", "create", "freeze",
    "toString", "valueOf", "toJSON", "then", "catch", "finally", "resolve", "reject",
    "next", "done", "error", "warn", "info", "debug", "log", "close", "open",
    "start", "stop", "init", "read", "write", "send", "emit", "on", "off", "once",
    "default", "new", "value", "data", "item", "items", "name", "type", "id",
    "size", "length", "count", "index", "key", "result", "state", "status", "ok",
    "Text", "Column", "Row", "Box", "Spacer", "Modifier", "Icon", "Button", "Card",
    "Surface", "Scaffold", "padding", "fillMaxWidth", "fillMaxSize", "weight", "align",
    "copy", "equals", "hashCode", "let", "apply", "also", "with", "into",
    "try_into", "try_from", "clone", "unwrap", "expect", "as_ref", "as_str",
    "to_string", "len", "is_empty", "iter", "collect", "fmt", "drop",
    "JSON", "JSONObject", "JSONArray", "Promise", "Array", "Object", "String",
    "Number", "Boolean", "Error", "Map", "Set", "WeakMap", "WeakSet", "List",
    "MutableList", "Pair", "Result", "Unit",
}

# Definition patterns are CANDIDATE generators only: a name found here is
# a query for the engine, and only the engine's AST answer becomes a node.
_DEFINITION_PATTERNS = {
    "go": [
        re.compile(r"^\s*func\s+(?:\(\s*[^)]*\)\s*)?([A-Za-z_]\w*)\s*\(", re.MULTILINE),
        re.compile(r"^\s*type\s+([A-Za-z_]\w*)\s+", re.MULTILINE),
    ],
    "rust": [
        re.compile(r"^\s*(?:pub\s+)?fn\s+([A-Za-z_]\w*)\s*[\(<]", re.MULTILINE),
        re.compile(r"^\s*(?:pub\s+)?(?:struct|enum|trait)\s+([A-Za-z_]\w*)", re.MULTILINE),
    ],
    "python": [
        re.compile(r"^\s*(?:def|class)\s+([A-Za-z_]\w*)", re.MULTILINE),
    ],
}

_JS_TS_DECL_PATTERN = re.compile(
    r"^(?:export\s+(?:default\s+)?)?(?:async\s+)?"
    r"(?:function\*?|class|interface|type|enum|const|let|var)\s+([A-Za-z_$][\w$]*)",
    re.MULTILINE,
)

_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def unavailable_layer(reason: str, *, full_engine_edges: bool = False) -> Dict[str, Any]:
    """The explicit no-engine layer. Never raises."""
    schema_version = (
        LEGACY_ENGINE_LAYER_SCHEMA_VERSION
        if full_engine_edges
        else ENGINE_LAYER_SCHEMA_VERSION
    )
    return {
        "schema_version": schema_version,
        "available": False,
        "engine": None,
        "reason": str(reason),
        "error": None,
        "symbol_nodes": [],
        "symbol_edges": [],
        "engine_file_edges": [],
        "coverage": {
            "languages": [],
            "engine_language_files": 0,
            "target_files": 0,
            "symbol_nodes": 0,
            "symbol_edges": 0,
            "scope": "target-grounded",
            "symbols_total": 0,
            "symbols_filtered_common": 0,
            "budget": None,
            "truncated": False,
            "window_hits_dropped": 0,
            "generated_files_excluded": 0,
            "self_edges_excluded": 0,
            "high_caller_suppressed": [],
            "batch_mode": None,
            "cache_status": "miss",
            "symbols_queried": [],
            "symbols_without_definition": [],
            "symbols_failed": [],
        },
        "authority_note": AUTHORITY_NOTE,
    }


def _is_candidate(name: Any) -> bool:
    return (
        isinstance(name, str)
        and len(name) >= 2
        and bool(_IDENTIFIER_RE.match(name))
    )


def _relpath(path: str, root: str) -> str:
    """Root-relative forward-slash path (the layer's path convention)."""
    value = str(path).replace("\\", "/")
    if os.path.isabs(value):
        try:
            value = os.path.relpath(value, root).replace("\\", "/")
        except (OSError, ValueError):
            pass
    return _normalize_path(value)


def _canon_rel(path: str, root_abs: str) -> str:
    """Normalize a repo, CWD-relative, or root-relative path to root-relative POSIX."""
    text = _normalize_path(str(path))
    if os.path.isabs(text):
        return _relpath(os.path.abspath(text), root_abs)
    abs_cwd = os.path.abspath(text)
    try:
        if os.path.commonpath([abs_cwd, root_abs]) == root_abs:
            return _normalize_path(os.path.relpath(abs_cwd, root_abs))
    except ValueError:
        pass
    return text


def _walk_engine_files(
    root: str,
    wanted_rel: Optional[Set[str]],
    root_abs: str,
) -> Dict[str, str]:
    """Engine-language files under root: normalized path -> language."""
    found: Dict[str, str] = {}
    if wanted_rel is not None:
        for rel in sorted(wanted_rel):
            ext = os.path.splitext(rel)[1].lower()
            language = ENGINE_FILE_EXTENSIONS.get(ext)
            if language is None:
                continue
            fp = rel if os.path.isabs(rel) else os.path.join(root_abs, rel)
            if os.path.isfile(fp):
                found[_normalize_path(fp)] = language
        return found
    ignored = set(DEFAULT_IGNORE_DIRS)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(
            d for d in dirnames if d not in ignored and not d.startswith(".")
        )
        for filename in sorted(filenames):
            ext = os.path.splitext(filename)[1].lower()
            language = ENGINE_FILE_EXTENSIONS.get(ext)
            if language is None:
                continue
            full = _normalize_path(os.path.join(dirpath, filename))
            found[full] = language
    return dict(sorted(found.items()))


def _definition_candidates(content: str, language: str) -> Set[str]:
    names: Set[str] = set()
    for pattern in _DEFINITION_PATTERNS.get(language, []):
        for match in pattern.finditer(content):
            if _is_candidate(match.group(1)):
                names.add(match.group(1))
    return names


def _source_top_level_definitions(content: str, path: str) -> Set[str]:
    """Lightweight definition-name extractor for internal symbol verification."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".kt":
        return {n for n in _kotlin_top_level_names(content) if _is_candidate(n)}
    if ext == ".rs":
        return {n for n in _rust_top_level_names(content) if _is_candidate(n)}
    if ext in FILE_LANGUAGE_BY_EXTENSION and FILE_LANGUAGE_BY_EXTENSION[ext] in (
        "javascript", "jsx", "typescript", "tsx",
    ):
        clean = _strip_js_comments(content)
        return {m.group(1) for m in _JS_TS_DECL_PATTERN.finditer(clean) if _is_candidate(m.group(1))}
    lang = ENGINE_FILE_EXTENSIONS.get(ext)
    if lang:
        return _definition_candidates(content, lang)
    return set()


def _harvest_graph_candidates(
    graph: Dict[str, Any],
    wanted_rel: Optional[Set[str]],
    root_abs: str,
) -> Tuple[Set[str], Dict[str, int], Set[str], Set[str], Set[str], Set[str]]:
    """Collect candidates, import counts, type names, and internal definitions.

    When ``wanted_rel`` is provided, only vertices and ``type_shapes`` entries
    belonging to ``wanted_rel`` are included.  Internal definitions across all
    non-generated ``file_map`` entries are still recorded in
    ``internal_defined`` so signal-based stopword suppression never drops a
    genuinely project-defined symbol like ``class Box``.
    """
    candidates: Set[str] = set()
    import_counts: Dict[str, int] = {}
    internal_defined: Set[str] = set()
    scoped_defined: Set[str] = set()
    type_shape_names: Set[str] = set()
    generated_excluded: Set[str] = set()
    scoped_generated_excluded: Set[str] = set()

    file_map = graph.get("file_map") or {}
    vertices = list(graph.get("vertices") or [])

    for fp in vertices:
        fp_str = str(fp)
        rel = _canon_rel(fp_str, root_abs)
        content = file_map.get(fp)
        content_str = content if isinstance(content, str) else ""
        in_scope = wanted_rel is None or rel in wanted_rel
        if _is_generated_or_vendored_asset(rel, content_str):
            generated_excluded.add(rel)
            if in_scope:
                scoped_generated_excluded.add(rel)
            continue
        defs_here = _source_top_level_definitions(content_str, rel) if content_str else set()
        internal_defined |= defs_here

        if not in_scope:
            continue
        # Include locally defined top-level symbols in scope (even if unimported
        # entrypoints/leaves) so internal definitions outrank external imports.
        scoped_defined |= defs_here
        candidates |= defs_here
        if content_str:
            try:
                seen_in_file: Set[str] = set()
                for item in parse_imports_with_nature(content_str, fp_str):
                    for name in list(item.get("symbols") or []) + list(
                        item.get("semantic_usages") or []
                    ):
                        if _is_candidate(name):
                            candidates.add(name)
                            seen_in_file.add(name)
                for name in seen_in_file:
                    import_counts[name] = import_counts.get(name, 0) + 1
            except Exception:
                pass

    for fp, shapes in (graph.get("type_shapes") or {}).items():
        rel = _canon_rel(str(fp), root_abs)
        if _is_declaration_file(rel):
            if wanted_rel is None or rel in wanted_rel:
                scoped_generated_excluded.add(rel)
            continue
        if wanted_rel is not None and rel not in wanted_rel:
            continue
        if rel in generated_excluded:
            continue
        if isinstance(shapes, dict):
            for name in shapes:
                if _is_candidate(name):
                    candidates.add(name)
                    type_shape_names.add(name)

    return (
        candidates,
        import_counts,
        internal_defined,
        scoped_defined,
        type_shape_names,
        scoped_generated_excluded,
    )


def _rank_symbol(
    symbol: str,
    *,
    engine_defined: Set[str],
    scoped_defined: Set[str],
    internal_defined: Set[str],
    import_counts: Dict[str, int],
    type_shape_names: Set[str],
    seed_terms: Sequence[str] = (),
) -> int:
    score = 0
    if symbol in engine_defined or symbol in scoped_defined:
        score += 8
    if symbol in internal_defined:
        score += 4
    score += min(6, import_counts.get(symbol, 0) * 2)
    if symbol in type_shape_names:
        score += 2
    if any(ch.isupper() for ch in symbol) or "_" in symbol:
        score += 2
    if len(symbol) <= 3 and symbol.islower():
        score -= 2
    if seed_terms:
        sym_l = symbol.lower()
        if sym_l in seed_terms:
            score += 24
        elif any(len(term) >= 4 and term in sym_l for term in seed_terms):
            score += 12
    return score


def _file_language(path: str) -> str:
    return FILE_LANGUAGE_BY_EXTENSION.get(os.path.splitext(path)[1].lower(), "unknown")


def _engine_cache_key(
    *,
    root_abs: str,
    graph: Optional[Dict[str, Any]],
    engine_files: Dict[str, str],
    engine_status: Dict[str, Any],
    wanted_rel: Optional[Set[str]],
    effective_max_symbols: Optional[int],
    full_engine: bool,
    full_engine_edges: bool,
    seed_terms: Sequence[str] = (),
) -> str:
    graph_sig = ""
    if graph is not None:
        graph_sig = str((graph.get("cache") or {}).get("graph_content_signature") or "")
        if not graph_sig:
            graph_sig = graph_content_signature(graph)

    engine_stats: List[Tuple[str, int, int]] = []
    for fp in sorted(engine_files):
        try:
            st = os.stat(fp)
            engine_stats.append((_canon_rel(fp, root_abs), int(st.st_size), int(st.st_mtime_ns)))
        except OSError:
            engine_stats.append((_canon_rel(fp, root_abs), -1, -1))

    identity = {
        "cache_schema": ENGINE_CACHE_SCHEMA_VERSION,
        "schema_version": (
            LEGACY_ENGINE_LAYER_SCHEMA_VERSION if full_engine_edges else ENGINE_LAYER_SCHEMA_VERSION
        ),
        "root_abs": root_abs,
        "graph_signature": graph_sig,
        "engine_digest": str(engine_status.get("digest") or ""),
        "engine_schema": str(engine_status.get("schema") or ""),
        "engine_commit": str(engine_status.get("commit") or ""),
        "engine_files": engine_stats,
        "wanted": sorted(wanted_rel) if wanted_rel is not None else None,
        "max_symbols": effective_max_symbols,
        "full_engine": bool(full_engine),
        "full_engine_edges": bool(full_engine_edges),
        "noise_cap": HIGH_CALLER_NOISE_CAP,
        **({"seed_terms": list(seed_terms)} if seed_terms else {}),
    }
    encoded = json.dumps(identity, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()[:24]


def _engine_cache_path(cache_key: str) -> Path:
    return cache_path("codebase", "engine_layer", f"engine_layer_{cache_key}.json")


def _load_engine_cache(cache_key: str, engine_block: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    path = _engine_cache_path(cache_key)
    try:
        if not path.is_file():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not data.get("available") or data.get("error"):
            return None
        data["engine"] = dict(engine_block)
        coverage = dict(data.get("coverage") or {})
        coverage["cache_status"] = "hit"
        data["coverage"] = coverage
        return data
    except (OSError, ValueError):
        return None


def _save_engine_cache(cache_key: str, layer: Dict[str, Any]) -> None:
    if not layer.get("available") or layer.get("error"):
        return
    path = _engine_cache_path(cache_key)
    ensure_private_directory(path.parent)
    tmp_path: Optional[Path] = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            dir=str(path.parent),
            prefix=f".engine_layer_{cache_key}_",
            suffix=".tmp",
            delete=False,
        ) as handle:
            tmp_path = Path(handle.name)
            json.dump(layer, handle, separators=(",", ":"), ensure_ascii=False)
        try:
            os.chmod(tmp_path, 0o600)
        except OSError:
            pass
        os.replace(tmp_path, path)
    except OSError:
        if tmp_path is not None:
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass


def build_engine_layer(
    root: str,
    graph: Optional[Dict[str, Any]] = None,
    *,
    target_files: Optional[List[str]] = None,
    max_symbols: Optional[int] = None,
    timeout_s: int = DEFAULT_TIMEOUT_S,
    binary: Optional[str] = None,
    full_engine: bool = False,
    full_engine_edges: bool = False,
    cache_mode: str = "auto",
    seed_terms: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    """Build the engine symbol layer for a target root. Never raises.

    root is the scan root; graph is the SharedGraph dict (or None);
    target_files, when given, restricts candidate collection to those files;
    max_symbols overrides the default whole-repo 300-symbol budget;
    full_engine disables the default 300-symbol budget;
    full_engine_edges emits legacy plw-topology-engine-v1 expanded provenance.
    """
    root_path = Path(root)
    if not root_path.is_dir():
        return unavailable_layer(
            f"root is not a directory: {root}",
            full_engine_edges=full_engine_edges,
        )
    try:
        return _build_engine_layer(
            root, graph, target_files=target_files,
            max_symbols=max_symbols, timeout_s=timeout_s, binary=binary,
            full_engine=full_engine, full_engine_edges=full_engine_edges,
            cache_mode=cache_mode,
            seed_terms=seed_terms,
        )
    except Exception as exc:  # never break topology for the engine layer
        layer = unavailable_layer(
            f"topology engine layer failed: {exc}",
            full_engine_edges=full_engine_edges,
        )
        layer["error"] = str(exc)
        return layer


def _build_engine_layer(
    root: str,
    graph: Optional[Dict[str, Any]],
    *,
    target_files: Optional[List[str]],
    max_symbols: Optional[int],
    timeout_s: int,
    binary: Optional[str],
    full_engine: bool,
    full_engine_edges: bool,
    cache_mode: str,
    seed_terms: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    root_path = Path(root)
    root_abs = _normalize_path(os.path.abspath(root))
    wanted_rel: Optional[Set[str]] = None
    if target_files is not None:
        wanted_rel = {_canon_rel(tf, root_abs) for tf in target_files}

    # The walk needs no engine: even the unavailable layer reports how
    # many engine-language files exist, so the projection can say
    # honestly that they are uncovered.
    engine_files = _walk_engine_files(root, wanted_rel, root_abs)
    if wanted_rel is not None:
        target_file_count = len(wanted_rel)
    elif graph is not None:
        unique_files: Set[str] = {
            _canon_rel(str(v), root_abs) for v in (graph.get("vertices") or [])
        }
        unique_files |= {_canon_rel(fp, root_abs) for fp in engine_files}
        target_file_count = len(unique_files)
    else:
        target_file_count = len(engine_files)

    effective_max_symbols: Optional[int]
    if max_symbols is not None:
        effective_max_symbols = max(0, int(max_symbols))
    elif wanted_rel is None and not full_engine:
        effective_max_symbols = DEFAULT_WHOLE_REPO_MAX_SYMBOLS
    else:
        effective_max_symbols = None

    status = doctor_status(binary)
    if not status.get("available"):
        layer = unavailable_layer(
            str(status.get("reason") or "codesearch engine unavailable"),
            full_engine_edges=full_engine_edges,
        )
        layer["coverage"]["engine_language_files"] = len(engine_files)
        layer["coverage"]["target_files"] = target_file_count
        return layer
    binary_path = Path(str(status["binary"]))
    discovered_via = str(status.get("discovered_via") or "")
    engine_block = {
        "name": "codesearch-go",
        "binary": str(binary_path),
        "discovered_via": discovered_via,
        "schema": status.get("schema"),
        "commit": status.get("commit"),
    }

    cache_mode_norm = str(cache_mode or "auto").strip().lower()
    cache_key: Optional[str] = None
    seed_terms_norm = sorted({
        str(t).strip().lower() for t in (seed_terms or ()) if len(str(t).strip()) >= 3
    })
    if cache_mode_norm in ("auto", "refresh"):
        cache_key = _engine_cache_key(
            root_abs=root_abs,
            graph=graph,
            engine_files=engine_files,
            engine_status=status,
            wanted_rel=wanted_rel,
            effective_max_symbols=effective_max_symbols,
            full_engine=full_engine,
            full_engine_edges=full_engine_edges,
            seed_terms=seed_terms_norm,
        )
        if cache_mode_norm == "auto":
            cached = _load_engine_cache(cache_key, engine_block)
            if cached is not None:
                return cached

    candidates: Set[str] = set()
    import_counts: Dict[str, int] = {}
    internal_defined: Set[str] = set()
    scoped_defined: Set[str] = set()
    type_shape_names: Set[str] = set()
    engine_defined: Set[str] = set()
    generated_excluded_files: Set[str] = set()
    languages: Set[str] = set()
    if graph is not None:
        (
            g_cands,
            import_counts,
            internal_defined,
            scoped_defined,
            type_shape_names,
            scoped_generated_excluded,
        ) = _harvest_graph_candidates(graph, wanted_rel, root_abs)
        candidates |= g_cands
        generated_excluded_files |= scoped_generated_excluded
    for fp, language in engine_files.items():
        rel_ef = _canon_rel(fp, root_abs)
        try:
            with open(fp, "r", encoding="utf-8", errors="replace") as handle:
                raw_ef = handle.read()
        except OSError:
            continue
        if _is_generated_or_vendored_asset(rel_ef, raw_ef):
            generated_excluded_files.add(rel_ef)
            continue
        languages.add(language)
        edefs = _definition_candidates(raw_ef, language)
        candidates |= edefs
        engine_defined |= edefs
        internal_defined |= edefs

    # Review Guardrail #3: Signal-based stopword filtering — only drop common
    # stdlib/UI tokens when no internal definition exists in target scope.
    eligible: List[str] = []
    filtered_common = 0
    for sym in sorted(candidates):
        if sym in COMMON_NOISE_SYMBOLS and sym not in internal_defined:
            filtered_common += 1
            continue
        eligible.append(sym)

    truncated = False
    if effective_max_symbols is not None and len(eligible) > effective_max_symbols:
        ranked = sorted(
            eligible,
            key=lambda sym: (
                -_rank_symbol(
                    sym,
                    engine_defined=engine_defined,
                    scoped_defined=scoped_defined,
                    internal_defined=internal_defined,
                    import_counts=import_counts,
                    type_shape_names=type_shape_names,
                    seed_terms=seed_terms_norm,
                ),
                sym,
            ),
        )
        symbols = sorted(ranked[:effective_max_symbols])
        truncated = True
    else:
        symbols = sorted(eligible)

    symbol_nodes: List[Dict[str, Any]] = []
    symbol_edges: List[Dict[str, Any]] = []
    symbols_queried: List[str] = list(symbols)
    symbols_without_definition: List[str] = []
    symbols_failed: List[str] = []
    batch_modes: Set[str] = set()
    window_hits_dropped = 0
    high_caller_suppressed: Set[str] = set()
    self_edges_excluded = 0

    file_map_by_rel: Dict[str, str] = {}
    if graph is not None:
        for fp, content in (graph.get("file_map") or {}).items():
            if isinstance(content, str):
                file_map_by_rel[_canon_rel(str(fp), root_abs)] = content

    _excluded_cache: Dict[str, bool] = {}

    def _is_excluded_hit_file(rel: str) -> bool:
        cached_val = _excluded_cache.get(rel)
        if cached_val is not None:
            return cached_val
        if _is_generated_or_vendored_asset(rel, ""):
            _excluded_cache[rel] = True
            generated_excluded_files.add(rel)
            return True
        head = file_map_by_rel.get(rel, "")
        if not head:
            disk_path = rel if os.path.isabs(rel) else os.path.join(root_abs, rel)
            try:
                with open(disk_path, "r", encoding="utf-8", errors="replace") as handle:
                    head = handle.read(8192)
            except OSError:
                head = ""
        flag = _is_generated_or_vendored_asset(rel, head)
        _excluded_cache[rel] = flag
        if flag:
            generated_excluded_files.add(rel)
        return flag

    defs_by_symbol: Dict[str, List[Dict[str, Any]]] = {}
    defs_batch_failed = False
    if symbols:
        try:
            defs = run_batch_query("defs", root_path, symbols, binary_path, discovered_via, timeout_s)
            batch_modes.add(str(defs.get("batch_mode") or "batch"))
            defs_by_symbol = defs.get("grouped") or {}
        except EngineError:
            symbols_failed.extend(symbols)
            defs_batch_failed = True

    defs_for: Dict[str, List[Dict[str, Any]]] = {}
    for symbol in symbols:
        if defs_batch_failed:
            continue
        nodes_by_loc: Dict[Tuple[str, Optional[int]], Dict[str, Any]] = {}
        for hit in defs_by_symbol.get(symbol) or []:
            if not isinstance(hit, dict):
                continue
            hit_kind = hit.get("kind")
            if str(hit_kind or "") == "window":
                window_hits_dropped += 1
                continue
            rel = _relpath(str(hit.get("path", "")), root_abs)
            if not rel or _is_excluded_hit_file(rel):
                continue
            line_no = hit.get("start")
            loc_key = (rel, line_no)
            existing = nodes_by_loc.get(loc_key)
            if existing is not None:
                # Prefer "sig" over "body" if both start at the exact same location.
                if existing.get("kind") != "sig" and hit_kind == "sig":
                    existing["kind"] = "sig"
                continue
            node: Dict[str, Any] = {
                "symbol": symbol,
                "file": rel,
                "line": line_no,
                "kind": hit_kind,
                "language": _file_language(rel),
                "authority": "definition",
            }
            if full_engine_edges:
                node["provenance"] = {
                    "engine": "codesearch-go",
                    "schema": status.get("schema"),
                    "commit": status.get("commit"),
                    "query": symbol,
                }
            nodes_by_loc[loc_key] = node
            languages.add(node["language"])
        nodes = sorted(nodes_by_loc.values(), key=lambda n: (n["file"], n["line"] or 0, n["symbol"]))
        if not nodes:
            symbols_without_definition.append(symbol)
            continue
        defs_for[symbol] = nodes
        symbol_nodes.extend(nodes)

    symbol_nodes.sort(key=lambda n: (n["file"], n["line"] or 0, n["symbol"]))
    node_id_by_key: Dict[Tuple[str, Optional[int], str], int] = {}
    for idx, node in enumerate(symbol_nodes):
        if not full_engine_edges:
            node["id"] = idx
        node_id_by_key[(node["file"], node["line"], node["symbol"])] = idx

    with_defs = sorted(defs_for)
    calls_by_symbol: Dict[str, List[Dict[str, Any]]] = {}
    related_by_symbol: Dict[str, List[Dict[str, Any]]] = {}
    if with_defs:
        try:
            callers = run_batch_query("callers", root_path, with_defs, binary_path, discovered_via, timeout_s)
            batch_modes.add(str(callers.get("batch_mode") or "batch"))
            calls_by_symbol = callers.get("grouped") or {}
        except EngineError:
            symbols_failed.extend(with_defs)
        try:
            related = run_batch_query("related", root_path, with_defs, binary_path, discovered_via, timeout_s)
            batch_modes.add(str(related.get("batch_mode") or "batch"))
            related_by_symbol = related.get("grouped") or {}
        except EngineError:
            symbols_failed.extend(with_defs)

    file_edges: Set[Tuple[str, str]] = set()
    for symbol in with_defs:
        defs_for_symbol = defs_for[symbol]
        candidate_ids = [
            node_id_by_key[(n["file"], n["line"], n["symbol"])]
            for n in defs_for_symbol
        ]
        raw_calls = calls_by_symbol.get(symbol) or []
        valid_calls: List[Tuple[str, Dict[str, Any]]] = []
        for call in raw_calls:
            if not isinstance(call, dict):
                continue
            rel = _relpath(str(call.get("path", "")), root_abs)
            if not rel or _is_excluded_hit_file(rel):
                continue
            valid_calls.append((rel, call))

        # Review Guardrail #3: post-query suppression when a stopword with an
        # internal definition matches > HIGH_CALLER_NOISE_CAP generic call sites.
        if symbol in COMMON_NOISE_SYMBOLS and len(valid_calls) > HIGH_CALLER_NOISE_CAP:
            high_caller_suppressed.add(symbol)
            valid_calls = []

        for rel, call in valid_calls:
            for def_node in defs_for_symbol:
                dst = def_node["file"]
                if not dst:
                    continue
                if rel == dst:
                    self_edges_excluded += 1
                    if not full_engine_edges:
                        continue
                file_edges.add((rel, dst))

            if full_engine_edges:
                symbol_edges.append({
                    "kind": "calls",
                    "caller": {
                        "file": rel,
                        "line": call.get("line"),
                        "symbol": call.get("caller"),
                    },
                    "callee": {
                        "symbol": symbol,
                        "candidates": [
                            {"file": n["file"], "line": n["line"], "kind": n["kind"]}
                            for n in defs_for_symbol
                        ],
                    },
                    "authority": "lead-name-based",
                    "evidence": {"text": call.get("text")},
                    "provenance": {
                        "engine": "codesearch-go",
                        "schema": status.get("schema"),
                        "commit": status.get("commit"),
                        "query": symbol,
                    },
                })
            else:
                symbol_edges.append({
                    "kind": "calls",
                    "caller": {
                        "file": rel,
                        "line": call.get("line"),
                        "symbol": call.get("caller"),
                    },
                    "callee": {
                        "symbol": symbol,
                        "candidate_ids": candidate_ids,
                        "candidate_count": len(candidate_ids),
                    },
                    "authority": "lead-name-based",
                    "evidence": {"text": call.get("text")},
                })

        for row in related_by_symbol.get(symbol) or []:
            if not isinstance(row, dict):
                continue
            if row.get("kind") == "def":
                continue  # already a definition node
            rel = _relpath(str(row.get("path", "")), root_abs)
            if not rel or _is_excluded_hit_file(rel):
                continue
            if full_engine_edges:
                symbol_edges.append({
                    "kind": "related",
                    "relation": row.get("kind"),
                    "file": rel,
                    "symbol": symbol,
                    "authority": "lead-name-based",
                    "evidence": {},
                    "provenance": {
                        "engine": "codesearch-go",
                        "schema": status.get("schema"),
                        "commit": status.get("commit"),
                        "query": symbol,
                    },
                })
            else:
                symbol_edges.append({
                    "kind": "related",
                    "relation": row.get("kind"),
                    "file": rel,
                    "symbol": symbol,
                    "authority": "lead-name-based",
                })

    symbol_edges.sort(key=lambda e: (
        e.get("caller", {}).get("file", "") if isinstance(e.get("caller"), dict) else e.get("file", ""),
        e.get("caller", {}).get("line", 0) if isinstance(e.get("caller"), dict) else 0,
        e.get("kind", ""),
        (e.get("callee") or {}).get("symbol", "") if isinstance(e.get("callee"), dict) else e.get("symbol", ""),
    ))

    engine_file_edges = [
        {
            "source": src,
            "target": dst,
            "via": "calls",
            "authority": "lead-name-based",
        }
        for src, dst in sorted(file_edges)
    ]

    error = None
    if symbols_failed:
        error = (
            "engine queries failed for symbols: " + ", ".join(sorted(set(symbols_failed)))
        )
    if wanted_rel is not None:
        scope = "target-grounded"
    elif truncated:
        scope = "whole-repo-bounded"
    elif batch_modes == {"batch"}:
        scope = "whole-repo"
    else:
        scope = "target-grounded"
    if "fallback" in batch_modes:
        batch_mode = "fallback"
    elif batch_modes:
        batch_mode = "batch"
    elif not symbols:
        batch_mode = "batch"
    else:
        batch_mode = "failed"

    schema_version = (
        LEGACY_ENGINE_LAYER_SCHEMA_VERSION
        if full_engine_edges
        else ENGINE_LAYER_SCHEMA_VERSION
    )
    layer: Dict[str, Any] = {
        "schema_version": schema_version,
        "available": True,
        "engine": engine_block,
        "reason": None,
        "error": error,
        "symbol_nodes": symbol_nodes,
        "symbol_edges": symbol_edges,
        "engine_file_edges": engine_file_edges,
        "coverage": {
            "languages": sorted(languages),
            "engine_language_files": len(engine_files),
            "target_files": target_file_count,
            "symbol_nodes": len(symbol_nodes),
            "symbol_edges": len(symbol_edges),
            "scope": scope,
            "symbols_total": len(eligible),
            "symbols_filtered_common": filtered_common,
            "budget": effective_max_symbols,
            "truncated": truncated,
            "window_hits_dropped": window_hits_dropped,
            "generated_files_excluded": len(generated_excluded_files),
            "self_edges_excluded": self_edges_excluded,
            "high_caller_suppressed": sorted(high_caller_suppressed),
            "batch_mode": batch_mode,
            "cache_status": "miss",
            "symbols_queried": symbols_queried,
            "symbols_without_definition": sorted(set(symbols_without_definition)),
            "symbols_failed": sorted(set(symbols_failed)),
        },
        "authority_note": AUTHORITY_NOTE,
    }
    if cache_key is not None and cache_mode_norm in ("auto", "refresh") and not error:
        _save_engine_cache(cache_key, layer)
    return layer


def engine_lead_impact(
    layer: Dict[str, Any],
    target_file: str,
    scan_root: str = ".",
) -> Dict[str, Any]:
    """Impact via engine file edges only, separate from import impact.

    Never raises. Reachability is computed within the layer alone and
    reported as leads; the import-graph impact is reported separately.
    """
    root_abs = _normalize_path(os.path.abspath(scan_root))
    target_rel = _canon_rel(target_file, root_abs)
    upstream_adj: Dict[str, Set[str]] = {}
    downstream_adj: Dict[str, Set[str]] = {}
    endpoints: Set[str] = set()
    for edge in (layer or {}).get("engine_file_edges") or []:
        src = str(edge.get("source", ""))
        dst = str(edge.get("target", ""))
        if not src or not dst:
            continue
        endpoints.add(src)
        endpoints.add(dst)
        upstream_adj.setdefault(dst, set()).add(src)
        downstream_adj.setdefault(src, set()).add(dst)

    def _reachable(start: str, adj: Dict[str, Set[str]]) -> List[str]:
        seen: Set[str] = set()
        stack = [start]
        while stack:
            node = stack.pop()
            for nxt in sorted(adj.get(node, ())):
                if nxt not in seen and nxt != start:
                    seen.add(nxt)
                    stack.append(nxt)
        return sorted(seen)

    # edge A -> B means A calls a symbol defined in B.
    # downstream(F) = files that (transitively) depend on F.
    # upstream(F) = files F (transitively) depends on.
    downstream = _reachable(target_rel, upstream_adj)
    upstream = _reachable(target_rel, downstream_adj)
    return {
        "target": target_rel,
        "exists_in_engine_layer": target_rel in endpoints,
        "upstream": upstream,
        "downstream": downstream,
        "upstream_count": len(upstream),
        "downstream_count": len(downstream),
        "authority": "lead-name-based",
        "note": (
            "Reachability within the engine symbol layer only; "
            "import-graph impact is reported separately."
        ),
    }
