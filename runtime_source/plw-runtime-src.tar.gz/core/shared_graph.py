"""
SharedGraph Builder — HoTT Kernel Foundation
Schema Version: 3.0.0-kernel

Membangun SharedGraph dalam SATU discovery pass:
- Filesystem scan (1x, sebelumnya 9x)
- Import parsing (1x, sebelumnya 5x)
- Graph construction (1x, sebelumnya 4x)
- Node metadata extraction (1x)
- Boundary detection (1x)
- Type shape extraction (1x)

SharedGraph kemudian di-share ke semua analyzer. Cache layer boleh memakai
discovery manifest dan memasok snapshot file yang tervalidasi; analyzer tetap
tidak boleh scan filesystem sendiri.
"""

import os
import re
import json
import hashlib
import datetime
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from language_semantics import (
    JS_RESOLUTION_EXTENSIONS as RESOLUTION_EXTENSIONS,
    RUST_STDLIB_CRATES,
    SOURCE_EXTENSIONS,
    alias_candidates as _alias_candidates,
    android_manifest_entrypoints as _android_manifest_entrypoints,
    candidate_targets as _candidate_targets,
    classify_js_import_nature as classify_import_nature,
    has_cli_shebang as _has_cli_shebang,
    is_source_file as _is_source_file,
    is_tool_config_file as _is_tool_config_file,
    kotlin_aidl_fqns as _kotlin_aidl_fqns,
    kotlin_is_generated_import as _kotlin_is_generated,
    kotlin_is_internal_import as _kotlin_is_internal,
    kotlin_module_candidates as _kotlin_module_candidates,
    kotlin_package_of as _kotlin_package_of,
    kotlin_same_package_declarations as _kotlin_same_package_declarations,
    kotlin_source_root as _kotlin_source_root,
    kotlin_strip_comments_and_strings as _kotlin_strip_comments_and_strings,
    kotlin_top_level_names as _kotlin_top_level_names,
    load_alias_rules as _load_alias_rules,
    normalize_path as _normalize_path,
    package_json_entrypoints as _package_json_entrypoints,
    parse_kotlin_imports as _parse_kotlin_imports,
    parse_python_imports,
    parse_rust_imports as _parse_rust_imports,
    pick_preferred_entrypoint as _pick_preferred_entrypoint,
    python_module_candidates,
    resolve_relative_import_path as _resolve_import_path,
    rust_cargo_package_name as _rust_cargo_package_name,
    rust_manifest_entrypoints as _rust_manifest_entrypoints,
    rust_module_path_of as _rust_module_path_of,
    rust_pub_reexports as _rust_pub_reexports,
    _rust_strip_comments_and_strings,
    rust_top_level_names as _rust_top_level_names,
    source_language,
    source_path_allowed,
    strip_js_comments as _strip_comments,
    strip_jsonc_comments as _strip_jsonc_comments,
)

SCHEMA_VERSION = "3.0.0-kernel"

BARREL_FILENAMES = ("index.ts", "index.tsx", "index.js", "index.jsx", "public-api.ts")

DEFAULT_IGNORE_DIRS = {
    "node_modules", ".git", "dist", ".angular",
    ".Jules", "coverage", ".next", "out", "fixtures_min",
    # Track 4 (K5 follow-up): "vendor" is third-party code vendored
    # into the repo (Go `go mod vendor`), not the repo's own code —
    # without it, the whole-repo topology walk swallowed 1555 vendor
    # files (11,488 symbols) and the batch defs query blew the 120s
    # timeout on a slow CPU, even though both engine binaries answer
    # the same batch identically.
    "vendor",
}

IMPORT_EXPORT_REGEX = re.compile(
    r"""(?:import\s+(?:[^"';\n]*?\bfrom\s+)?|export\s+[^"';\n]*?\bfrom\s+|import\s*\(\s*)["']([^"']+)["']"""
)
IMPORT_REGEX = IMPORT_EXPORT_REGEX

IMPORT_STATEMENT_REGEX = re.compile(
    r"""(?:(?P<stmt>(?:import|export)\s+(?:[^"';]*?\bfrom\s+)?|import\s*\(\s*))["'](?P<path>[^"']+)["']""",
    re.MULTILINE,
)


def _extract_imported_symbols(stmt: str) -> List[str]:
    stmt = re.sub(r'\b(?:import|export|from|type)\b', '', stmt)
    symbols = []
    
    named_match = re.search(r'\{([^}]+)\}', stmt)
    if named_match:
        named_str = named_match.group(1)
        for s in named_str.split(','):
            s = s.strip()
            if not s: continue
            if ' as ' in s:
                symbols.append(s.split(' as ')[1].strip())
            else:
                symbols.append(s)
        stmt = stmt.replace('{' + named_str + '}', '')
    
    stmt = stmt.strip()
    if stmt:
        for s in stmt.split(','):
            s = s.strip()
            if not s: continue
            if s.startswith('* as '):
                symbols.append(s[5:].strip())
            elif '*' not in s:
                symbols.append(s)
                
    return symbols

_SEM_IDENT_REGEX = re.compile(r"^[A-Za-z0-9_]+$")
_SEM_NEW_REGEX = re.compile(r"\bnew\s+([A-Za-z0-9_]+)\b")
_SEM_CALL_REGEX = re.compile(r"\b([A-Za-z0-9_]+)\s*\(")
_SEM_DEC_REGEX = re.compile(r"@([A-Za-z0-9_]+)\b")
_SEM_COLON_TYPE_REGEX = re.compile(r":\s*([A-Za-z0-9_]+)\b")
_SEM_ANGLE_TYPE_REGEX = re.compile(r"<([A-Za-z0-9_]+)>")
_SEM_JSX_REGEX = re.compile(r"<([A-Za-z0-9_]+)\b")
_SEM_INH_REGEX = re.compile(r"\b(?:extends|implements)\s+([A-Za-z0-9_]+)\b")
_SEM_NS_REGEX = re.compile(r"\b([A-Za-z0-9_]+)\.")


def _build_semantic_usage_index(
    content: str,
) -> Tuple[Set[str], Set[str], Set[str], Set[str], Set[str], Set[str], Set[str]]:
    return (
        set(_SEM_NEW_REGEX.findall(content)),
        set(_SEM_CALL_REGEX.findall(content)),
        set(_SEM_DEC_REGEX.findall(content)),
        set(_SEM_COLON_TYPE_REGEX.findall(content)) | set(_SEM_ANGLE_TYPE_REGEX.findall(content)),
        set(_SEM_JSX_REGEX.findall(content)),
        set(_SEM_INH_REGEX.findall(content)),
        set(_SEM_NS_REGEX.findall(content)),
    )


def _find_semantic_usages(
    symbols: List[str],
    content: str,
    _usage_index: Optional[
        Tuple[Set[str], Set[str], Set[str], Set[str], Set[str], Set[str], Set[str]]
    ] = None,
) -> List[str]:
    if not symbols:
        return []
    s_new, s_call, s_dec, s_typ, s_jsx, s_inh, s_ns = (
        _usage_index if _usage_index is not None else _build_semantic_usage_index(content)
    )
    usages = []
    for sym in symbols:
        if not _SEM_IDENT_REGEX.match(sym):
            continue

        if sym in s_new:
            usages.append(f"instantiated({sym})")
        elif sym in s_call:
            if sym in s_dec:
                usages.append(f"decorator({sym})")
            else:
                usages.append(f"called({sym})")
        elif sym in s_typ:
            usages.append(f"typed({sym})")
        elif sym in s_jsx:
            usages.append(f"jsx_component({sym})")
        elif sym in s_inh:
            usages.append(f"inherited({sym})")
        elif sym in s_ns:
            usages.append(f"namespace_access({sym})")

    return sorted(set(usages))


def parse_imports_with_nature(content: str, file_path: str = "") -> List[Dict[str, Any]]:
    lang = source_language(file_path)
    if lang == "python":
        return parse_python_imports(content)
    if lang == "kotlin":
        items = _parse_kotlin_imports(content)
        if items:
            clean_content = _strip_comments(content)
            usage_idx = _build_semantic_usage_index(clean_content)
            for item in items:
                item["semantic_usages"] = _find_semantic_usages(
                    item.get("symbols", []), clean_content, usage_idx
                )
        return items
    if lang == "rust":
        items = _parse_rust_imports(content)
        if items:
            clean_content = _rust_strip_comments_and_strings(content)
            usage_idx = _build_semantic_usage_index(clean_content)
            for item in items:
                existing = list(item.get("semantic_usages") or ())
                if item.get("rust_mod"):
                    item["semantic_usages"] = sorted(set(existing))
                    continue
                found = _find_semantic_usages(
                    item.get("symbols", []), clean_content, usage_idx
                )
                item["semantic_usages"] = sorted(set(existing + found))
        return items
    clean_content = _strip_comments(content)
    results: List[Dict[str, str]] = []
    usage_idx: Optional[
        Tuple[Set[str], Set[str], Set[str], Set[str], Set[str], Set[str], Set[str]]
    ] = None

    for match in IMPORT_STATEMENT_REGEX.finditer(clean_content):
        raw_path = match.group("path")
        stmt = match.group("stmt") or ""
        nature = classify_import_nature(stmt)

        symbols = _extract_imported_symbols(stmt)
        if symbols and usage_idx is None:
            usage_idx = _build_semantic_usage_index(clean_content)
        usages = _find_semantic_usages(symbols, clean_content, usage_idx) if symbols else []

        results.append(
            {
                "raw_import": raw_path,
                "import_nature": nature,
                "statement": stmt,
                "symbols": symbols,
                "semantic_usages": usages,
            }
        )

    return results

ENTRYPOINT_RULES = [
    (re.compile(r"^main\.server\.(ts|js)$"), "ssr_bootstrap", 0.95),
    (re.compile(r"^main\.(ts|js)$"), "browser_bootstrap", 0.95),
    # R1: a Rust binary crate's entry point.
    (re.compile(r"^main\.rs$"), "binary_entry", 0.90),
    (re.compile(r"^server\.(ts|js)$"), "server_http", 0.90),
    (re.compile(r"^entry\.server\.(ts|js)$"), "ssr_bootstrap", 0.90),
    (re.compile(r"^entry\.client\.(ts|js)$"), "browser_bootstrap", 0.90),
    (re.compile(r"^bootstrap\.(ts|js)$"), "app_bootstrap", 0.80),
]

TEST_FILE_REGEX = re.compile(
    r"\.(spec|test)\.(ts|tsx|js|jsx|mts|cts|mjs|cjs)$"
)

INTERFACE_REGEX = re.compile(
    r"(?:export\s+)?interface\s+(\w+)[^{]*\{([^}]*)\}",
    re.DOTALL
)

TYPE_ALIAS_REGEX = re.compile(
    r"(?:export\s+)?type\s+(\w+)\s*=\s*\{([^}]*)\}",
    re.DOTALL
)


def _is_test_file(file_path: str) -> bool:
    # K6/R1: Recognize JS/TS (`*.spec.*`/`*.test.*`), Kotlin (`*Test.kt`,
    # `*Tests.kt`, `*Spec.kt`, `src/test/`, `src/androidTest/`), Rust
    # (`tests/`, `*_test.rs`), and Python (`test_*.py`, `*_test.py`).
    if TEST_FILE_REGEX.search(file_path):
        return True
    base = os.path.basename(file_path)
    if base.endswith(("Test.kt", "Tests.kt", "Spec.kt", "_test.rs")):
        return True
    if base.endswith(".py") and (base.startswith("test_") or base.endswith("_test.py")):
        return True
    norm = "/" + file_path.replace("\\", "/").lstrip("/")
    if "/src/test/" in norm or "/src/androidTest/" in norm:
        return True
    # R1: Rust integration tests live under a `tests/` directory.
    return "/tests/" in norm or "/__tests__/" in norm


def _read_file(path: str) -> Optional[str]:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        return None


def graph_content_signature(shared_graph: Dict[str, Any]) -> str:
    """Hash the stable semantic graph, excluding timestamp and cache metrics."""
    semantic_graph = {}
    for key, value in shared_graph.items():
        if key in ("scan_timestamp", "cache"):
            continue
        if isinstance(value, dict):
            semantic_graph[key] = {
                (f"{k[0]} -> {k[1]}" if isinstance(k, tuple) else str(k)): v
                for k, v in value.items()
            }
        else:
            semantic_graph[key] = value

    encoded = json.dumps(
        semantic_graph,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    digest = hashlib.sha256(encoded)
    return f"sha256:{digest.hexdigest()}"


def _detect_entrypoint(filename: str) -> Tuple[bool, str, float]:
    base = os.path.basename(filename)
    for pattern, kind, confidence in ENTRYPOINT_RULES:
        if pattern.match(base):
            return True, kind, confidence
    return False, "none", 0.0


def _classify_node(file_path: str, content: str) -> str:
    lower_path = file_path.lower()
    if ".service." in lower_path or "@Injectable" in content:
        return "Service"
    if ".component." in lower_path or "@Component" in content:
        return "Component"
    if ".module." in lower_path or ".routes." in lower_path:
        return "Module"
    if "util" in lower_path or "helper" in lower_path:
        return "Helper"
    return "Other"


def _find_matching_brace(content: str, start_idx: int) -> int:
    """
    Menemukan indeks '}' penutup yang cocok untuk '{' pada start_idx.
    Memperhatikan string literal ('...', "...", `...`) dan escape sequence.
    Mengembalikan -1 jika kurung kurawal tidak seimbang.
    """
    depth = 0
    in_quote: Optional[str] = None
    escaped = False
    n = len(content)

    for idx in range(start_idx, n):
        c = content[idx]
        if in_quote:
            if escaped:
                escaped = False
            elif c == "\\":
                escaped = True
            elif c == in_quote:
                in_quote = None
            continue

        if c in ('"', "'", "`"):
            in_quote = c
            escaped = False
            continue

        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return idx

    return -1


def _parse_body_props(body_str: str) -> Set[str]:
    """
    Mengekstrak nama properti dari body type/interface menggunakan
    brace-matching counter untuk mendukung tipe bertingkat (nested types).
    Menghasilkan properti tingkat atas serta jalur nested (e.g. 'user', 'user.profile.id').
    """
    props: Set[str] = set()
    bi = 0
    bn = len(body_str)
    path: List[str] = []
    current_token: List[str] = []
    in_quote: Optional[str] = None
    escaped = False
    paren_depth = 0
    angle_depth = 0

    def _flush_stmt():
        nonlocal current_token
        stmt = "".join(current_token).strip()
        current_token = []
        if stmt:
            m = re.match(r"^(?:readonly\s+)?([A-Za-z0-9_$]+)\s*\??\s*[:(]", stmt)
            if m:
                pname = m.group(1)
                if pname not in ("get", "set", "new", "type", "interface", "export", "default"):
                    if path:
                        non_anon = [p for p in path if p != "_anon"]
                        if non_anon:
                            dot_prefix = ".".join(non_anon)
                            props.add(f"{dot_prefix}.{pname}")
                        else:
                            props.add(pname)
                    else:
                        props.add(pname)

    while bi < bn:
        char = body_str[bi]
        if in_quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == in_quote:
                in_quote = None
            bi += 1
            continue

        if char in ('"', "'", "`"):
            in_quote = char
            escaped = False
            bi += 1
            continue

        if char == "(":
            paren_depth += 1
        elif char == ")":
            paren_depth = max(0, paren_depth - 1)
        elif char == "<":
            angle_depth += 1
        elif char == ">":
            angle_depth = max(0, angle_depth - 1)

        # Menangani kurung kurawal pembuka bersarang (nested object property)
        if char == "{" and paren_depth == 0:
            prefix = "".join(current_token).strip()
            current_token = []
            prop_name: Optional[str] = None
            m = re.search(r"(?:readonly\s+)?([A-Za-z0-9_$]+)\s*\??\s*:\s*$", prefix)
            if m:
                prop_name = m.group(1)
            elif prefix:
                m2 = re.search(r"([A-Za-z0-9_$]+)\s*$", prefix)
                if m2:
                    prop_name = m2.group(1)

            if prop_name and prop_name not in ("get", "set", "new", "type", "interface", "export", "default"):
                path.append(prop_name)
                full = ".".join(path)
                props.add(full)
            else:
                path.append("_anon")
            bi += 1
            continue
        elif char == "}":
            _flush_stmt()
            if path:
                path.pop()
            bi += 1
            continue

        if (char in (";", "\n", ",") or bi == bn - 1) and paren_depth == 0 and angle_depth == 0:
            if bi == bn - 1 and char not in (";", "\n", ","):
                current_token.append(char)
            _flush_stmt()
            bi += 1
            continue

        current_token.append(char)
        bi += 1

    return props


def _extract_type_shapes(
    content: str,
    known_shapes: Optional[Dict[str, Set[str]]] = None,
) -> Dict[str, Set[str]]:
    """
    Ekstrak nama type/interface dan himpunan property names dengan AST & shape rigor:
    - Menangani kurung kurawal bersarang (brace-matching counter) untuk nested types
    - Menangani generic types (interface ApiResponse<T>)
    - Menangani union/intersection types (type AdminUser = User & { role: 'admin' })
    - Menangani utility types (Partial<T>, Readonly<T>, Pick<T, ...>, Omit<T, ...>)
    - Menangani pewarisan interface (interface A extends B)
    """
    if "interface" not in content and "type" not in content:
        return {}
    clean = _strip_comments(content)
    n = len(clean)
    raw_shapes: Dict[str, Set[str]] = {}
    inheritance: Dict[str, List[str]] = {}

    # 1. Scan interfaces
    interface_pattern = re.compile(
        r"(?:export\s+)?(?:default\s+)?interface\s+([A-Za-z0-9_$]+)"
    )
    for match in interface_pattern.finditer(clean):
        name = match.group(1)
        cursor = match.end()
        angle_d = 0
        open_brace = -1
        header_chars: List[str] = []

        while cursor < n:
            c = clean[cursor]
            if c == "<":
                angle_d += 1
            elif c == ">":
                angle_d = max(0, angle_d - 1)
            elif c == "{" and angle_d == 0:
                open_brace = cursor
                break
            else:
                header_chars.append(c)
            cursor += 1

        if open_brace != -1:
            close_brace = _find_matching_brace(clean, open_brace)
            if close_brace != -1:
                body = clean[open_brace + 1:close_brace]
                props = _parse_body_props(body)
                raw_shapes[name] = props

                header_str = "".join(header_chars)
                ext_match = re.search(r"\bextends\s+([^{]+)", header_str)
                if ext_match:
                    parents = [
                        p.strip().split("<")[0].strip()
                        for p in ext_match.group(1).split(",")
                        if p.strip()
                    ]
                    inheritance[name] = parents

    # 2. Scan type aliases
    type_pattern = re.compile(
        r"(?:export\s+)?(?:default\s+)?type\s+([A-Za-z0-9_$]+)(?:<[^>]*>)?\s*="
    )
    for match in type_pattern.finditer(clean):
        name = match.group(1)
        rhs_start = match.end()

        cursor = rhs_start
        angle_d = 0
        paren_d = 0
        brace_d = 0
        end_idx = n
        while cursor < n:
            c = clean[cursor]
            if c == "<":
                angle_d += 1
            elif c == ">":
                angle_d = max(0, angle_d - 1)
            elif c == "(":
                paren_d += 1
            elif c == ")":
                paren_d = max(0, paren_d - 1)
            elif c == "{":
                brace_d += 1
            elif c == "}":
                brace_d = max(0, brace_d - 1)
            elif c == ";" and angle_d == 0 and paren_d == 0 and brace_d == 0:
                end_idx = cursor
                break
            cursor += 1

        rhs = clean[rhs_start:end_idx]
        props: Set[str] = set()
        parents: List[str] = []

        rc = 0
        rn = len(rhs)
        while rc < rn:
            if rhs[rc] == "{":
                g_close = _find_matching_brace(clean, rhs_start + rc)
                if g_close != -1:
                    body = clean[rhs_start + rc + 1:g_close]
                    props.update(_parse_body_props(body))
                    rc = (g_close - rhs_start) + 1
                    continue
            rc += 1

        # Utility types: Partial<User>, Readonly<User>, Required<User>, Pick<User, ...>, Omit<User, ...>
        util_match = re.finditer(
            r"\b(?:Partial|Readonly|Required|Pick|Omit)\s*<\s*([A-Za-z0-9_$]+)",
            rhs
        )
        for um in util_match:
            parents.append(um.group(1))

        # Referensi type langsung: type AdminUser = User & { ... } atau type Alias = User
        ref_match = re.finditer(
            r"(?:^|&|\||=)\s*([A-Za-z0-9_$]+)\s*(?:&|\||;|$)",
            rhs
        )
        ts_primitives = {
            "true", "false", "null", "undefined", "any", "unknown", "never",
            "string", "number", "boolean", "object", "symbol", "bigint", "void"
        }
        for rm in ref_match:
            ref_name = rm.group(1).strip()
            if ref_name and ref_name not in ts_primitives:
                parents.append(ref_name)

        raw_shapes[name] = props
        if parents:
            inheritance[name] = parents

    # 3. Propagasi inheritance dan utility types
    shapes = {k: set(v) for k, v in raw_shapes.items()}
    for _ in range(5):
        changed = False
        for child, parent_list in inheritance.items():
            if child in shapes:
                for parent in parent_list:
                    if parent in shapes:
                        before_len = len(shapes[child])
                        shapes[child].update(shapes[parent])
                        if len(shapes[child]) != before_len:
                            changed = True
                    elif known_shapes and parent in known_shapes:
                        before_len = len(shapes[child])
                        shapes[child].update(known_shapes[parent])
                        if len(shapes[child]) != before_len:
                            changed = True
        if not changed:
            break

    return shapes


def _detect_boundaries(
    all_files: List[str],
    scan_root: str,
) -> Tuple[Dict[str, Dict], Dict[str, str]]:
    """
    Deteksi module boundaries.
    Boundary = folder dengan barrel file, atau top-level folder.
    """
    scan_root_norm = _normalize_path(scan_root)

    # Identifikasi folder dengan barrel
    barrel_folders: Dict[str, str] = {}
    for fp in all_files:
        dirname = os.path.dirname(fp)
        basename = os.path.basename(fp)
        if basename in BARREL_FILENAMES:
            barrel_folders[dirname] = fp

    # Assign setiap file ke boundary
    boundaries: Dict[str, Dict] = {}
    file_to_boundary: Dict[str, str] = {}

    for fp in all_files:
        current = os.path.dirname(fp)
        assigned = None

        while current and current.startswith(scan_root_norm):
            if current in barrel_folders:
                assigned = current
                break
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent

        if assigned is None:
            rel = os.path.relpath(fp, scan_root_norm)
            top_folder = rel.split("/")[0] if "/" in rel else ""
            if top_folder:
                assigned = _normalize_path(os.path.join(scan_root_norm, top_folder))
            else:
                assigned = scan_root_norm

        if assigned not in boundaries:
            boundaries[assigned] = {
                "barrel": barrel_folders.get(assigned),
                "files": [],
            }

        boundaries[assigned]["files"].append(fp)
        file_to_boundary[fp] = assigned

    return boundaries, file_to_boundary


def discover_source_files(
    scan_root: str = ".",
    ignore_dirs: Optional[Set[str]] = None,
    include_tool_source: bool = False,
) -> Dict[str, Dict[str, int]]:
    """Discover supported source files and cheap stat fingerprints once."""
    ignored = set(DEFAULT_IGNORE_DIRS if ignore_dirs is None else ignore_dirs)
    discovered: Dict[str, Dict[str, int]] = {}
    for root, dirs, files in os.walk(scan_root):
        dirs[:] = sorted(
            [
                directory
                for directory in dirs
                if directory not in ignored and not directory.startswith(".")
            ]
        )
        for filename in sorted(files):
            if not _is_source_file(filename, include_python=include_tool_source):
                continue
            full_path = _normalize_path(os.path.join(root, filename))
            if not source_path_allowed(full_path, include_tool_source=include_tool_source, scan_root=scan_root):
                continue
            try:
                stat = os.stat(full_path)
            except OSError:
                continue
            discovered[full_path] = {
                "size": int(stat.st_size),
                "mtime_ns": int(stat.st_mtime_ns),
                "ctime_ns": int(stat.st_ctime_ns),
            }
    return dict(sorted(discovered.items()))


def _rust_package_for_file(file_path: str) -> Tuple[str, str]:
    """Return (lib_name, lib_root) for a Rust file from its nearest Cargo.toml (R1).

    The lib target name defaults to the package name with `-` -> `_` (an
    explicit `[lib] name` wins — see `rust_cargo_package_name`). The lib
    root is the package dir's `src`, in corpus path form. Returns ("", "")
    when no manifest is found or the package has no `[package] name`
    (e.g. snapshot mode) — the caller then treats `<pkg>::` imports as
    external, never as wrong edges.
    """
    directory = os.path.dirname(file_path)
    while True:
        fs_dir = os.path.abspath(directory) if directory else os.getcwd()
        manifest = os.path.join(fs_dir, "Cargo.toml")
        if os.path.isfile(manifest):
            try:
                with open(manifest, encoding="utf-8", errors="ignore") as f:
                    text = f.read()
            except OSError:
                return "", ""
            _package, lib_name = _rust_cargo_package_name(text)
            if not lib_name:
                return "", ""
            lib_root = _normalize_path(os.path.join(directory, "src")) if directory else "src"
            return lib_name, lib_root
        if not directory:
            return "", ""
        parent = os.path.dirname(directory)
        if parent == directory:
            return "", ""
        directory = parent


@dataclass
class _KotlinCorpusIndex:
    packages: Set[str]
    roots: List[str]
    symbol_index: Dict[Tuple[str, str], str]
    file_packages: Dict[str, str]
    same_pkg_index: Dict[str, List[Tuple[str, str, str]]]
    stripped_map: Dict[str, str]
    aidl_fqns: Set[str]


@dataclass
class _RustCorpusIndex:
    file_module: Dict[str, Tuple[str, Tuple[str, ...]]]
    module_index: Dict[Tuple[str, Tuple[str, ...]], str]
    symbol_index: Dict[Tuple[str, Tuple[str, ...], str], str]
    super_symbol_index: Dict[Tuple[str, Tuple[str, ...], str], str]
    top_modules: Dict[str, Set[str]]
    package_lib: Dict[str, str]


@dataclass
class _ImportResolutionState:
    scan_root_norm: str
    all_files_set: Set[str]
    alias_rules: List[Dict[str, Any]]
    kotlin_index: _KotlinCorpusIndex
    rust_index: _RustCorpusIndex
    edges: List[Tuple[str, str]]
    unresolved_imports: List[Dict[str, Any]]
    external_imports: List[Dict[str, Any]]
    resolved_edge_natures: Dict[Tuple[str, str], List[str]]
    resolved_edge_usages: Dict[Tuple[str, str], List[str]]


def _collect_corpus_sources(
    scan_root: str,
    ignore_dirs: Set[str],
    _file_snapshot: Optional[Dict[str, Dict[str, Any]]],
    include_tool_source: bool,
) -> Tuple[List[str], Dict[str, str], Dict[str, List[Dict[str, Any]]]]:
    """PASS 1: Filesystem discovery (or snapshot load) + file reading + import parsing."""
    all_files: List[str] = []
    file_map: Dict[str, str] = {}
    file_imports: Dict[str, List[Dict[str, Any]]] = {}

    if _file_snapshot is None:
        for full_path in discover_source_files(
            scan_root, ignore_dirs, include_tool_source=include_tool_source
        ):
            content = _read_file(full_path)
            if content is None:
                continue
            all_files.append(full_path)
            file_map[full_path] = content
            file_imports[full_path] = parse_imports_with_nature(content, full_path)
        return all_files, file_map, file_imports

    for full_path in sorted(_file_snapshot):
        if not source_path_allowed(
            full_path, include_tool_source=include_tool_source, scan_root=scan_root
        ):
            continue
        record = _file_snapshot[full_path]
        content = record.get("content")
        imports = record.get("imports")
        if not isinstance(content, str) or not isinstance(imports, list):
            continue
        all_files.append(full_path)
        file_map[full_path] = content
        if content:
            file_imports[full_path] = parse_imports_with_nature(content, full_path)
        else:
            file_imports[full_path] = [
                {"raw_import": str(value), "import_nature": "runtime"}
                for value in imports
            ]
    return all_files, file_map, file_imports


def _build_kotlin_index(
    all_files: List[str],
    file_map: Dict[str, str],
    scan_root_norm: str = "",
    ignore_dirs: Optional[Set[str]] = None,
) -> _KotlinCorpusIndex:
    """PASS 1.5 (Kotlin K5): Build package, root, top-level symbol, AIDL, and same-package indexes."""
    kotlin_packages: Set[str] = set()
    kotlin_roots: List[str] = []
    kotlin_symbol_index: Dict[Tuple[str, str], str] = {}
    kotlin_file_packages: Dict[str, str] = {}
    kotlin_same_pkg_raw: Dict[Tuple[str, str], Dict[str, str]] = {}
    kotlin_stripped_map: Dict[str, str] = {}
    has_kotlin = False

    for _fp in all_files:
        if not _fp.endswith(".kt"):
            continue
        has_kotlin = True
        _content = file_map.get(_fp, "")
        _pkg = _kotlin_package_of(_content)
        if not _pkg:
            continue
        kotlin_packages.add(_pkg)
        kotlin_file_packages[_fp] = _pkg
        _root = _kotlin_source_root(_fp, _pkg)
        if _root and _root not in kotlin_roots:
            kotlin_roots.append(_root)
        for _name in _kotlin_top_level_names(_content):
            kotlin_symbol_index.setdefault((_pkg, _name), _fp)
        _stripped_kt = _kotlin_strip_comments_and_strings(_content)
        kotlin_stripped_map[_fp] = _stripped_kt
        for _sym, _skind in _kotlin_same_package_declarations(
            _content, _stripped=_stripped_kt
        ).items():
            kotlin_same_pkg_raw.setdefault((_pkg, _sym), {})[_fp] = _skind

    # Keep only unique (package, symbol) owners so duplicate-named top-level
    # symbols across variant source roots (e.g. src/debug vs src/release) fail closed.
    kotlin_same_pkg_index: Dict[str, List[Tuple[str, str, str]]] = {}
    for (_pkg, _sym), _owners in kotlin_same_pkg_raw.items():
        if len(_owners) == 1:
            _owner_fp, _skind = next(iter(_owners.items()))
            kotlin_same_pkg_index.setdefault(_pkg, []).append((_sym, _owner_fp, _skind))
    for _pkg in kotlin_same_pkg_index:
        kotlin_same_pkg_index[_pkg].sort()

    aidl_fqns = (
        _kotlin_aidl_fqns(scan_root_norm, ignore_dirs=ignore_dirs)
        if has_kotlin and scan_root_norm
        else set()
    )

    return _KotlinCorpusIndex(
        packages=kotlin_packages,
        roots=kotlin_roots,
        symbol_index=kotlin_symbol_index,
        file_packages=kotlin_file_packages,
        same_pkg_index=kotlin_same_pkg_index,
        stripped_map=kotlin_stripped_map,
        aidl_fqns=aidl_fqns,
    )


def _resolve_rust_reexport_path(
    raw_path: str,
    own_root: str,
    own_mod: Tuple[str, ...],
    rust_module_index: Dict[Tuple[str, Tuple[str, ...]], str],
    rust_top_modules: Dict[str, Set[str]],
    rust_package_lib: Dict[str, str],
) -> Optional[Tuple[str, Tuple[str, ...], List[str]]]:
    """Resolve the base module path of a Rust `pub use` re-export spec."""
    segs = raw_path.split("::")
    if not segs:
        return None
    if segs[0] == "crate":
        return own_root, (), segs[1:]
    if segs[0] == "self":
        return own_root, own_mod, segs[1:]
    if segs[0] == "super":
        ups = 0
        while ups < len(segs) and segs[ups] == "super":
            ups += 1
        base = own_mod[: max(0, len(own_mod) - ups)]
        return own_root, base, segs[ups:]
    if segs[0] in RUST_STDLIB_CRATES:
        return None
    if segs[0] in rust_package_lib:
        return rust_package_lib[segs[0]], (), segs[1:]
    if own_mod and (own_root, own_mod + (segs[0],)) in rust_module_index:
        return own_root, own_mod, segs
    if segs[0] in rust_top_modules.get(own_root, set()):
        return own_root, (), segs
    return None


def _build_rust_index(
    all_files: List[str],
    file_map: Dict[str, str],
) -> _RustCorpusIndex:
    """PASS 1.5 (Rust R1): Build crate-relative module, symbol, re-export, and Cargo package indexes."""
    rust_file_module: Dict[str, Tuple[str, Tuple[str, ...]]] = {}
    rust_module_index: Dict[Tuple[str, Tuple[str, ...]], str] = {}
    rust_symbol_index: Dict[Tuple[str, Tuple[str, ...], str], str] = {}
    rust_top_modules: Dict[str, Set[str]] = {}
    rust_package_lib: Dict[str, str] = {}
    rust_reexports: List[Tuple[str, Tuple[str, ...], str, Optional[str], bool]] = []
    rust_all_uses: List[Tuple[str, Tuple[str, ...], str, Optional[str], bool]] = []

    for _fp in all_files:
        if not _fp.endswith(".rs"):
            continue
        _content = file_map.get(_fp, "")
        _root, _modpath = _rust_module_path_of(_fp, all_files)
        rust_file_module[_fp] = (_root, _modpath)
        rust_module_index.setdefault((_root, _modpath), _fp)
        if _modpath:
            rust_top_modules.setdefault(_root, set()).add(_modpath[0])
        for _name in _rust_top_level_names(_content):
            rust_symbol_index.setdefault((_root, _modpath, _name), _fp)
        for _rpath, _ralias, _rwild in _rust_pub_reexports(_content, include_private=False):
            rust_reexports.append((_root, _modpath, _rpath, _ralias, _rwild))
        for _rpath, _ralias, _rwild in _rust_pub_reexports(_content, include_private=True):
            rust_all_uses.append((_root, _modpath, _rpath, _ralias, _rwild))
        _lib_name, _lib_root = _rust_package_for_file(_fp)
        if _lib_name and _lib_root:
            rust_package_lib.setdefault(_lib_name, _lib_root)

    def _propagate(
        target_index: Dict[Tuple[str, Tuple[str, ...], str], str],
        items: List[Tuple[str, Tuple[str, ...], str, Optional[str], bool]],
    ) -> None:
        for _ in range(6):
            changed = False
            by_module: Dict[Tuple[str, Tuple[str, ...]], List[Tuple[str, str]]] = {}
            for (_r, _m, _sym), _def_fp in target_index.items():
                by_module.setdefault((_r, _m), []).append((_sym, _def_fp))

            for own_root, own_mod, raw_path, alias, wildcard in items:
                resolved = _resolve_rust_reexport_path(
                    raw_path,
                    own_root,
                    own_mod,
                    rust_module_index,
                    rust_top_modules,
                    rust_package_lib,
                )
                if resolved is None:
                    continue
                target_root, base, rest = resolved
                if wildcard:
                    src_mod = base + tuple(rest)
                    for _sym, _def_fp in by_module.get((target_root, src_mod), ()):
                        key = (own_root, own_mod, _sym)
                        if key not in target_index:
                            target_index[key] = _def_fp
                            changed = True
                    continue
                if not rest:
                    src_mod = base
                    src_fp = rust_module_index.get((target_root, src_mod))
                    exported_name = alias or (base[-1] if base else "")
                else:
                    src_mod = base + tuple(rest[:-1])
                    src_sym = rest[-1]
                    src_fp = rust_module_index.get((target_root, base + tuple(rest)))
                    if src_fp is None:
                        src_fp = target_index.get((target_root, src_mod, src_sym))
                    exported_name = alias or src_sym
                if src_fp and exported_name:
                    key = (own_root, own_mod, exported_name)
                    if key not in target_index:
                        target_index[key] = src_fp
                        changed = True
            if not changed:
                break

    # 1. Propagate `pub use` re-exports into `rust_symbol_index` (publicly visible).
    _propagate(rust_symbol_index, rust_reexports)

    # 2. Propagate top-level private `use` imports into `rust_super_symbol_index`
    # so child submodules (`use super::ActiveOp;`) resolve parent lexical scope.
    rust_super_symbol_index: Dict[Tuple[str, Tuple[str, ...], str], str] = dict(rust_symbol_index)
    _propagate(rust_super_symbol_index, rust_all_uses)

    return _RustCorpusIndex(
        file_module=rust_file_module,
        module_index=rust_module_index,
        symbol_index=rust_symbol_index,
        super_symbol_index=rust_super_symbol_index,
        top_modules=rust_top_modules,
        package_lib=rust_package_lib,
    )


def _build_node_metadata_table(
    scan_root_norm: str,
    all_files: List[str],
    all_files_set: Set[str],
    file_map: Dict[str, str],
    ignore_dirs: Set[str],
) -> Dict[str, Dict[str, Any]]:
    """PASS 2: Extract node classifications, test markers, and multi-source entrypoints."""
    manifest_entrypoints = _android_manifest_entrypoints(
        scan_root_norm,
        [(fp, file_map[fp]) for fp in all_files if fp.endswith(".kt")],
    )
    rust_entrypoints = _rust_manifest_entrypoints(
        scan_root_norm,
        all_files_set,
        ignore_dirs=ignore_dirs,
    )
    pkg_entrypoints = _package_json_entrypoints(
        scan_root_norm,
        all_files_set,
        ignore_dirs=ignore_dirs,
    )

    node_metadata: Dict[str, Dict[str, Any]] = {}
    for fp in all_files:
        content = file_map[fp]
        filename = os.path.basename(fp)

        base_ep = _detect_entrypoint(filename)
        manifest_ep = (
            (True, "android_manifest", 0.95)
            if fp in manifest_entrypoints
            else (False, "none", 0.0)
        )
        rust_ep = (
            (True, rust_entrypoints[fp][0], rust_entrypoints[fp][1])
            if fp in rust_entrypoints
            else (False, "none", 0.0)
        )
        pkg_ep = (
            (True, pkg_entrypoints[fp][0], pkg_entrypoints[fp][1])
            if fp in pkg_entrypoints
            else (False, "none", 0.0)
        )
        shebang_ep = (
            (True, "cli_shebang", 0.85)
            if _has_cli_shebang(content)
            else (False, "none", 0.0)
        )
        config_ep = (
            (True, "tool_config_entry", 0.75)
            if _is_tool_config_file(fp)
            else (False, "none", 0.0)
        )
        is_entrypoint, ep_kind, ep_conf = _pick_preferred_entrypoint(
            base_ep, manifest_ep, rust_ep, pkg_ep, shebang_ep, config_ep
        )
        node_metadata[fp] = {
            "type": _classify_node(fp, content),
            "is_entrypoint": is_entrypoint,
            "entrypoint_kind": ep_kind,
            "entrypoint_confidence": ep_conf,
            "is_test": _is_test_file(fp),
        }
    return node_metadata


def _record_resolved_edge(
    state: _ImportResolutionState,
    fp: str,
    target: str,
    nature: str,
    usages: List[str],
    resolved_targets: List[str],
) -> None:
    """Record one resolved dependency edge along with its nature and semantic usages."""
    state.edges.append((fp, target))
    state.resolved_edge_natures.setdefault((fp, target), []).append(nature)
    if usages:
        state.resolved_edge_usages.setdefault((fp, target), []).extend(usages)
    resolved_targets.append(target)


def _resolve_relative_import(
    state: _ImportResolutionState,
    fp: str,
    item: Dict[str, Any],
    resolved_targets: List[str],
) -> None:
    raw_import = item["raw_import"]
    nature = item.get("import_nature", "runtime")
    usages = item.get("semantic_usages", [])
    resolved_base = _resolve_import_path(fp, raw_import)
    language = item.get("language", source_language(fp))
    candidates = _candidate_targets(resolved_base, language)
    matched = next((cand for cand in candidates if cand in state.all_files_set), None)
    if matched:
        _record_resolved_edge(state, fp, matched, nature, usages, resolved_targets)
    else:
        state.unresolved_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "attempted_candidates": candidates,
        })


def _resolve_kotlin_import(
    state: _ImportResolutionState,
    fp: str,
    item: Dict[str, Any],
    resolved_targets: List[str],
) -> None:
    raw_import = item["raw_import"]
    nature = item.get("import_nature", "runtime")
    usages = item.get("semantic_usages", [])
    if item.get("wildcard"):
        state.unresolved_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "reason": "kotlin_wildcard",
        })
        return

    matched = next(
        (
            cand
            for cand in _kotlin_module_candidates(raw_import, state.kotlin_index.roots)
            if cand in state.all_files_set
        ),
        None,
    )
    if not matched:
        parts = raw_import.split(".")
        for k in range(len(parts) - 1, 0, -1):
            cand_file = state.kotlin_index.symbol_index.get(
                (".".join(parts[:k]), parts[k])
            )
            if cand_file is not None and cand_file in state.all_files_set:
                matched = cand_file
                break

    if matched:
        _record_resolved_edge(state, fp, matched, nature, usages, resolved_targets)
    elif _kotlin_is_generated(raw_import, state.kotlin_index.packages):
        state.external_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "reason": "kotlin_generated",
        })
    elif raw_import in state.kotlin_index.aidl_fqns:
        state.external_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "reason": "kotlin_aidl_generated",
        })
    elif _kotlin_is_internal(raw_import, state.kotlin_index.packages):
        state.unresolved_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "reason": "kotlin_unresolved",
        })
    else:
        state.external_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "reason": "kotlin_external",
        })


def _resolve_rust_mod_declaration(
    state: _ImportResolutionState,
    fp: str,
    item: Dict[str, Any],
    resolved_targets: List[str],
) -> None:
    raw_import = item["raw_import"]
    nature = item.get("import_nature", "runtime")
    usages = item.get("semantic_usages", [])
    own_root, own_mod = state.rust_index.file_module.get(fp, (fp, ()))
    target_mod = own_mod + (raw_import,)
    matched = state.rust_index.module_index.get((own_root, target_mod))
    if matched is None and own_root == fp:
        mod_dir = os.path.dirname(fp)
        mod_cands = [
            _normalize_path(os.path.join(mod_dir, raw_import + ".rs")),
            _normalize_path(os.path.join(mod_dir, raw_import, "mod.rs")),
        ]
        matched = next((c for c in mod_cands if c in state.all_files_set), None)
    if matched:
        _record_resolved_edge(state, fp, matched, nature, usages, resolved_targets)
    else:
        mod_base = (
            _normalize_path(os.path.join(own_root, *target_mod))
            if own_root != fp
            else _normalize_path(os.path.join(os.path.dirname(fp), raw_import))
        )
        state.unresolved_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "reason": "rust_mod_unresolved",
            "attempted_candidates": [
                mod_base + ".rs",
                mod_base + "/mod.rs",
            ],
        })


def _resolve_rust_import(
    state: _ImportResolutionState,
    fp: str,
    item: Dict[str, Any],
    resolved_targets: List[str],
) -> None:
    if item.get("rust_mod"):
        _resolve_rust_mod_declaration(state, fp, item, resolved_targets)
        return

    raw_import = item["raw_import"]
    nature = item.get("import_nature", "runtime")
    usages = item.get("semantic_usages", [])
    segs = raw_import.split("::")
    own_root, own_mod = state.rust_index.file_module.get(fp, (fp, ()))
    target_root = own_root
    anchored = False
    own_package = False

    if segs[0] == "crate":
        base: Tuple[str, ...] = ()
        rest = segs[1:]
        anchored = True
    elif segs[0] == "self":
        base = own_mod
        rest = segs[1:]
        anchored = True
    elif segs[0] == "super":
        ups = 0
        while ups < len(segs) and segs[ups] == "super":
            ups += 1
        inline_depth = int(item.get("inline_mod_depth") or 0)
        net_ups = ups - inline_depth
        if net_ups <= 0:
            if net_ups == 0:
                base = own_mod
                rest = segs[ups:]
                anchored = True
            else:
                return
        else:
            base = own_mod[: max(0, len(own_mod) - net_ups)]
            rest = segs[ups:]
            anchored = True
    elif segs[0] in RUST_STDLIB_CRATES:
        state.external_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "reason": "rust_stdlib",
        })
        return
    elif segs[0] in state.rust_index.package_lib:
        target_root = state.rust_index.package_lib[segs[0]]
        base = ()
        rest = segs[1:]
        own_package = True
    elif own_mod and (own_root, own_mod + (segs[0],)) in state.rust_index.module_index:
        base = own_mod
        rest = segs
        own_package = True
    else:
        base = ()
        rest = segs

    full = base + tuple(rest)
    matched = None
    if rest:
        matched = state.rust_index.module_index.get((target_root, full))
    elif anchored:
        matched = state.rust_index.module_index.get((target_root, base))
    if not matched and rest and not item.get("wildcard"):
        matched = state.rust_index.symbol_index.get(
            (target_root, base + tuple(rest[:-1]), rest[-1])
        )
        if not matched and segs[0] == "super":
            matched = state.rust_index.super_symbol_index.get(
                (target_root, base + tuple(rest[:-1]), rest[-1])
            )
    if matched == fp:
        return
    if matched:
        _record_resolved_edge(state, fp, matched, nature, usages, resolved_targets)
    elif anchored or own_package or (
        rest and rest[0] in state.rust_index.top_modules.get(target_root, set())
    ):
        state.unresolved_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "reason": "rust_glob" if item.get("wildcard") else "rust_unresolved",
        })
    else:
        state.external_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "reason": "rust_external",
        })


def _resolve_python_import(
    state: _ImportResolutionState,
    fp: str,
    item: Dict[str, Any],
    resolved_targets: List[str],
) -> None:
    raw_import = item["raw_import"]
    nature = item.get("import_nature", "runtime")
    usages = item.get("semantic_usages", [])
    python_roots = [state.scan_root_norm]
    src_root = (
        _normalize_path(os.path.join(state.scan_root_norm, "src"))
        if state.scan_root_norm not in ("", ".")
        else "src"
    )
    if src_root not in python_roots:
        python_roots.append(src_root)
    python_candidates = python_module_candidates(raw_import, python_roots)
    matched = next((cand for cand in python_candidates if cand in state.all_files_set), None)
    if matched:
        _record_resolved_edge(state, fp, matched, nature, usages, resolved_targets)
    else:
        state.external_imports.append({"importer": fp, "raw_import": raw_import})


def _resolve_alias_import(
    state: _ImportResolutionState,
    fp: str,
    item: Dict[str, Any],
    resolved_targets: List[str],
) -> None:
    raw_import = item["raw_import"]
    nature = item.get("import_nature", "runtime")
    usages = item.get("semantic_usages", [])
    alias_bases = _alias_candidates(raw_import, state.alias_rules) if state.alias_rules else []
    if not alias_bases:
        state.external_imports.append({
            "importer": fp,
            "raw_import": raw_import,
        })
        return

    attempted_candidates: List[str] = []
    matched = None
    for alias_base in alias_bases:
        candidates = _candidate_targets(alias_base)
        attempted_candidates.extend(candidates)
        for cand in candidates:
            if cand in state.all_files_set:
                matched = cand
                break
        if matched:
            break

    if matched:
        _record_resolved_edge(state, fp, matched, nature, usages, resolved_targets)
    else:
        state.unresolved_imports.append({
            "importer": fp,
            "raw_import": raw_import,
            "reason": "alias_candidate_not_found",
            "attempted_candidates": attempted_candidates,
        })


_LANGUAGE_IMPORT_RESOLVERS: Dict[
    str,
    Callable[[_ImportResolutionState, str, Dict[str, Any], List[str]], None],
] = {
    "kotlin": _resolve_kotlin_import,
    "rust": _resolve_rust_import,
    "python": _resolve_python_import,
}


def _resolve_kotlin_same_package_edges(
    state: _ImportResolutionState,
    fp: str,
    file_map: Dict[str, str],
    resolved_targets: List[str],
) -> None:
    """PASS 3b: Resolve implicit Kotlin same-package symbol references."""
    pkg = state.kotlin_index.file_packages.get(fp, "")
    pkg_entries = state.kotlin_index.same_pkg_index.get(pkg)
    if not (pkg and pkg_entries):
        return
    body_kt = state.kotlin_index.stripped_map.get(fp)
    if body_kt is None:
        body_kt = _kotlin_strip_comments_and_strings(file_map.get(fp, ""))
    body_kt = re.sub(
        r"^[ \t]*(?:package|import)\b[^\n]*",
        "",
        body_kt,
        flags=re.MULTILINE,
    )
    tokens = set(
        re.findall(r"(?<!::)(?<![.\w])[A-Za-z_][A-Za-z0-9_]*\b", body_kt)
    )
    explicit_set = set(resolved_targets)
    same_pkg_targets: Set[str] = set()
    for sym, target_fp, kind in pkg_entries:
        if target_fp == fp or target_fp in explicit_set:
            continue
        if sym not in tokens:
            continue
        if kind == "fun" and not re.search(
            rf"(?<!::)(?<![.\w]){re.escape(sym)}\s*\(",
            body_kt,
        ):
            continue
        same_pkg_targets.add(target_fp)
    for target_fp in sorted(same_pkg_targets):
        _record_resolved_edge(
            state,
            fp,
            target_fp,
            "same_package",
            ["same_package_ref"],
            resolved_targets,
        )


def _resolve_corpus_imports(
    all_files: List[str],
    file_map: Dict[str, str],
    file_imports: Dict[str, List[Dict[str, Any]]],
    state: _ImportResolutionState,
) -> Dict[str, List[str]]:
    """PASS 3: Resolve imports across all discovered files via extensible language dispatch."""
    resolved_imports: Dict[str, List[str]] = {}
    for fp in all_files:
        resolved_targets: List[str] = []
        for item in file_imports.get(fp, []):
            raw_import = item["raw_import"]
            if raw_import.startswith("."):
                _resolve_relative_import(state, fp, item, resolved_targets)
                continue
            language = item.get("language", source_language(fp))
            resolver = _LANGUAGE_IMPORT_RESOLVERS.get(language, _resolve_alias_import)
            resolver(state, fp, item, resolved_targets)

        if fp.endswith(".kt"):
            _resolve_kotlin_same_package_edges(state, fp, file_map, resolved_targets)
        resolved_imports[fp] = resolved_targets
    return resolved_imports


def _finalize_edge_metadata(
    raw_edges: List[Tuple[str, str]],
    resolved_edge_natures: Dict[Tuple[str, str], List[str]],
    resolved_edge_usages: Dict[Tuple[str, str], List[str]],
) -> Tuple[List[Tuple[str, str]], Dict[str, str], List[Dict[str, Any]]]:
    """Deduplicate edges and aggregate edge_natures and semantic edge_details."""
    edges = sorted(set(raw_edges))
    edge_natures: Dict[str, str] = {}
    for edge in edges:
        u, v = edge
        natures = resolved_edge_natures.get(edge, [])
        if "runtime" in natures:
            nature = "runtime"
        elif "type_only" in natures:
            nature = "type_only"
        elif "same_package" in natures:
            nature = "same_package"
        else:
            nature = "runtime"
        edge_natures[f"{u} -> {v}"] = nature

    edge_details = [
        {
            "source": u,
            "target": v,
            "import_nature": edge_natures.get(f"{u} -> {v}", "runtime"),
            "semantic_usages": sorted(set(resolved_edge_usages.get((u, v), []))),
        }
        for u, v in edges
    ]
    return edges, edge_natures, edge_details


def _compute_degree_metrics(
    all_files: List[str],
    edges: List[Tuple[str, str]],
    node_metadata: Dict[str, Dict[str, Any]],
) -> None:
    """PASS 4: Populate fan_in and fan_out on each node's metadata entry."""
    fan_in: Dict[str, int] = {}
    fan_out: Dict[str, int] = {}
    for src, tgt in edges:
        fan_out[src] = fan_out.get(src, 0) + 1
        fan_in[tgt] = fan_in.get(tgt, 0) + 1
    for fp in all_files:
        node_metadata[fp]["fan_in"] = fan_in.get(fp, 0)
        node_metadata[fp]["fan_out"] = fan_out.get(fp, 0)


def _extract_corpus_type_shapes(
    all_files: List[str],
    file_map: Dict[str, str],
) -> Dict[str, Dict[str, List[str]]]:
    """PASS 6: Two-pass type/interface shape extraction with cross-file inheritance."""
    type_shapes: Dict[str, Dict[str, List[str]]] = {}
    known_global_shapes: Dict[str, Set[str]] = {}
    shape_candidate_files: List[str] = []

    for fp in all_files:
        shapes = _extract_type_shapes(file_map[fp])
        if shapes:
            shape_candidate_files.append(fp)
            for sname, sprops in shapes.items():
                if sname not in known_global_shapes:
                    known_global_shapes[sname] = set(sprops)
                else:
                    known_global_shapes[sname].update(sprops)

    for fp in shape_candidate_files:
        shapes = _extract_type_shapes(file_map[fp], known_shapes=known_global_shapes)
        if shapes:
            type_shapes[fp] = {
                name: sorted(props) for name, props in shapes.items()
            }
    return type_shapes


def build_shared_graph(
    scan_root: str = ".",
    ignore_dirs: Optional[Set[str]] = None,
    _file_snapshot: Optional[Dict[str, Dict[str, Any]]] = None,
    include_tool_source: bool = False,
) -> Dict[str, Any]:
    """
    Bangun SharedGraph dari satu discovery pass atau snapshot tervalidasi.

    Discovery filesystem tetap terpusat di modul ini. Semua analyzer
    mengonsumsi output fungsi ini dan tidak melakukan scan sendiri.
    """
    if ignore_dirs is None:
        ignore_dirs = set(DEFAULT_IGNORE_DIRS)

    scan_root_norm = _normalize_path(scan_root)
    alias_rules = _load_alias_rules([scan_root_norm, "."])

    all_files, file_map, file_imports = _collect_corpus_sources(
        scan_root, ignore_dirs, _file_snapshot, include_tool_source
    )
    all_files_set = set(all_files)

    kotlin_index = _build_kotlin_index(
        all_files,
        file_map,
        scan_root_norm=scan_root_norm,
        ignore_dirs=ignore_dirs,
    )
    rust_index = _build_rust_index(all_files, file_map)

    node_metadata = _build_node_metadata_table(
        scan_root_norm, all_files, all_files_set, file_map, ignore_dirs
    )

    resolution_state = _ImportResolutionState(
        scan_root_norm=scan_root_norm,
        all_files_set=all_files_set,
        alias_rules=alias_rules,
        kotlin_index=kotlin_index,
        rust_index=rust_index,
        edges=[],
        unresolved_imports=[],
        external_imports=[],
        resolved_edge_natures={},
        resolved_edge_usages={},
    )
    resolved_imports = _resolve_corpus_imports(
        all_files, file_map, file_imports, resolution_state
    )
    edges, edge_natures, edge_details = _finalize_edge_metadata(
        resolution_state.edges,
        resolution_state.resolved_edge_natures,
        resolution_state.resolved_edge_usages,
    )

    _compute_degree_metrics(all_files, edges, node_metadata)
    boundaries, file_to_boundary = _detect_boundaries(all_files, scan_root)
    type_shapes = _extract_corpus_type_shapes(all_files, file_map)

    result = {
        "schema_version": SCHEMA_VERSION,
        "scan_root": scan_root_norm,
        "scan_timestamp": (
            datetime.datetime.now(datetime.timezone.utc)
            .isoformat()
            .replace("+00:00", "Z")
        ),

        # Core topology
        "vertices": sorted(all_files),
        "edges": edges,
        "edge_natures": edge_natures,
        "edge_details": edge_details,
        "file_map": file_map,
        "node_metadata": node_metadata,

        # Import resolution
        "resolved_imports": resolved_imports,
        "unresolved_imports": resolution_state.unresolved_imports,
        "external_imports": resolution_state.external_imports,

        # Boundaries
        "boundaries": boundaries,
        "file_to_boundary": file_to_boundary,

        # Type shapes
        "type_shapes": type_shapes,

        # Summary
        "summary": {
            "total_files": len(all_files),
            "total_edges": len(edges),
            "runtime_edge_count": sum(1 for (u, v) in edges if edge_natures.get(f"{u} -> {v}", "runtime") == "runtime"),
            "type_only_edge_count": sum(1 for (u, v) in edges if edge_natures.get(f"{u} -> {v}", "runtime") == "type_only"),
            "same_package_edge_count": sum(1 for (u, v) in edges if edge_natures.get(f"{u} -> {v}", "runtime") == "same_package"),
            "total_boundaries": len(boundaries),
            "total_type_shapes": sum(len(v) for v in type_shapes.values()),
            "total_unresolved": len(resolution_state.unresolved_imports),
            "total_external": len(resolution_state.external_imports),
            "alias_rules_count": len(alias_rules),
            "entrypoint_count": sum(
                1 for m in node_metadata.values() if m.get("is_entrypoint")
            ),
            "test_file_count": sum(
                1 for m in node_metadata.values() if m.get("is_test")
            ),
        },
    }
    if include_tool_source:
        result["source_ownership_policy"] = {
            "tool_source_included": True,
            "default_global_scan_excludes_tool_implementation": True,
            "experimental_python_enabled": True,
        }
    return result


if __name__ == "__main__":
    import sys
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    graph = build_shared_graph(root)
    # Jangan print file_map (terlalu besar), hapus untuk output
    output = {k: v for k, v in graph.items() if k != "file_map"}
    print(json.dumps(output, indent=2))
