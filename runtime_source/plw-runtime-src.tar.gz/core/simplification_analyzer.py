"""Proof-guided structural simplification analysis over canonical PLW anatomy.

This module does not rewrite code. Python rules use AST witnesses; TS/JS rules
consume the same SharedGraph source snapshot through bounded lexical witnesses.
Behavioral equivalence remains a separate proof obligation.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from language_semantics import is_declaration_file, is_generated_or_vendored_asset

SIMPLIFICATION_SCHEMA_VERSION = "self-simplification-v14-js-structural-v2"
DEFAULT_IGNORES = {
    ".git", "__pycache__", "node_modules", "dist", "coverage",
    "build", ".gradle", ".angular", "target",
}


def _sha(value: str) -> str:
    return f"sha256:{hashlib.sha256(value.encode('utf-8')).hexdigest()}"


def _graph_signature(graph: Dict[str, Any]) -> str:
    from core.shared_graph import graph_content_signature
    return graph_content_signature(graph)


def _canonical_language_inventory(graph: Dict[str, Any]) -> Dict[str, Any]:
    """Describe reference coverage separately from semantic-rule coverage."""
    suffix_counts = {
        ".ts": 0, ".tsx": 0, ".js": 0, ".jsx": 0,
        ".mjs": 0, ".cjs": 0, ".mts": 0, ".cts": 0,
        ".py": 0, ".rs": 0, ".kt": 0,
    }
    for raw_path in graph.get("vertices", []) or []:
        path = str(raw_path)
        if is_declaration_file(path):
            continue
        for suffix in suffix_counts:
            if path.endswith(suffix):
                suffix_counts[suffix] += 1
                break
    observed = [suffix for suffix, count in suffix_counts.items() if count]
    semantic_frontends = {
        ".py": "python_ast",
        ".ts": "js_structural_v2",
        ".tsx": "js_structural_v2",
        ".js": "js_structural_v2",
        ".jsx": "js_structural_v2",
        ".mjs": "js_structural_v2",
        ".cjs": "js_structural_v2",
        ".mts": "js_structural_v2",
        ".cts": "js_structural_v2",
        ".rs": "rs_structural_v1",
        ".kt": "kt_structural_v1",
    }
    uncovered = [suffix for suffix in observed if suffix not in semantic_frontends]
    python_count = suffix_counts[".py"]
    return {
        "reference_source_counts": suffix_counts,
        "reference_observed_extensions": observed,
        "semantic_rule_frontends": semantic_frontends,
        "reference_covered_but_semantic_rules_pending": uncovered,
        "zero_candidate_is_clean_evidence": not (python_count == 0 and bool(uncovered)),
        "zero_candidate_interpretation": (
            "NOT_CLEAN_EVIDENCE_SEMANTIC_FRONTEND_UNAVAILABLE"
            if python_count == 0 and uncovered
            else "CANDIDATE_RESULT_APPLIES_TO_ACTIVE_SEMANTIC_FRONTEND_ONLY"
        ),
    }


JS_SEMANTIC_EXTENSIONS = (".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".mts", ".cts")


def _canonical_js_source_snapshot(
    graph: Dict[str, Any],
    root: Path,
    *,
    excluded: Optional[Set[str]] = None,
) -> List[Tuple[str, str, str]]:
    """Return stable TS/JS source plus one shared length-preserving code mask."""
    file_map = graph.get("file_map", {}) or {}
    rows: List[Tuple[str, str, str]] = []
    for raw_path in graph.get("vertices", []) or []:
        path = str(raw_path)
        source = file_map.get(raw_path)
        if path.endswith(JS_SEMANTIC_EXTENSIONS) and isinstance(source, str):
            rel = _relative_graph_path(path, root)
            if is_declaration_file(rel) or is_generated_or_vendored_asset(rel, source):
                if excluded is not None:
                    excluded.add(rel)
                continue
            rows.append((rel, source, _mask_js_noncode(source)))
    rows.sort(key=lambda row: row[0])
    return rows


def _mask_js_noncode(source: str) -> str:
    """Length-preserving conservative mask for comments and string/template literals."""
    out, i, n = list(source), 0, len(source)
    while i < n:
        c = source[i]
        if c == "/" and i + 1 < n and source[i + 1] in ("/", "*"):
            block = source[i + 1] == "*"
            out[i] = out[i + 1] = " "
            i += 2
            while i < n:
                if block and source[i] == "*" and i + 1 < n and source[i + 1] == "/":
                    out[i] = out[i + 1] = " "; i += 2; break
                if not block and source[i] == "\n":
                    break
                if source[i] != "\n":
                    out[i] = " "
                i += 1
            continue
        if c in ("'", '"', "`"):
            quote, escaped = c, False
            out[i] = " "; i += 1
            while i < n:
                ch = source[i]
                if ch != "\n":
                    out[i] = " "
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == quote:
                    i += 1; break
                i += 1
            continue
        i += 1
    return "".join(out)


def _matching_js_brace(masked: str, start: int) -> int:
    if start < 0 or start >= len(masked) or masked[start] != "{":
        return -1
    depth = 0
    for idx, char in enumerate(masked[start:], start):
        depth += char == "{"
        depth -= char == "}"
        if depth == 0:
            return idx
    return -1


def _js_nonthrowing_literal(expr: str) -> bool:
    value = expr.strip()
    if re.fullmatch(r"(?:true|false|null)|[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", value):
        return True
    if len(value) < 2 or value[0] != value[-1] or value[0] not in ("'", '"', "`"):
        return False
    return "\n" not in value and "\r" not in value and (value[0] != "`" or "${" not in value)


_CONTINUATION_OPERATORS = set("=,:?([{+-*/%&|!~^.<>")
_CONTINUATION_KEYWORDS = {
    "else", "return", "throw", "try", "do", "case", "yield", "await",
}
_CLAUSE_WITH_PAREN_KEYWORDS = {"if", "for", "while", "with", "catch", "switch", "when"}
_TAIL_CONTINUATION_START_CHARS = set(".?:+-*/%&|^=<>)];}")
_TAIL_CONTINUATION_KEYWORDS = ("as", "is", "in", "instanceof", "else")
_INLINE_COMMENT_RE = re.compile(r"//[^\n]*|/\*[\s\S]*?\*/")


def _extract_exact_forwarding_args(
    source: str, masked: str, abs_start: int, abs_end: int,
) -> Optional[List[str]]:
    """Extract conservative plain-identifier forwarding argument tokens using masked + raw slices."""
    args_src = source[abs_start:abs_end]
    args_mask = masked[abs_start:abs_end]
    if not args_src.strip() and not args_mask.strip():
        return []
    pieces: List[str] = []
    last = 0
    paren = bracket = brace = angle = 0
    for idx, ch in enumerate(args_mask):
        if ch == "(":
            paren += 1
        elif ch == ")":
            if paren == 0:
                return None
            paren -= 1
        elif ch == "[":
            bracket += 1
        elif ch == "]":
            if bracket == 0:
                return None
            bracket -= 1
        elif ch == "{":
            brace += 1
        elif ch == "}":
            if brace == 0:
                return None
            brace -= 1
        elif ch == "<":
            angle += 1
        elif ch == ">" and angle:
            angle -= 1
        elif ch == "," and paren == bracket == brace == angle == 0:
            m_piece = args_mask[last:idx].strip()
            s_piece = args_src[last:idx].strip()
            if not m_piece or m_piece != s_piece:
                return None
            pieces.append(m_piece)
            last = idx + 1
    if paren or bracket or brace or angle:
        return None
    m_piece = args_mask[last:].strip()
    s_piece = args_src[last:].strip()
    if not m_piece or m_piece != s_piece:
        return None
    pieces.append(m_piece)
    return pieces


def _preceded_by_keyword(masked: str, pos: int, keyword: str) -> bool:
    """Return True when *pos* is immediately preceded (modulo whitespace/masked comments) by *keyword*."""
    idx = pos - 1
    while idx >= 0 and masked[idx].isspace():
        idx -= 1
    start = idx - len(keyword) + 1
    if start < 0 or masked[start:idx + 1] != keyword:
        return False
    if start > 0 and (masked[start - 1].isalnum() or masked[start - 1] in "_$"):
        return False
    return True


def _leading_statement_boundary_ok(prefix_raw: str) -> bool:
    """Reject brace-less clause headers (`if (...) return`) and expression continuations before a terminal."""
    prefix = prefix_raw.rstrip()
    if not prefix:
        return True
    last = prefix[-1]
    if last in ";}":
        return True
    if last in _CONTINUATION_OPERATORS:
        return False
    had_newline = "\n" in prefix_raw[len(prefix):]
    if last == ")":
        if not had_newline:
            return False
        depth = 1
        idx = len(prefix) - 2
        while idx >= 0 and depth > 0:
            if prefix[idx] == ")":
                depth += 1
            elif prefix[idx] == "(":
                depth -= 1
            idx -= 1
        if depth != 0:
            return False
        while idx >= 0 and prefix[idx].isspace():
            idx -= 1
        if idx >= 0 and (prefix[idx].isalnum() or prefix[idx] in "_$"):
            end_tok = idx + 1
            while idx >= 0 and (prefix[idx].isalnum() or prefix[idx] in "_$"):
                idx -= 1
            word = prefix[idx + 1:end_tok]
            if word in _CLAUSE_WITH_PAREN_KEYWORDS:
                return False
        return True
    word_match = re.search(r"[A-Za-z_$][A-Za-z0-9_$]*$", prefix)
    if word_match and word_match.group(0) in _CONTINUATION_KEYWORDS:
        return False
    return had_newline


def _terminal_top_level_statement_kind(
    masked_segment: str,
    terminal_kinds: Tuple[str, ...],
    *,
    source_segment: str = "",
) -> Optional[str]:
    """Return the terminal keyword iff the final top-level statement in *masked_segment* is directly terminal."""
    n = len(masked_segment)
    brace = paren = bracket = 0
    last_stmt: Optional[Tuple[str, int, int]] = None
    i = 0
    while i < n:
        ch = masked_segment[i]
        if ch == "{":
            brace += 1
        elif ch == "}":
            brace -= 1
        elif ch == "(":
            paren += 1
        elif ch == ")":
            paren -= 1
        elif ch == "[":
            bracket += 1
        elif ch == "]":
            bracket -= 1
        elif brace == paren == bracket == 0 and (ch.isalpha() or ch in "_$"):
            j = i + 1
            while j < n and (masked_segment[j].isalnum() or masked_segment[j] in "_$"):
                j += 1
            word = masked_segment[i:j]
            if word in terminal_kinds:
                last_stmt = (word, i, j)
            i = j
            continue
        if brace < 0 or paren < 0 or bracket < 0:
            return None
        i += 1
    if brace != 0 or paren != 0 or bracket != 0 or last_stmt is None:
        return None
    kind, stmt_start, stmt_kw_end = last_stmt
    if not _leading_statement_boundary_ok(masked_segment[:stmt_start]):
        return None
    src = source_segment if len(source_segment) == n else masked_segment
    brace = paren = bracket = 0
    saw_expr_token = False
    line_last_nonspace = ""
    cur_line_start = stmt_kw_end
    for k in range(stmt_kw_end, n):
        ch = masked_segment[k]
        if ch == ";":
            if brace == paren == bracket == 0:
                return kind if not masked_segment[k + 1:].strip() else None
            saw_expr_token = True
            line_last_nonspace = ch
        elif ch == "\n":
            if brace == paren == bracket == 0:
                rest = masked_segment[k + 1:].lstrip()
                if not rest:
                    return kind
                expr_so_far = saw_expr_token or bool(_INLINE_COMMENT_RE.sub("", src[stmt_kw_end:k]).strip())
                if not expr_so_far:
                    return None
                if not line_last_nonspace or line_last_nonspace not in _CONTINUATION_OPERATORS:
                    line_word = re.search(r"([A-Za-z_]+)\s*$", masked_segment[cur_line_start:k])
                    if not (line_word and line_word.group(1) in _TAIL_CONTINUATION_KEYWORDS):
                        if rest[0] not in _TAIL_CONTINUATION_START_CHARS:
                            kw_cont = re.match(r"([A-Za-z_]+)\b", rest)
                            if not kw_cont or kw_cont.group(1) not in _TAIL_CONTINUATION_KEYWORDS:
                                return None
            cur_line_start = k + 1
            line_last_nonspace = ""
        elif not ch.isspace():
            saw_expr_token = True
            line_last_nonspace = ch
        if ch == "{":
            brace += 1
        elif ch == "}":
            brace -= 1
        elif ch == "(":
            paren += 1
        elif ch == ")":
            paren -= 1
        elif ch == "[":
            bracket += 1
        elif ch == "]":
            bracket -= 1
        if brace < 0 or paren < 0 or bracket < 0:
            return None
    if brace or paren or bracket:
        return None
    return kind


def _terminal_js_return(source: str, masked: str, body_start: int, body_end: int) -> Optional[Dict[str, Any]]:
    segment = masked[body_start:body_end]
    raw_segment = source[body_start:body_end]
    if _terminal_top_level_statement_kind(segment, ("return",), source_segment=raw_segment) != "return":
        return None
    match = re.search(r"\breturn\b(?P<expr>[^;{}]*)\;\s*$", segment, flags=re.S)
    if not match or re.search(r"\breturn\b", segment[:match.start()]):
        return None
    brace = paren = bracket = 0
    for idx, ch in enumerate(segment):
        if idx == match.start() and (brace or paren or bracket):
            return None
        if ch == "{":
            brace += 1
        elif ch == "}":
            brace -= 1
        elif ch == "(":
            paren += 1
        elif ch == ")":
            paren -= 1
        elif ch == "[":
            bracket += 1
        elif ch == "]":
            bracket -= 1
        if brace < 0 or paren < 0 or bracket < 0:
            return None
    if brace or paren or bracket:
        return None
    if not _leading_statement_boundary_ok(segment[:match.start()]):
        return None
    raw_expr = source[body_start + match.start("expr"):body_start + match.end("expr")].strip()
    if not _js_nonthrowing_literal(raw_expr):
        return None
    return {"expression": raw_expr, "expression_fingerprint": _sha(raw_expr)}


def _enclosing_js_function_name(masked: str, position: int) -> str:
    """Best-effort owner label for declarations, block arrows, and class methods."""
    candidates: List[Tuple[int, int, str]] = []
    patterns = (
        re.compile(r"(?:async\s+)?function\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*(?:<[^;{}()]*>)?\s*\([^)]*\)\s*(?:\:[^{]+)?\{"),
        re.compile(r"(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][A-Za-z0-9_$]*)[^;=]*=\s*(?:async\s+)?(?:\([^;{}]*\)|[A-Za-z_$][A-Za-z0-9_$]*)\s*(?:\:[^=;{}]+)?=>\s*\{"),
        re.compile(r"(?m)^[ \t]*(?:(?:public|private|protected|static|readonly|override|async)\s+)*(#?[A-Za-z_$][A-Za-z0-9_$]*)\s*(?:<[^;{}()]*>)?\s*\([^)]*\)\s*(?:\:[^{]+)?\{"),
    )
    blocked = {"if", "for", "while", "switch", "catch", "with", "constructor"}
    for pattern in patterns:
        for match in pattern.finditer(masked, 0, position):
            name = match.group(1)
            if name in blocked:
                continue
            open_brace = masked.rfind("{", match.start(), match.end())
            close = _matching_js_brace(masked, open_brace)
            if close >= position:
                candidates.append((open_brace, close, name))
    if not candidates:
        return "<local-try-catch>"
    # Innermost containing function wins.
    candidates.sort(key=lambda row: (row[1] - row[0], -row[0]))
    return candidates[0][2]


def _js_candidate_row(
    *, rel: str, masked: str, position: int, line_start: int, line_end: int,
    kind: str, identity: Dict[str, Any], witness: Dict[str, Any], proof_rule: str,
    validation: List[str],
) -> Dict[str, Any]:
    name = _enclosing_js_function_name(masked, position)
    return _candidate(
        identity={"file": rel, "kind": kind, "function": name, "line": line_start, **identity},
        kind=kind, files=[rel], names=[name],
        members=[_member(rel, name, line_start, line_end, private=True)], estimated_loc=1,
        witness=witness, proof_rule=proof_rule, validation=validation,
    )


def _js_try_catch_terminal_return_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    """Find identical non-throwing terminal returns in one try/catch pair."""
    candidates: List[Dict[str, Any]] = []
    for rel, source, masked in sources:
        for match in re.finditer(r"\btry\s*\{", masked):
            try_open = masked.find("{", match.start(), match.end())
            try_close = _matching_js_brace(masked, try_open)
            if try_close < 0:
                continue
            cursor = try_close + 1
            while cursor < len(masked) and masked[cursor].isspace(): cursor += 1
            catch_match = re.match(r"catch\s*(?:\([^)]*\))?\s*\{", masked[cursor:])
            if not catch_match:
                continue
            catch_open = cursor + catch_match.group(0).rfind("{")
            catch_close = _matching_js_brace(masked, catch_open)
            if catch_close < 0:
                continue
            after = catch_close + 1
            while after < len(masked) and masked[after].isspace(): after += 1
            if masked.startswith("finally", after) or "/" in masked[try_open + 1:catch_close]:
                continue
            try_ret = _terminal_js_return(source, masked, try_open + 1, try_close)
            catch_ret = _terminal_js_return(source, masked, catch_open + 1, catch_close)
            if not try_ret or not catch_ret or try_ret["expression"] != catch_ret["expression"]:
                continue
            line_start = source.count("\n", 0, match.start()) + 1
            line_end = source.count("\n", 0, catch_close) + 1
            candidates.append(_js_candidate_row(
                rel=rel, masked=masked, position=match.start(), line_start=line_start, line_end=line_end,
                kind="js_try_catch_identical_terminal_return",
                identity={"expr": try_ret["expression_fingerprint"]},
                witness={
                    "type": "js_try_catch_identical_terminal_return_v1",
                    "same_owner_file": True, "terminal_return_expression_identical": True,
                    "return_expression_nonthrowing_literal": True,
                    "return_expression_fingerprint": try_ret["expression_fingerprint"],
                    "try_prefix_preserved": True, "catch_prefix_preserved": True,
                    "catch_boundary_preserved": True, "finally_absent": True,
                    "prior_return_absent_in_try_and_catch_prefix": True,
                    "regex_or_division_token_absent_in_candidate_span": True,
                    "authority": "bounded_js_lexical_control_flow_witness_only",
                },
                proof_rule="hoist only the identical non-throwing terminal return after try/catch while preserving both prefixes and the catch boundary",
                validation=[
                    "preserve try-prefix side effects and await ordering",
                    "preserve catch exception swallowing and catch-prefix side effects",
                    "do not move a potentially throwing return expression outside the catch boundary",
                    "run affected TS/Angular tests and reference-machine topology/context checks",
                ],
            ))
    return candidates


def _js_terminal_literal_temporary_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    """Find a terminal ``const x = <literal>; return x;`` using the shared mask."""
    candidates: List[Dict[str, Any]] = []
    pattern = re.compile(
        r"\bconst\s+(?P<name>[A-Za-z_$][A-Za-z0-9_$]*)(?:\s*:\s*[^\s=;{}][^=;{}]*)?\s*=(?P<expr>[^;{}]+);"
        r"\s*return\s+(?P=name)\s*;"
    )
    for rel, source, masked in sources:
        for match in pattern.finditer(masked):
            after = match.end()
            while after < len(masked) and masked[after].isspace(): after += 1
            if after >= len(masked) or masked[after] != "}":
                continue
            raw_expr = source[match.start("expr"):match.end("expr")].strip()
            if not _js_nonthrowing_literal(raw_expr):
                continue
            name = match.group("name")
            line_start = source.count("\n", 0, match.start()) + 1
            line_end = source.count("\n", 0, match.end()) + 1
            candidates.append(_js_candidate_row(
                rel=rel, masked=masked, position=match.start(), line_start=line_start, line_end=line_end,
                kind="js_terminal_literal_temporary",
                identity={"binding": name, "expr": _sha(raw_expr)},
                witness={
                    "type": "js_terminal_literal_temporary_v1", "same_owner_file": True,
                    "adjacent_assignment_return": True, "const_binding": True,
                    "returned_name_matches_assignment": True, "return_expression_nonthrowing_literal": True,
                    "terminal_return_in_same_block": True, "shared_mask_js_noncode_reused": True,
                    "shared_nonthrowing_literal_predicate_reused": True, "shared_function_labeling_reused": True,
                    "authority": "bounded_js_lexical_terminal_temporary_witness_only",
                },
                proof_rule="inline only an adjacent terminal const bound to a non-throwing literal into its return statement",
                validation=[
                    "preserve literal value and return ordering",
                    "do not inline calls/member access/object literals or other potentially throwing expressions",
                    "do not claim debugger/line-event equivalence",
                    "run affected TS/Angular tests when applying a target patch",
                ],
            ))
    return candidates



def _matching_js_delimiter(masked: str, start: int, opening: str, closing: str) -> int:
    if start < 0 or start >= len(masked) or masked[start] != opening:
        return -1
    depth = 0
    for idx in range(start, len(masked)):
        char = masked[idx]
        if char == opening:
            depth += 1
        elif char == closing:
            depth -= 1
            if depth == 0:
                return idx
    return -1


def _skip_js_space(masked: str, position: int) -> int:
    while position < len(masked) and masked[position].isspace():
        position += 1
    return position


def _js_function_body_open(masked: str, after_params: int) -> int:
    """Find a conservative block-body brace after a JS/TS parameter list.

    The helper understands the common ``): Type {`` shape and skips a leading
    TypeScript object return type ``): { ... } {``.  Ambiguous signatures are
    intentionally rejected by returning ``-1`` rather than guessing.
    """
    pos = _skip_js_space(masked, after_params)
    colon_seen = pos < len(masked) and masked[pos] == ":"
    while pos < len(masked):
        if masked.startswith("=>", pos):
            pos = _skip_js_space(masked, pos + 2)
            return pos if pos < len(masked) and masked[pos] == "{" else -1
        if masked[pos] == ";":
            return -1
        if masked[pos] == "{":
            if not colon_seen:
                return pos
            prefix = masked[after_params:pos].strip()
            last = prefix[-1:] if prefix else ""
            # ``): {a: T} {`` or ``): Foo | {a:T} {``: first brace is type.
            if prefix == ":" or last in ("|", "&", "<", ",", "("):
                type_close = _matching_js_delimiter(masked, pos, "{", "}")
                if type_close < 0:
                    return -1
                pos = _skip_js_space(masked, type_close + 1)
                continue
            return pos
        pos += 1
    return -1


def _js_simple_parameter_names(source: str, masked: str, open_pos: int, close_pos: int) -> Optional[List[str]]:
    """Return simple JS/TS parameter names or None for destructuring/defaults."""
    raw = source[open_pos + 1:close_pos]
    code = masked[open_pos + 1:close_pos]
    pieces: List[Tuple[str, str]] = []
    last = 0
    paren = bracket = brace = angle = 0
    for idx, ch in enumerate(code):
        if ch == "(": paren += 1
        elif ch == ")": paren -= 1
        elif ch == "[": bracket += 1
        elif ch == "]": bracket -= 1
        elif ch == "{": brace += 1
        elif ch == "}": brace -= 1
        elif ch == "<": angle += 1
        elif ch == ">" and angle: angle -= 1
        elif ch == "," and paren == bracket == brace == angle == 0:
            pieces.append((raw[last:idx], code[last:idx])); last = idx + 1
    pieces.append((raw[last:], code[last:]))
    if len(pieces) == 1 and not pieces[0][1].strip():
        return []
    names: List[str] = []
    for raw_piece, code_piece in pieces:
        token = code_piece.strip()
        if not token or any(symbol in token for symbol in ("...", "=", "{", "[")):
            return None
        match = re.fullmatch(
            r"(?:(?:public|private|protected|readonly|override)\s+)*"
            r"(?P<name>[A-Za-z_$][A-Za-z0-9_$]*)\s*\??\s*(?::[\s\S]+)?",
            token,
        )
        if not match:
            return None
        names.append(match.group("name"))
    return names


def _js_function_records(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    """Discover conservative block-bodied JS/TS functions, arrows and class methods."""
    records: List[Dict[str, Any]] = []
    seen: set[Tuple[str, int]] = set()

    def add_record(rel: str, source: str, masked: str, *, name: str, start: int,
                   params_open: int, params_close: int, body_open: int,
                   exported: bool, private: bool, async_fn: bool, form: str) -> None:
        body_close = _matching_js_brace(masked, body_open)
        if body_close < 0 or (rel, body_open) in seen:
            return
        params = _js_simple_parameter_names(source, masked, params_open, params_close)
        seen.add((rel, body_open))
        records.append({
            "file": rel, "source": source, "masked": masked, "name": name,
            "start": start, "params_open": params_open, "params_close": params_close,
            "params": params, "body_open": body_open, "body_close": body_close,
            "line_start": source.count("\n", 0, start) + 1,
            "line_end": source.count("\n", 0, body_close) + 1,
            "exported": bool(exported), "private": bool(private),
            "async": bool(async_fn), "form": form,
        })

    for rel, source, masked in sources:
        declaration = re.compile(
            r"(?P<export>\bexport\s+(?:default\s+)?)?(?P<async>\basync\s+)?"
            r"\bfunction\s*\*?\s*(?P<name>[A-Za-z_$][A-Za-z0-9_$]*)\s*(?:<[^;{}()]*>)?\s*\("
        )
        for match in declaration.finditer(masked):
            params_open = masked.find("(", match.start(), match.end())
            params_close = _matching_js_delimiter(masked, params_open, "(", ")")
            if params_close < 0:
                continue
            body_open = _js_function_body_open(masked, params_close + 1)
            if body_open < 0:
                continue
            name = match.group("name")
            add_record(rel, source, masked, name=name, start=match.start(),
                       params_open=params_open, params_close=params_close, body_open=body_open,
                       exported=bool(match.group("export")), private=name.startswith("_"),
                       async_fn=bool(match.group("async")), form="function_declaration")

        arrow = re.compile(
            r"(?P<export>\bexport\s+)?\b(?:const|let|var)\s+"
            r"(?P<name>[A-Za-z_$][A-Za-z0-9_$]*)\s*(?:\??\s*:\s*[^=;]+)?\s*=\s*"
            r"(?P<async>async\s+)?(?P<params>\([^;{}]*\)|[A-Za-z_$][A-Za-z0-9_$]*)"
            r"\s*(?::\s*[^=;{}]+)?\s*=>\s*\{"
        )
        for match in arrow.finditer(masked):
            params_text = match.group("params")
            if params_text.startswith("("):
                params_open = match.start("params")
                params_close = _matching_js_delimiter(masked, params_open, "(", ")")
            else:
                # Normalize one bare arrow parameter into a synthetic span that
                # the forwarding rule can still compare directly.
                params_open = params_close = -1
            body_open = masked.find("{", match.start("params"), match.end())
            if body_open < 0:
                continue
            name = match.group("name")
            if params_open < 0:
                body_close = _matching_js_brace(masked, body_open)
                if body_close < 0 or (rel, body_open) in seen:
                    continue
                seen.add((rel, body_open))
                records.append({
                    "file": rel, "source": source, "masked": masked, "name": name,
                    "start": match.start(), "params_open": -1, "params_close": -1,
                    "params": [params_text], "body_open": body_open, "body_close": body_close,
                    "line_start": source.count("\n", 0, match.start()) + 1,
                    "line_end": source.count("\n", 0, body_close) + 1,
                    "exported": bool(match.group("export")), "private": name.startswith("_"),
                    "async": bool(match.group("async")), "form": "arrow_block",
                })
            else:
                add_record(rel, source, masked, name=name, start=match.start(),
                           params_open=params_open, params_close=params_close, body_open=body_open,
                           exported=bool(match.group("export")), private=name.startswith("_"),
                           async_fn=bool(match.group("async")), form="arrow_block")

        for class_match in re.finditer(r"\bclass\s+[A-Za-z_$][A-Za-z0-9_$]*[^{};]*\{", masked):
            class_open = masked.find("{", class_match.start(), class_match.end())
            class_close = _matching_js_brace(masked, class_open)
            if class_close < 0:
                continue
            class_body = masked[class_open + 1:class_close]
            method = re.compile(
                r"(?m)^[ \t]*(?P<mods>(?:(?:public|private|protected|static|readonly|override|async)\s+)*)"
                r"(?P<name>#?[A-Za-z_$][A-Za-z0-9_$]*)\s*(?:<[^;{}()]*>)?\s*\("
            )
            for match in method.finditer(class_body):
                absolute = class_open + 1 + match.start()
                # Only direct class members; nested function-like text is ignored.
                prefix = masked[class_open + 1:absolute]
                if prefix.count("{") != prefix.count("}"):
                    continue
                name = match.group("name")
                if name in {"if", "for", "while", "switch", "catch", "with"}:
                    continue
                params_open = masked.find("(", absolute, class_open + 1 + match.end())
                params_close = _matching_js_delimiter(masked, params_open, "(", ")")
                if params_close < 0:
                    continue
                body_open = _js_function_body_open(masked, params_close + 1)
                if body_open < 0 or body_open > class_close:
                    continue
                mods = match.group("mods") or ""
                add_record(rel, source, masked, name=name, start=absolute,
                           params_open=params_open, params_close=params_close, body_open=body_open,
                           exported=False, private=(name.startswith("#") or "private" in mods.split()),
                           async_fn="async" in mods.split(), form="class_method")

    records.sort(key=lambda row: (row["file"], row["start"], row["name"]))
    return records


def _js_normalized_body_tokens(source: str, start: int, end: int) -> Optional[List[str]]:
    """Tokenize a JS body conservatively for exact-structure fingerprinting.

    Comments/formatting are ignored, while string/template literal bytes and
    punctuator boundaries are preserved. Regex/division-heavy bodies are
    rejected because this frontend intentionally does not guess that ambiguity.
    """
    tokens: List[str] = []
    i = start
    punctuators = (
        ">>>=", "**=", "&&=", "||=", "??=", "===", "!==", ">>>", "<<=", ">>=",
        "=>", "==", "!=", "<=", ">=", "++", "--", "&&", "||", "??", "?.", "**",
        "<<", ">>", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "...",
    )
    while i < end:
        ch = source[i]
        if ch.isspace():
            i += 1; continue
        if ch == "/" and i + 1 < end and source[i + 1] == "/":
            newline = source.find("\n", i + 2, end)
            i = end if newline < 0 else newline + 1; continue
        if ch == "/" and i + 1 < end and source[i + 1] == "*":
            close = source.find("*/", i + 2, end)
            if close < 0: return None
            i = close + 2; continue
        if ch == "/":
            return None
        if ch in ("'", '"', "`"):
            quote, j, escaped = ch, i + 1, False
            while j < end:
                current = source[j]
                if escaped:
                    escaped = False
                elif current == "\\":
                    escaped = True
                elif current == quote:
                    j += 1; break
                j += 1
            if j > end: return None
            tokens.append(source[i:j]); i = j; continue
        ident = re.match(r"[A-Za-z_$][A-Za-z0-9_$]*", source[i:end])
        if ident:
            value = ident.group(0); tokens.append(value); i += len(value); continue
        number = re.match(r"(?:0[xX][0-9A-Fa-f]+|0[bB][01]+|0[oO][0-7]+|\d+(?:\.\d*)?(?:[eE][+-]?\d+)?)n?", source[i:end])
        if number:
            value = number.group(0); tokens.append(value); i += len(value); continue
        matched = next((op for op in punctuators if source.startswith(op, i)), None)
        if matched:
            tokens.append(matched); i += len(matched); continue
        tokens.append(ch); i += 1
    return tokens


def _js_direct_forwarding_wrapper_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []
    for fn in _js_function_records(sources=sources):
        params = fn.get("params")
        if params is None or fn.get("async"):
            continue
        body_start = fn["body_open"] + 1
        body_mask = fn["masked"][body_start:fn["body_close"]]
        match = re.fullmatch(
            r"\s*return\s+(?P<callee>[A-Za-z_$][A-Za-z0-9_$]*)\s*\((?P<args>[^;{}()]*)\)\s*;?\s*",
            body_mask,
            flags=re.S,
        )
        if not match or match.group("callee") == fn["name"]:
            continue
        raw_args = _extract_exact_forwarding_args(
            fn["source"],
            fn["masked"],
            body_start + match.start("args"),
            body_start + match.end("args"),
        )
        if raw_args is None or raw_args != list(params):
            continue
        private = bool(fn["private"])
        candidates.append(_candidate(
            identity={"file": fn["file"], "kind": "js_direct_forwarding_wrapper", "function": fn["name"], "callee": match.group("callee")},
            kind="js_direct_forwarding_wrapper", files=[fn["file"]], names=[fn["name"]],
            members=[_member(fn["file"], fn["name"], fn["line_start"], fn["line_end"], private=private)],
            estimated_loc=max(1, fn["line_end"] - fn["line_start"] + 1),
            witness={
                "type": "js_direct_forwarding_wrapper_v2", "same_owner_file": True,
                "simple_parameters_only": True, "argument_forwarding_exact": True,
                "direct_identifier_callee": True, "async_wrapper_excluded": True,
                "wrapper_exported": bool(fn["exported"]), "wrapper_private": private,
                "function_form": fn["form"], "callee": match.group("callee"),
                "authority": "bounded_js_structural_forwarding_witness_only",
            },
            proof_rule="remove/share a JS forwarding wrapper only when callable/API identity and all consumers remain compatible",
            validation=[
                "preserve exported/public callable names unless compatibility is explicitly retained",
                "preserve this-binding by allowing only direct identifier callees in V2",
                "preserve argument order and arity", "run affected TS/JS tests and type-check",
            ],
        ))
    return candidates


def _js_exact_function_body_duplication_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for fn in _js_function_records(sources=sources):
        raw_body = fn["source"][fn["body_open"] + 1:fn["body_close"]]
        if fn["file"].endswith((".tsx", ".jsx")) and "<" in fn["masked"][fn["body_open"] + 1:fn["body_close"]]:
            continue
        tokens = _js_normalized_body_tokens(fn["source"], fn["body_open"] + 1, fn["body_close"])
        if tokens is None or len(tokens) < 8:
            continue
        fingerprint = _sha(json.dumps(tokens, ensure_ascii=False, separators=(",", ":")))
        grouped.setdefault(fingerprint, []).append(fn)
    candidates: List[Dict[str, Any]] = []
    for fingerprint, members in grouped.items():
        if len(members) < 2:
            continue
        files = sorted({row["file"] for row in members})
        names = sorted({row["name"] for row in members})
        locs = sorted((row["line_end"] - row["line_start"] + 1 for row in members), reverse=True)
        removable = sum(locs[1:])
        if removable <= 0:
            continue
        candidates.append(_candidate(
            identity={"kind": "js_exact_function_body_duplication", "body": fingerprint, "files": files, "names": names},
            kind="js_exact_function_body_duplication", files=files, names=names,
            members=[_member(row["file"], row["name"], row["line_start"], row["line_end"], private=row["private"]) for row in members],
            estimated_loc=removable, duplicate_loc=removable,
            witness={
                "type": "js_exact_function_body_tokens_v2", "exact_token_body_identical": True,
                "comments_and_formatting_ignored": True, "string_and_template_literal_bytes_preserved": True,
                "regex_or_division_ambiguous_bodies_excluded": True,
                "jsx_body_token_equivalence_not_claimed": True,
                "member_count": len(members), "body_fingerprint": fingerprint,
                "authority": "bounded_js_token_body_duplication_witness_only",
            },
            proof_rule="share exact JS/TS function-body implementations only behind a neutral owner while preserving every public callable surface",
            validation=[
                "preserve exported/public functions as compatibility wrappers when required",
                "preserve module initialization and import behavior", "run affected TS/JS tests and type-check",
            ],
        ))
    return candidates


def _js_redundant_else_after_terminal_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []
    for rel, source, masked in sources:
        for match in re.finditer(r"\bif\s*\(", masked):
            if (
                _preceded_by_keyword(masked, match.start(), "else")
                or _preceded_by_keyword(masked, match.start(), "return")
            ):
                continue
            cond_open = masked.find("(", match.start(), match.end())
            cond_close = _matching_js_delimiter(masked, cond_open, "(", ")")
            if cond_close < 0:
                continue
            then_open = _skip_js_space(masked, cond_close + 1)
            if then_open >= len(masked) or masked[then_open] != "{":
                continue
            then_close = _matching_js_brace(masked, then_open)
            if then_close < 0:
                continue
            terminal_kind = _terminal_top_level_statement_kind(
                masked[then_open + 1:then_close],
                ("return", "throw"),
                source_segment=source[then_open + 1:then_close],
            )
            if terminal_kind is None:
                continue
            cursor = _skip_js_space(masked, then_close + 1)
            if not masked.startswith("else", cursor):
                continue
            if cursor + 4 < len(masked) and (masked[cursor + 4].isalnum() or masked[cursor + 4] in "_$"):
                continue
            else_open = _skip_js_space(masked, cursor + 4)
            if else_open >= len(masked) or masked[else_open] != "{":
                continue
            else_close = _matching_js_brace(masked, else_open)
            if else_close < 0:
                continue
            line_start = source.count("\n", 0, match.start()) + 1
            line_end = source.count("\n", 0, else_close) + 1
            candidates.append(_js_candidate_row(
                rel=rel, masked=masked, position=match.start(), line_start=line_start, line_end=line_end,
                kind="js_redundant_else_after_terminal",
                identity={"terminal": terminal_kind, "else_line": source.count("\n", 0, cursor) + 1},
                witness={
                    "type": "js_redundant_else_after_terminal_v2", "same_owner_file": True,
                    "then_block_directly_terminal": True, "terminal_kind": terminal_kind,
                    "else_is_braced": True, "else_if_excluded": True,
                    "else_if_chain_inner_if_excluded": True,
                    "condition_evaluation_preserved": True, "else_block_scope_must_be_preserved": True,
                    "authority": "bounded_js_structural_control_flow_witness_only",
                },
                proof_rule="remove only the redundant else keyword while preserving the else block as a standalone block after a directly terminal then-branch",
                validation=[
                    "preserve condition evaluation exactly once", "preserve else-block lexical scope braces",
                    "preserve return/throw control flow", "run affected TS/JS tests and type-check",
                ],
            ))
    return candidates


def _js_boolean_guard_return_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    """Find exact, bounded ``if (condition) return bool; return !bool`` sites.

    Earlier V2 code matched one greedy condition across an entire function.
    That could attach a valid terminal pair to unrelated preceding branches.
    This detector now emits one candidate per exact source span so identity,
    planner input, and later selection all name the same site.
    """
    candidates: List[Dict[str, Any]] = []
    terminal_pair = re.compile(
        r"(?m)"
        r"^(?P<indent>[ \t]*)if[ \t]*\((?P<cond>[^\r\n()]*)\)[ \t]*\{[ \t]*(?P<nl>\r?\n)"
        r"(?P<bodyindent>[ \t]+)return[ \t]+(?P<first>true|false)(?P<semi1>;?)[ \t]*(?P=nl)"
        r"(?P=indent)\}[ \t]*(?P=nl)"
        r"(?:[ \t]*(?:\r?\n))*"
        r"(?P=indent)return[ \t]+(?P<second>true|false)(?P<semi2>;?)[ \t]*(?=(?:\r?\n|$))"
    )
    simple_strict_string = re.compile(
        r"^\s*(?P<left>[A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)*)"
        r"\s*(?P<operator>===|!==|==|!=)\s*"
        r"(?P<right>'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\")\s*$"
    )
    for fn in _js_function_records(sources=sources):
        body_start = fn["body_open"] + 1
        body_end = fn["body_close"]
        source = fn["source"]
        body_masked = fn["masked"][body_start:body_end]
        valid_matches = []
        for match in terminal_pair.finditer(body_masked):
            source_start = body_start + match.start()
            source_end = body_start + match.end()
            matched_text = source[source_start:source_end]
            if "/*" in matched_text or "//" in matched_text:
                continue
            if match.group("first") == match.group("second"):
                continue
            condition_start = body_start + match.start("cond")
            condition_end = body_start + match.end("cond")
            condition = source[condition_start:condition_end].strip()
            if not condition or re.search(r"\b(?:yield|await)\b", condition):
                continue
            valid_matches.append((match, condition, source_start, source_end))

        for match, condition, source_start, source_end in valid_matches:
            inverse = match.group("first") == "false"
            site_text = source[source_start:source_end]
            site_digest = _sha(site_text)
            condition_match = simple_strict_string.fullmatch(condition)
            operator = None
            left_shape = "UNSUPPORTED_OR_COMPOUND"
            right_kind = "OTHER_OR_UNKNOWN"
            right_literal = None
            left_operand = None
            if condition_match:
                operator = condition_match.group("operator")
                left_operand = condition_match.group("left")
                left_shape = "IDENT_OR_MEMBER_CHAIN_NO_OPTIONAL_CHAINING"
                right_kind = "STRING_LITERAL"
                right_literal = condition_match.group("right")

            line_start = source.count("\n", 0, source_start) + 1
            line_end = source.count("\n", 0, source_end) + 1
            transformation = "inverse" if inverse else "positive"
            legacy_identity = {
                "file": fn["file"],
                "kind": "js_boolean_guard_return",
                "function": fn["name"],
                "inverse": inverse,
            }
            identity = legacy_identity
            if len(valid_matches) > 1:
                # Retain the historical function identity when it names one
                # exact site. Multiple sites need a content-bound disambiguator.
                identity = {
                    **legacy_identity,
                    "site_sha256": site_digest,
                    "source_char_start": source_start,
                    "source_char_end": source_end,
                }
            candidate = _candidate(
                identity=identity,
                kind="js_boolean_guard_return", files=[fn["file"]], names=[fn["name"]],
                members=[_member(fn["file"], fn["name"], line_start, line_end, private=fn["private"])],
                estimated_loc=2,
                witness={
                    "type": "js_boolean_guard_return_v3", "same_function": True,
                    "condition_evaluated_once_before_and_after": True, "true_false_terminals_opposite": True,
                    "await_and_yield_condition_excluded": True, "inverse": inverse,
                    "condition_facts": {
                        "source_condition_sha256": _sha(condition),
                        "operator": operator,
                        "left_operand": left_operand,
                        "left_operand_shape": left_shape,
                        "right_operand_kind": right_kind,
                        "right_literal": right_literal,
                        "transformation": transformation,
                    },
                    "source_site": {
                        "char_start": source_start,
                        "char_end": source_end,
                        "line_start": line_start,
                        "line_end": line_end,
                        "matched_source_sha256": site_digest,
                        "owner_line_start": int(fn["line_start"]),
                        "owner_line_end": int(fn["line_end"]),
                    },
                    "authority": "bounded_js_structural_boolean_return_site_witness_only",
                },
                proof_rule="collapse only this exact if/boolean-return pair to one equivalent boolean return that evaluates the original condition exactly once",
                validation=[
                    "preserve condition evaluation count and short-circuit semantics", "preserve explicit boolean return type",
                    "run affected TS/JS tests and type-check",
                ],
            )
            candidate["candidate_instance_id"] = _sha(json.dumps({
                "candidate_id": candidate["candidate_id"],
                "source_site_sha256": site_digest,
                "source_char_start": source_start,
                "source_char_end": source_end,
            }, sort_keys=True))
            if len(valid_matches) > 1:
                candidate["parent_candidate_id"] = _sha(json.dumps(legacy_identity, sort_keys=True))
            candidates.append(candidate)
    return candidates


def _js_terminal_expression_temporary_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    """Broaden terminal-temporary detection beyond literals without inferred-name traps."""
    candidates: List[Dict[str, Any]] = []
    pattern = re.compile(
        r"\bconst\s+(?P<name>[A-Za-z_$][A-Za-z0-9_$]*)\s*=\s*(?P<expr>[^\s;{}][^;{}]*);"
        r"\s*return\s+(?P=name)\s*;"
    )
    for rel, source, masked in sources:
        for match in pattern.finditer(masked):
            after = _skip_js_space(masked, match.end())
            if after >= len(masked) or masked[after] != "}":
                continue
            expr_mask = match.group("expr").strip()
            raw_expr = source[match.start("expr"):match.end("expr")].strip()
            if _js_nonthrowing_literal(raw_expr):
                continue  # V1 literal rule owns this case.
            name = match.group("name")
            if re.search(rf"\b{re.escape(name)}\b", expr_mask):
                continue
            if re.search(r"\b(?:await|yield|function|class)\b|=>", expr_mask):
                continue
            line_start = source.count("\n", 0, match.start()) + 1
            line_end = source.count("\n", 0, match.end()) + 1
            candidates.append(_js_candidate_row(
                rel=rel, masked=masked, position=match.start(), line_start=line_start, line_end=line_end,
                kind="js_terminal_expression_temporary",
                identity={"binding": name, "expr": _sha(raw_expr)},
                witness={
                    "type": "js_terminal_expression_temporary_v2", "same_owner_file": True,
                    "adjacent_assignment_return": True, "const_binding": True,
                    "returned_name_matches_assignment": True, "terminal_return_in_same_block": True,
                    "explicit_type_annotation_absent": True, "self_reference_tdz_excluded": True,
                    "function_class_arrow_inferred_name_cases_excluded": True,
                    "await_and_yield_excluded": True,
                    "authority": "bounded_js_structural_terminal_temporary_witness_only",
                },
                proof_rule="inline only an adjacent terminal const initializer when the initializer cannot gain/lose inferred function/class naming and no type annotation contract is removed",
                validation=[
                    "preserve initializer evaluation order and exception boundary", "preserve TypeScript return-type checking",
                    "do not apply to function/class/arrow initializers", "run affected TS/JS tests and type-check",
                ],
            ))
    return candidates

RS_SEMANTIC_EXTENSIONS = (".rs",)
KT_SEMANTIC_EXTENSIONS = (".kt",)


def _brace_char_literal_end(source: str, start: int, end: int) -> int:
    """Return the index just past a char literal starting at ``start``, or -1.

    Accepts one plain character or one escape (``\\n``, ``\\x41``,
    Rust ``\\u{41}``, Kotlin ``\\u0041``).  A lifetime (``'a``) has no
    closing quote after one character/escape, so it returns -1 and the
    quote stays visible instead of swallowing the rest of the file.
    """
    if start + 2 >= end or source[start] != "'":
        return -1
    j = start + 1
    if source[j] == "\\":
        j += 1
        if j >= end:
            return -1
        esc = source[j]
        if esc == "u":
            if j + 1 < end and source[j + 1] == "{":
                close = source.find("}", j + 2, end)
                if close < 0:
                    return -1
                j = close + 1
            else:
                if j + 4 >= end:
                    return -1
                j += 5
        elif esc == "x":
            if j + 2 >= end:
                return -1
            j += 3
        else:
            j += 1
    else:
        j += 1
    if j < end and source[j] == "'":
        return j + 1
    return -1


def _mask_rs_noncode(source: str) -> str:
    """Length-preserving conservative mask for Rust comments/strings/chars.

    Lifetimes (``&'a str``) are NOT char literals: a quote is treated as a
    char-literal start only when ``_brace_char_literal_end`` accepts it.
    Raw strings (``r"..."`` / ``r#"..."#`` / ``br#"..."#``) are masked as a
    unit so braces inside them never reach brace matching.  Nested block
    comments are a known v1 limitation: only the first ``*/`` closes the
    mask, like the JS mask's non-nested handling.
    """
    out, i, n = list(source), 0, len(source)
    while i < n:
        c = source[i]
        if c == "/" and i + 1 < n and source[i + 1] in ("/", "*"):
            block = source[i + 1] == "*"
            out[i] = out[i + 1] = " "
            i += 2
            while i < n:
                if block and source[i] == "*" and i + 1 < n and source[i + 1] == "/":
                    out[i] = out[i + 1] = " "; i += 2; break
                if not block and source[i] == "\n":
                    break
                if source[i] != "\n":
                    out[i] = " "
                i += 1
            continue
        # Raw string: r"..." / r#"..."# / br"..." / br#"..."#.
        raw_start = -1
        raw_hashes = 0
        if c == "r" or (c == "b" and i + 1 < n and source[i + 1] == "r"):
            j = i + 1 if c == "r" else i + 2
            while j < n and source[j] == "#":
                raw_hashes += 1; j += 1
            if j < n and source[j] == '"':
                raw_start = i
        if raw_start >= 0:
            closing = '"' + "#" * raw_hashes
            close = source.find(closing, j + 1)
            stop = n if close < 0 else close + len(closing)
            for k in range(raw_start, stop):
                if source[k] != "\n":
                    out[k] = " "
            i = stop
            continue
        if c == '"':
            out[i] = " "; i += 1
            escaped = False
            while i < n:
                ch = source[i]
                if ch != "\n":
                    out[i] = " "
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    i += 1; break
                i += 1
            continue
        if c == "'":
            char_end = _brace_char_literal_end(source, i, n)
            if char_end > 0:
                for k in range(i, char_end):
                    if source[k] != "\n":
                        out[k] = " "
                i = char_end
                continue
            i += 1
            continue
        i += 1
    return "".join(out)


def _mask_kt_noncode(source: str) -> str:
    """Length-preserving conservative mask for Kotlin comments/strings/chars.

    Triple-quoted raw strings (``\"\"\"...\"\"\"``) are masked as a unit so
    braces inside them never reach brace matching.  String templates
    (``${...}``) are masked as a whole, like JS template literals: braces
    inside a template are hidden, so a template containing a block is a
    known v1 limitation.  Block comments are masked non-nested, like the
    JS mask; Kotlin block comments can nest, so a nested comment containing
    braces is a known v1 limitation.
    """
    out, i, n = list(source), 0, len(source)
    while i < n:
        c = source[i]
        if c == "/" and i + 1 < n and source[i + 1] in ("/", "*"):
            block = source[i + 1] == "*"
            out[i] = out[i + 1] = " "
            i += 2
            while i < n:
                if block and source[i] == "*" and i + 1 < n and source[i + 1] == "/":
                    out[i] = out[i + 1] = " "; i += 2; break
                if not block and source[i] == "\n":
                    break
                if source[i] != "\n":
                    out[i] = " "
                i += 1
            continue
        if c == '"' and source.startswith('"""', i):
            close = source.find('"""', i + 3)
            stop = n if close < 0 else close + 3
            for k in range(i, stop):
                if source[k] != "\n":
                    out[k] = " "
            i = stop
            continue
        if c == '"':
            out[i] = " "; i += 1
            escaped = False
            while i < n:
                ch = source[i]
                if ch != "\n":
                    out[i] = " "
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    i += 1; break
                i += 1
            continue
        if c == "'":
            char_end = _brace_char_literal_end(source, i, n)
            if char_end > 0:
                for k in range(i, char_end):
                    if source[k] != "\n":
                        out[k] = " "
                i = char_end
                continue
            i += 1
            continue
        i += 1
    return "".join(out)


def _canonical_brace_source_snapshot(
    graph: Dict[str, Any],
    root: Path,
    extensions: Tuple[str, ...],
    mask_fn,
    *,
    excluded: Optional[Set[str]] = None,
) -> List[Tuple[str, str, str]]:
    """Return stable brace-language source plus one shared length-preserving code mask."""
    file_map = graph.get("file_map", {}) or {}
    rows: List[Tuple[str, str, str]] = []
    for raw_path in graph.get("vertices", []) or []:
        path = str(raw_path)
        source = file_map.get(raw_path)
        if path.endswith(extensions) and isinstance(source, str):
            rel = _relative_graph_path(path, root)
            if is_declaration_file(rel) or is_generated_or_vendored_asset(rel, source):
                if excluded is not None:
                    excluded.add(rel)
                continue
            rows.append((rel, source, mask_fn(source)))
    rows.sort(key=lambda row: row[0])
    return rows


def _canonical_rs_source_snapshot(
    graph: Dict[str, Any],
    root: Path,
    *,
    excluded: Optional[Set[str]] = None,
) -> List[Tuple[str, str, str]]:
    return _canonical_brace_source_snapshot(
        graph, root, RS_SEMANTIC_EXTENSIONS, _mask_rs_noncode, excluded=excluded,
    )


def _canonical_kt_source_snapshot(
    graph: Dict[str, Any],
    root: Path,
    *,
    excluded: Optional[Set[str]] = None,
) -> List[Tuple[str, str, str]]:
    return _canonical_brace_source_snapshot(
        graph, root, KT_SEMANTIC_EXTENSIONS, _mask_kt_noncode, excluded=excluded,
    )


def _split_top_level_commas(code: str) -> List[str]:
    """Split a parameter list on top-level commas (mirrors the JS helper's scan)."""
    pieces: List[str] = []
    last = 0
    paren = bracket = brace = angle = 0
    for idx, ch in enumerate(code):
        if ch == "(": paren += 1
        elif ch == ")": paren -= 1
        elif ch == "[": bracket += 1
        elif ch == "]": bracket -= 1
        elif ch == "{": brace += 1
        elif ch == "}": brace -= 1
        elif ch == "<": angle += 1
        elif ch == ">" and angle: angle -= 1
        elif ch == "," and paren == bracket == brace == angle == 0:
            pieces.append(code[last:idx]); last = idx + 1
    pieces.append(code[last:])
    return pieces


def _rs_simple_parameter_names(source: str, masked: str, open_pos: int, close_pos: int) -> Optional[List[str]]:
    """Return simple Rust parameter names or None for patterns/complex forms."""
    code = masked[open_pos + 1:close_pos]
    pieces = _split_top_level_commas(code)
    if len(pieces) == 1 and not pieces[0].strip():
        return []
    names: List[str] = []
    for piece in pieces:
        token = piece.strip()
        if not token:
            return None
        if re.fullmatch(r"(?:mut\s+)?self", token) or re.fullmatch(
            r"&(?:'[A-Za-z_][A-Za-z0-9_]*\s+)?(?:mut\s+)?self", token
        ):
            names.append("self")
            continue
        match = re.fullmatch(
            r"(?:mut\s+)?(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*:[\s\S]+",
            token,
        )
        if not match:
            return None
        names.append(match.group("name"))
    return names


def _kt_simple_parameter_names(source: str, masked: str, open_pos: int, close_pos: int) -> Optional[List[str]]:
    """Return simple Kotlin parameter names or None for destructuring/complex forms."""
    code = masked[open_pos + 1:close_pos]
    pieces = _split_top_level_commas(code)
    if len(pieces) == 1 and not pieces[0].strip():
        return []
    names: List[str] = []
    for piece in pieces:
        token = piece.strip()
        if not token or any(symbol in token for symbol in ("{", "[")):
            return None
        match = re.fullmatch(
            r"(?:vararg\s+)?(?:crossinline\s+|noinline\s+)?"
            r"(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*:[\s\S]+",
            token,
        )
        if not match:
            return None
        names.append(match.group("name"))
    return names


def _rs_function_body_open(masked: str, after_params: int) -> int:
    """Find a conservative block-body brace after a Rust parameter list.

    Skips the return type and ``where`` clause.  A ``;`` at depth 0 means a
    declaration without a body (trait method, ``extern`` block item).
    Bracket/paren/angle depth is tracked so ``-> [u8; 3]`` never ends the
    scan early.  Returns -1 instead of guessing.
    """
    pos = _skip_js_space(masked, after_params)
    paren = bracket = angle = 0
    while pos < len(masked):
        ch = masked[pos]
        if ch == "(": paren += 1
        elif ch == ")":
            if paren == 0: return -1
            paren -= 1
        elif ch == "[": bracket += 1
        elif ch == "]":
            if bracket == 0: return -1
            bracket -= 1
        elif ch == "<": angle += 1
        elif ch == ">" and angle: angle -= 1
        elif ch == ";" and paren == bracket == angle == 0:
            return -1
        elif ch == "{" and paren == bracket == angle == 0:
            return pos
        elif ch == "}" and paren == bracket == angle == 0:
            return -1
        pos += 1
    return -1


_KT_DECLARATION_KEYWORDS = (
    "fun", "val", "var", "class", "object", "interface", "enum", "sealed",
    "data", "private", "public", "protected", "internal", "open", "override",
    "suspend", "inline", "tailrec", "operator", "infix", "external", "actual",
    "expect", "abstract", "companion", "init", "constructor", "import", "package",
)


def _kt_function_body_open(masked: str, after_params: int) -> Tuple[Optional[str], int]:
    """Find a Kotlin function body: ("block", brace_pos) or ("expr", equals_pos).

    Skips the return type.  A ``;`` or enclosing ``}`` at depth 0, or a
    following declaration line, means a declaration without a body
    (interface member, ``external fun``).  Expression bodies are detected
    only when ``=`` opens them; multi-line expression bodies are not
    resolved in v1 and fall through to the single-line capture in the
    record builder.
    """
    pos = _skip_js_space(masked, after_params)
    paren = bracket = angle = 0
    while pos < len(masked):
        ch = masked[pos]
        if ch == "(": paren += 1
        elif ch == ")":
            if paren == 0: return None, -1
            paren -= 1
        elif ch == "[": bracket += 1
        elif ch == "]":
            if bracket == 0: return None, -1
            bracket -= 1
        elif ch == "<": angle += 1
        elif ch == ">" and angle: angle -= 1
        elif ch == ";" and paren == bracket == angle == 0:
            return None, -1
        elif ch == "}" and paren == bracket == angle == 0:
            return None, -1
        elif ch == "{" and paren == bracket == angle == 0:
            return "block", pos
        elif ch == "=" and paren == bracket == angle == 0:
            if pos + 1 < len(masked) and masked[pos + 1] == "=":
                return None, -1
            return "expr", pos
        elif ch == "\n" and paren == bracket == angle == 0:
            nxt = _skip_js_space(masked, pos + 1)
            if nxt < len(masked) and masked[nxt] in "}@":
                return None, -1
            keyword = re.match(
                r"(?:" + "|".join(_KT_DECLARATION_KEYWORDS) + r")\b", masked[nxt:]
            )
            if keyword:
                return None, -1
        pos += 1
    return None, -1


def _rs_function_records(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    """Discover conservative block-bodied Rust functions and methods.

    Functions inside ``macro_rules!`` definitions are excluded: their bodies
    are template text, not top-level items, and grouping them with real
    functions would mislabel macro template duplication as code duplication.
    """
    records: List[Dict[str, Any]] = []
    seen: set[Tuple[str, int]] = set()
    declaration = re.compile(
        r"(?P<pub>\bpub(?:\s*\([^)]*\))?\s+)?"
        r"(?P<mods>(?:(?:async|unsafe|const|extern\s+\"[^\"]*\")\s+)*)"
        r"\bfn\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*(?:<[^;{}()]*>)?\s*\("
    )
    macro_def = re.compile(r"\bmacro_rules!\s*[A-Za-z_][A-Za-z0-9_]*\s*\{")
    for rel, source, masked in sources:
        macro_spans: List[Tuple[int, int]] = []
        for macro_match in macro_def.finditer(masked):
            macro_open = masked.find("{", macro_match.start(), macro_match.end())
            macro_close = _matching_js_brace(masked, macro_open)
            if macro_close >= 0:
                macro_spans.append((macro_open, macro_close))
        for match in declaration.finditer(masked):
            if any(start <= match.start() <= end for start, end in macro_spans):
                continue
            params_open = masked.find("(", match.start(), match.end())
            params_close = _matching_js_delimiter(masked, params_open, "(", ")")
            if params_close < 0:
                continue
            body_open = _rs_function_body_open(masked, params_close + 1)
            if body_open < 0 or (rel, body_open) in seen:
                continue
            body_close = _matching_js_brace(masked, body_open)
            if body_close < 0:
                continue
            params = _rs_simple_parameter_names(source, masked, params_open, params_close)
            seen.add((rel, body_open))
            name = match.group("name")
            exported = bool(match.group("pub"))
            mods = match.group("mods") or ""
            records.append({
                "file": rel, "source": source, "masked": masked, "name": name,
                "start": match.start(), "params_open": params_open, "params_close": params_close,
                "params": params, "body_open": body_open, "body_close": body_close,
                "line_start": source.count("\n", 0, match.start()) + 1,
                "line_end": source.count("\n", 0, body_close) + 1,
                "exported": exported, "private": not exported,
                "async": "async" in mods.split(), "form": "function",
                "expr_start": -1, "expr_end": -1,
            })
    records.sort(key=lambda row: (row["file"], row["start"], row["name"]))
    return records


_KT_FUNCTION_MODIFIERS = {
    "public", "private", "protected", "internal", "open", "override",
    "suspend", "inline", "tailrec", "operator", "infix", "external",
    "actual", "expect", "abstract",
}


def _preceding_kt_annotations(masked: str, pos: int) -> Tuple[List[str], Set[str]]:
    """Collect adjacent preceding Kotlin @Annotations and modifier keywords."""
    annotations: List[str] = []
    extra_mods: Set[str] = set()
    idx = pos - 1
    while idx >= 0:
        while idx >= 0 and masked[idx].isspace():
            idx -= 1
        if idx < 0:
            break
        if masked[idx] == ")":
            depth = 1
            idx -= 1
            while idx >= 0 and depth > 0:
                if masked[idx] == ")":
                    depth += 1
                elif masked[idx] == "(":
                    depth -= 1
                idx -= 1
            if depth != 0:
                break
            while idx >= 0 and masked[idx].isspace():
                idx -= 1
            if idx < 0:
                break
            end_tok = idx + 1
            while idx >= 0 and (masked[idx].isalnum() or masked[idx] in "_.:"):
                idx -= 1
            if idx >= 0 and masked[idx] == "@":
                ann = masked[idx + 1:end_tok].split(":")[-1]
                if ann:
                    annotations.append(ann)
                idx -= 1
                continue
            break
        if masked[idx].isalnum() or masked[idx] in "_.":
            end_tok = idx + 1
            while idx >= 0 and (masked[idx].isalnum() or masked[idx] in "_.:"):
                idx -= 1
            token = masked[idx + 1:end_tok]
            if idx >= 0 and masked[idx] == "@":
                ann = token.split(":")[-1]
                if ann:
                    annotations.append(ann)
                idx -= 1
                continue
            if token in _KT_FUNCTION_MODIFIERS:
                extra_mods.add(token)
                continue
            break
        break
    annotations.reverse()
    return annotations, extra_mods


def _kt_function_records(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    """Discover Kotlin functions: block bodies and single-line ``=`` bodies."""
    records: List[Dict[str, Any]] = []
    seen: set[Tuple[str, int]] = set()
    declaration = re.compile(
        r"(?P<mods>(?:(?:public|private|protected|internal|open|override|suspend|inline|tailrec|operator|infix|external|actual|expect|abstract)\s+)*)"
        r"fun\s+(?:<[^;{}()]*>\s*)?(?:(?P<receiver>[A-Za-z_][A-Za-z0-9_]*)\s*\.\s*)?"
        r"(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*(?:<[^;{}()]*>)?\s*\("
    )
    for rel, source, masked in sources:
        for match in declaration.finditer(masked):
            params_open = masked.find("(", match.start(), match.end())
            params_close = _matching_js_delimiter(masked, params_open, "(", ")")
            if params_close < 0:
                continue
            form, body_pos = _kt_function_body_open(masked, params_close + 1)
            if form is None:
                continue
            if form == "block":
                body_open = body_pos
                body_close = _matching_js_brace(masked, body_open)
                if body_close < 0 or (rel, body_open) in seen:
                    continue
                seen.add((rel, body_open))
                expr_start = expr_end = -1
                line_end = source.count("\n", 0, body_close) + 1
            else:
                expr_start = body_pos + 1
                line_end_pos = source.find("\n", expr_start)
                semi = masked.find(";", expr_start)
                expr_end = len(source)
                if line_end_pos >= 0:
                    expr_end = min(expr_end, line_end_pos)
                if semi >= 0:
                    expr_end = min(expr_end, semi)
                body_open = body_close = -1
                line_end = source.count("\n", 0, expr_end) + 1
                # A single-line capture can truncate a multi-line expression:
                # ``= JSONObject()`` followed by ``.put(...)`` on the next
                # line is a builder chain, not a forwarding call.  When the
                # expression ended at a newline (not ``;``), peek at the next
                # line: a leading ``.`` or infix operator continues it, so
                # the record is not a single-line expression body in v1.
                expr_continues = False
                if expr_end < len(source) and source[expr_end] == "\n":
                    nxt = _skip_js_space(masked, expr_end)
                    if nxt < len(masked) and masked[nxt] == ".":
                        expr_continues = True
                    elif nxt < len(masked) and re.match(
                        r"(?:&&|\|\||[+\-*/%]|\?:|as\b|is\b|!in\b|in\b)",
                        masked[nxt:],
                    ):
                        expr_continues = True
            params = _kt_simple_parameter_names(source, masked, params_open, params_close)
            name = match.group("name")
            mods = match.group("mods") or ""
            annotations, extra_mods = _preceding_kt_annotations(masked, match.start())
            mods_set = set(mods.split()) | extra_mods
            private = "private" in mods_set
            is_override = "override" in mods_set
            is_test_fn = any(
                ann == "Test"
                or ann.endswith(".Test")
                or ann in {"ParameterizedTest", "RepeatedTest", "TestFactory", "TestTemplate"}
                for ann in annotations
            )
            records.append({
                "file": rel, "source": source, "masked": masked, "name": name,
                "start": match.start(), "params_open": params_open, "params_close": params_close,
                "params": params, "body_open": body_open, "body_close": body_close,
                "line_start": source.count("\n", 0, match.start()) + 1,
                "line_end": line_end,
                "exported": not private, "private": private,
                "async": False, "form": "function" if form == "block" else "expression",
                "expr_start": expr_start, "expr_end": expr_end,
                "expr_continues": expr_continues if form == "expr" else False,
                "annotations": annotations,
                "is_override": is_override,
                "is_test_fn": is_test_fn,
            })
    records.sort(key=lambda row: (row["file"], row["start"], row["name"]))
    return records


def _brace_normalized_body_tokens(source: str, start: int, end: int) -> Optional[List[str]]:
    """Tokenize a Rust/Kotlin body conservatively for exact-structure fingerprinting.

    Comments/formatting are ignored, while string/char literal bytes and
    punctuator boundaries are preserved.  Unlike the JS tokenizer there is no
    regex/division ambiguity: ``/`` is always division in both languages.
    Lifetimes (``'a``) tokenize as a quote plus an identifier; char literals
    stay one token.  Rust raw strings (``r#"..."#``) and Kotlin raw strings
    (``\"\"\"...\"\"\"``) are consumed as single tokens.
    """
    tokens: List[str] = []
    i = start
    punctuators = (
        "::", "->", "=>", "..=", "...", "..", "?.", "?:", "==", "!=", "<=", ">=",
        "&&", "||", "<<", ">>", "+=", "-=", "*=", "/=", "%=", "++", "--",
    )
    while i < end:
        ch = source[i]
        if ch.isspace():
            i += 1; continue
        if ch == "/" and i + 1 < end and source[i + 1] == "/":
            newline = source.find("\n", i + 2, end)
            i = end if newline < 0 else newline + 1; continue
        if ch == "/" and i + 1 < end and source[i + 1] == "*":
            close = source.find("*/", i + 2, end)
            if close < 0: return None
            i = close + 2; continue
        if ch == "r" or (ch == "b" and i + 1 < end and source[i + 1] == "r"):
            j = i + 1 if ch == "r" else i + 2
            hashes = 0
            while j < end and source[j] == "#":
                hashes += 1; j += 1
            if j < end and source[j] == '"':
                closing = '"' + "#" * hashes
                close = source.find(closing, j + 1, end)
                if close < 0: return None
                tokens.append(source[i:close + len(closing)]); i = close + len(closing); continue
        if ch == '"' and source.startswith('"""', i, end):
            close = source.find('"""', i + 3, end)
            if close < 0: return None
            tokens.append(source[i:close + 3]); i = close + 3; continue
        if ch == '"':
            j, escaped = i + 1, False
            while j < end:
                current = source[j]
                if escaped:
                    escaped = False
                elif current == "\\":
                    escaped = True
                elif current == '"':
                    j += 1; break
                j += 1
            if j > end: return None
            tokens.append(source[i:j]); i = j; continue
        if ch == "'":
            char_end = _brace_char_literal_end(source, i, end)
            if char_end > 0:
                tokens.append(source[i:char_end]); i = char_end; continue
            tokens.append(ch); i += 1; continue
        ident = re.match(r"[A-Za-z_][A-Za-z0-9_]*", source[i:end])
        if ident:
            value = ident.group(0); tokens.append(value); i += len(value); continue
        number = re.match(
            r"(?:0[xX][0-9A-Fa-f_]+|0[bB][01_]+|0[oO][0-7_]+|\d[\d_]*(?:\.\d[\d_]*)?(?:[eE][+-]?\d[\d_]*)?)[A-Za-z]*",
            source[i:end],
        )
        if number:
            value = number.group(0); tokens.append(value); i += len(value); continue
        matched = next((op for op in punctuators if source.startswith(op, i)), None)
        if matched:
            tokens.append(matched); i += len(matched); continue
        tokens.append(ch); i += 1
    return tokens


def _brace_candidate_row(
    *, rel: str, name: str, line_start: int, line_end: int,
    kind: str, identity: Dict[str, Any], witness: Dict[str, Any], proof_rule: str,
    validation: List[str],
) -> Dict[str, Any]:
    return _candidate(
        identity={"file": rel, "kind": kind, "function": name, "line": line_start, **identity},
        kind=kind, files=[rel], names=[name],
        members=[_member(rel, name, line_start, line_end, private=True)], estimated_loc=1,
        witness=witness, proof_rule=proof_rule, validation=validation,
    )


def _brace_direct_forwarding_wrapper_candidates(
    *, sources: List[Tuple[str, str, str]], lang: str, records_fn,
) -> List[Dict[str, Any]]:
    """Find exact-parameter forwarding wrappers in a brace language.

    Rust accepts a ``return`` statement or a bare tail-expression call;
    a call followed by ``;`` without ``return`` discards its value and is
    NOT forwarding.  Kotlin block bodies require ``return``; Kotlin
    single-expression bodies (``= callee(args)``) are forwarding by shape.
    Callees are plain identifiers, plus ``self.<name>`` in Rust (method
    delegation); ``Self::``, ``super::`` and ``crate::`` paths are deferred.
    """
    candidates: List[Dict[str, Any]] = []
    kind = f"{lang}_direct_forwarding_wrapper"
    for fn in records_fn(sources=sources):
        params = fn.get("params")
        if params is None or fn.get("async"):
            continue
        if lang == "kt":
            if fn.get("is_override") or fn.get("is_test_fn"):
                continue
            norm_file = f"/{str(fn['file']).replace(chr(92), '/').lower()}"
            if (
                "/src/test/" in norm_file
                or "/src/androidtest/" in norm_file
                or "/src/commontest/" in norm_file
            ):
                continue
        forward_params = [p for p in params if p != "self"]
        callee: Optional[str] = None
        if fn["form"] == "expression":
            # A truncated multi-line expression (e.g. ``= JSONObject()``
            # continued by ``.put(...)``) is a builder chain, not a
            # forwarding call; _kt_function_records flags it.
            if fn.get("expr_continues"):
                continue
            expr_start = fn["expr_start"]
            expr_mask = fn["masked"][expr_start:fn["expr_end"]]
            match = re.fullmatch(
                r"\s*(?P<callee>[A-Za-z_][A-Za-z0-9_]*)\s*\((?P<args>[^;{}()]*)\)\s*",
                expr_mask, flags=re.S,
            )
            if not match:
                continue
            callee = match.group("callee")
            raw_args = _extract_exact_forwarding_args(
                fn["source"],
                fn["masked"],
                expr_start + match.start("args"),
                expr_start + match.end("args"),
            )
        else:
            body_start = fn["body_open"] + 1
            body_mask = fn["masked"][body_start:fn["body_close"]]
            if lang == "rs":
                callee_pattern = (
                    r"(?P<callee>[A-Za-z_][A-Za-z0-9_]*(?:\s*\.\s*[A-Za-z_][A-Za-z0-9_]*)?)"
                )
                match = re.fullmatch(
                    r"\s*return\s+" + callee_pattern + r"\s*\((?P<args>[^;{}()]*)\)\s*;?\s*",
                    body_mask, flags=re.S,
                )
                if not match:
                    match = re.fullmatch(
                        r"\s*" + callee_pattern + r"\s*\((?P<args>[^;{}()]*)\)\s*",
                        body_mask, flags=re.S,
                    )
            else:
                match = re.fullmatch(
                    r"\s*return\s+(?P<callee>[A-Za-z_][A-Za-z0-9_]*)\s*\((?P<args>[^;{}()]*)\)\s*;?\s*",
                    body_mask, flags=re.S,
                )
            if not match:
                continue
            callee = re.sub(r"\s+", "", match.group("callee"))
            raw_args = _extract_exact_forwarding_args(
                fn["source"],
                fn["masked"],
                body_start + match.start("args"),
                body_start + match.end("args"),
            )
        if not callee or callee.split(".")[-1] == fn["name"]:
            continue
        if lang == "kt":
            leaf = callee.split(".")[-1]
            if leaf and leaf[0].isupper():
                continue
        if raw_args is None or raw_args != list(forward_params):
            continue
        private = bool(fn["private"])
        is_self_callee = "." in callee
        candidates.append(_candidate(
            identity={"file": fn["file"], "kind": kind, "function": fn["name"], "callee": callee},
            kind=kind, files=[fn["file"]], names=[fn["name"]],
            members=[_member(fn["file"], fn["name"], fn["line_start"], fn["line_end"], private=private)],
            estimated_loc=max(1, fn["line_end"] - fn["line_start"] + 1),
            witness={
                "type": f"{lang}_direct_forwarding_wrapper_v1", "same_owner_file": True,
                "simple_parameters_only": True, "argument_forwarding_exact": True,
                "direct_identifier_callee": not is_self_callee,
                "self_receiver_callee": is_self_callee,
                "async_wrapper_excluded": True,
                "wrapper_exported": bool(fn["exported"]), "wrapper_private": private,
                "function_form": fn["form"], "callee": callee,
                "authority": f"bounded_{lang}_structural_forwarding_witness_only",
            },
            proof_rule=f"remove/share a {lang.upper()} forwarding wrapper only when callable/API identity and all consumers remain compatible",
            validation=[
                "preserve exported/public callable names unless compatibility is explicitly retained",
                "preserve receiver binding by allowing only direct identifier or self-receiver callees in v1",
                "preserve argument order and arity", f"run affected {lang.upper()} tests and type-check",
            ],
        ))
    return candidates


def _brace_exact_function_body_duplication_candidates(
    *, sources: List[Tuple[str, str, str]], lang: str, records_fn,
) -> List[Dict[str, Any]]:
    """Find conservative exact structural body duplication in a brace language."""
    kind = f"{lang}_exact_function_body_duplication"
    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for fn in records_fn(sources=sources):
        if fn["body_open"] < 0:
            continue
        tokens = _brace_normalized_body_tokens(fn["source"], fn["body_open"] + 1, fn["body_close"])
        if tokens is None or len(tokens) < 8:
            continue
        fingerprint = _sha(json.dumps(tokens, ensure_ascii=False, separators=(",", ":")))
        grouped.setdefault(fingerprint, []).append(fn)
    candidates: List[Dict[str, Any]] = []
    for fingerprint, members in grouped.items():
        if len(members) < 2:
            continue
        files = sorted({row["file"] for row in members})
        names = sorted({row["name"] for row in members})
        locs = sorted((row["line_end"] - row["line_start"] + 1 for row in members), reverse=True)
        removable = sum(locs[1:])
        if removable <= 0:
            continue
        candidates.append(_candidate(
            identity={"kind": kind, "body": fingerprint, "files": files, "names": names},
            kind=kind, files=files, names=names,
            members=[_member(row["file"], row["name"], row["line_start"], row["line_end"], private=row["private"]) for row in members],
            estimated_loc=removable, duplicate_loc=removable,
            witness={
                "type": f"{lang}_exact_function_body_tokens_v1", "exact_token_body_identical": True,
                "comments_and_formatting_ignored": True, "string_and_char_literal_bytes_preserved": True,
                "nested_block_comment_bodies_excluded_by_mask_limitation": True,
                "member_count": len(members), "body_fingerprint": fingerprint,
                "authority": f"bounded_{lang}_token_body_duplication_witness_only",
            },
            proof_rule=f"share exact {lang.upper()} function-body implementations only behind a neutral owner while preserving every public callable surface",
            validation=[
                "preserve exported/public functions as compatibility wrappers when required",
                "preserve module initialization and import behavior", f"run affected {lang.upper()} tests and type-check",
            ],
        ))
    return candidates


def _brace_redundant_else_after_terminal_candidates(
    *, sources: List[Tuple[str, str, str]], lang: str, records_fn,
) -> List[Dict[str, Any]]:
    """Find a braced ``else`` following a directly terminal ``if`` branch.

    Two guards beyond the JS rule, because Rust/Kotlin ``if`` can be an
    expression: (1) the ``if`` must be in statement position (the previous
    non-space character is not ``= ( [ , :`` or ``->`` and it is not
    preceded by ``return`` or by ``else`` for an ``else if`` chain); (2) the
    ``else`` block must not end in a bare tail expression, which would be the
    value of an expression-position ``if``.
    """
    kind = f"{lang}_redundant_else_after_terminal"
    candidates: List[Dict[str, Any]] = []
    records_by_file: Dict[str, List[Dict[str, Any]]] = {}
    for fn in records_fn(sources=sources):
        records_by_file.setdefault(fn["file"], []).append(fn)
    terminal_kinds = ("return", "throw") if lang == "kt" else ("return",)
    for rel, source, masked in sources:
        for match in re.finditer(r"\bif\b", masked):
            prev = match.start() - 1
            while prev >= 0 and masked[prev].isspace():
                prev -= 1
            if prev >= 0 and (
                masked[prev] in "=([,:"
                or masked[max(0, prev - 1):prev + 1] == "->"
            ):
                continue
            if (
                _preceded_by_keyword(masked, match.start(), "return")
                or _preceded_by_keyword(masked, match.start(), "else")
            ):
                continue
            pos = match.end()
            paren = bracket = angle = 0
            then_open = -1
            while pos < len(masked):
                ch = masked[pos]
                if ch == "(": paren += 1
                elif ch == ")":
                    if paren == 0: break
                    paren -= 1
                elif ch == "[": bracket += 1
                elif ch == "]":
                    if bracket == 0: break
                    bracket -= 1
                elif ch == "<": angle += 1
                elif ch == ">" and angle: angle -= 1
                elif ch == "{" and paren == bracket == angle == 0:
                    then_open = pos; break
                elif ch in ";}" and paren == bracket == angle == 0:
                    break
                pos += 1
            if then_open < 0:
                continue
            then_close = _matching_js_brace(masked, then_open)
            if then_close < 0:
                continue
            terminal_kind = _terminal_top_level_statement_kind(
                masked[then_open + 1:then_close],
                terminal_kinds,
                source_segment=source[then_open + 1:then_close],
            )
            if terminal_kind is None:
                continue
            cursor = _skip_js_space(masked, then_close + 1)
            if not masked.startswith("else", cursor):
                continue
            if cursor + 4 < len(masked) and (masked[cursor + 4].isalnum() or masked[cursor + 4] in "_$"):
                continue
            else_open = _skip_js_space(masked, cursor + 4)
            if else_open >= len(masked) or masked[else_open] != "{":
                continue
            else_close = _matching_js_brace(masked, else_open)
            if else_close < 0:
                continue
            else_body = masked[else_open + 1:else_close].strip()
            if else_body and not else_body.endswith(";") and _terminal_top_level_statement_kind(
                masked[else_open + 1:else_close],
                terminal_kinds,
                source_segment=source[else_open + 1:else_close],
            ) is None:
                continue
            line_start = source.count("\n", 0, match.start()) + 1
            line_end = source.count("\n", 0, else_close) + 1
            enclosing = "unknown"
            for fn in records_by_file.get(rel, []):
                span_end = fn["body_close"] if fn["body_open"] >= 0 else fn["expr_end"]
                if fn["start"] <= match.start() <= span_end:
                    enclosing = fn["name"]
                    break
            candidates.append(_brace_candidate_row(
                rel=rel, name=enclosing, line_start=line_start, line_end=line_end,
                kind=kind,
                identity={"terminal": terminal_kind, "else_line": source.count("\n", 0, cursor) + 1},
                witness={
                    "type": f"{lang}_redundant_else_after_terminal_v1", "same_owner_file": True,
                    "then_block_directly_terminal": True, "terminal_kind": terminal_kind,
                    "else_is_braced": True, "else_if_excluded": True,
                    "else_if_chain_inner_if_excluded": True,
                    "statement_position_if_only": True, "else_block_value_free": True,
                    "condition_evaluation_preserved": True, "else_block_scope_must_be_preserved": True,
                    "authority": f"bounded_{lang}_structural_control_flow_witness_only",
                },
                proof_rule="remove only the redundant else keyword while preserving the else block as a standalone block after a directly terminal then-branch",
                validation=[
                    "preserve condition evaluation exactly once", "preserve else-block lexical scope braces",
                    "preserve return/throw control flow", f"run affected {lang.upper()} tests and type-check",
                ],
            ))
    return candidates


def _rs_direct_forwarding_wrapper_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    return _brace_direct_forwarding_wrapper_candidates(sources=sources, lang="rs", records_fn=_rs_function_records)


def _rs_exact_function_body_duplication_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    return _brace_exact_function_body_duplication_candidates(sources=sources, lang="rs", records_fn=_rs_function_records)


def _rs_redundant_else_after_terminal_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    return _brace_redundant_else_after_terminal_candidates(sources=sources, lang="rs", records_fn=_rs_function_records)


def _kt_direct_forwarding_wrapper_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    return _brace_direct_forwarding_wrapper_candidates(sources=sources, lang="kt", records_fn=_kt_function_records)


def _kt_exact_function_body_duplication_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    return _brace_exact_function_body_duplication_candidates(sources=sources, lang="kt", records_fn=_kt_function_records)


def _kt_redundant_else_after_terminal_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    return _brace_redundant_else_after_terminal_candidates(sources=sources, lang="kt", records_fn=_kt_function_records)


def _canonical_python_source_snapshot(
    root: Path,
    *,
    excluded: Optional[Set[str]] = None,
) -> Tuple[Dict[str, Any], List[Tuple[str, str]]]:
    """Return Python sources from the canonical SharedGraph discovery snapshot.

    Simplification owns semantic rules, not filesystem discovery.  The graph
    builder is therefore the single source inventory/content authority.  This
    keeps the Python self-host frontend aligned with the same ownership and
    topology snapshot used by the rest of PLW and avoids a second scan/read
    path inside the simplifier.
    """
    from core.shared_graph import DEFAULT_IGNORE_DIRS as GRAPH_DEFAULT_IGNORE_DIRS
    from core.shared_graph import build_shared_graph
    try:
        from core.graph_cache import build_cached_shared_graph
    except Exception:
        build_cached_shared_graph = None

    ignored = set(GRAPH_DEFAULT_IGNORE_DIRS) | set(DEFAULT_IGNORES)
    if build_cached_shared_graph is not None:
        graph = build_cached_shared_graph(
            str(root),
            ignore_dirs=ignored,
            include_tool_source=True,
        )
    else:
        graph = build_shared_graph(
            str(root),
            ignore_dirs=ignored,
            include_tool_source=True,
        )
    file_map = graph.get("file_map", {}) or {}
    sources: List[Tuple[str, str]] = []
    for raw_path in graph.get("vertices", []) or []:
        path = str(raw_path)
        if not path.endswith(".py"):
            continue
        source = file_map.get(raw_path)
        if not isinstance(source, str):
            continue
        rel = _relative_graph_path(path, root)
        if is_generated_or_vendored_asset(rel, source):
            if excluded is not None:
                excluded.add(rel)
            continue
        sources.append((rel, source))
    sources.sort(key=lambda row: row[0])
    return graph, sources


def _relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def _without_docstring(body: List[ast.stmt]) -> List[ast.stmt]:
    if body:
        first = body[0]
        if (
            isinstance(first, ast.Expr)
            and isinstance(first.value, ast.Constant)
            and isinstance(first.value.value, str)
        ):
            return body[1:]
    return body


def _function_body_fingerprint(node: ast.AST) -> str:
    body = _without_docstring(list(getattr(node, "body", [])))
    normalized = ast.dump(
        ast.Module(body=body, type_ignores=[]),
        include_attributes=False,
        annotate_fields=True,
    )
    return _sha(normalized)


def _signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    return ast.unparse(node.args) if hasattr(ast, "unparse") else node.name


def _member(rel: str, name: str, start: int, end: int, *, private: Optional[bool] = None) -> Dict[str, Any]:
    return {
        "file": rel, "name": name, "line_start": int(start), "line_end": int(end),
        "loc": int(end) - int(start) + 1, "private": name.startswith("_") if private is None else bool(private),
    }


def _candidate(
    *, identity: Dict[str, Any], kind: str, files: List[str], names: List[str],
    members: List[Dict[str, Any]], estimated_loc: int, witness: Dict[str, Any],
    proof_rule: str, validation: List[str], duplicate_loc: int = 0,
) -> Dict[str, Any]:
    """Canonical candidate envelope shared by semantic simplification rules."""
    return {
        "candidate_id": _sha(json.dumps(identity, sort_keys=True)),
        "kind": kind, "files": files, "names": names, "members": members,
        "member_count": len(members), "estimated_removable_loc": int(estimated_loc),
        "estimated_removable_duplicate_loc": int(duplicate_loc),
        "semantic_witness": witness,
        "proof_obligation": {"required": True, "rule": proof_rule, "validation": validation},
    }


def _complexity_metrics(tree: ast.AST) -> Dict[str, int]:
    counters = {
        "ast_nodes": 0,
        "branches": 0,
        "loops": 0,
        "try_blocks": 0,
        "functions": 0,
        "classes": 0,
    }
    for node in ast.walk(tree):
        counters["ast_nodes"] += 1
        if isinstance(node, (ast.If, ast.IfExp, ast.Match)):
            counters["branches"] += 1
        elif isinstance(node, (ast.For, ast.AsyncFor, ast.While)):
            counters["loops"] += 1
        elif isinstance(node, ast.Try):
            counters["try_blocks"] += 1
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            counters["functions"] += 1
        elif isinstance(node, ast.ClassDef):
            counters["classes"] += 1
    return counters




def _pure_local_constant_condition(node: ast.AST) -> bool:
    """Return True only for conservative side-effect-free branch predicates.

    V1 intentionally accepts only local-name comparisons against literal
    constants/containers.  Removing such a condition cannot suppress a call,
    attribute access, subscription, or user-defined coercion performed by the
    predicate itself.
    """
    if not isinstance(node, ast.Compare) or len(node.ops) != 1 or len(node.comparators) != 1:
        return False
    if not isinstance(node.left, ast.Name):
        return False
    right = node.comparators[0]
    if isinstance(node.ops[0], (ast.Eq, ast.NotEq, ast.Is, ast.IsNot)):
        return isinstance(right, ast.Constant)
    if isinstance(node.ops[0], (ast.In, ast.NotIn)) and isinstance(right, (ast.Tuple, ast.List, ast.Set)):
        return all(isinstance(item, ast.Constant) for item in right.elts)
    return False




def _function_parameters(node: ast.FunctionDef | ast.AsyncFunctionDef) -> Optional[List[str]]:
    """Return simple positional parameter names or None for complex signatures.

    Forwarding-wrapper V1 intentionally excludes defaults, keyword-only
    parameters, varargs and kwargs.  This makes one-to-one argument forwarding
    mechanically checkable without reasoning about call binding semantics.
    """
    args = node.args
    if args.vararg is not None or args.kwarg is not None or args.kwonlyargs:
        return None
    if args.defaults or args.kw_defaults:
        return None
    return [arg.arg for arg in [*args.posonlyargs, *args.args]]


def _direct_forward_call_witness(
    fn: ast.FunctionDef | ast.AsyncFunctionDef,
    body: List[ast.stmt],
) -> Optional[Dict[str, Any]]:
    """Return a mechanical witness for a pure direct forwarding wrapper.

    V1 accepts exactly one `return callee(p1, ..., pn)` statement where the
    callee is a direct Name and every simple positional parameter is forwarded
    once, in order, without constants, transformations or keyword injection.
    """
    params = _function_parameters(fn)
    if params is None or len(body) != 1:
        return None
    stmt = body[0]
    if not isinstance(stmt, ast.Return) or not isinstance(stmt.value, ast.Call):
        return None
    call = stmt.value
    if not isinstance(call.func, ast.Name) or call.func.id == fn.name:
        return None
    if call.keywords or len(call.args) != len(params):
        return None
    forwarded: List[str] = []
    for expected, arg in zip(params, call.args):
        if not isinstance(arg, ast.Name) or arg.id != expected:
            return None
        forwarded.append(arg.id)
    return {
        "callee": call.func.id,
        "parameters": params,
        "forwarded_arguments": forwarded,
        "argument_forwarding_exact": True,
        "call_transformations_present": False,
    }


def _forwarding_wrapper_candidates(*, trees: List[Tuple[str, ast.AST]]) -> List[Dict[str, Any]]:
    """Find mechanically witnessed direct forwarding wrappers.

    Private wrappers can be simplification candidates when their proof surface
    is local.  Public wrappers are surfaced as structural debt but are deferred
    because the callable name itself may be a compatibility/API contract.
    """
    candidates: List[Dict[str, Any]] = []
    for rel, tree in trees:
        for fn in ast.walk(tree):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            body = _without_docstring(list(fn.body))
            witness = _direct_forward_call_witness(fn, body)
            if witness is None:
                continue
            start = int(fn.lineno)
            end = int(getattr(fn, "end_lineno", fn.lineno))
            private = fn.name.startswith("_")
            witness_payload = {
                "file": rel,
                "function": fn.name,
                "callee": witness["callee"],
                "parameters": witness["parameters"],
                "private": private,
            }
            candidates.append(_candidate(
                identity=witness_payload, kind="direct_forwarding_wrapper", files=[rel], names=[fn.name],
                members=[_member(rel, fn.name, start, end, private=private)], estimated_loc=max(1, end - start + 1),
                witness={"type": "direct_parameter_forwarding_wrapper", **witness, "wrapper_private": private,
                         "public_surface_contract_risk": not private, "authority": "syntactic_local_forwarding_witness_only"},
                proof_rule="remove only after all local wrapper call sites are redirected to the witnessed callee",
                validation=["preserve public callable surface; public wrappers defer by default",
                            "re-run affected context/kernel fixtures", "re-run kernel CLI/integration smoke",
                            "compare against stable reference contract"],
            ))
    return candidates



def _sequence_control_transfer_free(statements: List[ast.stmt]) -> bool:
    """Conservative witness for helper-extractable direct statement sequences.

    V1 permits ordinary assignments and nested local loops/branches, but rejects
    control transfer, scope mutation, async suspension, imports and nested
    definitions.  This proves only that the repeated block has the same AST and
    no obvious non-local control transfer; helper extraction still requires
    regression/reference validation because the call frame changes.
    """
    banned = (
        ast.Return, ast.Raise, ast.Break, ast.Continue,
        ast.Yield, ast.YieldFrom, ast.Await,
        ast.Global, ast.Nonlocal,
        ast.Import, ast.ImportFrom,
        ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef,
    )
    return not any(isinstance(node, banned) for stmt in statements for node in ast.walk(stmt))


def _sequence_name_flow(statements: List[ast.stmt]) -> Dict[str, List[str]]:
    loaded: set[str] = set()
    stored: set[str] = set()
    for stmt in statements:
        for node in ast.walk(stmt):
            if isinstance(node, ast.Name):
                if isinstance(node.ctx, ast.Load):
                    loaded.add(node.id)
                elif isinstance(node.ctx, (ast.Store, ast.Del)):
                    stored.add(node.id)
    return {
        "loaded_names": sorted(loaded),
        "assigned_names": sorted(stored),
        "external_name_candidates": sorted(loaded - stored),
    }


def _direct_body_sequence_windows(
    fn: ast.FunctionDef | ast.AsyncFunctionDef,
    *,
    min_statements: int = 3,
    max_statements: int = 8,
) -> List[Dict[str, Any]]:
    body = _without_docstring(list(fn.body))
    rows: List[Dict[str, Any]] = []
    max_len = min(max_statements, len(body))
    for length in range(max_len, min_statements - 1, -1):
        for offset in range(0, len(body) - length + 1):
            statements = body[offset:offset + length]
            if not _sequence_control_transfer_free(statements):
                continue
            normalized = ast.dump(
                ast.Module(body=statements, type_ignores=[]),
                include_attributes=False,
                annotate_fields=True,
            )
            start = int(statements[0].lineno)
            end = int(getattr(statements[-1], "end_lineno", statements[-1].lineno))
            rows.append({
                "function": fn.name,
                "function_private": fn.name.startswith("_"),
                "offset": offset,
                "statement_count": length,
                "line_start": start,
                "line_end": end,
                "loc_span": end - start + 1,
                "normalized_ast": normalized,
                "sequence_fingerprint": _sha(normalized),
                "name_flow": _sequence_name_flow(statements),
            })
    return rows


def _repeated_statement_sequence_candidates(*, trees: List[Tuple[str, ast.AST]]) -> List[Dict[str, Any]]:
    """Find exact direct-body statement sequences repeated across functions in one owner.

    The detector is intentionally owner-local.  It never proposes cross-file
    extraction, and it does not claim helper extraction is behaviorally
    equivalent merely because statement ASTs match.
    """
    candidates: List[Dict[str, Any]] = []
    for rel, tree in trees:
        top_level_functions = [
            node for node in getattr(tree, "body", [])
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        ]
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for fn in top_level_functions:
            for row in _direct_body_sequence_windows(fn):
                grouped.setdefault(row["sequence_fingerprint"], []).append(row)

        raw: List[Dict[str, Any]] = []
        for fingerprint, occurrences in grouped.items():
            distinct_functions = sorted({row["function"] for row in occurrences})
            if len(distinct_functions) < 2:
                continue
            # One occurrence per function is sufficient for V1 and avoids
            # inflating support when a function repeats the same sequence twice.
            chosen: List[Dict[str, Any]] = []
            seen_functions: set[str] = set()
            for row in sorted(occurrences, key=lambda r: (r["function"], r["line_start"])):
                if row["function"] in seen_functions:
                    continue
                seen_functions.add(row["function"])
                chosen.append(row)
            if len(chosen) < 2:
                continue
            statement_count = int(chosen[0]["statement_count"])
            min_span = min(int(row["loc_span"]) for row in chosen)
            repeated_span_total = sum(int(row["loc_span"]) for row in chosen)
            estimated_helper_loc = min_span + 2  # def/signature + conservative return/packing allowance
            estimated_callsite_loc = len(chosen)
            estimated_net_reduction = max(
                0,
                repeated_span_total - estimated_helper_loc - estimated_callsite_loc,
            )
            name_flow = chosen[0]["name_flow"]
            witness_payload = {
                "file": rel,
                "functions": sorted(row["function"] for row in chosen),
                "sequence_fingerprint": fingerprint,
                "statement_count": statement_count,
            }
            raw.append(_candidate(
                identity=witness_payload, kind="repeated_direct_statement_sequence", files=[rel],
                names=sorted(row["function"] for row in chosen),
                members=[_member(rel, row["function"], row["line_start"], row["line_end"],
                                 private=row["function_private"]) for row in chosen],
                estimated_loc=estimated_net_reduction,
                witness={"type": "same_owner_exact_direct_statement_sequence", "same_owner_file": True,
                         "direct_function_body_only": True, "repeated_sequence_ast_identical": True,
                         "control_transfer_free_under_v1": True, "statement_count": statement_count,
                         "occurrence_count": len(chosen), "sequence_fingerprint": fingerprint,
                         "repeated_span_total_loc": repeated_span_total, "estimated_helper_loc": estimated_helper_loc,
                         "estimated_callsite_loc": estimated_callsite_loc,
                         "estimated_net_loc_reduction": estimated_net_reduction,
                         "estimate_is_structural_not_codegen": True, **name_flow,
                         "helper_extraction_changes_call_frame": True,
                         "authority": "syntactic_repeated_sequence_witness_only"},
                proof_rule="extract only to a private same-owner helper with explicit inputs/outputs and preserve every occurrence",
                validation=["preserve public function signatures", "preserve occurrence count and execution order",
                            "re-run affected domain fixtures", "re-run kernel CLI/integration smoke",
                            "compare against stable reference contract"],
            ))

        # Keep maximal representatives.  Sub-windows with the same occurrence
        # function set and wholly-contained source ranges add noise but no new
        # simplification information.
        raw.sort(key=lambda row: (-int(row["semantic_witness"]["statement_count"]), -int(row["member_count"]), row["candidate_id"]))
        accepted: List[Dict[str, Any]] = []
        for row in raw:
            functions = tuple(row["names"])
            contained = False
            for previous in accepted:
                if tuple(previous["names"]) != functions:
                    continue
                previous_by_name = {m["name"]: m for m in previous["members"]}
                if all(
                    previous_by_name[m["name"]]["line_start"] <= m["line_start"]
                    and previous_by_name[m["name"]]["line_end"] >= m["line_end"]
                    for m in row["members"]
                ):
                    contained = True
                    break
            if not contained:
                accepted.append(row)
        candidates.extend(accepted)
    return candidates




def _iter_statement_blocks(node: ast.AST) -> Iterable[List[ast.stmt]]:
    """Yield statement lists inside one function without crossing nested scopes."""
    for field_name, value in ast.iter_fields(node):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)) and field_name != "body":
            continue
        if isinstance(value, list) and value and all(isinstance(item, ast.stmt) for item in value):
            yield value
            for item in value:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    continue
                yield from _iter_statement_blocks(item)
        elif isinstance(value, ast.AST):
            if isinstance(value, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
                continue
            yield from _iter_statement_blocks(value)


def _terminal_temporary_candidates(*, trees: List[Tuple[str, ast.AST]]) -> List[Dict[str, Any]]:
    """Find adjacent ``name = expr; return name`` inside one function/block.

    The witness is intentionally syntactic.  It proves that no Python statement
    occurs between assignment and return and that the assigned local is returned
    unchanged.  It does not claim debug/trace line-event equivalence, so every
    patch still needs regression/reference validation.
    """
    candidates: List[Dict[str, Any]] = []
    for rel, tree in trees:
        for fn in ast.walk(tree):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for block in _iter_statement_blocks(fn):
                for assign, ret in zip(block, block[1:]):
                    if not isinstance(assign, ast.Assign) or len(assign.targets) != 1:
                        continue
                    target = assign.targets[0]
                    if not isinstance(target, ast.Name):
                        continue
                    if not isinstance(ret, ast.Return) or not isinstance(ret.value, ast.Name):
                        continue
                    if ret.value.id != target.id:
                        continue
                    start = int(assign.lineno)
                    end = int(getattr(ret, "end_lineno", ret.lineno))
                    payload = {
                        "file": rel,
                        "function": fn.name,
                        "local": target.id,
                        "assign_line": start,
                        "return_line": int(ret.lineno),
                    }
                    candidates.append(_candidate(
                        identity=payload, kind="terminal_temporary_inline", files=[rel], names=[fn.name],
                        members=[_member(rel, fn.name, start, end)], estimated_loc=1,
                        witness={"type": "adjacent_terminal_local_assignment_return", "same_function": True,
                                 "same_statement_block": True, "adjacent_statements": True, "single_name_assignment": True,
                                 "returned_name_matches_assignment": True, "local_name": target.id,
                                 "rhs_ast": ast.dump(assign.value, include_attributes=False),
                                 "debug_line_event_equivalence_not_claimed": True,
                                 "authority": "syntactic_terminal_temporary_witness_only"},
                        proof_rule="inline only when assignment/return stay adjacent and stable behavior tests remain equivalent",
                        validation=["preserve expression evaluation order and exception behavior", "re-run affected domain fixtures",
                                    "re-run stable critical fixtures", "re-run kernel CLI/integration smoke"],
                    ))
    return candidates


def _literal_dict_keys(node: ast.AST) -> Optional[List[str]]:
    if not isinstance(node, ast.Dict) or not node.keys:
        return None
    keys: List[str] = []
    for key in node.keys:
        if not isinstance(key, ast.Constant) or not isinstance(key.value, str):
            return None
        keys.append(key.value)
    return keys


def _parallel_payload_candidates(*, trees: List[Tuple[str, ast.AST]]) -> List[Dict[str, Any]]:
    """Find owner-local guard/terminal dict returns with the same key contract.

    V1 is deliberately narrow: the guard must be a direct-body ``if`` without
    ``else`` whose last statement returns a literal-key dict, and the same
    function must end with another literal-key dict return using the exact same
    ordered key contract.  This witnesses duplicated payload construction only;
    normalization still needs regression proof because value evaluation order and
    early-return behavior must be preserved explicitly by the refactor.
    """
    candidates: List[Dict[str, Any]] = []
    for rel, tree in trees:
        for fn in getattr(tree, 'body', []):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            body = _without_docstring(list(fn.body))
            if len(body) < 2 or not isinstance(body[-1], ast.Return):
                continue
            terminal = body[-1]
            terminal_keys = _literal_dict_keys(terminal.value)
            if terminal_keys is None or len(terminal_keys) < 4:
                continue
            for offset, stmt in enumerate(body[:-1]):
                if not isinstance(stmt, ast.If) or stmt.orelse or not stmt.body:
                    continue
                guard_return = stmt.body[-1]
                if not isinstance(guard_return, ast.Return):
                    continue
                guard_keys = _literal_dict_keys(guard_return.value)
                if guard_keys != terminal_keys:
                    continue
                # The remaining direct-body statements are part of the non-guard
                # path.  We only surface the shape; we do not claim moving values
                # across the guard is safe.
                key_count = len(terminal_keys)
                guard_start = int(guard_return.lineno)
                guard_end = int(getattr(guard_return, 'end_lineno', guard_return.lineno))
                terminal_start = int(terminal.lineno)
                terminal_end = int(getattr(terminal, 'end_lineno', terminal.lineno))
                duplicate_payload_span = (guard_end - guard_start + 1) + (terminal_end - terminal_start + 1)
                estimated_net = max(1, min(key_count, duplicate_payload_span // 2))
                test_text = ast.unparse(stmt.test) if hasattr(ast, 'unparse') else '<guard>'
                payload = {
                    'file': rel,
                    'function': fn.name,
                    'keys': terminal_keys,
                    'guard_line': int(stmt.lineno),
                    'terminal_line': terminal_start,
                }
                candidates.append(_candidate(
                    identity=payload, kind='parallel_payload_return_normalization', files=[rel], names=[fn.name],
                    members=[_member(rel, fn.name, int(stmt.lineno), terminal_end)], estimated_loc=estimated_net,
                    witness={'type': 'same_literal_key_payload_guard_and_terminal_return', 'same_owner_file': True,
                             'same_function': True, 'guard_has_no_else': True, 'guard_condition': test_text,
                             'literal_key_contract_identical': True, 'ordered_keys': terminal_keys, 'key_count': key_count,
                             'value_expressions_may_differ': True, 'early_return_semantics_must_be_preserved': True,
                             'evaluation_order_equivalence_not_proven': True,
                             'authority': 'syntactic_payload_contract_witness_only'},
                    proof_rule='normalize payload construction only if guard evaluation, lazy branch-only work, key order, values, and return shape remain equivalent',
                    validation=['preserve exact ordered output keys', 'preserve guard-only/terminal-only side effects and I/O',
                                're-run affected domain cache/integrity fixtures', 'compare against stable reference contract'],
                ))
    return candidates

def _semantic_control_flow_candidates(
    *,
    trees: List[Tuple[str, ast.AST]],
) -> List[Dict[str, Any]]:
    """Find mechanically witnessed local control-flow simplifications.

    These are stronger than generic complexity heuristics: a candidate is only
    emitted when the branch condition is side-effect-free under the narrow V1
    predicate and the branch body is AST-identical to its fallback body.
    Even then, the analyzer proposes a candidate; regression/reference proof is
    still required before accepting a patch.
    """
    candidates: List[Dict[str, Any]] = []
    for rel, tree in trees:
        for fn in ast.walk(tree):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for node in ast.walk(fn):
                if not isinstance(node, ast.If) or not node.body or not node.orelse:
                    continue
                # `elif` is represented as a single nested If in orelse; the
                # candidate here intentionally targets a final branch whose
                # fallback performs exactly the same work.
                if len(node.orelse) == 1 and isinstance(node.orelse[0], ast.If):
                    continue
                if not _pure_local_constant_condition(node.test):
                    continue
                body_dump = ast.dump(ast.Module(body=node.body, type_ignores=[]), include_attributes=False)
                else_dump = ast.dump(ast.Module(body=node.orelse, type_ignores=[]), include_attributes=False)
                if body_dump != else_dump:
                    continue
                start = int(node.lineno)
                end = int(getattr(node, 'end_lineno', node.lineno))
                body_start = int(getattr(node.body[0], 'lineno', start + 1))
                else_start = int(getattr(node.orelse[0], 'lineno', end))
                # Removing the condition branch preserves the fallback copy;
                # count only source lines that disappear, never the survivor.
                body_end = int(getattr(node.body[-1], 'end_lineno', body_start))
                removed_loc = max(1, body_end - start + 1)
                test_text = ast.unparse(node.test) if hasattr(ast, 'unparse') else '<pure-local-compare>'
                witness_payload = {
                    'file': rel,
                    'function': fn.name,
                    'line_start': start,
                    'line_end': end,
                    'test': test_text,
                    'body': body_dump,
                }
                candidates.append(_candidate(
                    identity=witness_payload, kind='redundant_branch_identical_body', files=[rel], names=[fn.name],
                    members=[_member(rel, fn.name, start, end)], estimated_loc=removed_loc,
                    witness={'type': 'identical_branch_body_with_pure_local_condition', 'condition': test_text,
                             'condition_side_effect_free_under_v1': True, 'branch_body_ast_identical': True,
                             'witness_sha256': _sha(body_dump + '\n' + test_text),
                             'authority': 'syntactic_local_equivalence_witness_only'},
                    proof_rule='remove redundant branch only when the surviving fallback body remains identical',
                    validation=['preserve function public signature', 're-run claim-obligation fixtures',
                                're-run kernel CLI/integration smoke', 'compare against stable reference contract'],
                ))
    return candidates

def _relative_graph_path(path: str, root: Path) -> str:
    try:
        return Path(path).resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        normalized = str(path).replace("\\", "/")
        root_norm = root.resolve().as_posix().rstrip("/")
        prefix = root_norm + "/"
        return normalized[len(prefix):] if normalized.startswith(prefix) else normalized


def _proof_surface(candidate: Dict[str, Any], graph: Dict[str, Any], root: Path) -> Dict[str, Any]:
    """Estimate the amount of code/proof surface a simplification can disturb.

    This is a prioritization heuristic only.  It never proves equivalence and
    never changes the acceptance contract.
    """
    owners = set(candidate.get("files", []))
    edges = [
        (_relative_graph_path(str(a), root), _relative_graph_path(str(b), root))
        for a, b in graph.get("edges", [])
    ]
    adjacency: Dict[str, set[str]] = {}
    reverse: Dict[str, set[str]] = {}
    for source, target in edges:
        adjacency.setdefault(source, set()).add(target)
        reverse.setdefault(target, set()).add(source)

    direct: set[str] = set()
    for owner in owners:
        direct.update(adjacency.get(owner, set()))
        direct.update(reverse.get(owner, set()))
    direct.difference_update(owners)

    reached = set(owners) | set(direct)
    frontier = set(direct) or set(owners)
    for _ in range(1):  # expand to radius 2 from owners
        nxt: set[str] = set()
        for node in frontier:
            nxt.update(adjacency.get(node, set()))
            nxt.update(reverse.get(node, set()))
        nxt.difference_update(reached)
        reached.update(nxt)
        frontier = nxt
    two_hop = reached - owners

    public_members = sum(1 for member in candidate.get("members", []) if not member.get("private", False))
    owner_domains = {
        file.split("/", 1)[0] if "/" in file else "."
        for file in owners
    }
    neighborhood_domains = {
        file.split("/", 1)[0] if "/" in file else "."
        for file in owners | direct
    }
    cross_owner_domain_boundary = len(owner_domains) > 1
    test_neighbors = {
        file for file in direct
        if (
            file.endswith(("_test.py", ".spec.py", ".test.py"))
            or "/tests/" in f"/{file}"
            or file.startswith("tests/")
            or file == "fixture_check.py"
        )
    }
    fan_edges = sum(
        1 for source, target in edges
        if source in owners or target in owners
    )

    # Deliberately interpretable ordinal risk.  Large cross-domain/public
    # surfaces become expensive even when LOC savings look attractive.
    risk_units = (
        2.0 * len(owners)
        + 0.50 * len(direct)
        + 0.15 * min(len(two_hop), 12)
        + 2.5 * public_members
        + 1.5 * max(0, len(neighborhood_domains) - 1)
        + 8.0 * max(0, len(owner_domains) - 1)
        + 0.5 * len(test_neighbors)
        + 0.10 * fan_edges
    )
    risk_units = round(max(1.0, risk_units), 3)
    risk_level = "low" if risk_units < 8 else "medium" if risk_units < 18 else "high"
    return {
        "owner_file_count": len(owners),
        "direct_neighbor_count": len(direct),
        "two_hop_reachable_count": len(two_hop),
        "incident_edge_count": fan_edges,
        "public_member_count": public_members,
        "top_level_domain_count": len(neighborhood_domains),
        "owner_top_level_domains": sorted(owner_domains),
        "owner_domain_count": len(owner_domains),
        "cross_owner_domain_boundary": cross_owner_domain_boundary,
        "neutral_abstraction_owner_required": cross_owner_domain_boundary,
        "direct_test_neighbor_count": len(test_neighbors),
        "risk_units": risk_units,
        "risk_level": risk_level,
        "authority": "structural_proof_surface_estimate_only",
    }




def _witness_has(witness: Dict[str, Any], *keys: str) -> bool:
    return all(bool(witness.get(key)) for key in keys)


def _recommend_candidate(group: Dict[str, Any], surface: Dict[str, Any], execution_lane: str) -> str:
    """Apply the bounded recommendation lattice without granting proof authority."""
    kind = str(group.get("kind", ""))
    witness = group.get("semantic_witness", {}) or {}
    risk = str(surface.get("risk_level", "high"))
    removable = int(group.get("estimated_removable_loc", 0))
    if surface.get("cross_owner_domain_boundary"):
        recommendation = "defer_cross_domain_until_neutral_owner_proven"
    elif kind == "direct_forwarding_wrapper" and _witness_has(witness, "argument_forwarding_exact") and not witness.get("wrapper_private"):
        recommendation = "defer_public_api_wrapper"
    elif kind == "parallel_payload_return_normalization" and _witness_has(witness, "literal_key_contract_identical", "same_function"):
        recommendation = "defer_payload_normalization_high_proof_surface" if risk == "high" else ("defer_payload_no_positive_patch_margin" if removable <= 1 else "candidate_local_payload_normalization")
    elif kind == "terminal_temporary_inline" and _witness_has(witness, "adjacent_statements", "returned_name_matches_assignment", "same_function"):
        recommendation = "defer_stable_lane_requires_selective_promotion" if execution_lane == "stable_lane_shadow" else ("defer_terminal_temporary_high_proof_surface" if risk == "high" else "candidate_intra_function_terminal_temporary")
    elif kind == "js_try_catch_identical_terminal_return" and _witness_has(witness, "terminal_return_expression_identical", "return_expression_nonthrowing_literal", "catch_boundary_preserved", "finally_absent"):
        recommendation = "defer_js_try_catch_high_proof_surface" if risk == "high" else "candidate_js_try_catch_return_hoist"
    elif kind == "js_terminal_literal_temporary" and _witness_has(witness, "adjacent_assignment_return", "const_binding", "returned_name_matches_assignment", "return_expression_nonthrowing_literal", "terminal_return_in_same_block"):
        recommendation = "defer_js_terminal_temporary_high_proof_surface" if risk == "high" else "candidate_js_terminal_literal_temporary_inline"
    elif kind == "js_terminal_expression_temporary" and _witness_has(witness, "adjacent_assignment_return", "const_binding", "returned_name_matches_assignment", "terminal_return_in_same_block"):
        recommendation = "defer_js_terminal_expression_high_proof_surface" if risk == "high" else "candidate_js_terminal_expression_temporary_inline"
    elif kind == "js_direct_forwarding_wrapper" and _witness_has(witness, "argument_forwarding_exact", "direct_identifier_callee"):
        if witness.get("wrapper_exported") or not witness.get("wrapper_private"):
            recommendation = "defer_js_public_api_wrapper"
        else:
            recommendation = "defer_js_forwarding_high_proof_surface" if risk == "high" else "candidate_js_private_forwarding_wrapper"
    elif kind == "js_exact_function_body_duplication" and witness.get("exact_token_body_identical"):
        recommendation = "defer_js_duplicate_high_proof_surface" if risk == "high" else "candidate_js_exact_body_dedup"
    elif kind == "js_redundant_else_after_terminal" and _witness_has(witness, "then_block_directly_terminal", "else_is_braced", "condition_evaluation_preserved"):
        recommendation = "defer_js_redundant_else_high_proof_surface" if risk == "high" else "candidate_js_redundant_else_elision"
    elif kind == "js_boolean_guard_return" and _witness_has(witness, "condition_evaluated_once_before_and_after", "true_false_terminals_opposite"):
        recommendation = "defer_js_boolean_return_high_proof_surface" if risk == "high" else "candidate_js_boolean_guard_collapse"
    elif kind == "rs_direct_forwarding_wrapper" and _witness_has(witness, "argument_forwarding_exact") and (witness.get("direct_identifier_callee") or witness.get("self_receiver_callee")):
        if witness.get("wrapper_exported") or not witness.get("wrapper_private"):
            recommendation = "defer_rs_public_api_wrapper"
        else:
            recommendation = "defer_rs_forwarding_high_proof_surface" if risk == "high" else "candidate_rs_private_forwarding_wrapper"
    elif kind == "kt_direct_forwarding_wrapper" and _witness_has(witness, "argument_forwarding_exact", "direct_identifier_callee"):
        if witness.get("wrapper_exported") or not witness.get("wrapper_private"):
            recommendation = "defer_kt_public_api_wrapper"
        else:
            recommendation = "defer_kt_forwarding_high_proof_surface" if risk == "high" else "candidate_kt_private_forwarding_wrapper"
    elif kind == "rs_exact_function_body_duplication" and witness.get("exact_token_body_identical"):
        recommendation = "defer_rs_duplicate_high_proof_surface" if risk == "high" else "candidate_rs_exact_body_dedup"
    elif kind == "kt_exact_function_body_duplication" and witness.get("exact_token_body_identical"):
        recommendation = "defer_kt_duplicate_high_proof_surface" if risk == "high" else "candidate_kt_exact_body_dedup"
    elif kind == "rs_redundant_else_after_terminal" and _witness_has(witness, "then_block_directly_terminal", "else_is_braced", "condition_evaluation_preserved"):
        recommendation = "defer_rs_redundant_else_high_proof_surface" if risk == "high" else "candidate_rs_redundant_else_elision"
    elif kind == "kt_redundant_else_after_terminal" and _witness_has(witness, "then_block_directly_terminal", "else_is_braced", "condition_evaluation_preserved"):
        recommendation = "defer_kt_redundant_else_high_proof_surface" if risk == "high" else "candidate_kt_redundant_else_elision"
    elif kind == "repeated_direct_statement_sequence" and _witness_has(witness, "repeated_sequence_ast_identical", "control_transfer_free_under_v1", "same_owner_file"):
        recommendation = "defer_sequence_no_positive_net_gain" if removable <= 0 else ("defer_sequence_high_proof_surface" if risk == "high" else "candidate_local_sequence_extraction")
    elif (kind == "redundant_branch_identical_body" and witness.get("branch_body_ast_identical")) or (kind == "direct_forwarding_wrapper" and witness.get("argument_forwarding_exact")):
        recommendation = "candidate_strong_local_witness"
    else:
        recommendation = "candidate" if risk in ("low", "medium") else "defer_until_narrower_candidates_exhausted"
    if execution_lane == "stable_lane_shadow" and recommendation.startswith("candidate"):
        return "defer_stable_lane_requires_selective_promotion"
    return recommendation



def _adjudication(disposition: str, decision: str, reopen: str, owner: Optional[str] = None) -> Dict[str, Any]:
    return {
        "disposition": disposition,
        "owner_decision": decision,
        "reopen_condition": reopen,
        "neutral_owner": owner,
    }


def _adjudicate_candidate(group: Dict[str, Any]) -> Dict[str, Any]:
    """Give already-detected F90 debt an explicit architecture disposition."""
    recommendation = str(group.get("priority", {}).get("recommendation", ""))
    names = {str(name) for name in group.get("names", [])}
    files = {str(path).replace("\\", "/") for path in group.get("files", [])}
    gain = int(group.get("estimated_removable_loc", group.get("estimated_removable_duplicate_loc", 0)))

    if recommendation == "defer_public_api_wrapper":
        return _adjudication(
            "API_PROOF_CANDIDATE", "PUBLIC_COMPATIBILITY_SURFACE_MUST_BE_PROVEN",
            "prove all callers/consumers and provide compatibility or deprecation transition before wrapper removal",
        )
    if recommendation in {"defer_payload_no_positive_patch_margin", "defer_sequence_no_positive_net_gain"}:
        return _adjudication(
            "KEEP", "NO_POSITIVE_NET_SIMPLIFICATION_GAIN",
            "reopen only if surrounding code changes create a positive measured patch margin",
        )
    if recommendation in {"defer_sequence_high_proof_surface", "defer_js_try_catch_high_proof_surface"}:
        return _adjudication(
            "DEFER", "HIGH_PROOF_SURFACE_REQUIRES_DOMAIN_SPECIFIC_REVIEW",
            "provide bounded behavioral differential and reduce or explicitly accept the affected proof surface",
        )
    if recommendation == "candidate_js_try_catch_return_hoist":
        return _adjudication(
            "DEFER", "JS_LOCAL_SEMANTIC_CANDIDATE_REQUIRES_BEHAVIORAL_PROOF",
            "apply only in a target worktree after preserving try/catch exception behavior and passing affected TS/Angular tests",
        )
    if recommendation == "candidate_js_terminal_literal_temporary_inline":
        return _adjudication(
            "DEFER", "JS_LOCAL_TERMINAL_TEMPORARY_REQUIRES_BEHAVIORAL_PROOF",
            "apply only in a target worktree after proving literal value/order preservation and passing affected TS/JS tests",
        )
    if recommendation in {
        "candidate_rs_private_forwarding_wrapper",
        "candidate_rs_exact_body_dedup", "candidate_rs_redundant_else_elision",
        "candidate_kt_private_forwarding_wrapper",
        "candidate_kt_exact_body_dedup", "candidate_kt_redundant_else_elision",
    }:
        return _adjudication(
            "DEFER", "RS_KT_STRUCTURAL_V1_CANDIDATE_REQUIRES_BEHAVIORAL_PROOF",
            "apply only in a target worktree after Rust/Kotlin tests, type-check where applicable, and bounded reference validation",
        )
    if recommendation in {"defer_rs_public_api_wrapper", "defer_kt_public_api_wrapper"}:
        return _adjudication(
            "API_PROOF_CANDIDATE", "RS_KT_EXPORTED_OR_PUBLIC_WRAPPER_COMPATIBILITY_MUST_BE_PROVEN",
            "preserve the callable surface or prove all consumers before wrapper removal",
        )
    if recommendation in {
        "defer_rs_forwarding_high_proof_surface", "defer_rs_duplicate_high_proof_surface",
        "defer_rs_redundant_else_high_proof_surface",
        "defer_kt_forwarding_high_proof_surface", "defer_kt_duplicate_high_proof_surface",
        "defer_kt_redundant_else_high_proof_surface",
    }:
        return _adjudication(
            "DEFER", "RS_KT_STRUCTURAL_V1_HIGH_PROOF_SURFACE",
            "reduce the affected proof surface or provide domain-specific differential evidence before patching",
        )
    if recommendation in {
        "candidate_js_terminal_expression_temporary_inline", "candidate_js_private_forwarding_wrapper",
        "candidate_js_exact_body_dedup", "candidate_js_redundant_else_elision",
        "candidate_js_boolean_guard_collapse",
    }:
        return _adjudication(
            "DEFER", "JS_STRUCTURAL_V2_CANDIDATE_REQUIRES_BEHAVIORAL_PROOF",
            "apply only in a target worktree after TypeScript/JavaScript tests, type-check where applicable, and bounded reference validation",
        )
    if recommendation == "defer_js_public_api_wrapper":
        return _adjudication(
            "API_PROOF_CANDIDATE", "JS_EXPORTED_OR_PUBLIC_WRAPPER_COMPATIBILITY_MUST_BE_PROVEN",
            "preserve the callable surface or prove all consumers before wrapper removal",
        )
    if recommendation in {
        "defer_js_forwarding_high_proof_surface", "defer_js_duplicate_high_proof_surface",
        "defer_js_redundant_else_high_proof_surface", "defer_js_boolean_return_high_proof_surface",
        "defer_js_terminal_expression_high_proof_surface",
    }:
        return _adjudication(
            "DEFER", "JS_STRUCTURAL_V2_HIGH_PROOF_SURFACE",
            "reduce the affected proof surface or provide domain-specific differential evidence before patching",
        )
    if recommendation == "defer_until_narrower_candidates_exhausted":
        if names == {"expect"} and files == {"fixture_check.py", "experimental_fixture_check.py"}:
            return _adjudication(
                "KEEP", "PROOF_LANE_INDEPENDENCE_IS_INTENTIONAL",
                "reopen only if stable and experimental proof harnesses acquire a neutral test-support layer without coupling their execution lanes",
            )
        return _adjudication(
            "DEFER", "HIGH_RISK_GENERAL_DEBT_NEEDS_MANUAL_ARCHITECTURE_PROOF",
            "supply a narrower mechanical witness or an explicit architecture review with bounded regression proof",
        )
    if recommendation == "defer_cross_domain_until_neutral_owner_proven":
        if names.issubset({"normalize_path", "_normalize_path"}) and "language_semantics.py" in files:
            return _adjudication(
                "NEUTRAL_OWNER_CANDIDATE", "EXISTING_NEUTRAL_OWNER_ALREADY_PRESENT",
                "selectively migrate remaining callers to language_semantics.normalize_path and prove cache/path identity compatibility",
                "language_semantics.normalize_path",
            )
        if names & {"_now", "_now_iso", "_utc_now", "_utc_timestamp"} and len(files) >= 8:
            return _adjudication(
                "NEUTRAL_OWNER_CANDIDATE", "NEW_NEUTRAL_CLOCK_OWNER_MAY_JUSTIFY_BROAD_DEDUP",
                "define one stdlib-only UTC timestamp contract and prove serialization/time-format compatibility across all owners",
                "UNPROVEN_UTC_TIME_SEMANTICS_OWNER",
            )
        if gain <= 6:
            return _adjudication(
                "KEEP", "LOCAL_DUPLICATION_CHEAPER_THAN_NEW_CROSS_DOMAIN_COUPLING",
                "reopen only if a neutral owner already exists or reuse expands enough to outweigh dependency cost",
            )
        return _adjudication(
            "DEFER", "CROSS_DOMAIN_SEMANTICS_NEED_NEUTRAL_OWNER_PROOF",
            "identify a neutral owner and prove domain-specific semantics remain equivalent before extraction",
        )
    return _adjudication(
        "DEFER", "UNCLASSIFIED_BY_F90_POLICY",
        "manual adjudication required before any patch",
    )

def _self_host_overlay_paths(root: Path) -> Optional[set[str]]:
    """Return F86 overlay paths when self-host lane separation is available."""
    manifest = root / "experiments" / "f86_stable_rebase_experimental_reattach.json"
    if not manifest.is_file():
        return None
    try:
        payload = json.loads(manifest.read_text(encoding="utf-8"))
    except Exception:
        return None
    if payload.get("checkpoint") != "F86":
        return None
    overlay = payload.get("overlay_files", {}) or {}
    return {str(path).replace("\\", "/") for path in overlay}


def analyze_simplification(root: str = ".") -> Dict[str, Any]:
    root_path = Path(root).resolve()
    self_host_overlay_paths = _self_host_overlay_paths(root_path)
    file_rows: List[Dict[str, Any]] = []
    functions: List[Dict[str, Any]] = []
    parsed_trees: List[Tuple[str, ast.AST]] = []
    parse_errors: List[Dict[str, str]] = []
    totals = {
        "python_files": 0,
        "source_loc": 0,
        "ast_nodes": 0,
        "branches": 0,
        "loops": 0,
        "try_blocks": 0,
        "functions": 0,
        "classes": 0,
    }

    excluded_generated: Set[str] = set()
    graph, source_snapshot = _canonical_python_source_snapshot(root_path, excluded=excluded_generated)
    js_source_snapshot = _canonical_js_source_snapshot(graph, root_path, excluded=excluded_generated)
    rs_source_snapshot = _canonical_rs_source_snapshot(graph, root_path, excluded=excluded_generated)
    kt_source_snapshot = _canonical_kt_source_snapshot(graph, root_path, excluded=excluded_generated)
    language_inventory = _canonical_language_inventory(graph)
    for rel, source in source_snapshot:
        try:
            tree = ast.parse(source, filename=rel)
            parsed_trees.append((rel, tree))
        except Exception as exc:
            parse_errors.append({"file": rel, "error": type(exc).__name__})
            continue

        lines = source.splitlines()
        metrics = _complexity_metrics(tree)
        loc = len(lines)
        row = {"file": rel, "source_loc": loc, **metrics}
        file_rows.append(row)
        totals["python_files"] += 1
        totals["source_loc"] += loc
        for key in metrics:
            totals[key] += metrics[key]

        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            end = int(getattr(node, "end_lineno", node.lineno))
            body_fp = _function_body_fingerprint(node)
            functions.append({
                "file": rel,
                "name": node.name,
                "signature": _signature(node),
                "line_start": int(node.lineno),
                "line_end": end,
                "loc": end - int(node.lineno) + 1,
                "body_fingerprint": body_fp,
                "private": node.name.startswith("_"),
            })

    by_fp: Dict[str, List[Dict[str, Any]]] = {}
    for row in functions:
        by_fp.setdefault(row["body_fingerprint"], []).append(row)

    duplicate_groups: List[Dict[str, Any]] = []
    for fingerprint, members in by_fp.items():
        if len(members) < 2:
            continue
        files = sorted({m["file"] for m in members})
        if len(files) < 2:
            continue
        locs = sorted((m["loc"] for m in members), reverse=True)
        removable = sum(locs[1:])
        if removable <= 0:
            continue
        names = sorted({m["name"] for m in members})
        duplicate_groups.append({
            "candidate_id": _sha(json.dumps({"fp": fingerprint, "files": files, "names": names}, sort_keys=True)),
            "kind": "exact_function_body_duplication",
            "body_fingerprint": fingerprint,
            "members": sorted(members, key=lambda m: (m["file"], m["line_start"], m["name"])),
            "member_count": len(members),
            "files": files,
            "names": names,
            "total_loc": sum(locs),
            "estimated_removable_duplicate_loc": removable,
            "proof_obligation": {
                "required": True,
                "rule": "extract/shared implementation only if callers and observable behavior remain equivalent",
                "validation": [
                    "preserve public callable surface",
                    "preserve import-resolution behavior",
                    "run affected fixtures",
                    "run kernel CLI/integration smoke",
                ],
            },
        })

    detector_specs = (
        ("semantic", _semantic_control_flow_candidates, "semantic_control_flow_candidates", "estimated_removable_semantic_loc"),
        ("forwarding", _forwarding_wrapper_candidates, "semantic_forwarding_wrapper_candidates", "estimated_removable_forwarding_loc"),
        ("sequence", _repeated_statement_sequence_candidates, "semantic_repeated_sequence_candidates", "estimated_removable_sequence_loc"),
        ("payload", _parallel_payload_candidates, "semantic_parallel_payload_candidates", "estimated_removable_payload_loc"),
        ("terminal", _terminal_temporary_candidates, "semantic_terminal_temporary_candidates", "estimated_removable_terminal_temporary_loc"),
    )
    detected = {name: detector(trees=parsed_trees) for name, detector, _, _ in detector_specs}
    js_try_catch_candidates = _js_try_catch_terminal_return_candidates(sources=js_source_snapshot)
    js_terminal_temporary_candidates = _js_terminal_literal_temporary_candidates(sources=js_source_snapshot)
    js_forwarding_candidates = _js_direct_forwarding_wrapper_candidates(sources=js_source_snapshot)
    js_duplicate_body_candidates = _js_exact_function_body_duplication_candidates(sources=js_source_snapshot)
    js_redundant_else_candidates = _js_redundant_else_after_terminal_candidates(sources=js_source_snapshot)
    js_boolean_return_candidates = _js_boolean_guard_return_candidates(sources=js_source_snapshot)
    js_terminal_expression_candidates = _js_terminal_expression_temporary_candidates(sources=js_source_snapshot)
    js_candidates = (
        js_try_catch_candidates
        + js_terminal_temporary_candidates
        + js_forwarding_candidates
        + js_duplicate_body_candidates
        + js_redundant_else_candidates
        + js_boolean_return_candidates
        + js_terminal_expression_candidates
    )
    rs_forwarding_candidates = _rs_direct_forwarding_wrapper_candidates(sources=rs_source_snapshot)
    rs_duplicate_body_candidates = _rs_exact_function_body_duplication_candidates(sources=rs_source_snapshot)
    rs_redundant_else_candidates = _rs_redundant_else_after_terminal_candidates(sources=rs_source_snapshot)
    rs_candidates = (
        rs_forwarding_candidates
        + rs_duplicate_body_candidates
        + rs_redundant_else_candidates
    )
    kt_forwarding_candidates = _kt_direct_forwarding_wrapper_candidates(sources=kt_source_snapshot)
    kt_duplicate_body_candidates = _kt_exact_function_body_duplication_candidates(sources=kt_source_snapshot)
    kt_redundant_else_candidates = _kt_redundant_else_after_terminal_candidates(sources=kt_source_snapshot)
    kt_candidates = (
        kt_forwarding_candidates
        + kt_duplicate_body_candidates
        + kt_redundant_else_candidates
    )
    all_candidates = (
        duplicate_groups
        + [candidate for name, _, _, _ in detector_specs for candidate in detected[name]]
        + js_candidates
        + rs_candidates
        + kt_candidates
    )

    for group in all_candidates:
        surface = _proof_surface(group, graph, root_path)
        gain_loc = int(group.get("estimated_removable_loc", group.get("estimated_removable_duplicate_loc", 0)))
        implementation_reduction = max(1, int(group.get("member_count", 1)) - 1)
        gain_units = float(gain_loc) + 2.0 * float(implementation_reduction)
        priority = round(gain_units / (max(1.0, float(surface["risk_units"])) ** 1.2), 6)
        group["simplification_gain"] = {
            "loc_reduction": gain_loc,
            "duplicate_loc": int(group.get("estimated_removable_duplicate_loc", 0)),
            "duplicate_implementations_removed_if_extracted": implementation_reduction if group.get("kind") == "exact_function_body_duplication" else 0,
            "gain_units": round(gain_units, 3),
        }
        group["proof_surface"] = surface
        risk_level = str(surface.get("risk_level", "high"))
        cross_domain = bool(surface.get("cross_owner_domain_boundary"))
        candidate_files = {str(path).replace("\\", "/") for path in group.get("files", [])}
        if self_host_overlay_paths is None:
            execution_lane = "target"
        elif candidate_files and candidate_files.issubset(self_host_overlay_paths):
            execution_lane = "experimental_overlay"
        else:
            execution_lane = "stable_lane_shadow"
        group["execution_lane"] = execution_lane
        recommendation = _recommend_candidate(group, surface, execution_lane)
        group["priority"] = {
            "policy": "intra_function_frontier_then_existing_gates_v8",
            "score": priority,
            "higher_is_better_within_risk_gate": True,
            "risk_gate": "defer_cross_domain_and_high_surface_by_default",
            "recommendation": recommendation,
            "cross_domain_dedup_requires_neutral_abstraction_owner": cross_domain,
            "execution_lane": execution_lane,
            "stable_lane_mutation_requires_selective_promotion": execution_lane == "stable_lane_shadow",
            "does_not_prove_equivalence": True,
        }
        group["adjudication"] = _adjudicate_candidate(group)

    all_candidates.sort(
        key=lambda group: (
            1 if not str(group.get("priority", {}).get("recommendation", "")).startswith("candidate") else 0,
            1 if group.get("proof_surface", {}).get("risk_level") == "high" else 0,
            -float(group.get("priority", {}).get("score", 0.0)),
            -int(group.get("estimated_removable_loc", group.get("estimated_removable_duplicate_loc", 0))),
            group["candidate_id"],
        )
    )
    recommended_candidates = [
        group for group in all_candidates
        if str(group.get("priority", {}).get("recommendation", "")).startswith("candidate")
    ]
    recommendation_counts: Dict[str, int] = {}
    for group in all_candidates:
        label = str(group.get("priority", {}).get("recommendation", "unknown"))
        recommendation_counts[label] = recommendation_counts.get(label, 0) + 1
    if not language_inventory.get("zero_candidate_is_clean_evidence", True):
        frontier_status = "SEMANTIC_FRONTEND_COVERAGE_INCOMPLETE"
    else:
        frontier_status = (
            "LOCAL_SIMPLIFICATION_FRONTIER_REACHED"
            if not recommended_candidates
            else "LOCAL_SIMPLIFICATION_FRONTIER_OPEN"
        )
    lane_counts: Dict[str, int] = {}
    for group in all_candidates:
        lane = str(group.get("execution_lane", "target"))
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
    stable_shadow_candidates = [
        group for group in all_candidates
        if group.get("execution_lane") == "stable_lane_shadow"
        and group.get("kind") == "terminal_temporary_inline"
    ]
    disposition_counts: Dict[str, int] = {}
    decision_counts: Dict[str, int] = {}
    for group in all_candidates:
        adjudication = group.get("adjudication", {}) or {}
        disposition = str(adjudication.get("disposition", "UNADJUDICATED"))
        decision = str(adjudication.get("owner_decision", "UNADJUDICATED"))
        disposition_counts[disposition] = disposition_counts.get(disposition, 0) + 1
        decision_counts[decision] = decision_counts.get(decision, 0) + 1
    unadjudicated = sum(
        1 for group in all_candidates
        if not group.get("adjudication")
        or str(group.get("adjudication", {}).get("owner_decision", "")).startswith("UNCLASSIFIED")
    )

    removable_total = sum(int(g["estimated_removable_duplicate_loc"]) for g in duplicate_groups)
    detector_metrics: Dict[str, int] = {}
    for name, _, count_key, removable_key in detector_specs:
        rows = detected[name]
        detector_metrics[count_key] = len(rows)
        detector_metrics[removable_key] = sum(int(g.get("estimated_removable_loc", 0)) for g in rows)
    detector_metrics["semantic_candidates_total"] = sum(len(rows) for rows in detected.values()) + len(js_candidates) + len(rs_candidates) + len(kt_candidates)
    detector_metrics["semantic_js_try_catch_candidates"] = len(js_try_catch_candidates)
    detector_metrics["estimated_removable_js_try_catch_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in js_try_catch_candidates)
    detector_metrics["semantic_js_terminal_literal_temporary_candidates"] = len(js_terminal_temporary_candidates)
    detector_metrics["estimated_removable_js_terminal_literal_temporary_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in js_terminal_temporary_candidates)
    detector_metrics["semantic_js_forwarding_wrapper_candidates"] = len(js_forwarding_candidates)
    detector_metrics["estimated_removable_js_forwarding_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in js_forwarding_candidates)
    detector_metrics["semantic_js_exact_duplicate_body_candidates"] = len(js_duplicate_body_candidates)
    detector_metrics["estimated_removable_js_duplicate_body_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in js_duplicate_body_candidates)
    detector_metrics["semantic_js_redundant_else_candidates"] = len(js_redundant_else_candidates)
    detector_metrics["estimated_removable_js_redundant_else_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in js_redundant_else_candidates)
    detector_metrics["semantic_js_boolean_guard_return_candidates"] = len(js_boolean_return_candidates)
    detector_metrics["estimated_removable_js_boolean_guard_return_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in js_boolean_return_candidates)
    detector_metrics["semantic_js_terminal_expression_temporary_candidates"] = len(js_terminal_expression_candidates)
    detector_metrics["estimated_removable_js_terminal_expression_temporary_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in js_terminal_expression_candidates)
    detector_metrics["js_semantic_files_scanned"] = len(js_source_snapshot)
    detector_metrics["js_semantic_source_loc"] = sum(len(source.splitlines()) for _, source, _ in js_source_snapshot)
    detector_metrics["semantic_rs_forwarding_wrapper_candidates"] = len(rs_forwarding_candidates)
    detector_metrics["estimated_removable_rs_forwarding_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in rs_forwarding_candidates)
    detector_metrics["semantic_rs_exact_duplicate_body_candidates"] = len(rs_duplicate_body_candidates)
    detector_metrics["estimated_removable_rs_duplicate_body_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in rs_duplicate_body_candidates)
    detector_metrics["semantic_rs_redundant_else_candidates"] = len(rs_redundant_else_candidates)
    detector_metrics["estimated_removable_rs_redundant_else_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in rs_redundant_else_candidates)
    detector_metrics["rs_semantic_files_scanned"] = len(rs_source_snapshot)
    detector_metrics["rs_semantic_source_loc"] = sum(len(source.splitlines()) for _, source, _ in rs_source_snapshot)
    detector_metrics["semantic_kt_forwarding_wrapper_candidates"] = len(kt_forwarding_candidates)
    detector_metrics["estimated_removable_kt_forwarding_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in kt_forwarding_candidates)
    detector_metrics["semantic_kt_exact_duplicate_body_candidates"] = len(kt_duplicate_body_candidates)
    detector_metrics["estimated_removable_kt_duplicate_body_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in kt_duplicate_body_candidates)
    detector_metrics["semantic_kt_redundant_else_candidates"] = len(kt_redundant_else_candidates)
    detector_metrics["estimated_removable_kt_redundant_else_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in kt_redundant_else_candidates)
    detector_metrics["kt_semantic_files_scanned"] = len(kt_source_snapshot)
    detector_metrics["kt_semantic_source_loc"] = sum(len(source.splitlines()) for _, source, _ in kt_source_snapshot)
    detector_metrics["generated_files_excluded"] = len(excluded_generated)
    return {
        "schema_version": SIMPLIFICATION_SCHEMA_VERSION,
        "root": ".",
        "language": "canonical_multi_frontend",
        "legacy_python_api_compatibility": True,
        "analysis_authority": "structural_candidate_generation_only",
        "canonical_anatomy_bridge": {
            "inventory_authority": "core.shared_graph",
            "source_content_authority": "shared_graph.file_map",
            "shared_graph_schema_version": graph.get("schema_version"),
            "shared_graph_content_signature": _graph_signature(graph),
            "semantic_frontend": "python_ast+js_structural_v2",
            "semantic_frontend_scope": {
                "python": "existing AST rule registry",
                "ts_js": "shared structural v2 frontend for TS/JS/TSX/JSX with seven conservative mechanical rules; still not a full language parser",
                "ts_js_rule_count": 7,
                "ts_js_rule_families": ["try_catch_terminal_return", "terminal_literal_temporary", "direct_forwarding_wrapper", "exact_function_body_duplication", "redundant_else_after_terminal", "boolean_guard_return", "terminal_expression_temporary"],
                "ts_js_shared_primitives": ["shared_graph.file_map", "_mask_js_noncode", "_js_function_records", "_matching_js_delimiter", "_js_normalized_body_tokens"],
                "rs_kt": "shared structural v1 frontend for Rust/Kotlin with three conservative mechanical rules per language; still not a full language parser",
                "rs_rule_count": 3,
                "kt_rule_count": 3,
                "rs_rule_families": ["direct_forwarding_wrapper", "exact_function_body_duplication", "redundant_else_after_terminal"],
                "kt_rule_families": ["direct_forwarding_wrapper", "exact_function_body_duplication", "redundant_else_after_terminal"],
                "rs_kt_shared_primitives": ["shared_graph.file_map", "_mask_rs_noncode", "_mask_kt_noncode", "_rs_function_records", "_kt_function_records", "_matching_js_delimiter", "_brace_normalized_body_tokens"],
                "independent_second_lexer_or_scanner": False,
            },
            "single_discovery_snapshot": True,
            "independent_simplifier_filesystem_scan": False,
            "python_source_count": len(source_snapshot),
            "language_inventory": language_inventory,
        },
        "candidate_priority_policy": "intra_function_frontier_then_existing_gates_v8",
        "architectural_adjudication_policy": "f90_remaining_debt_disposition_v1",
        "self_host_scan": {
            "explicit_analyzer_mode": True,
            "ordinary_global_scan_must_exclude_tool_implementation": True,
            "stable_overlay_lane_boundary_active": self_host_overlay_paths is not None,
        },
        "cannot_assert_behavioral_equivalence": True,
        "architectural_adjudication": {
            "status": "ARCHITECTURAL_DEBT_ADJUDICATED" if unadjudicated == 0 else "ARCHITECTURAL_DEBT_AMBIGUOUS",
            "unadjudicated_candidate_count": unadjudicated,
            "disposition_counts": dict(sorted(disposition_counts.items())),
            "owner_decision_counts": dict(sorted(decision_counts.items())),
            "patches_applied_by_F90": 0,
            "meaning": "remaining debt has an explicit architecture/API/economic disposition; F90 opens no new detector frontier",
        },
        "frontier": {
            "status": frontier_status,
            "recommended_local_candidates": len(recommended_candidates),
            "remaining_candidate_count": len(all_candidates),
            "remaining_debt_by_recommendation": dict(sorted(recommendation_counts.items())),
            "candidate_count_by_execution_lane": dict(sorted(lane_counts.items())),
            "stable_lane_shadow_candidates": len(stable_shadow_candidates),
            "meaning": (
                "reference inventory is available, but one or more observed source languages lack an active semantic simplification frontend; zero candidates is not clean evidence"
                if frontier_status == "SEMANTIC_FRONTEND_COVERAGE_INCOMPLETE"
                else (
                    "no remaining mechanically recommended local-safe simplification; remaining debt needs architectural/API/high-risk/no-margin decisions"
                    if frontier_status == "LOCAL_SIMPLIFICATION_FRONTIER_REACHED"
                    else "one or more local-safe mechanically witnessed candidates remain"
                )
            ),
        },
        "metrics": {
            **totals,
            "exact_duplicate_groups": len(duplicate_groups),
            "estimated_removable_duplicate_loc": removable_total,
            **detector_metrics,
        },
        "candidates": all_candidates,
        "parse_errors": parse_errors,
        "invariants": {
            "candidate_is_not_patch": True,
            "lower_loc_is_not_equivalence": True,
            "tests_are_evidence_not_universal_equivalence": True,
            "reference_validation_required_before_accept": True,
            "highest_loc_saving_is_not_automatically_highest_priority": True,
            "proof_surface_priority_is_not_equivalence": True,
            "cross_domain_duplication_is_not_automatically_a_refactor_target": True,
            "neutral_abstraction_owner_required_before_cross_domain_dedup": True,
            "semantic_candidate_requires_mechanical_witness": True,
            "semantic_witness_is_not_regression_proof": True,
            "branch_condition_must_be_side_effect_free_before_elision": True,
            "forwarding_wrapper_requires_exact_parameter_forwarding": True,
            "public_forwarding_wrapper_is_not_auto_removable": True,
            "repeated_sequence_requires_same_owner_exact_ast": True,
            "repeated_sequence_requires_control_transfer_free_witness": True,
            "repeated_sequence_witness_does_not_prove_helper_equivalence": True,
            "repeated_sequence_raw_duplication_is_not_net_simplification": True,
            "sequence_extraction_requires_positive_estimated_net_gain": True,
            "sequence_extraction_respects_high_proof_surface_gate": True,
            "parallel_payload_requires_identical_literal_key_contract": True,
            "parallel_payload_witness_does_not_prove_value_evaluation_equivalence": True,
            "parallel_payload_normalization_respects_high_proof_surface_gate": True,
            "payload_normalization_requires_positive_patch_margin": True,
            "frontier_status_requires_zero_recommended_local_candidates": True,
            "terminal_temporary_requires_adjacent_same_block_assignment_return": True,
            "terminal_temporary_debug_line_event_equivalence_is_not_claimed": True,
            "stable_lane_candidate_requires_selective_promotion_under_F86": True,
            "remaining_debt_requires_explicit_architectural_disposition_under_F90": True,
            "F90_adjudication_does_not_authorize_patch": True,
            "js_frontend_consumes_shared_graph_source_snapshot": True,
            "js_try_catch_return_hoist_requires_nonthrowing_literal_expression": True,
            "js_try_catch_prefixes_and_catch_boundary_must_be_preserved": True,
            "js_structural_frontend_v2_is_not_a_full_js_ts_parser": True,
            "js_frontend_v2_supports_ts_tsx_js_jsx_uniformly": True,
            "js_rule2_reuses_v1_lexical_substrate": True,
            "js_rule2_does_not_add_independent_lexer_or_scanner": True,
            "js_terminal_literal_temporary_requires_nonthrowing_literal": True,
            "rs_structural_frontend_v1_is_not_a_full_rust_parser": True,
            "kt_structural_frontend_v1_is_not_a_full_kotlin_parser": True,
            "rs_kt_forwarding_wrapper_requires_exact_parameter_forwarding": True,
            "rs_kt_redundant_else_requires_statement_position_and_value_free_else_block": True,
            "rs_kt_else_if_chain_inner_if_excluded": True,
        },
    }


# Compatibility alias: historical callers keep the old name without creating a
# forwarding-wrapper function that would become self-host simplification debt.
analyze_python_simplification = analyze_simplification


def compare_simplification(reference_root: str, candidate_root: str) -> Dict[str, Any]:
    reference = analyze_python_simplification(reference_root)
    candidate = analyze_python_simplification(candidate_root)
    ref_metrics = reference["metrics"]
    cand_metrics = candidate["metrics"]
    keys = (
        "source_loc", "ast_nodes", "branches", "loops", "try_blocks",
        "functions", "classes", "exact_duplicate_groups",
        "estimated_removable_duplicate_loc",
        "semantic_control_flow_candidates", "semantic_forwarding_wrapper_candidates",
        "semantic_repeated_sequence_candidates", "semantic_parallel_payload_candidates", "semantic_terminal_temporary_candidates", "semantic_candidates_total", "estimated_removable_semantic_loc",
        "estimated_removable_forwarding_loc", "estimated_removable_sequence_loc", "estimated_removable_payload_loc", "estimated_removable_terminal_temporary_loc",
        "semantic_js_try_catch_candidates", "estimated_removable_js_try_catch_loc",
        "semantic_js_terminal_literal_temporary_candidates", "estimated_removable_js_terminal_literal_temporary_loc",
        "semantic_js_forwarding_wrapper_candidates", "estimated_removable_js_forwarding_loc",
        "semantic_js_exact_duplicate_body_candidates", "estimated_removable_js_duplicate_body_loc",
        "semantic_js_redundant_else_candidates", "estimated_removable_js_redundant_else_loc",
        "semantic_js_boolean_guard_return_candidates", "estimated_removable_js_boolean_guard_return_loc",
        "semantic_js_terminal_expression_temporary_candidates", "estimated_removable_js_terminal_expression_temporary_loc",
        "js_semantic_files_scanned", "js_semantic_source_loc",
    )
    delta = {key: int(cand_metrics.get(key, 0)) - int(ref_metrics.get(key, 0)) for key in keys}
    return {
        "schema_version": SIMPLIFICATION_SCHEMA_VERSION,
        "reference": reference,
        "candidate": candidate,
        "delta_candidate_minus_reference": delta,
        "interpretation": {
            "negative_complexity_delta_is_only_a_simplification_signal": True,
            "behavioral_equivalence_requires_separate_validation": True,
        },
    }


__all__ = [
    "SIMPLIFICATION_SCHEMA_VERSION",
    "analyze_simplification",
    "analyze_python_simplification",
    "compare_simplification",
]
