"""
HoTT Kernel — Unified Entry Point
Schema Version: 3.0.0-kernel

Single entry point untuk seluruh analisis codebase.
Menggantikan 13 tool calls terpisah menjadi 1.

Usage:
    python3 hott_kernel.py analyze src
    python3 hott_kernel.py analyze src --analyzers topo.orphan,topo.entrypoint
    python3 hott_kernel.py analyzers
"""

import os
import sys
import json
import hashlib
import datetime
from typing import Any, Callable, Dict, List, Optional, Sequence

# Import kernel components
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

try:
    from core.shared_graph import (
        SOURCE_EXTENSIONS,
        build_shared_graph,
        graph_content_signature,
    )
    SHARED_GRAPH_AVAILABLE = True
except ImportError:
    try:
        from shared_graph import (
            SOURCE_EXTENSIONS,
            build_shared_graph,
            graph_content_signature,
        )
        SHARED_GRAPH_AVAILABLE = True
    except ImportError:
        SOURCE_EXTENSIONS = (".ts", ".tsx", ".js", ".jsx")
        graph_content_signature = None
        SHARED_GRAPH_AVAILABLE = False

try:
    from core.graph_cache import (
        CACHE_MODES,
        build_cached_shared_graph,
        clear_graph_cache,
        get_graph_cache_status,
    )
    GRAPH_CACHE_AVAILABLE = True
except ImportError:
    CACHE_MODES = ("auto", "refresh", "off")
    GRAPH_CACHE_AVAILABLE = False

try:
    from core.analyzer_registry import (
        run_analyzers,
        get_available_analyzers,
        get_structural_analyzers,
    )
    REGISTRY_AVAILABLE = True
except ImportError:
    try:
        from analyzer_registry import (
            run_analyzers,
            get_available_analyzers,
            get_structural_analyzers,
        )
        REGISTRY_AVAILABLE = True
    except ImportError:
        REGISTRY_AVAILABLE = False

try:
    from core.analyzer_cache import (
        clear_analyzer_cache,
        get_analyzer_cache_status,
        run_cached_analyzers,
    )
    ANALYZER_CACHE_AVAILABLE = True
except ImportError:
    ANALYZER_CACHE_AVAILABLE = False

try:
    from core.context_optimizer import (
        DEFAULT_BUDGET_TOKENS,
        DEFAULT_MAX_HOPS,
        MAX_BUDGET_TOKENS,
        MAX_HOPS,
        MIN_BUDGET_TOKENS,
        build_context_pack,
    )
    CONTEXT_OPTIMIZER_AVAILABLE = True
except ImportError:
    CONTEXT_OPTIMIZER_AVAILABLE = False

try:
    from core.adaptive_work import (
        WORK_DEPTHS,
        WORK_GOALS,
        build_adaptive_work_plan,
        select_work_findings,
    )
    ADAPTIVE_WORK_AVAILABLE = True
except ImportError:
    WORK_DEPTHS = ("auto", "quick", "standard", "deep")
    WORK_GOALS = (
        "auto", "understand", "change", "architecture", "performance", "runtime", "history",
    )
    ADAPTIVE_WORK_AVAILABLE = False

try:
    from core.semantic_affordance import build_work_semantics
    SEMANTIC_AFFORDANCE_AVAILABLE = True
except ImportError:
    SEMANTIC_AFFORDANCE_AVAILABLE = False

try:
    from core.ui_agent_handoff import build_ui_agent_handoff
except ImportError:
    build_ui_agent_handoff = None

try:
    from core.target_topology import build_target_topology_orientation
    TARGET_TOPOLOGY_AVAILABLE = True
except ImportError:
    TARGET_TOPOLOGY_AVAILABLE = False

try:
    from core.target_resolution import build_target_resolution
    TARGET_RESOLUTION_AVAILABLE = True
except ImportError:
    TARGET_RESOLUTION_AVAILABLE = False

try:
    from core.evidence_needs import build_evidence_need_derivation
    EVIDENCE_NEEDS_AVAILABLE = True
except ImportError:
    EVIDENCE_NEEDS_AVAILABLE = False

try:
    from core.capability_selection import build_capability_selection
    CAPABILITY_SELECTION_AVAILABLE = True
except ImportError:
    CAPABILITY_SELECTION_AVAILABLE = False

try:
    from core.agent_communication import build_agent_decision_frame, normalize_skill_handoff
    AGENT_COMMUNICATION_AVAILABLE = True
except ImportError:
    AGENT_COMMUNICATION_AVAILABLE = False

try:
    from core.truth_delivery import (
        finalize_truth_delivery,
        plan_proactive_truth_delivery,
    )
    TRUTH_DELIVERY_AVAILABLE = True
except ImportError:
    TRUTH_DELIVERY_AVAILABLE = False


try:
    from core.truth_floor import (
        evaluate_truth_floor,
        fail_closed_prompt,
        plan_truth_floor,
    )
    TRUTH_FLOOR_AVAILABLE = True
except ImportError:
    TRUTH_FLOOR_AVAILABLE = False


try:
    from core.claim_obligations import (
        classify_claim_intent,
        claim_guard_prompt,
        evaluate_claim_obligations,
    )
    CLAIM_OBLIGATIONS_AVAILABLE = True
except ImportError:
    CLAIM_OBLIGATIONS_AVAILABLE = False

try:
    from core.proof_transitions import (
        compile_proof_transitions,
        transition_guard_prompt,
    )
    PROOF_TRANSITIONS_AVAILABLE = True
except ImportError:
    PROOF_TRANSITIONS_AVAILABLE = False

try:
    from core.proof_state import abstract_proof_state
    PROOF_STATE_AVAILABLE = True
except ImportError:
    PROOF_STATE_AVAILABLE = False


try:
    from core.runtime_attestation import (
        find_admissible_runtime_attestations,
        find_runtime_attestation_attempts,
    )
    RUNTIME_ATTESTATION_AVAILABLE = True
except ImportError:
    RUNTIME_ATTESTATION_AVAILABLE = False


try:
    from memory.transition_outcomes import (
        annotate_transition_candidates,
        record_settled_runtime_outcomes,
        summarize_transition_outcomes,
    )
    TRANSITION_OUTCOME_MEMORY_AVAILABLE = True
except ImportError:
    TRANSITION_OUTCOME_MEMORY_AVAILABLE = False

try:
    from memory.state_transition_model import (
        annotate_candidates_with_state_model,
        register_transition_intents,
        summarize_state_transition_model,
    )
    STATE_TRANSITION_MODEL_AVAILABLE = True
except ImportError:
    STATE_TRANSITION_MODEL_AVAILABLE = False


try:
    from memory.q_value_model import (
        annotate_candidates_with_q_values,
        summarize_q_value_model,
    )
    Q_VALUE_MODEL_AVAILABLE = True
except ImportError:
    Q_VALUE_MODEL_AVAILABLE = False


try:
    from core.shadow_policy import evaluate_shadow_policy
    SHADOW_POLICY_AVAILABLE = True
except ImportError:
    SHADOW_POLICY_AVAILABLE = False


try:
    from core.outcome_reconciliation import refresh_outcome_reconciliation
    OUTCOME_RECONCILIATION_AVAILABLE = True
except ImportError:
    OUTCOME_RECONCILIATION_AVAILABLE = False


try:
    from codebase.targeted_queries import query_impact, query_outline, query_brief
    TOPO_QUERIES_AVAILABLE = True
except ImportError:
    try:
        from topology_analyzers import query_impact, query_outline, query_brief
        TOPO_QUERIES_AVAILABLE = True
    except ImportError:
        TOPO_QUERIES_AVAILABLE = False

try:
    from codebase.mermaid_graph import (
        MERMAID_DEPTH_NAMES as _MERMAID_DEPTH_NAMES,
        MERMAID_DIRECTIONS as _MERMAID_DIRECTIONS,
        generate_mermaid_diagram as _generate_mermaid_diagram,
        mermaid_build_path_trie as _mermaid_build_path_trie,
        mermaid_compact_group as _mermaid_compact_group,
        mermaid_escape as _mermaid_escape,
        mermaid_is_passthrough_dir as _mermaid_is_passthrough_dir,
        mermaid_short_module_label as _mermaid_short_module_label,
    )
    MERMAID_GRAPH_AVAILABLE = True
except ImportError:
    _MERMAID_DIRECTIONS = ("LR", "TD", "TB", "RL", "BT")
    _MERMAID_DEPTH_NAMES = {
        1: "subsystem_overview",
        2: "module_dependency_flow",
        3: "file_architecture_graph",
        4: "file_micro_neighborhood",
    }
    _generate_mermaid_diagram = None
    MERMAID_GRAPH_AVAILABLE = False

try:
    from core.synthesizer import encode_topological_invariants
    ENCODER_AVAILABLE = True
except ImportError:
    try:
        from invariant_encoder import encode_topological_invariants
        ENCODER_AVAILABLE = True
    except ImportError:
        ENCODER_AVAILABLE = False

try:
    from core.synthesizer import establish_baseline, steer_decoder
    STEERING_AVAILABLE = True
except ImportError:
    try:
        from decoder_steering import establish_baseline, steer_decoder
        STEERING_AVAILABLE = True
    except ImportError:
        STEERING_AVAILABLE = False

try:
    from memory.store import (
        store_memory, recall_memories, get_memory_stats,
        store_association, consolidate_memories,
    )
    from memory.graph import build_memory_graph
    from memory.analyzers import run_memory_analyzers
    MEMORY_AVAILABLE = True
except ImportError:
    try:
        from memory_store import (
            store_memory, recall_memories, get_memory_stats,
            store_association, consolidate_memories,
        )
        from memory_graph import build_memory_graph
        from memory_analyzers import run_memory_analyzers
        MEMORY_AVAILABLE = True
    except ImportError:
        MEMORY_AVAILABLE = False

try:
    from memory.store import (
        clear_memory_recall_cache,
        get_memory_recall_cache_status,
        refresh_memory_recall_cache,
    )
    MEMORY_RECALL_CACHE_AVAILABLE = True
except ImportError:
    try:
        from memory_store import (
            clear_memory_recall_cache,
            get_memory_recall_cache_status,
            refresh_memory_recall_cache,
        )
        MEMORY_RECALL_CACHE_AVAILABLE = True
    except ImportError:
        MEMORY_RECALL_CACHE_AVAILABLE = False

try:
    from memory.synthesizer import (
        compute_memory_fingerprint,
        establish_memory_baseline,
        load_memory_baseline,
        detect_memory_drift,
        generate_memory_steering_signals,
        assemble_memory_prompt_block,
    )
    MEMORY_SYNTH_AVAILABLE = True
except ImportError:
    try:
        from memory_synthesizer import (
            compute_memory_fingerprint,
            establish_memory_baseline,
            load_memory_baseline,
            detect_memory_drift,
            generate_memory_steering_signals,
            assemble_memory_prompt_block,
        )
        MEMORY_SYNTH_AVAILABLE = True
    except ImportError:
        MEMORY_SYNTH_AVAILABLE = False

try:
    from bridge.xanalyze import (
        filter_findings_for_memory,
        auto_store_findings,
        check_consolidation_trigger,
    )
    from bridge.xsteer import cross_domain_steer
    from bridge.xcontext import get_memory_context_for_file, get_memory_evidence
    CROSS_DOMAIN_AVAILABLE = True
except ImportError:
    try:
        from cross_domain_bridge import (
            filter_findings_for_memory,
            auto_store_findings,
            check_consolidation_trigger,
            cross_domain_steer,
            get_memory_context_for_file,
            get_memory_evidence,
        )
        CROSS_DOMAIN_AVAILABLE = True
    except ImportError:
        CROSS_DOMAIN_AVAILABLE = False

try:
    from memory.runtime import (
        MemoryStateError,
        configure_memory_runtime,
        memory_runtime_provenance,
    )
    MEMORY_RUNTIME_AVAILABLE = True
except ImportError:
    MEMORY_RUNTIME_AVAILABLE = False

    class MemoryStateError(RuntimeError):
        """Fallback exception type when the optional memory runtime is absent."""

        error_code = "memory_state_error"
        details: Dict[str, Any] = {}

try:
    from context.fibration import (
        init_fiber, lift_to_fiber, descend_from_fiber,
        start_section, add_to_section, get_section_status,
        fiber_status, switch_base,
        transport_from_archive, list_archived_fibers,
    )
    FIBRATION_AVAILABLE = True
except ImportError:
    try:
        from memory_fibration import (
            init_fiber, lift_to_fiber, descend_from_fiber,
            start_section, add_to_section, get_section_status,
            fiber_status, switch_base,
            transport_from_archive, list_archived_fibers,
        )
        FIBRATION_AVAILABLE = True
    except ImportError:
        FIBRATION_AVAILABLE = False

try:
    from memory.kan_extension import kan_retrieve
    KAN_EXTENSION_AVAILABLE = True
except ImportError:
    try:
        from memory_kan_extension import kan_retrieve
        KAN_EXTENSION_AVAILABLE = True
    except ImportError:
        KAN_EXTENSION_AVAILABLE = False


CODEBASE_SCHEMA_VERSION = "3.0.0-kernel"

# Usage lines for modes whose --help must answer instead of being swallowed
# as a positional (work: task, impact/outline/brief: file, memory/fiber:
# subcommand). Strings mirror the usage map in main()'s top-level help
# (work/impact/outline/brief) and the branches' own usage errors
# (memory/fiber). Only modes listed here answer --help; every other mode
# keeps its existing behavior.
_MODE_HELP_USAGE = {
    "work": "python3 hott_kernel.py work <task> [root] [--root DIR] [--target file[,file]] [--goal auto|understand|change|architecture|performance|runtime|history] [--depth auto|quick|standard|deep] [--frame-only] [--full-engine] [--full-engine-edges]",
    "impact": "python3 hott_kernel.py impact <file> [root] [--root DIR] [--output full|summary]",
    "outline": "python3 hott_kernel.py outline <file> [root] [--root DIR]",
    "brief": "python3 hott_kernel.py brief <file> [root] [--root DIR] [--output full|summary]",
    "cycle_break": "python3 hott_kernel.py cycle-break [root] [--root DIR] [--target FILE] [--output full|summary]",
    "memory": "python3 hott_kernel.py memory <status|stats|list|search|recall|store|get|associate|consolidate|compact|drift|establish|analyze|steer|bridge|bridge-candidates|bridge-auto|kan> [args]",
    "fiber": "python3 hott_kernel.py fiber <init|lift|descend|status|section_start|section_add|section_status|switch|transport|list_archives> [args]",
}
PUBLIC_KERNEL_MODES = (
    "work",
    "analyze",
    "analyzers",
    "cache",
    "impact",
    "outline",
    "brief",
    "cycle_break",
    "context",
    "establish",
    "synthesize",
    "steer",
    "memory_store",
    "memory_recall",
    "memory_analyze",
    "memory_stats",
    "memory_associate",
    "memory_consolidate",
    "memory_steer",
    "memory_establish",
    "memory_drift",
    "memory_compact",
    "memory_bridge",
    "memory_bridge_auto",
    "memory_bridge_candidates",
    "memory_kan",
    "memory",
    "fiber",
    "xanalyze",
    "xsteer",
    "xcontext",
)
_ACTIVE_GRAPH_CACHE_MODE = os.environ.get(
    "AI_STUDIO_GRAPH_CACHE",
    "auto",
).strip().lower()
_MEMORY_SCOPE_EXPLICIT = any(
    os.environ.get(name)
    for name in (
        "AI_STUDIO_PROJECT_ROOT",
        "AI_STUDIO_MEMORY_SCOPE",
    )
)


def _utc_timestamp() -> str:
    """Return an explicit UTC timestamp without deprecated naive datetime APIs."""
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


def _kernel_error(error_code: str, message: str, **details: Any) -> Dict[str, Any]:
    """Build a stable machine-readable error payload for CLI and API callers."""
    return {
        "schema_version": CODEBASE_SCHEMA_VERSION,
        "error": message,
        "error_code": error_code,
        **details,
    }


def _infer_project_root(scan_root: str) -> str:
    """Infer the nearest project boundary without coupling to Angular names."""
    scan_path = os.path.abspath(scan_root)
    candidate = scan_path if os.path.isdir(scan_path) else os.path.dirname(scan_path)
    markers = ("package.json", "tsconfig.json", "pyproject.toml", ".git")
    current = candidate
    for _ in range(6):
        if any(os.path.exists(os.path.join(current, marker)) for marker in markers):
            return current
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent
    if os.path.basename(candidate).lower() in ("src", "source"):
        return os.path.dirname(candidate)
    return candidate


def _bind_memory_scope_to_scan(scan_root: str) -> None:
    """Keep scan-backed memory isolated even when the CLI runs outside a project."""
    if not MEMORY_RUNTIME_AVAILABLE or _MEMORY_SCOPE_EXPLICIT:
        return
    configure_memory_runtime(project_root=_infer_project_root(scan_root))


def _validate_scan_root(scan_root: str) -> Optional[Dict[str, Any]]:
    if not os.path.exists(scan_root):
        return _kernel_error(
            "scan_root_not_found",
            f"Scan root does not exist: {scan_root}",
            scan_root=scan_root,
        )
    if not os.path.isdir(scan_root):
        return _kernel_error(
            "scan_root_not_directory",
            f"Scan root is not a directory: {scan_root}",
            scan_root=scan_root,
        )
    return None


def _validate_output_mode(
    output_mode: str,
    allowed: tuple[str, ...],
) -> Optional[Dict[str, Any]]:
    if output_mode in allowed:
        return None
    return _kernel_error(
        "invalid_output_mode",
        f"Invalid output mode: {output_mode}",
        output_mode=output_mode,
        supported_output_modes=list(allowed),
    )


def _set_graph_cache_mode(mode: str) -> Optional[Dict[str, Any]]:
    """Validate and activate one cache policy for this kernel process."""
    global _ACTIVE_GRAPH_CACHE_MODE
    normalized = str(mode).strip().lower()
    if normalized not in CACHE_MODES:
        return _kernel_error(
            "invalid_graph_cache_mode",
            f"Invalid graph cache mode: {mode}",
            cache_mode=mode,
            supported_cache_modes=list(CACHE_MODES),
        )
    _ACTIVE_GRAPH_CACHE_MODE = normalized
    return None


def _build_kernel_graph(scan_root: str) -> Dict[str, Any]:
    """Build the canonical graph using the active cross-invocation cache policy."""
    if GRAPH_CACHE_AVAILABLE:
        return build_cached_shared_graph(
            scan_root,
            mode=_ACTIVE_GRAPH_CACHE_MODE,
        )
    graph = build_shared_graph(scan_root)
    graph["cache"] = {
        "mode": "off",
        "status": "unavailable",
        "files_discovered": graph.get("summary", {}).get("total_files", 0),
        "files_reused": 0,
        "files_read": graph.get("summary", {}).get("total_files", 0),
        "hit_ratio": 0.0,
    }
    return graph


def _topology_engine_unavailable(
    reason: str,
    *,
    full_engine_edges: bool = False,
) -> Dict[str, Any]:
    """Explicit no-engine layer for the topology path. Never raises."""
    schema_version = (
        "plw-topology-engine-v1"
        if full_engine_edges
        else "plw-topology-engine-v2"
    )
    return {
        "schema_version": schema_version,
        "available": False,
        "engine": None,
        "reason": str(reason),
        "error": None,
        "symbol_nodes": [],
        "symbol_edges": [],
        "engine_file_edges": [],
        "coverage": {
            "languages": [],
            "engine_language_files": 0,
            "target_files": 0,
            "symbol_nodes": 0,
            "symbol_edges": 0,
            "scope": "target-grounded",
            "symbols_total": 0,
            "symbols_filtered_common": 0,
            "budget": None,
            "truncated": False,
            "window_hits_dropped": 0,
            "generated_files_excluded": 0,
            "self_edges_excluded": 0,
            "high_caller_suppressed": [],
            "batch_mode": None,
            "cache_status": "miss",
            "symbols_queried": [],
            "symbols_without_definition": [],
            "symbols_failed": [],
        },
        "authority_note": (
            "codesearch --callers/--related is name-based (trailing identifier), "
            "not type-resolved. Rows are leads: read the cited file before treating "
            "a call or relation as proven. Topology is not causality; candidate is not patch."
        ),
    }


def _build_topology_engine_layer(
    scan_root: str,
    graph: Dict[str, Any],
    target_files: Optional[List[str]] = None,
    *,
    max_symbols: Optional[int] = None,
    full_engine: bool = False,
    full_engine_edges: bool = False,
    seed_terms: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    """Best-effort engine symbol layer for topology/impact. Never raises.

    The layer is built outside the cached SharedGraph and merged at
    projection time, so a missing or failing engine can never break
    topology, orient, or impact.
    """
    try:
        from core.topology_engine import build_engine_layer
    except ImportError as exc:
        return _topology_engine_unavailable(
            f"topology engine module unavailable: {exc}",
            full_engine_edges=full_engine_edges,
        )
    try:
        return build_engine_layer(
            scan_root,
            graph,
            target_files=target_files,
            max_symbols=max_symbols,
            full_engine=full_engine,
            full_engine_edges=full_engine_edges,
            cache_mode=_ACTIVE_GRAPH_CACHE_MODE,
            seed_terms=seed_terms,
        )
    except Exception as exc:
        return _topology_engine_unavailable(
            f"topology engine layer failed: {exc}",
            full_engine_edges=full_engine_edges,
        )


def _resolve_engine_target_files(
    scan_root: str,
    graph: Dict[str, Any],
    *,
    explicit_targets: List[str],
    target_resolution: Dict[str, Any],
    full_engine: bool,
) -> Optional[List[str]]:
    """Derive target-grounded engine scope (1-hop neighborhood) for kernel_work.

    Guardrail #2: when target_resolution resolves one or more graph targets
    without full_engine, scope the engine to resolved_targets union
    direct_imports union direct_importers so blast-radius leads remain intact
    while keeping large repositories fast.
    """
    if full_engine:
        return None
    resolution = (target_resolution or {}).get("resolution") or {}
    state = str(resolution.get("state") or "")
    selected = [str(item) for item in (resolution.get("selected_targets") or []) if item]
    if state in ("RESOLVED", "MULTI_TARGET_RESOLVED") and selected:
        try:
            from core.topology_engine import _canon_rel
        except ImportError:
            _canon_rel = lambda p, _r: str(p).replace("\\", "/")
        root_abs = os.path.abspath(scan_root or ".").replace("\\", "/")
        seed_scope = {_canon_rel(item, root_abs) for item in selected}
        for item in explicit_targets:
            if str(item).strip():
                seed_scope.add(_canon_rel(str(item), root_abs))
        one_hop = set(seed_scope)
        for edge in (graph.get("edges") or []):
            if not isinstance(edge, (list, tuple)) or len(edge) != 2:
                continue
            src = _canon_rel(str(edge[0]), root_abs)
            dst = _canon_rel(str(edge[1]), root_abs)
            if src in seed_scope:
                one_hop.add(dst)
            if dst in seed_scope:
                one_hop.add(src)
        return sorted(one_hop)
    if explicit_targets:
        return sorted({str(item) for item in explicit_targets if str(item).strip()}) or None
    return None


def _engine_lead_impact_for(
    scan_root: str,
    graph: Dict[str, Any],
    target_file: str,
) -> Dict[str, Any]:
    """Impact via engine file edges only, separate from import impact."""
    layer = _build_topology_engine_layer(scan_root, graph, target_files=[target_file])
    try:
        from core.topology_engine import engine_lead_impact
    except ImportError as exc:
        return {
            "target": str(target_file),
            "exists_in_engine_layer": False,
            "upstream": [],
            "downstream": [],
            "upstream_count": 0,
            "downstream_count": 0,
            "authority": "lead-name-based",
            "note": f"engine lead impact unavailable: {exc}",
        }
    try:
        return engine_lead_impact(layer, target_file, scan_root=scan_root)
    except Exception as exc:
        return {
            "target": str(target_file),
            "exists_in_engine_layer": False,
            "upstream": [],
            "downstream": [],
            "upstream_count": 0,
            "downstream_count": 0,
            "authority": "lead-name-based",
            "note": f"engine lead impact failed: {exc}",
        }


def _run_kernel_analyzers(
    graph: Dict[str, Any],
    analyzer_names: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Run analyzers under the same cache policy as the canonical graph."""
    if not REGISTRY_AVAILABLE:
        return {
            "analyzers_run": [],
            "analyzers_succeeded": [],
            "analyzers_failed": 0,
            "errors": {},
            "results": {},
            "cache": {
                "mode": "off",
                "status": "unavailable",
                "analyzers_requested": analyzer_names or [],
                "analyzers_reused": [],
                "analyzers_executed": [],
                "reused_count": 0,
                "executed_count": 0,
                "hit_ratio": 0.0,
            },
        }
    if ANALYZER_CACHE_AVAILABLE:
        return run_cached_analyzers(
            graph,
            analyzer_names,
            mode=_ACTIVE_GRAPH_CACHE_MODE,
        )

    output = run_analyzers(graph, analyzer_names)
    executed = list(output.get("analyzers_run", []))
    output["cache"] = {
        "mode": "off",
        "status": "unavailable",
        "analyzers_requested": executed,
        "analyzers_reused": [],
        "analyzers_executed": executed,
        "reused_count": 0,
        "executed_count": len(executed),
        "hit_ratio": 0.0,
    }
    return output


def kernel_cache(action: str, scan_root: str = ".") -> Dict[str, Any]:
    """Manage source, analyzer, and scoped memory-recall derived caches."""
    if not GRAPH_CACHE_AVAILABLE:
        return _kernel_error(
            "graph_cache_unavailable",
            "persistent graph cache module is not available",
        )
    if action not in ("status", "refresh", "clear"):
        return _kernel_error(
            "invalid_cache_action",
            f"Invalid cache action: {action}",
            action=action,
            supported_actions=["status", "refresh", "clear"],
        )
    if action != "clear":
        root_error = _validate_scan_root(scan_root)
        if root_error:
            return root_error
    _bind_memory_scope_to_scan(scan_root)
    if action == "status":
        cache_result = get_graph_cache_status(scan_root)
        if ANALYZER_CACHE_AVAILABLE:
            analyzer_cache_result = get_analyzer_cache_status(
                cache_result.get("cache_key", ""),
                cache_result.get("graph_content_signature"),
            )
            source_status = cache_result.get("status")
            if (
                source_status != "valid"
                and analyzer_cache_result.get("status") not in ("missing", "corrupt")
            ):
                stale_reasons = list(analyzer_cache_result.get("stale_reasons", []))
                reason = f"source_snapshot_{source_status}"
                if reason not in stale_reasons:
                    stale_reasons.append(reason)
                analyzer_cache_result.update({
                    "status": "stale",
                    "stale_reasons": stale_reasons,
                })
            cache_result["analyzer_cache"] = analyzer_cache_result
        else:
            cache_result["analyzer_cache"] = {"status": "unavailable"}
        cache_result["memory_recall_cache"] = (
            get_memory_recall_cache_status()
            if MEMORY_RECALL_CACHE_AVAILABLE
            else {"status": "unavailable"}
        )
    elif action == "clear":
        cache_result = clear_graph_cache(scan_root)
        if cache_result.get("status") == "clear_failed":
            return _kernel_error(
                "graph_cache_clear_failed",
                "persistent graph cache entry could not be removed",
                scan_root=scan_root,
                cache=cache_result,
            )
        if ANALYZER_CACHE_AVAILABLE:
            analyzer_cache_result = clear_analyzer_cache(
                cache_result.get("cache_key", ""),
            )
            cache_result["analyzer_cache"] = analyzer_cache_result
            if analyzer_cache_result.get("status") == "clear_failed":
                return _kernel_error(
                    "analyzer_cache_clear_failed",
                    "persistent analyzer cache entry could not be removed",
                    scan_root=scan_root,
                    cache=cache_result,
                )
        else:
            cache_result["analyzer_cache"] = {"status": "unavailable"}
        memory_cache_result = (
            clear_memory_recall_cache()
            if MEMORY_RECALL_CACHE_AVAILABLE
            else {"status": "unavailable"}
        )
        cache_result["memory_recall_cache"] = memory_cache_result
        if memory_cache_result.get("status") == "clear_failed":
            return _kernel_error(
                "memory_recall_cache_clear_failed",
                "derived memory recall cache could not be removed",
                scan_root=scan_root,
                cache=cache_result,
            )
    else:
        graph = build_cached_shared_graph(scan_root, mode="refresh")
        analyzer_output = (
            run_cached_analyzers(graph, mode="refresh")
            if ANALYZER_CACHE_AVAILABLE and REGISTRY_AVAILABLE
            else _run_kernel_analyzers(graph)
        )
        cache_result = graph.get("cache", {})
        cache_result = {
            **cache_result,
            "analyzer_cache": analyzer_output.get("cache", {}),
            "memory_recall_cache": (
                refresh_memory_recall_cache()
                if MEMORY_RECALL_CACHE_AVAILABLE
                else {"status": "unavailable"}
            ),
            "graph_summary": graph.get("summary", {}),
        }
        if cache_result["memory_recall_cache"].get("status") == "write_failed":
            return _kernel_error(
                "memory_recall_cache_refresh_failed",
                "derived memory recall cache could not be refreshed",
                scan_root=scan_root,
                cache=cache_result,
            )
    return {
        "schema_version": CODEBASE_SCHEMA_VERSION,
        "mode": "cache",
        "action": action,
        "scan_root": scan_root,
        "cache": cache_result,
    }


def _analysis_status(total_files: int, analyzers_failed: int = 0) -> Dict[str, Any]:
    """Describe whether a supported TS/JS analysis domain was discovered."""
    if total_files <= 0:
        state = "empty"
    elif analyzers_failed > 0:
        state = "partial"
    else:
        state = "complete"
    status = {
        "analysis_status": state,
        "supported_source_extensions": list(SOURCE_EXTENSIONS),
    }
    if total_files == 0:
        status["analysis_warning"] = (
            "No supported TypeScript/JavaScript source files were found in scan_root."
        )
    return status


def _emit_cli_result(result: Dict[str, Any]) -> None:
    """Print one JSON result and expose a reliable status to Bash callers."""
    print(json.dumps(result, indent=2))
    if result.get("error"):
        raise SystemExit(2)
    if result.get("unified_summary", {}).get("analyzers_failed", 0) > 0:
        raise SystemExit(3)


def _exception_result(exc: Exception) -> Dict[str, Any]:
    """Preserve typed durable-state failures for the top-level CLI boundary."""
    if isinstance(exc, MemoryStateError):
        raise exc
    error_code = getattr(exc, "error_code", None)
    if error_code:
        return _kernel_error(
            str(error_code),
            str(exc),
            **getattr(exc, "details", {}),
        )
    return {"error": str(exc)}


def kernel_memory_store(
    memory_type: str,
    content: str,
    source: str = "manual",
    importance: float = 0.5,
    tags: Optional[str] = None,
) -> Dict[str, Any]:
    """Simpan memori baru."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}

    tag_list = [t.strip() for t in tags.split(",")] if tags else []

    try:
        memory = store_memory(
            memory_type=memory_type,
            content=content,
            source=source,
            importance=importance,
            tags=tag_list,
        )
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_store",
            "status": "stored",
            "memory": memory,
            "memory_scope": memory_runtime_provenance() if MEMORY_RUNTIME_AVAILABLE else {},
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_get(memory_id: str) -> Dict[str, Any]:
    """Recover one exact canonical memory record by ID for evidence-debt settlement."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}
    try:
        try:
            from memory.store import get_memory
        except ImportError:
            from memory_store import get_memory
        memory = get_memory(memory_id)
        if memory is None:
            return _kernel_error(
                "memory_not_found",
                f"Memory not found: {memory_id}",
                memory_id=memory_id,
            )
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_get",
            "memory": memory,
            "memory_scope": memory_runtime_provenance() if MEMORY_RUNTIME_AVAILABLE else {},
            "authority": "historical_or_procedural_memory; verify current-source claims against source",
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_recall(
    query: Optional[str] = None,
    memory_type: Optional[str] = None,
    tags: Optional[str] = None,
    limit: int = 20,
) -> Dict[str, Any]:
    """Recall memori berdasarkan filter."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}

    tag_list = [t.strip() for t in tags.split(",")] if tags else None

    results = recall_memories(
        query=query,
        memory_type=memory_type,
        tags=tag_list,
        limit=limit,
        cache_mode=_ACTIVE_GRAPH_CACHE_MODE,
    )

    return {
        "schema_version": "4.1.0-memory",
        "mode": "memory_recall",
        "query": query,
        "memory_type": memory_type,
        "results": results,
        "count": len(results),
        "memory_scope": memory_runtime_provenance() if MEMORY_RUNTIME_AVAILABLE else {},
    }


def kernel_memory_analyze(
    analyzer_names: Optional[List[str]] = None,
    output_mode: str = "full",
    include_historical: bool = False,
    include_provenance: bool = False,
) -> Dict[str, Any]:
    """Analisis topologi memori."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}

    memory_graph = build_memory_graph(
        include_historical=include_historical,
        include_provenance=include_provenance,
    )
    analyzer_output = run_memory_analyzers(memory_graph, analyzer_names)

    total_findings = sum(
        len(r.get("findings", []))
        for r in analyzer_output.get("results", {}).values()
    )
    severity_counts = {"high": 0, "medium": 0, "low": 0}
    for r in analyzer_output.get("results", {}).values():
        for f in r.get("findings", []):
            sev = f.get("severity", "low")
            if sev in severity_counts:
                severity_counts[sev] += 1

    total_memories = memory_graph["summary"]["total_memories"]
    weighted_sum = (
        severity_counts["high"] * 3
        + severity_counts["medium"] * 2
        + severity_counts["low"] * 1
    )
    pressure = weighted_sum / max(1, total_memories)
    health_score = round(1.0 / (1.0 + pressure), 3)
    health_model = {
        "name": "severity_weighted_structural_pressure_v1",
        "formula": "1 / (1 + weighted_finding_count / max(1, current_vertices))",
        "weighted_finding_count": weighted_sum,
        "structural_pressure": round(pressure, 6),
        "not_correctness_or_truth_score": True,
        "healthy_fragmentation_possible": True,
        "bridge_requires_relation_witness": True,
    }
    betti_breakdown = analyzer_output.get("results", {}).get(
        "mem.betti_breakdown", {}
    )
    betti_data = betti_breakdown.get("betti_numbers", {})
    betti_numbers = {
        "beta_0": int(betti_data.get("beta_0", 0)),
        "beta_1": int(betti_data.get("beta_1_total", 0)),
        "beta_2": 0,
    }
    memory_archetype = analyzer_output.get("results", {}).get(
        "mem.manifold", {}
    ).get("summary", {}).get("memory_archetype", "unknown")
    circular_summary = analyzer_output.get("results", {}).get(
        "mem.circular", {}
    ).get("summary", {})
    cycle_semantics = {
        "beta_1_is_not_directed_cycle_count": True,
        "directed_reasoning_cycle_witness_count": (
            betti_breakdown.get("summary", {}).get(
                "directed_reasoning_cycle_witness_count", 0
            )
        ),
        "directed_cycle_witness_semantics": circular_summary.get(
            "directed_cycle_witness_semantics",
            "deduplicated DFS back-edge witnesses; not all elementary cycles",
        ),
    }

    if output_mode == "summary":
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_analyze",
            "topological_model": memory_graph.get("model", {}),
            "cycle_semantics": cycle_semantics,
            "betti_numbers": betti_numbers,
            "memory_archetype": memory_archetype,
            "memory_stats": memory_graph["summary"],
            "memory_health_score": health_score,
            "memory_health_model": health_model,
            "findings_by_severity": severity_counts,
            "total_findings": total_findings,
            "analyzers_run": analyzer_output["analyzers_run"],
            "analyzers_failed": analyzer_output.get("analyzers_failed", 0),
            "analyzer_errors": analyzer_output.get("errors", {}),
        }

    return {
        "schema_version": "4.1.0-memory",
        "mode": "memory_analyze",
        "topological_model": memory_graph.get("model", {}),
        "cycle_semantics": cycle_semantics,
        "betti_numbers": betti_numbers,
        "memory_archetype": memory_archetype,
        "memory_graph_summary": memory_graph["summary"],
        "analyzers": analyzer_output,
        "memory_health_score": health_score,
        "memory_health_model": health_model,
        "unified_summary": {
            "total_memories": total_memories,
            "total_associations": memory_graph["summary"]["total_associations"],
            "total_findings": total_findings,
            "findings_by_severity": severity_counts,
            "memory_health_score": health_score,
            "memory_health_model": health_model,
            "betti_numbers": betti_numbers,
            "memory_archetype": memory_archetype,
        },
    }


def kernel_memory_stats() -> Dict[str, Any]:
    """Statistik memory store."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}

    stats = get_memory_stats()
    return {
        "schema_version": "4.1.0-memory",
        "mode": "memory_stats",
        **stats,
    }


def kernel_memory_associate(
    from_id: str,
    to_id: str,
    assoc_type: str,
    strength: float = 0.5,
) -> Dict[str, Any]:
    """Buat asosiasi antara dua memori."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}

    try:
        assoc = store_association(
            from_id=from_id,
            to_id=to_id,
            assoc_type=assoc_type,
            strength=strength,
        )
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_associate",
            "status": "associated",
            "association": assoc,
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_consolidate(
    source_ids: List[str],
    content: str,
    tags: Optional[str] = None,
    importance: float = 0.9,
) -> Dict[str, Any]:
    """Konsolidasi memori (colimit operation)."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}

    tag_list = [t.strip() for t in tags.split(",")] if tags else []

    try:
        result = consolidate_memories(
            source_ids=source_ids,
            content=content,
            tags=tag_list,
            importance=importance,
        )
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_consolidate",
            "status": "consolidated",
            **result,
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_steer(output_mode: str = "full") -> Dict[str, Any]:
    """Memory steering: topology → reasoning strategy."""
    if not MEMORY_AVAILABLE or not MEMORY_SYNTH_AVAILABLE:
        return {"error": "memory modules not available"}

    # Build memory graph
    memory_graph = build_memory_graph()

    # Run manifold analyzer untuk Betti numbers
    from memory.analyzers import analyze_manifold
    manifold_result = analyze_manifold(memory_graph)
    manifold_data = manifold_result.get("manifold", {})

    # Compute health score
    from memory.analyzers import run_memory_analyzers
    analyzer_output = run_memory_analyzers(memory_graph)
    severity_counts = {"high": 0, "medium": 0, "low": 0}
    for r in analyzer_output.get("results", {}).values():
        for f in r.get("findings", []):
            sev = f.get("severity", "low")
            if sev in severity_counts:
                severity_counts[sev] += 1

    total_memories = memory_graph["summary"]["total_memories"]
    weighted_sum = (
        severity_counts["high"] * 3
        + severity_counts["medium"] * 2
        + severity_counts["low"] * 1
    )
    pressure = weighted_sum / max(1, total_memories)
    health_score = round(1.0 / (1.0 + pressure), 3)

    # Compute fingerprint
    memory_stats = memory_graph["summary"]
    fingerprint = compute_memory_fingerprint(manifold_data, memory_stats)

    # Load baseline & detect drift
    baseline = load_memory_baseline()
    drift = detect_memory_drift(fingerprint, baseline)

    # Generate steering signals
    directed_reasoning_count = (
        analyzer_output.get("results", {})
        .get("mem.betti_breakdown", {})
        .get("summary", {})
        .get("directed_reasoning_cycle_witness_count", 0)
    )
    signals = generate_memory_steering_signals(
        fingerprint,
        drift,
        health_score,
        directed_reasoning_cycle_witness_count=directed_reasoning_count,
    )

    # Assemble prompt block
    prompt_block = assemble_memory_prompt_block(fingerprint, drift, signals, health_score)

    if output_mode == "summary":
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_steer",
            "summary": {
                "has_baseline": drift.get("has_baseline", False),
                "drift_interpretation": drift.get("interpretation", "no_baseline"),
                "reasoning_strategy": signals["reasoning_strategy"],
                "reasoning_budget": signals["reasoning_budget"],
                "regrounding_needed": signals["regrounding_needed"],
                "health_score": health_score,
            },
            "steering_signals": signals,
        }

    return {
        "schema_version": "4.1.0-memory",
        "mode": "memory_steer",
        "fingerprint": fingerprint,
        "health_score": health_score,
        "drift_analysis": drift,
        "steering_signals": signals,
        "steering_prompt_block": prompt_block,
    }


def kernel_memory_establish() -> Dict[str, Any]:
    """Establish memory baseline."""
    if not MEMORY_AVAILABLE or not MEMORY_SYNTH_AVAILABLE:
        return {"error": "memory modules not available"}

    # Build graph & compute fingerprint
    memory_graph = build_memory_graph()
    from memory.analyzers import analyze_manifold, run_memory_analyzers
    manifold_result = analyze_manifold(memory_graph)
    manifold_data = manifold_result.get("manifold", {})

    # Compute health score
    analyzer_output = run_memory_analyzers(memory_graph)
    severity_counts = {"high": 0, "medium": 0, "low": 0}
    for r in analyzer_output.get("results", {}).values():
        for f in r.get("findings", []):
            sev = f.get("severity", "low")
            if sev in severity_counts:
                severity_counts[sev] += 1

    total_memories = memory_graph["summary"]["total_memories"]
    weighted_sum = (
        severity_counts["high"] * 3
        + severity_counts["medium"] * 2
        + severity_counts["low"] * 1
    )
    pressure = weighted_sum / max(1, total_memories)
    health_score = round(1.0 / (1.0 + pressure), 3)

    # Compute fingerprint
    fingerprint = compute_memory_fingerprint(manifold_data, memory_graph["summary"])

    # Establish baseline
    result = establish_memory_baseline(fingerprint, health_score)

    return {
        "schema_version": "4.1.0-memory",
        "mode": "memory_establish",
        **result,
    }


def kernel_memory_drift() -> Dict[str, Any]:
    """Detect memory drift against baseline."""
    if not MEMORY_AVAILABLE or not MEMORY_SYNTH_AVAILABLE:
        return {"error": "memory modules not available"}

    # Build graph & compute fingerprint
    memory_graph = build_memory_graph()
    from memory.analyzers import analyze_manifold
    manifold_result = analyze_manifold(memory_graph)
    manifold_data = manifold_result.get("manifold", {})

    fingerprint = compute_memory_fingerprint(manifold_data, memory_graph["summary"])

    # Load baseline & detect drift
    baseline = load_memory_baseline()
    drift = detect_memory_drift(fingerprint, baseline)

    return {
        "schema_version": "4.1.0-memory",
        "mode": "memory_drift",
        "fingerprint": fingerprint,
        "drift_analysis": drift,
    }


def kernel_memory_consolidate_by_tag(
    tag: str,
    content: Optional[str] = None,
    importance: float = 0.9,
) -> Dict[str, Any]:
    """Konsolidasi memori berdasarkan tag."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}
    try:
        from memory.store import consolidate_by_tag
        result = consolidate_by_tag(tag=tag, content=content, importance=importance)
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_consolidate_by_tag",
            **result,
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_consolidate_auto(
    min_group_size: int = 3,
    importance: float = 0.9,
) -> Dict[str, Any]:
    """Otomatis konsolidasi semua tag groups yang memenuhi threshold."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}
    try:
        from memory.store import consolidate_by_tag_auto
        result = consolidate_by_tag_auto(
            min_group_size=min_group_size,
            importance=importance,
        )
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_consolidate_auto",
            **result,
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_unconsolidated_tags() -> Dict[str, Any]:
    """Lihat ringkasan unconsolidated memories by tag."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}
    try:
        from memory.store import get_unconsolidated_by_tag
        result = get_unconsolidated_by_tag()
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_unconsolidated_tags",
            **result,
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_betti_breakdown() -> Dict[str, Any]:
    """Hitung β₁ breakdown per kategori edge type."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}
    try:
        from memory.graph import build_memory_graph
        from memory.analyzers import analyze_betti_breakdown
        memory_graph = build_memory_graph()
        result = analyze_betti_breakdown(memory_graph)
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_betti_breakdown",
            **result,
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_compact(
    only_consolidated: bool = True,
    memory_type: str = "episodic",
    dry_run: bool = False,
    restore: bool = False,
    restore_all: bool = False,
    restore_id: Optional[str] = None,
    stats: bool = False,
) -> Dict[str, Any]:
    """Memory compact: quotient forgetting untuk archived memories."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}

    try:
        from memory.store import (
            compact_memories, get_archive_stats,
            restore_memory, restore_all_archived,
        )
        from memory.graph import build_memory_graph
        from memory.analyzers import analyze_manifold
    except ImportError as exc:
        return {"error": f"import failed: {exc}"}

    # Mode: stats
    if stats:
        archive_stats = get_archive_stats()
        # Hitung Betti untuk active graph
        active_graph = build_memory_graph(include_archived=False)
        active_manifold = analyze_manifold(active_graph)
        # Hitung Betti untuk full graph (termasuk archived)
        full_graph = build_memory_graph(include_archived=True)
        full_manifold = analyze_manifold(full_graph)

        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_compact_stats",
            "archive_stats": archive_stats,
            "active_graph_betti": active_manifold["manifold"]["betti_numbers"],
            "full_graph_betti": full_manifold["manifold"]["betti_numbers"],
        }

    # Mode: restore
    if restore_all:
        result = restore_all_archived()
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_compact_restore",
            **result,
        }

    if restore_id:
        result = restore_memory(restore_id)
        if result is None:
            return {"error": f"Memory not found: {restore_id}"}
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_compact_restore",
            "restored": result,
        }

    # Mode: compact (dengan Betti impact analysis)
    # Hitung Betti SEBELUM compact
    graph_before = build_memory_graph(include_archived=False)
    manifold_before = analyze_manifold(graph_before)
    betti_before = manifold_before["manifold"]["betti_numbers"]

    # Execute compact
    compact_result = compact_memories(
        only_consolidated=only_consolidated,
        memory_type=memory_type,
        dry_run=dry_run,
    )

    if dry_run:
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_compact",
            **compact_result,
            "betti_before": betti_before,
        }

    # Hitung Betti SESUDAH compact
    graph_after = build_memory_graph(include_archived=False)
    manifold_after = analyze_manifold(graph_after)
    betti_after = manifold_after["manifold"]["betti_numbers"]

    # Hitung Betti impact
    betti_impact = {
        "beta_0": {"before": betti_before["beta_0"], "after": betti_after["beta_0"],
                    "delta": betti_after["beta_0"] - betti_before["beta_0"]},
        "beta_1": {"before": betti_before["beta_1"], "after": betti_after["beta_1"],
                    "delta": betti_after["beta_1"] - betti_before["beta_1"]},
        "beta_2": {"before": betti_before["beta_2"], "after": betti_after["beta_2"],
                    "delta": betti_after["beta_2"] - betti_before["beta_2"]},
    }

    return {
        "schema_version": "4.1.0-memory",
        "mode": "memory_compact",
        **compact_result,
        "betti_before": betti_before,
        "betti_after": betti_after,
        "betti_impact": betti_impact,
    }


def kernel_memory_bridge(
    from_id: str,
    to_id: str,
    assoc_type: str = "semantic",
    strength: float = 0.7,
    safe_mode: bool = True,
) -> Dict[str, Any]:
    """Manual bridge antara dua memories."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}
    try:
        from memory.store import bridge_memories
        result = bridge_memories(
            from_id=from_id,
            to_id=to_id,
            assoc_type=assoc_type,
            strength=strength,
            safe_mode=safe_mode,
        )
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_bridge",
            **result,
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_bridge_auto(
    min_shared_tags: int = 1,
    assoc_type: str = "semantic",
    safe_mode: bool = True,
    dry_run: bool = False,
) -> Dict[str, Any]:
    """Auto bridge: hubungkan semantic memories yang share tags."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}
    try:
        from memory.store import bridge_auto
        result = bridge_auto(
            min_shared_tags=min_shared_tags,
            assoc_type=assoc_type,
            safe_mode=safe_mode,
            dry_run=dry_run,
        )
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_bridge_auto",
            **result,
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_bridge_candidates(
    min_shared_tags: int = 1,
) -> Dict[str, Any]:
    """Lihat kandidat bridge sebelum eksekusi."""
    if not MEMORY_AVAILABLE:
        return {"error": "memory modules not available"}
    try:
        from memory.store import get_bridge_candidates
        result = get_bridge_candidates(min_shared_tags=min_shared_tags)
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_bridge_candidates",
            **result,
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_memory_kan(
    query: str,
    mode: str = "both",
    max_depth: int = 2,
) -> Dict[str, Any]:
    """Kan Extension retrieval: structured completion."""
    if not KAN_EXTENSION_AVAILABLE:
        return {"error": "memory_kan_extension not available"}

    try:
        result = kan_retrieve(query, mode=mode, max_depth=max_depth)
        return {
            "schema_version": "4.1.0-memory",
            "mode": "memory_kan",
            **result,
        }
    except Exception as exc:
        return _exception_result(exc)


def kernel_xanalyze(
    scan_root: str = ".",
    analyzer_names: Optional[List[str]] = None,
    output_mode: str = "summary",
    auto_store: bool = True,
) -> Dict[str, Any]:
    """
    Cross-Domain Analyze: analisis codebase + auto-store findings ke memory.
    """
    if not SHARED_GRAPH_AVAILABLE or not REGISTRY_AVAILABLE:
        return {"error": "required modules not available"}

    _bind_memory_scope_to_scan(scan_root)

    # Step 1: Build graph + run analyzers
    graph = _build_kernel_graph(scan_root)
    analyzer_output = _run_kernel_analyzers(graph, analyzer_names)
    analyzer_results = analyzer_output.get("results", {})

    # Step 2: Synthesize (untuk correlations & fingerprint)
    total_files = graph.get("summary", {}).get("total_files", 0)
    health_score = _compute_topological_health_score(analyzer_output, total_files)
    correlations = _detect_cross_analyzer_correlations(graph, analyzer_output)
    fingerprint = {}
    if ENCODER_AVAILABLE:
        enc_res = encode_topological_invariants(
            scan_root,
            shared_graph=graph,
            analyzer_output=analyzer_output,
        )
        if enc_res.get("available"):
            fingerprint = enc_res.get("topological_fingerprint", {})
    if not fingerprint and "hott.manifold" in analyzer_results:
        manifold_data = analyzer_results["hott.manifold"].get("manifold", {})
        fingerprint = {
            "signature_hash": "sha256:unknown",
            "complexity_score": manifold_data.get("complexity_score", 0.0),
            "structural_archetype": manifold_data.get("structural_archetype", "unknown"),
        }

    # Step 3: Selective filter + auto-store
    store_result = {"stored_count": 0, "skipped": True}
    if auto_store and CROSS_DOMAIN_AVAILABLE:
        storeable = filter_findings_for_memory(analyzer_results, correlations)
        full_graph_signature = graph.get("cache", {}).get(
            "graph_content_signature"
        )
        if not full_graph_signature and graph_content_signature is not None:
            full_graph_signature = graph_content_signature(graph)
        file_content_hashes = {
            path: f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}"
            for path, content in graph.get("file_map", {}).items()
        }
        store_result = auto_store_findings(
            storeable,
            scan_root,
            evidence_signature=fingerprint.get("signature_hash"),
            graph_content_signature=full_graph_signature,
            active_files=graph.get("vertices", []),
            file_content_hashes=file_content_hashes,
            analyzers_observed=analyzer_output.get(
                "analyzers_succeeded", analyzer_results.keys()
            ),
            analyzers_failed=analyzer_output.get("errors", {}).keys(),
        )

    # Step 4: Check consolidation trigger
    consolidation_signal = {"trigger": False}
    reconciled_activity = sum(
        int(store_result.get(key, 0))
        for key in (
            "stored_count", "reused_count", "revised_count",
            "resolved_count", "orphaned_count", "stale_count",
        )
    )
    if CROSS_DOMAIN_AVAILABLE and reconciled_activity > 0:
        consolidation_signal = check_consolidation_trigger()

    # Step 5: Format output
    total_findings = sum(
        len(r.get("findings", [])) for r in analyzer_results.values()
    )
    severity_counts = {"high": 0, "medium": 0, "low": 0, "info": 0}
    for r in analyzer_results.values():
        for f in r.get("findings", []):
            sev = f.get("severity", "info")
            if sev in severity_counts:
                severity_counts[sev] += 1

    if output_mode == "summary":
        return {
            "schema_version": "4.1.0-memory",
            "mode": "xanalyze",
            "scan_root": scan_root,
            "graph_cache": graph.get("cache", {}),
            "analyzer_cache": analyzer_output.get("cache", {}),
            "analysis_summary": {
                "total_findings": total_findings,
                "findings_by_severity": severity_counts,
                "correlation_count": len(correlations),
                "health_score": health_score,
                "archetype": fingerprint.get("structural_archetype", "unknown"),
            },
            "memory_store_result": store_result,
            "consolidation_signal": {
                "consolidation_candidate": consolidation_signal.get("trigger", False),
                "reasons": consolidation_signal.get("reasons", []),
            },
        }

    return {
        "schema_version": "4.1.0-memory",
        "mode": "xanalyze",
        "scan_root": scan_root,
        "graph_cache": graph.get("cache", {}),
        "analyzer_cache": analyzer_output.get("cache", {}),
        "analyzers": analyzer_output,
        "synthesis": {
            "fingerprint": fingerprint,
            "topological_health_score": health_score,
            "correlations": correlations,
        },
        "memory_store_result": store_result,
        "consolidation_signal": consolidation_signal,
    }


def kernel_xsteer(scan_root: str = ".", output_mode: str = "full") -> Dict[str, Any]:
    """Cross-Domain Steer: unified codebase + memory steering."""
    if not CROSS_DOMAIN_AVAILABLE:
        return {"error": "cross_domain_bridge not available"}

    _bind_memory_scope_to_scan(scan_root)

    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    graph = _build_kernel_graph(scan_root)
    structural = get_structural_analyzers() if REGISTRY_AVAILABLE else None
    analyzer_output = _run_kernel_analyzers(graph, structural)
    result = cross_domain_steer(
        scan_root,
        shared_graph=graph,
        analyzer_output=analyzer_output,
    )

    if output_mode == "summary":
        return {
            "schema_version": "4.1.0-memory",
            "mode": "xsteer",
            "graph_cache": graph.get("cache", {}),
            "analyzer_cache": analyzer_output.get("cache", {}),
            "codebase": result.get("codebase_steering", {}),
            "memory": result.get("memory_steering", {}),
            "memory_scope": result.get("memory_scope", {}),
            "consolidation_candidate": result.get("consolidation_signal", {}).get("consolidation_candidate", False),
        }

    return result


def kernel_xcontext(file_path: str) -> Dict[str, Any]:
    """Cross-Domain Context: recall relevant memories untuk file."""
    if not CROSS_DOMAIN_AVAILABLE:
        return {"error": "cross_domain_bridge not available"}

    return get_memory_context_for_file(file_path)


def kernel_fiber(subcommand: str, args: List[str]) -> Dict[str, Any]:
    """Router untuk fiber operations."""
    if not FIBRATION_AVAILABLE:
        return {"error": "memory_fibration not available"}

    if subcommand == "init":
        task = args[0] if len(args) > 0 else "general"
        focus = args[1] if len(args) > 1 else "general"
        return {"schema_version": "4.1.0-memory", "mode": "fiber_init", **init_fiber(task, focus)}

    elif subcommand == "lift":
        query = None
        mem_type = None
        tags = None
        max_lift = 10
        i = 0
        while i < len(args):
            if args[i] == "--query" and i + 1 < len(args):
                query = args[i + 1]
                i += 2
            elif args[i] == "--type" and i + 1 < len(args):
                mem_type = args[i + 1]
                i += 2
            elif args[i] == "--tags" and i + 1 < len(args):
                tags = args[i + 1].split(",")
                i += 2
            elif args[i] == "--max" and i + 1 < len(args):
                try:
                    max_lift = int(args[i + 1])
                except ValueError:
                    pass
                i += 2
            else:
                i += 1
        result = lift_to_fiber(query=query, memory_type=mem_type, tags=tags, max_lift=max_lift)
        return {"schema_version": "4.1.0-memory", "mode": "fiber_lift", **result}

    elif subcommand == "descend":
        memory_id = args[0] if args and not args[0].startswith("--") else None
        descend_all = "--all" in args
        reason = "task_completed"
        for i, arg in enumerate(args):
            if arg == "--reason" and i + 1 < len(args):
                reason = args[i + 1]
        result = descend_from_fiber(memory_id=memory_id, descend_all=descend_all, reason=reason)
        return {"schema_version": "4.1.0-memory", "mode": "fiber_descend", **result}

    elif subcommand == "status":
        return {"schema_version": "4.1.0-memory", "mode": "fiber_status", **fiber_status()}

    elif subcommand == "section_start":
        name = args[0] if len(args) > 0 else "unnamed"
        narrative = args[1] if len(args) > 1 else ""
        result = start_section(name, narrative)
        return {"schema_version": "4.1.0-memory", "mode": "fiber_section_start", **result}

    elif subcommand == "section_add":
        if not args:
            return {"error": "Usage: fiber section_add <memory_id>"}
        result = add_to_section(args[0])
        return {"schema_version": "4.1.0-memory", "mode": "fiber_section_add", **result}

    elif subcommand == "section_status":
        return {"schema_version": "4.1.0-memory", "mode": "fiber_section_status", **get_section_status()}

    elif subcommand == "switch":
        task = args[0] if len(args) > 0 else "new_task"
        focus = args[1] if len(args) > 1 else "new_focus"
        result = switch_base(task, focus)
        return {"schema_version": "4.1.0-memory", "mode": "fiber_switch", **result}

    elif subcommand == "list_archives":
        return kernel_fiber_list_archives()

    elif subcommand == "transport":
        if len(args) < 3:
            return {"error": "Usage: fiber transport <source_fiber_id> <new_task> <new_focus> [--threshold 0.6] [--max 10] [--dry-run]"}
        source_id = args[0]
        new_task = args[1]
        new_focus = args[2]
        threshold = 0.6
        max_transport = 10
        dry_run = False
        i = 3
        while i < len(args):
            if args[i] == "--threshold" and i + 1 < len(args):
                try:
                    threshold = float(args[i + 1])
                except ValueError:
                    pass
                i += 2
            elif args[i] == "--max" and i + 1 < len(args):
                try:
                    max_transport = int(args[i + 1])
                except ValueError:
                    pass
                i += 2
            elif args[i] == "--dry-run":
                dry_run = True
                i += 1
            else:
                i += 1
        return kernel_fiber_transport(source_id, new_task, new_focus, threshold, max_transport, dry_run)

    else:
        return {"error": f"Unknown fiber subcommand: {subcommand}"}


def kernel_fiber_transport(
    source_fiber_id: str,
    new_task: str,
    new_focus: str,
    threshold: float = 0.6,
    max_transport: int = 10,
    dry_run: bool = False,
) -> Dict[str, Any]:
    """Parallel transport dari fiber lama ke fiber baru."""
    if not FIBRATION_AVAILABLE:
        return {"error": "memory_fibration not available"}
    
    try:
        result = transport_from_archive(
            source_fiber_id=source_fiber_id,
            new_task=new_task,
            new_focus=new_focus,
            threshold=threshold,
            max_transport=max_transport,
            dry_run=dry_run,
        )
        return {"schema_version": "4.1.0-memory", "mode": "fiber_transport", **result}
    except Exception as exc:
        return _exception_result(exc)


def kernel_fiber_list_archives() -> Dict[str, Any]:
    """List archived fibers."""
    if not FIBRATION_AVAILABLE:
        return {"error": "memory_fibration not available"}
    
    try:
        result = list_archived_fibers()
        return {"schema_version": "4.1.0-memory", "mode": "fiber_list_archives", **result}
    except Exception as exc:
        return _exception_result(exc)




def kernel_topology(
    scan_root: str = ".",
    *,
    top_n: int = 8,
    include_edges: bool = False,
    full_engine: bool = False,
    full_engine_edges: bool = False,
    cache_mode: Optional[str] = None,
    include_engine: bool = True,
) -> Dict[str, Any]:
    """Bounded first-contact topology orientation for an unfamiliar target repo."""
    if not SHARED_GRAPH_AVAILABLE or not TARGET_TOPOLOGY_AVAILABLE:
        return {"error": "target topology bootstrap is unavailable", "available": False}
    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    if isinstance(top_n, bool) or not isinstance(top_n, int) or not 1 <= top_n <= 50:
        return _kernel_error(
            "invalid_topology_limit",
            "Topology top_n must be an integer between 1 and 50.",
            top_n=top_n, minimum=1, maximum=50,
        )
    if cache_mode is not None:
        cache_err = _set_graph_cache_mode(cache_mode)
        if cache_err:
            return cache_err
    graph = _build_kernel_graph(scan_root)
    engine_layer = (
        _build_topology_engine_layer(
            scan_root,
            graph,
            full_engine=full_engine,
            full_engine_edges=full_engine_edges,
        )
        if include_engine
        else None
    )
    try:
        orientation = build_target_topology_orientation(
            graph, top_n=top_n, include_edges=include_edges, engine_layer=engine_layer
        )
    except ValueError as exc:
        return _kernel_error("invalid_topology_request", str(exc))
    return {
        "schema_version": "4.3.0-target-topology",
        "mode": "topology",
        "scan_root": scan_root,
        "graph_cache": graph.get("cache", {}),
        "target_orientation": orientation,
        "authority": {
            "read_only": True,
            "selects_PLW_capability": False,
            "mutate_source": False,
            "execute_runtime": False,
            "commit_truth": False,
        },
    }


def kernel_mermaid(
    scan_root: str = ".",
    *,
    depth: int = 1,
    focus: Optional[str] = None,
    direction: str = "LR",
    max_nodes: int = 24,
    include_tests: bool = False,
) -> Dict[str, Any]:
    """Generate a multi-depth Mermaid architecture & dependency diagram from SharedGraph."""
    if not SHARED_GRAPH_AVAILABLE or not TARGET_TOPOLOGY_AVAILABLE or not MERMAID_GRAPH_AVAILABLE:
        return {"error": "mermaid topology generator is unavailable", "available": False}
    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    return _generate_mermaid_diagram(
        scan_root,
        depth=depth,
        focus=focus,
        direction=direction,
        max_nodes=max_nodes,
        include_tests=include_tests,
        graph_builder=_build_kernel_graph,
        orientation_builder=build_target_topology_orientation,
        impact_querier=query_impact if TOPO_QUERIES_AVAILABLE else None,
        outline_querier=query_outline if TOPO_QUERIES_AVAILABLE else None,
        signature_fn=globals().get("graph_content_signature"),
        error_factory=_kernel_error,
    )




def kernel_resolve_target(
    scan_root: str,
    task: str,
    *,
    target_files: Optional[List[str]] = None,
    top_n: int = 8,
    neighborhood_limit: int = 8,
) -> Dict[str, Any]:
    """Resolve task-relevant graph nodes without selecting a PLW capability."""
    if not TARGET_RESOLUTION_AVAILABLE:
        return {"error": "target resolution is unavailable", "available": False}
    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    if not isinstance(task, str) or not task.strip():
        return _kernel_error("empty_target_resolution_task", "Target resolution requires a non-empty task.")
    try:
        graph = _build_kernel_graph(scan_root)
        resolution = build_target_resolution(
            graph, task, explicit_targets=target_files or None,
            top_n=top_n, neighborhood_limit=neighborhood_limit,
        )
    except (TypeError, ValueError) as exc:
        return _kernel_error("invalid_target_resolution_request", str(exc))
    return {
        "schema_version": "4.4.0-target-resolution",
        "mode": "resolve-target",
        "task": task,
        "scan_root": scan_root,
        "target_resolution": resolution,
        "authority": {
            "semantic_ownership_proven": False,
            "selects_PLW_capability": False,
            "execute_runtime": False,
            "mutate_source": False,
            "commit_truth": False,
        },
    }

def kernel_evidence_needs(
    scan_root: str,
    task: str,
    *,
    target_files: Optional[List[str]] = None,
    top_n: int = 8,
    neighborhood_limit: int = 8,
) -> Dict[str, Any]:
    """Derive target-grounded technical evidence needs without selecting a capability."""
    if not EVIDENCE_NEEDS_AVAILABLE or not TARGET_RESOLUTION_AVAILABLE:
        return {"error": "evidence-need derivation is unavailable", "available": False}
    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    if not isinstance(task, str) or not task.strip():
        return _kernel_error("empty_evidence_need_task", "Evidence-need derivation requires a non-empty task.")
    try:
        graph = _build_kernel_graph(scan_root)
        resolution = build_target_resolution(
            graph, task, explicit_targets=target_files or None,
            top_n=top_n, neighborhood_limit=neighborhood_limit,
        )
        derivation = build_evidence_need_derivation(graph, task, resolution)
    except (TypeError, ValueError) as exc:
        return _kernel_error("invalid_evidence_need_request", str(exc))
    return {
        "schema_version": "4.5.0-evidence-needs",
        "mode": "evidence-needs",
        "task": task,
        "scan_root": scan_root,
        "target_resolution": resolution,
        "evidence_need_derivation": derivation,
        "authority": derivation.get("authority", {}),
    }


def kernel_capability_match(
    scan_root: str,
    task: str,
    *,
    target_files: Optional[List[str]] = None,
    top_n: int = 8,
    neighborhood_limit: int = 8,
) -> Dict[str, Any]:
    """Project candidate capabilities from target-grounded evidence needs."""
    if not CAPABILITY_SELECTION_AVAILABLE or not EVIDENCE_NEEDS_AVAILABLE or not TARGET_RESOLUTION_AVAILABLE:
        return {"error": "capability matching is unavailable", "available": False}
    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    if not isinstance(task, str) or not task.strip():
        return _kernel_error("empty_capability_match_task", "Capability matching requires a non-empty task.")
    try:
        graph = _build_kernel_graph(scan_root)
        resolution = build_target_resolution(
            graph, task, explicit_targets=target_files or None,
            top_n=top_n, neighborhood_limit=neighborhood_limit,
        )
        derivation = build_evidence_need_derivation(graph, task, resolution)
        selection = build_capability_selection(derivation)
    except (TypeError, ValueError) as exc:
        return _kernel_error("invalid_capability_match_request", str(exc))
    return {
        "schema_version": "4.6.0-capability-match",
        "mode": "capability-match",
        "task": task,
        "scan_root": scan_root,
        "target_resolution": resolution,
        "evidence_need_derivation": derivation,
        "capability_selection": selection,
        "authority": selection.get("authority", {}),
    }


_CHECK_FINDINGS_LIMIT = 100
_CHECK_COMPACT_FINDINGS_LIMIT = 10
_CHECK_LIMIT_AUTO = object()


def kernel_analyze(
    scan_root: str = ".",
    analyzer_names: Optional[List[str]] = None,
    output_mode: str = "full",
    findings_limit: Any = _CHECK_LIMIT_AUTO,
    compact: bool = False,
    include_perf: bool = False,
) -> Dict[str, Any]:
    """
    Orkestrasi penuh: build SharedGraph + run analyzers + synthesize.

    Output modes:
    - "full"     : semua data termasuk shared_graph (default)
    - "summary"  : hanya unified_summary + counts
    - "findings" : findings analyzers + summary, tanpa shared_graph
    - "graph"    : hanya shared_graph (tanpa file_map), tanpa analyzers
    """
    if not SHARED_GRAPH_AVAILABLE:
        return {"error": "shared_graph module not found", "available": False}

    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    output_error = _validate_output_mode(
        output_mode,
        ("full", "summary", "findings", "graph"),
    )
    if output_error:
        return output_error

    # Step 1: Build SharedGraph (1x scan, 1x graph build)
    shared_graph = _build_kernel_graph(scan_root)

    # Mode graph: langsung return tanpa jalankan analyzers
    if output_mode == "graph":
        graph_output = {k: v for k, v in shared_graph.items() if k != "file_map"}
        return {
            "schema_version": "3.0.0-kernel",
            "mode": "graph",
            "scan_root": scan_root,
            "graph_cache": shared_graph.get("cache", {}),
            "shared_graph": graph_output,
        }

    # Step 2: Run analyzers (structural topo.* + hott.* by default; perf.* is opt-in)
    if REGISTRY_AVAILABLE:
        effective_analyzers = analyzer_names
        if effective_analyzers is None and not include_perf:
            effective_analyzers = get_structural_analyzers()
        analyzer_output = _run_kernel_analyzers(shared_graph, effective_analyzers)
    else:
        analyzer_output = {"results": {}, "errors": {}, "analyzers_run": 0}

    # Step 3: Build unified summary
    unified_summary = {
        "total_files": shared_graph["summary"]["total_files"],
        "total_edges": shared_graph["summary"]["total_edges"],
        "total_boundaries": shared_graph["summary"]["total_boundaries"],
        "total_type_shapes": shared_graph["summary"]["total_type_shapes"],
        "entrypoint_count": shared_graph["summary"]["entrypoint_count"],
        "test_file_count": shared_graph["summary"]["test_file_count"],
        "total_findings": sum(
            len(r.get("findings", []))
            for r in analyzer_output.get("results", {}).values()
        ),
        "findings_by_severity": _count_findings_by_severity(analyzer_output),
        "analyzers_run": analyzer_output.get("analyzers_run", 0),
        "analyzers_failed": analyzer_output.get("analyzers_failed", 0),
        "analyzer_errors": analyzer_output.get("errors", {}),
        **_analysis_status(
            shared_graph["summary"]["total_files"],
            analyzer_output.get("analyzers_failed", 0),
        ),
    }

    if findings_limit is _CHECK_LIMIT_AUTO:
        effective_limit: Optional[int] = (
            _CHECK_COMPACT_FINDINGS_LIMIT if compact else _CHECK_FINDINGS_LIMIT
        )
    else:
        effective_limit = findings_limit

    raw_graph_cache = shared_graph.get("cache", {}) or {}
    raw_analyzer_cache = analyzer_output.get("cache", {}) or {}
    if compact:
        graph_cache = {
            k: raw_graph_cache[k]
            for k in ("mode", "status", "cache_key", "graph_content_signature")
            if k in raw_graph_cache
        }
        analyzer_cache = {
            k: raw_analyzer_cache[k]
            for k in ("status", "cache_key", "source_cache_key", "cache_path")
            if k in raw_analyzer_cache
        }
    else:
        graph_cache = raw_graph_cache
        analyzer_cache = raw_analyzer_cache

    base: Dict[str, Any] = {
        "schema_version": "3.0.0-kernel",
        "mode": "analyze",
        "output_mode": output_mode,
        "scan_root": scan_root,
        "timestamp": _utc_timestamp(),
        "graph_cache": graph_cache,
        "analyzer_cache": analyzer_cache,
    }
    if compact:
        base["compact"] = True

    # Step 4: Filter output berdasarkan mode
    if output_mode == "summary":
        base["unified_summary"] = unified_summary
        top_findings, findings_truncated = _top_check_findings(
            analyzer_output, limit=effective_limit, compact=compact
        )
        base["findings"] = top_findings
        base["findings_truncated"] = findings_truncated
        if compact:
            base["detail_contract"] = {
                "compact": True,
                "findings_limit": effective_limit,
                "cycle_basis_cap": 2,
                "omitted_cache_fields": [
                    "graph_cache.stat_trust_boundary",
                    "graph_cache.cache_path",
                    "analyzer_cache.analyzers_*",
                ],
                "full_output_hint": "omit --compact (or inspect analyzer_cache.cache_path) to retrieve full check envelope",
            }
        return base

    elif output_mode == "findings":
        base["analyzers"] = analyzer_output
        base["unified_summary"] = unified_summary
        return base

    else:  # "full"
        graph_output = {k: v for k, v in shared_graph.items() if k != "file_map"}
        base["shared_graph"] = graph_output
        base["analyzers"] = analyzer_output
        base["unified_summary"] = unified_summary
        return base


def _count_findings_by_severity(analyzer_output: Dict[str, Any]) -> Dict[str, int]:
    """Hitung total findings per severity level dari semua analyzer."""
    counts = {"high": 0, "medium": 0, "low": 0, "info": 0}
    for result in analyzer_output.get("results", {}).values():
        for finding in result.get("findings", []):
            sev = finding.get("severity", "info")
            if sev in counts:
                counts[sev] += 1
    return counts


def _top_check_findings(
    analyzer_output: Dict[str, Any],
    limit: Optional[int] = _CHECK_FINDINGS_LIMIT,
    compact: bool = False,
) -> tuple:
    """Flatten actionable findings for the `plw check --json` envelope.

    The summary envelope used to carry only counts, so an agent had to
    open the analyzer cache file to read a single finding — and the
    human-readable path could never list one either, because it reads
    the same top-level `findings` key. This returns the actionable
    findings (critical/error/high/medium), each tagged with its
    analyzer, in a deterministic order (severity, analyzer, file/node,
    full JSON), bounded to `limit` with a truncation flag
    (`limit=None` means uncapped). Low/info findings stay in the
    analyzer cache.

    Selection (G6): one finding per analyzer per round, in sorted
    analyzer order, each analyzer's findings severity-sorted
    internally — so no single analyzer can fill the envelope alone
    (the old global sort let `perf.async` take all 100 slots). The
    selected set is re-sorted by the documented order before it is
    returned, so the envelope stays sorted; only its membership is
    fair across analyzers.
    """
    rank = {"critical": 0, "error": 0, "high": 1, "medium": 2}

    def _order(f):
        return (
            rank.get(f.get("severity", "medium"), 2),
            f.get("analyzer", ""),
            f.get("file", "") or f.get("node", ""),
            json.dumps(f, sort_keys=True, ensure_ascii=False),
        )

    by_analyzer = {}
    for name, result in analyzer_output.get("results", {}).items():
        items = []
        for finding in result.get("findings", []):
            sev = finding.get("severity", "info")
            if sev not in rank:
                continue
            item = dict(finding)
            item.setdefault("analyzer", name)
            raw_basis = item.get("cycle_basis")
            if isinstance(raw_basis, list):
                basis_cap = 2 if compact else 5
                compacted_basis = []
                for entry in raw_basis[:basis_cap]:
                    if isinstance(entry, dict) and (
                        "witness_edges" in entry or "vertices" in entry
                    ):
                        compacted = {
                            k: v
                            for k, v in entry.items()
                            if k not in ("witness_edges", "vertices")
                        }
                        if isinstance(entry.get("witness_edges"), list):
                            compacted["witness_edge_count"] = len(entry["witness_edges"])
                        compacted_basis.append(compacted)
                    else:
                        compacted_basis.append(entry)
                item["cycle_basis"] = compacted_basis
                if len(raw_basis) > basis_cap:
                    item["cycle_basis_omitted_count"] = len(raw_basis) - basis_cap
                    item["cycle_basis_truncated"] = True
            items.append(item)
        if items:
            items.sort(key=_order)
            by_analyzer[name] = items

    total = sum(len(v) for v in by_analyzer.values())
    selected = []
    names = sorted(by_analyzer)
    round_idx = 0
    while (limit is None or len(selected) < limit) and any(
        round_idx < len(by_analyzer[n]) for n in names
    ):
        for name in names:
            if limit is not None and len(selected) >= limit:
                break
            items = by_analyzer[name]
            if round_idx < len(items):
                selected.append(items[round_idx])
        round_idx += 1
    selected.sort(key=_order)
    return selected, (limit is not None and total > limit)


def kernel_impact(
    scan_root: str,
    target_file: str,
    output_mode: str = "full",
) -> Dict[str, Any]:
    """Targeted impact analysis via SharedGraph."""
    if not SHARED_GRAPH_AVAILABLE or not TOPO_QUERIES_AVAILABLE:
        return {"error": "required modules not available"}

    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    output_error = _validate_output_mode(output_mode, ("full", "summary"))
    if output_error:
        return output_error

    graph = _build_kernel_graph(scan_root)
    result = query_impact(graph, target_file)

    if output_mode == "summary":
        summary_payload: Dict[str, Any] = {
            "schema_version": "3.0.0-kernel",
            "mode": "impact",
            "graph_cache": graph.get("cache", {}),
            "target": result.get("target"),
            "requested_target": result.get("requested_target", target_file),
            "target_resolution": result.get("target_resolution"),
            "exists": result.get("exists"),
            "change_risk_level": result.get("change_risk_level"),
            "affected_entrypoints": result.get("affected_entrypoints", []),
            "downstream_count": result.get("downstream_count", 0),
            "upstream_count": result.get("upstream_count", 0),
            "target_fan_in": result.get("target_fan_in", 0),
        }
        if result.get("candidate_targets"):
            summary_payload["candidate_targets"] = result.get("candidate_targets", [])
        if "error" in result:
            summary_payload["error"] = result["error"]
        return summary_payload

    engine_target = (
        str(result.get("target"))
        if result.get("exists") and result.get("target")
        else target_file
    )
    engine_lead_impact = _engine_lead_impact_for(scan_root, graph, engine_target)

    return {
        "schema_version": "3.0.0-kernel",
        "mode": "impact",
        "graph_cache": graph.get("cache", {}),
        "engine_lead_impact": engine_lead_impact,
        **result,
    }


def kernel_outline(
    scan_root: str,
    target_file: str,
) -> Dict[str, Any]:
    """Targeted outline extraction via SharedGraph."""
    if not SHARED_GRAPH_AVAILABLE or not TOPO_QUERIES_AVAILABLE:
        return {"error": "required modules not available"}

    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error

    graph = _build_kernel_graph(scan_root)
    result = query_outline(graph, target_file)

    return {
        "schema_version": "3.0.0-kernel",
        "mode": "outline",
        "graph_cache": graph.get("cache", {}),
        **result,
    }


def kernel_brief(
    scan_root: str,
    target_file: str,
    output_mode: str = "full",
) -> Dict[str, Any]:
    """Targeted brief (outline + impact) via SharedGraph."""
    if not SHARED_GRAPH_AVAILABLE or not TOPO_QUERIES_AVAILABLE:
        return {"error": "required modules not available"}

    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    output_error = _validate_output_mode(output_mode, ("full", "summary"))
    if output_error:
        return output_error

    graph = _build_kernel_graph(scan_root)
    result = query_brief(graph, target_file)

    if output_mode == "summary":
        impact_data = result.get("impact", {})
        outline_data = result.get("outline", {})
        summary_payload: Dict[str, Any] = {
            "schema_version": "3.0.0-kernel",
            "mode": "brief",
            "graph_cache": graph.get("cache", {}),
            "file": result.get("file"),
            "requested_target": result.get("requested_target", target_file),
            "target_resolution": result.get("target_resolution"),
            "exists": result.get("exists"),
            "export_count": outline_data.get("stats", {}).get("export_count", 0),
            "import_count": outline_data.get("stats", {}).get("import_count", 0),
            "change_risk_level": impact_data.get("change_risk_level"),
            "affected_entrypoints": impact_data.get("affected_entrypoints", []),
            "downstream_count": impact_data.get("downstream_count", 0),
        }
        if result.get("candidate_targets"):
            summary_payload["candidate_targets"] = result.get("candidate_targets", [])
        if "error" in result:
            summary_payload["error"] = result["error"]
        return summary_payload

    return {
        "schema_version": "3.0.0-kernel",
        "mode": "brief",
        "graph_cache": graph.get("cache", {}),
        **result,
    }


def kernel_cycle_break(
    scan_root: str,
    target_file: Optional[str] = None,
    output_mode: str = "full",
) -> Dict[str, Any]:
    """Targeted cycle-break advisor and Feedback Arc Set plan via SharedGraph."""
    if not SHARED_GRAPH_AVAILABLE:
        return {"error": "required modules not available"}

    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    output_error = _validate_output_mode(output_mode, ("full", "summary"))
    if output_error:
        return output_error

    graph = _build_kernel_graph(scan_root)
    from codebase.cycle_break import analyze_cycle_breaks
    advisor_result = analyze_cycle_breaks(graph)

    plan = advisor_result.get("summary", {})
    advisories = advisor_result.get("advisories", [])

    target_norm: Optional[str] = None
    if target_file:
        target_norm = os.path.normpath(target_file).replace("\\", "/")
        if target_norm.startswith("./"):
            target_norm = target_norm[2:]
        resolved_cb_target: Optional[str] = None
        try:
            from codebase.topology_analyzers import _resolve_query_target
            resolved_cb_target, _, _ = _resolve_query_target(
                target_norm,
                set(graph.get("vertices", [])),
                scan_root=scan_root,
            )
        except Exception:
            resolved_cb_target = None
        match_tokens = [target_norm]
        if resolved_cb_target and resolved_cb_target not in match_tokens:
            match_tokens.append(resolved_cb_target)
        # Filter advisories and cuts affecting target_file
        advisories = [
            adv for adv in advisories
            if any(any(tok in node for tok in match_tokens) for node in adv.get("cycle", []))
        ]
        recommended_cuts = [
            cut for cut in plan.get("recommended_cuts", [])
            if any(tok in cut.get("source", "") or tok in cut.get("target", "") for tok in match_tokens)
        ]
        optional_type_only_cuts = [
            cut for cut in plan.get("optional_type_only_cuts", [])
            if any(tok in cut.get("source", "") or tok in cut.get("target", "") for tok in match_tokens)
        ]
        plan = {
            **plan,
            "target_filtered": True,
            "target_file": target_norm,
            "cycles_affecting_target": len(advisories),
            "runtime_cycles_affecting_target": sum(1 for a in advisories if not a.get("is_type_only")),
            "type_only_cycles_affecting_target": sum(1 for a in advisories if a.get("is_type_only")),
            "cuts_affecting_target": len(recommended_cuts),
            "recommended_cuts": recommended_cuts,
            "optional_type_only_cuts": optional_type_only_cuts,
        }

    if output_mode == "summary":
        out: Dict[str, Any] = {
            "schema_version": CODEBASE_SCHEMA_VERSION,
            "mode": "cycle_break",
            "scan_root": scan_root,
            "graph_cache": graph.get("cache", {}),
            "summary": plan,
        }
        if target_norm is not None:
            out["target"] = target_norm
        return out

    out = {
        "schema_version": CODEBASE_SCHEMA_VERSION,
        "mode": "cycle_break",
        "scan_root": scan_root,
        "graph_cache": graph.get("cache", {}),
        "summary": plan,
        "advisories": advisories,
    }
    if target_norm is not None:
        out["target"] = target_norm
    return out


def _memory_context_metadata(memory_context: Dict[str, Any]) -> Dict[str, Any]:
    """Expose memory provenance without duplicating prompt content outside its budget."""
    return {
        "selected_count": memory_context.get("selected_count", 0),
        "retrieved_count": memory_context.get("retrieved_count", 0),
        "selected": [
            {
                "id": item.get("id"),
                "type": item.get("type"),
                "file": item.get("file"),
                "evidence_status": item.get("evidence_status"),
                "freshness": item.get("freshness"),
                "source_content_sha256": item.get("source_content_sha256"),
                "content_sha256": item.get("content_sha256"),
                "content_truncated": item.get("content_truncated", False),
                "retrieval_match": item.get("retrieval_match", {}),
            }
            for item in memory_context.get("memories", [])
        ],
        "memory_scope": memory_context.get("memory_scope", {}),
        "retrieval": memory_context.get("retrieval", {}),
    }


def kernel_context(
    scan_root: str,
    query: str,
    target_files: Optional[List[str]] = None,
    budget_tokens: int = DEFAULT_BUDGET_TOKENS,
    max_hops: int = DEFAULT_MAX_HOPS,
    detail: str = "source",
    output_mode: str = "prompt",
    proactive_truth: bool = True,
    truth_scope: Optional[str] = None,
    parent_lineage_ids: Optional[List[str]] = None,
    capability_workflow_context: Optional[Dict[str, Any]] = None,
    _shared_graph: Optional[Dict[str, Any]] = None,
    _analyzer_output: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a query-directed, budget-bounded context projection for an LLM."""
    if not SHARED_GRAPH_AVAILABLE or not REGISTRY_AVAILABLE or not CONTEXT_OPTIMIZER_AVAILABLE:
        return _kernel_error(
            "context_optimizer_unavailable",
            "context optimizer dependencies are not available",
        )

    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    if not query or not query.strip():
        return _kernel_error(
            "empty_context_query",
            "Context query must contain non-whitespace text.",
        )
    output_error = _validate_output_mode(output_mode, ("prompt", "summary", "full"))
    if output_error:
        return output_error
    if detail not in ("outline", "source"):
        return _kernel_error(
            "invalid_context_detail",
            f"Invalid context detail: {detail}",
            detail=detail,
            supported_details=["outline", "source"],
        )
    if not isinstance(budget_tokens, int) or not MIN_BUDGET_TOKENS <= budget_tokens <= MAX_BUDGET_TOKENS:
        return _kernel_error(
            "invalid_context_budget",
            (
                f"Context budget must be an integer between {MIN_BUDGET_TOKENS} "
                f"and {MAX_BUDGET_TOKENS} estimated tokens."
            ),
            budget_tokens=budget_tokens,
            minimum=MIN_BUDGET_TOKENS,
            maximum=MAX_BUDGET_TOKENS,
        )
    if not isinstance(max_hops, int) or not 0 <= max_hops <= MAX_HOPS:
        return _kernel_error(
            "invalid_context_hops",
            f"Context max_hops must be an integer between 0 and {MAX_HOPS}.",
            max_hops=max_hops,
            minimum=0,
            maximum=MAX_HOPS,
        )

    _bind_memory_scope_to_scan(scan_root)

    # One canonical scan; an adaptive work caller may inject the exact snapshot
    # it already built so context, target queries, and findings share one graph.
    graph = _shared_graph if _shared_graph is not None else _build_kernel_graph(scan_root)
    analyzer_output = (
        _analyzer_output
        if _analyzer_output is not None
        else _run_kernel_analyzers(graph)
    )

    user_target_files = list(target_files or [])
    truth_plan: Dict[str, Any] = {
        "enabled": bool(proactive_truth and TRUTH_DELIVERY_AVAILABLE),
        "status": "disabled" if not proactive_truth else "unavailable",
        "proactive_targets": [],
        "naturally_due_targets": [],
    }
    if proactive_truth and TRUTH_DELIVERY_AVAILABLE:
        truth_plan = plan_proactive_truth_delivery(
            graph,
            query,
            explicit_targets=user_target_files,
            truth_scope=truth_scope,
        )

    effective_target_files = list(user_target_files)
    for proactive_target in truth_plan.get("proactive_targets", []) or []:
        if proactive_target not in effective_target_files:
            effective_target_files.append(proactive_target)

    memory_context: Dict[str, Any] = {}
    current_graph_signature = graph.get("cache", {}).get("graph_content_signature")
    if not current_graph_signature and graph_content_signature is not None:
        current_graph_signature = graph_content_signature(graph)
    if CROSS_DOMAIN_AVAILABLE:
        current_graph_signature = graph.get("cache", {}).get(
            "graph_content_signature"
        )
        if not current_graph_signature and graph_content_signature is not None:
            current_graph_signature = graph_content_signature(graph)
        current_file_hashes = {
            path: f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}"
            for path, content in graph.get("file_map", {}).items()
        }
        memory_context = get_memory_evidence(
            query=query,
            target_files=effective_target_files or None,
            max_memories=5,
            current_graph_signature=current_graph_signature,
            current_file_hashes=current_file_hashes,
            cache_mode=_ACTIVE_GRAPH_CACHE_MODE,
            graph=graph,
            max_hops=max_hops,
        )

    truth_floor_plan: Dict[str, Any] = {
        "required_memory_ids": [],
        "history_intent": False,
        "truth_scope": str(truth_scope or "unscoped"),
    }
    if TRUTH_FLOOR_AVAILABLE:
        truth_floor_plan = plan_truth_floor(
            query=query,
            graph_signature=str(current_graph_signature or ""),
            truth_scope=truth_scope,
            memory_context=memory_context,
        )

    pack = build_context_pack(
        graph,
        query,
        target_files=effective_target_files or None,
        budget_tokens=budget_tokens,
        max_hops=max_hops,
        detail=detail,
        analyzer_output=analyzer_output,
        memory_context=memory_context,
        truth_scope=truth_scope,
        required_memory_ids=truth_floor_plan.get("required_memory_ids", []),
        user_target_files=user_target_files,
        due_source_files=list(dict.fromkeys(
            list(truth_plan.get("naturally_due_targets", []) or [])
            + list(truth_plan.get("proactive_targets", []) or [])
        )),
        parent_lineage_ids=parent_lineage_ids or [],
        capability_workflow_context=capability_workflow_context,
    )
    context_decision_id = (
        pack.get("accountability", {}).get("ledger", {}).get("id")
        if isinstance(pack.get("accountability"), dict)
        else None
    )
    truth_delivery = (
        finalize_truth_delivery(
            truth_plan,
            selected_paths=pack.get("selection", {}).get("selected_paths", []),
            current_context_decision_id=context_decision_id,
        )
        if proactive_truth and TRUTH_DELIVERY_AVAILABLE
        else truth_plan
    )
    pack["truth_delivery"] = truth_delivery

    truth_floor: Dict[str, Any] = {
        "status": "unavailable",
        "claim_gate": {
            "current_source_claims_allowed": True,
            "historical_or_rationale_claims_allowed": True,
            "context_may_be_presented_as_complete": True,
        },
    }
    if TRUTH_FLOOR_AVAILABLE:
        truth_floor = evaluate_truth_floor(
            plan=truth_floor_plan,
            pack=pack,
            truth_delivery=truth_delivery,
            detail=detail,
        )
    pack["truth_floor"] = truth_floor

    claim_obligations: Dict[str, Any] = {
        "status": "unavailable",
        "requested_claims": [],
        "allowed_claims": [],
        "blocked_claims": [],
        "required_transitions": [],
    }
    runtime_attestations: List[Dict[str, Any]] = []
    runtime_attempts: List[Dict[str, Any]] = []
    if RUNTIME_ATTESTATION_AVAILABLE:
        runtime_targets = pack.get("selection", {}).get("resolved_targets", []) \
            or pack.get("selection", {}).get("selected_paths", [])
        runtime_attempts = find_runtime_attestation_attempts(
            truth_scope=truth_scope, target_paths=runtime_targets,
        )
        runtime_attestations = find_admissible_runtime_attestations(
            truth_scope=truth_scope,
            graph_content_signature=current_graph_signature,
            target_paths=runtime_targets,
        )

    if CLAIM_OBLIGATIONS_AVAILABLE:
        claim_obligations = evaluate_claim_obligations(
            query=query,
            shared_graph=graph,
            analyzer_output=analyzer_output,
            pack=pack,
            truth_floor=truth_floor,
            runtime_attestations=runtime_attestations,
        )
    pack["claim_obligations"] = claim_obligations

    proof_state: Dict[str, Any] = {
        "status": "unavailable",
        "authority": "state_abstraction_only",
        "invariants": {"does_not_assert_truth": True, "markov_sufficiency_proven": False},
    }
    if PROOF_STATE_AVAILABLE:
        try:
            proof_state = abstract_proof_state(
                claim_obligations=claim_obligations,
                truth_floor=truth_floor,
                pack=pack,
                graph_content_signature=current_graph_signature,
                truth_scope=truth_scope,
                target_paths=pack.get("selection", {}).get("resolved_targets", [])
                    or pack.get("selection", {}).get("selected_paths", []),
            )
        except Exception as exc:
            proof_state = {**proof_state, "error": f"proof_state_abstraction_failed:{type(exc).__name__}"}
    pack["proof_state"] = proof_state

    transition_outcome_settlement: Dict[str, Any] = {
        "stored_count": 0, "reused_count": 0, "outcome_ids": [],
        "authority": "strategy_experience_only",
    }
    if TRANSITION_OUTCOME_MEMORY_AVAILABLE and (runtime_attestations or runtime_attempts):
        try:
            transition_outcome_settlement = record_settled_runtime_outcomes(
                runtime_attestations=runtime_attestations, claim_obligations=claim_obligations,
                destination_proof_state=proof_state, runtime_attempts=runtime_attempts,
                current_graph_content_signature=current_graph_signature,
            )
        except Exception as exc:
            transition_outcome_settlement = {**transition_outcome_settlement, "error": f"transition_outcome_record_failed:{type(exc).__name__}"}
    pack["transition_outcome_settlement"] = transition_outcome_settlement

    proof_transitions: Dict[str, Any] = {
        "status": "unavailable",
        "blocked_claims": list(claim_obligations.get("blocked_claims", []) or []),
        "candidates": [],
        "preferred_transition": None,
    }
    if PROOF_TRANSITIONS_AVAILABLE:
        context_lineage_id = str(((pack.get("accountability", {}) or {}).get("lineage", {}) or {}).get("id") or "")
        proof_transitions = compile_proof_transitions(
            claim_obligations=claim_obligations,
            truth_floor=truth_floor,
            graph_content_signature=current_graph_signature,
            target_paths=pack.get("selection", {}).get("resolved_targets", [])
                or pack.get("selection", {}).get("selected_paths", []),
            parent_lineage_ids=[context_lineage_id] if context_lineage_id else [],
            truth_scope=truth_scope,
        )

    transition_state_binding: Dict[str, Any] = {
        "available": False, "stored_count": 0, "reused_count": 0, "intent_ids": [],
        "authority": "strategy_state_binding_only",
    }
    if STATE_TRANSITION_MODEL_AVAILABLE and proof_state.get("state_class_id") and proof_transitions.get("candidates"):
        try:
            transition_state_binding = {
                **register_transition_intents(
                    proof_state=proof_state,
                    candidates=proof_transitions.get("candidates", []) or [],
                    truth_scope=str(truth_scope or "unscoped"),
                ),
                "authority": "strategy_state_binding_only",
            }
        except Exception as exc:
            transition_state_binding = {**transition_state_binding, "error": f"transition_state_binding_failed:{type(exc).__name__}"}
    pack["transition_state_binding"] = transition_state_binding

    transition_outcome_memory: Dict[str, Any] = {
        "authority": "strategy_experience_only", "outcome_count": 0,
        "invariants": {"cannot_satisfy_claim_obligations": True, "cannot_change_transition_validity": True, "changes_ranking_in_v1": False},
    }
    if TRANSITION_OUTCOME_MEMORY_AVAILABLE:
        try:
            transition_outcome_memory = summarize_transition_outcomes()
            annotated = annotate_transition_candidates(proof_transitions.get("candidates", []) or [])
            if STATE_TRANSITION_MODEL_AVAILABLE and proof_state.get("state_class_id"):
                annotated = annotate_candidates_with_state_model(
                    annotated, source_state_class_id=str(proof_state.get("state_class_id"))
                )
            if Q_VALUE_MODEL_AVAILABLE and proof_state.get("state_class_id"):
                annotated = annotate_candidates_with_q_values(
                    annotated, source_state_class_id=str(proof_state.get("state_class_id"))
                )
            proof_transitions["candidates"] = annotated
            preferred_id = (proof_transitions.get("preferred_transition") or {}).get("transition_id")
            if preferred_id:
                proof_transitions["preferred_transition"] = next((item for item in annotated if item.get("transition_id") == preferred_id), proof_transitions.get("preferred_transition"))
            proof_transitions["outcome_memory"] = {
                "authority": "strategy_experience_only", "outcome_count": transition_outcome_memory.get("outcome_count", 0),
                "changes_ranking_in_v1": False, "cannot_change_transition_validity": True,
            }
        except Exception as exc:
            transition_outcome_memory = {**transition_outcome_memory, "error": f"transition_outcome_summary_failed:{type(exc).__name__}"}
    pack["transition_outcome_memory"] = transition_outcome_memory

    state_transition_model: Dict[str, Any] = {
        "authority": "strategy_experience_only",
        "observation_count": 0,
        "state_action_models": [],
        "mdp_status": "state_conditioned_empirical_model_unavailable",
        "invariants": {
            "cannot_change_transition_validity": True,
            "cannot_satisfy_claim_obligations": True,
            "empirical_probability_is_not_truth_confidence": True,
            "markov_sufficiency_proven": False,
        },
    }
    if STATE_TRANSITION_MODEL_AVAILABLE:
        try:
            state_transition_model = summarize_state_transition_model(
                source_state_class_id=str(proof_state.get("state_class_id") or "") or None
            )
        except Exception as exc:
            state_transition_model = {**state_transition_model, "error": f"state_transition_model_failed:{type(exc).__name__}"}
    pack["state_transition_model"] = state_transition_model

    q_value_model: Dict[str, Any] = {
        "authority": "strategy_experience_only",
        "sample_count": 0,
        "state_action_values": [],
        "model_family": "proof_constrained_empirical_one_step_q_value",
        "invariants": {
            "q_value_is_not_truth_confidence": True,
            "cannot_change_transition_validity": True,
            "cannot_satisfy_claim_obligations": True,
            "reward_is_proof_first": True,
            "markov_sufficiency_proven": False,
            "bellman_optimality_proven": False,
        },
    }
    if Q_VALUE_MODEL_AVAILABLE:
        try:
            if OUTCOME_RECONCILIATION_AVAILABLE:
                refresh_outcome_reconciliation()
            q_value_model = summarize_q_value_model(
                source_state_class_id=str(proof_state.get("state_class_id") or "") or None
            )
        except Exception as exc:
            q_value_model = {**q_value_model, "error": f"q_value_model_failed:{type(exc).__name__}"}
    pack["q_value_model"] = q_value_model
    pack["proof_transitions"] = proof_transitions

    shadow_policy: Dict[str, Any] = {
        "status": "unavailable",
        "authority": "strategy_advisory_only",
        "invariants": {
            "cannot_change_transition_validity": True,
            "cannot_satisfy_claim_obligations": True,
            "probability_is_not_truth_confidence": True,
            "deterministic_registry_ranking_remains_authoritative_in_v1": True,
        },
    }
    if SHADOW_POLICY_AVAILABLE:
        try:
            shadow_policy = evaluate_shadow_policy(proof_transitions=proof_transitions)
        except Exception as exc:
            shadow_policy = {**shadow_policy, "error": f"shadow_policy_failed:{type(exc).__name__}"}
    pack["shadow_policy"] = shadow_policy

    if truth_floor.get("status") == "recovery_required":
        pack["partial_context_block"] = pack.get("context_block", "")
        pack["context_block"] = fail_closed_prompt(truth_floor)
    elif claim_obligations.get("status") == "recovery_required":
        # Claim-specific fail-closed keeps the bounded evidence visible so the
        # agent can choose the narrowest recovery transition, while preventing
        # the requested claim from being asserted prematurely.
        pack["partial_context_block"] = pack.get("context_block", "")
        pack["context_block"] = (
            claim_guard_prompt(claim_obligations)
            + transition_guard_prompt(proof_transitions)
            + pack.get("context_block", "")
        )

    unresolved_targets = pack.get("selection", {}).get("unresolved_targets", [])
    if unresolved_targets:
        return _kernel_error(
            "context_target_not_found",
            "One or more explicit context targets could not be resolved uniquely.",
            unresolved_targets=unresolved_targets,
            scan_root=scan_root,
        )

    base = {
        "schema_version": "3.0.0-kernel",
        "mode": "context",
        "output_mode": output_mode,
        "scan_root": scan_root,
        "query": query,
        "truth_scope": str(truth_scope or "unscoped"),
        "context_status": (
            "recovery_required"
            if truth_floor.get("status") == "recovery_required"
            or claim_obligations.get("status") == "recovery_required"
            else truth_floor.get("status", "unavailable")
        ),
        "graph_cache": graph.get("cache", {}),
        "analyzer_cache": analyzer_output.get("cache", {}),
        "runtime_evidence": {
            "attempt_count": len(runtime_attempts),
            "admissible_count": len(runtime_attestations),
            "attestation_ids": [item.get("attestation_id") for item in runtime_attestations],
            "authority": "current_runtime_observation",
        },
    }
    if output_mode == "prompt":
        selection = pack.get("selection", {})
        memory_metadata = _memory_context_metadata(pack.get("memory_context", {}))
        return {
            **base,
            "model": pack.get("model", {}),
            "selection": {
                "mode": selection.get("mode"),
                "confidence": selection.get("confidence"),
                "selected_paths": selection.get("selected_paths", []),
                "resolved_targets": selection.get("resolved_targets", []),
                "user_requested_targets": user_target_files,
                "proactive_targets": truth_delivery.get("proactive_targets", []),
                "max_hops": selection.get("max_hops"),
            },
            "budget": pack.get("budget", {}),
            "provenance": pack.get("provenance", {}),
            "compaction": pack.get("compaction", {}),
            "evidence_roles": pack.get("evidence_roles", {}),
            "accountability": pack.get("accountability", {}),
            "truth_delivery": truth_delivery,
            "truth_floor": truth_floor,
            "claim_obligations": claim_obligations,
            "proof_state": proof_state,
            "proof_transitions": proof_transitions,
            "transition_state_binding": transition_state_binding,
            "transition_outcome_memory": transition_outcome_memory,
            "state_transition_model": state_transition_model,
            "q_value_model": q_value_model,
            "shadow_policy": shadow_policy,
            "transition_outcome_settlement": transition_outcome_settlement,
            "recovery": pack.get("recovery", {}),
            "memory_context": memory_metadata,
            **({"capability_workflow": pack.get("capability_workflow", {})} if capability_workflow_context is not None else {}),
            "context_block": pack.get("context_block", ""),
        }
    if output_mode == "summary":
        memory_metadata = _memory_context_metadata(pack.get("memory_context", {}))
        return {
            **base,
            "model": pack.get("model", {}),
            "selection": pack.get("selection", {}),
            "budget": pack.get("budget", {}),
            "provenance": pack.get("provenance", {}),
            "compaction": pack.get("compaction", {}),
            "evidence_roles": pack.get("evidence_roles", {}),
            "accountability": pack.get("accountability", {}),
            "truth_delivery": truth_delivery,
            "truth_floor": truth_floor,
            "claim_obligations": claim_obligations,
            "proof_state": proof_state,
            "proof_transitions": proof_transitions,
            "transition_state_binding": transition_state_binding,
            "transition_outcome_memory": transition_outcome_memory,
            "state_transition_model": state_transition_model,
            "q_value_model": q_value_model,
            "shadow_policy": shadow_policy,
            "transition_outcome_settlement": transition_outcome_settlement,
            "recovery": pack.get("recovery", {}),
            "memory_context": memory_metadata,
            **({"capability_workflow": pack.get("capability_workflow", {})} if capability_workflow_context is not None else {}),
            "quotient_summary": pack.get("quotient_graph", {}).get("summary", {}),
            "selected_files": [
                {
                    "file": item.get("file"),
                    "score": item.get("score"),
                    "graph_distance": item.get("graph_distance"),
                    "primary_evidence_role": item.get("primary_evidence_role"),
                    "evidence_roles": item.get("evidence_roles", []),
                    "selection_signals": item.get("selection_signals", []),
                }
                for item in pack.get("selected_files", [])
            ],
        }
    return {**base, **pack}


def _work_ledger_projection(value: Any) -> Dict[str, Any]:
    """Keep a recoverable ledger pointer without returning the stored payload."""
    if not isinstance(value, dict):
        return {}
    return {
        key: value.get(key)
        for key in ("available", "id", "decision_id", "lineage_id", "command", "reason")
        if key in value
    }


def _work_context_projection(context: Dict[str, Any], full_detail: bool, scan_root: str = ".") -> Dict[str, Any]:
    """Project context for an ordinary work call; deep mode preserves the full API."""
    if full_detail:
        return context
    budget = context.get("budget") or {}
    allocation = budget.get("allocation") or {}
    roles = context.get("evidence_roles") or {}
    source_roles = roles.get("source") or {}
    memory_roles = roles.get("memory") or {}
    truth_delivery = context.get("truth_delivery") or {}
    return {
        "schema_version": context.get("schema_version"),
        "context_status": context.get("context_status"),
        "context_block": str(context.get("context_block", "")).replace(
            os.path.abspath(scan_root).rstrip(os.sep) + os.sep, ""
        ),
        "selection": context.get("selection", {}),
        "budget": {
            "requested_estimated_tokens": budget.get("requested_estimated_tokens"),
            "char_budget": budget.get("char_budget"),
            "used_chars": budget.get("used_chars"),
            "estimated_tokens": budget.get("estimated_tokens"),
            "within_budget": budget.get("within_budget"),
            "source_grounding_satisfied": allocation.get("source_grounding_satisfied"),
            "source_witnesses": allocation.get("source_witnesses", []),
        },
        "compaction": context.get("compaction", {}),
        "evidence_roles": {
            "source": {
                "proof_due_paths": source_roles.get("proof_due_paths", []),
                "explicit_target_paths": source_roles.get("explicit_target_paths", []),
                "selected_by_relevance_paths": source_roles.get("selected_by_relevance_paths", []),
            },
            "memory": {
                "proof_due_ids": memory_roles.get("proof_due_ids", []),
                "continuity_ids": memory_roles.get("continuity_ids", []),
                "required_but_not_included_ids": memory_roles.get("required_but_not_included_ids", []),
            },
            "optional_enrichment": roles.get("optional_enrichment", {}),
            "omission_is_not_irrelevance": (roles.get("invariants") or {}).get(
                "omission_is_not_irrelevance", True
            ),
        },
        "truth_delivery": {
            "status": truth_delivery.get("status"),
            "delivery_status": truth_delivery.get("delivery_status"),
            "due_targets": truth_delivery.get("due_targets", []),
            "delivered_targets": truth_delivery.get("delivered_targets", []),
            "unresolved_due_targets": truth_delivery.get("unresolved_due_targets", []),
            "ledger": _work_ledger_projection(truth_delivery.get("ledger")),
        },
        "accountability": _work_ledger_projection(context.get("accountability")),
        "recovery": context.get("recovery", {}),
        "detail_contract": {
            "level": "compact_recoverable",
            "full_context_available_with_depth": "deep",
            "context_block_paths_relative_to_scan_root": True,
        },
    }


def _work_target_resolution_projection(value: Dict[str, Any], full_detail: bool) -> Dict[str, Any]:
    if full_detail or not isinstance(value, dict):
        return value
    resolution = value.get("resolution", {}) or {}
    candidates = []
    for row in value.get("candidate_targets", [])[:5]:
        ctx = row.get("structural_context", {}) or {}
        candidates.append({
            "file": row.get("file"),
            "score": row.get("score"),
            "evidence": row.get("evidence", [])[:4],
            "structural_context": {
                "fan_in": ctx.get("fan_in"), "fan_out": ctx.get("fan_out"),
                "direct_imports": ctx.get("direct_imports", [])[:6],
                "direct_importers": ctx.get("direct_importers", [])[:6],
                "affected_entrypoints": ctx.get("affected_entrypoints", [])[:6],
                "reachable_tests": ctx.get("reachable_tests", [])[:6],
            },
        })
    return {
        "schema_version": value.get("schema_version"), "policy": value.get("policy"),
        "stage": value.get("stage"), "resolution": resolution,
        "candidate_targets": candidates, "next_reasoning": value.get("next_reasoning"),
        "authority": value.get("authority", {}),
        "detail_contract": {"level": "compact_recoverable", "standalone_full_command": "plw resolve-target"},
    }


def _work_evidence_need_projection(value: Dict[str, Any], full_detail: bool) -> Dict[str, Any]:
    if full_detail or not isinstance(value, dict):
        return value
    return {
        "schema_version": value.get("schema_version"), "policy": value.get("policy"),
        "stage": value.get("stage"), "target_resolution_state": value.get("target_resolution_state"),
        "selected_targets": value.get("selected_targets", []),
        "known": value.get("known", [])[:6], "unknown": value.get("unknown", [])[:8],
        "evidence_needed": value.get("evidence_needed", [])[:8],
        "blocked_reason": value.get("blocked_reason"), "next_reasoning": value.get("next_reasoning"),
        "authority": value.get("authority", {}),
        "detail_contract": {"level": "compact_recoverable", "standalone_full_command": "plw evidence-needs"},
    }


def _work_capability_selection_projection(selection: Dict[str, Any], full_detail: bool) -> Dict[str, Any]:
    """Keep ordinary work bounded while preserving recoverable candidate semantics."""
    if full_detail or not isinstance(selection, dict):
        return selection
    candidates = []
    for row in selection.get("candidate_capabilities", [])[:6]:
        candidates.append({
            "capability": row.get("capability"),
            "covers_evidence_classes": row.get("covers_evidence_classes", []),
            "coverage": row.get("coverage"),
            "information_role": row.get("role"),
            "canonical_concepts": list(row.get("canonical_concepts", []) or [])[:2],
            "expected_information_gain": list(row.get("expected_information_gain", []) or [])[:2],
            "does_not_prove": list(row.get("does_not_prove", []) or [])[:2],
            "operation_contract_available": bool(row.get("operation_contract_available", False)),
            "operation_contract_count": int(row.get("operation_contract_count", 0) or 0),
            "skill_path": row.get("skill_path"),
            "state_change": row.get("state_change", False),
        })
    return {
        "schema_version": selection.get("schema_version"),
        "policy": selection.get("policy"),
        "stage": selection.get("stage"),
        "selected_targets": selection.get("selected_targets", []),
        "task_text_used_for_selection": selection.get("task_text_used_for_selection", False),
        "selection_basis": selection.get("selection_basis"),
        "candidate_capabilities": candidates,
        "ranking_semantics": "coverage breadth/information role only; action priority is not computed",
        "action_priority_computed": False,
        "uncovered_needs": selection.get("uncovered_needs", []),
        "summary": selection.get("summary", {}),
        "authority": selection.get("authority", {}),
        "next_reasoning": selection.get("next_reasoning"),
        "detail_contract": {
            "level": "compact_recoverable",
            "full_need_matches_available_with_depth": "deep",
            "standalone_full_command": "plw capability-match",
        },
    }


def _work_transition_projection(value: Any, full_detail: bool) -> Any:
    if full_detail or not isinstance(value, dict):
        return value
    return {
        key: value.get(key)
        for key in (
            "transition_id", "transition_type", "claim_type", "target", "precondition",
            "capability", "interface", "authority_domain", "produces", "side_effect_class",
            "execution_authority", "auto_execute_allowed", "validation", "command_hint",
            "rank", "preferred",
        )
        if key in value
    } | {"lineage": _work_ledger_projection(value.get("lineage"))}


def _work_proof_projection(
    context: Dict[str, Any],
    stop_reason: str,
    preferred_transition: Any,
    full_detail: bool,
) -> Dict[str, Any]:
    claims = context.get("claim_obligations") or {}
    truth = context.get("truth_floor") or {}
    proof_state = context.get("proof_state") or {}
    if full_detail:
        projected_claims = claims
        projected_truth = truth
        projected_state = proof_state
        projected_transition = preferred_transition
        detail_contract = {"level": "full"}
    else:
        obligations = []
        for obligation in claims.get("proof_obligations", []) or []:
            witnesses = obligation.get("witnesses", []) or []
            obligations.append({
                "claim_type": obligation.get("claim_type"),
                "satisfied": obligation.get("satisfied"),
                "missing": obligation.get("missing", []),
                "witness_types": sorted({
                    str(witness.get("type"))
                    for witness in witnesses
                    if isinstance(witness, dict) and witness.get("type")
                }),
                "scope_limits": obligation.get("scope_limits", []),
            })
        source_floor = truth.get("source_floor") or {}
        memory_floor = truth.get("memory_floor") or {}
        projected_claims = {
            "status": claims.get("status"),
            "requested_claims": claims.get("requested_claims", []),
            "allowed_claims": claims.get("allowed_claims", []),
            "blocked_claims": claims.get("blocked_claims", []),
            "proof_obligations": obligations,
            "required_transitions": claims.get("required_transitions", []),
            "ledger": _work_ledger_projection(claims.get("ledger")),
        }
        projected_truth = {
            "status": truth.get("status"),
            "truth_scope": truth.get("truth_scope"),
            "source_floor": {
                "due_targets": source_floor.get("due_targets", []),
                "delivered_targets": source_floor.get("delivered_targets", []),
                "unresolved": source_floor.get("unresolved", []),
            },
            "memory_floor": {
                "required_ids": memory_floor.get("required_ids", []),
                "delivered_ids": memory_floor.get("delivered_ids", []),
                "unresolved": memory_floor.get("unresolved", []),
                "current_source_precedence": memory_floor.get("current_source_precedence"),
            },
            "claim_gate": truth.get("claim_gate", {}),
            "required_transitions": truth.get("required_transitions", []),
            "ledger": _work_ledger_projection(truth.get("ledger")),
        }
        projected_state = {
            "phase": proof_state.get("phase"),
            "state_class_id": proof_state.get("state_class_id"),
            "state_instance_id": proof_state.get("state_instance_id"),
            "features": proof_state.get("features", {}),
        }
        projected_transition = _work_transition_projection(preferred_transition, False)
        detail_contract = {
            "level": "compact_recoverable",
            "full_proof_available_with_depth": "deep",
        }
    return {
        "claim_obligations": projected_claims,
        "truth_floor": projected_truth,
        "proof_state": projected_state,
        "preferred_transition": projected_transition,
        "runtime_evidence": context.get("runtime_evidence", {}),
        "stop_reason": stop_reason,
        "detail_contract": detail_contract,
    }


def _engine_answer_summary(
    target_orientation: Dict[str, Any],
    terms: Any = None,
    *,
    target_resolved: bool = True,
) -> Dict[str, Any]:
    """Summarize engine-located symbols for the agent decision frame.

    The topology target may stay unresolved (or ambiguous) while the
    engine layer already located symbol(s) in the target; the summary
    lets the decision frame say so up front instead of reading as "no
    answer". Returns {} when the engine located nothing, so the frame
    stays silent instead of claiming an answer. Never raises.

    Only ``calls`` edges are projected as calls: ``symbol_edges`` also
    carries ``related`` rows (re-export, ffi, ...) which have no caller
    or callee at all — projecting them unfiltered used to emit
    ``{"caller": {"file": null, "line": null}, "callee": null}`` rows
    (the engine's file/line sort puts ``related`` rows first). When
    ``terms`` (task-seed terms) are given, rows whose names contain a
    term rank first, stable within each group, before the [:4] cut —
    otherwise the cut keeps whatever the engine's sort put first, which
    need not be what the task asked about.
    """
    try:
        engine = (target_orientation or {}).get("engine") or {}
        nodes = [n for n in (engine.get("symbol_nodes") or []) if isinstance(n, dict)]
        edges = [
            e for e in (engine.get("symbol_edges") or [])
            if isinstance(e, dict) and e.get("kind") == "calls"
        ]
        if not nodes and not edges:
            return {}
        terms_l = [str(t).lower() for t in (terms or []) if str(t).strip()]

        def _term_score(name: str) -> tuple:
            lowered = (name or "").lower()
            parts = lowered.split()
            exact = sum(1 for t in terms_l if t and (lowered == t or t in parts))
            long_hits = sum(1 for t in terms_l if len(t) >= 4 and t in lowered)
            all_hits = sum(1 for t in terms_l if t and t in lowered)
            best_len = max((len(t) for t in terms_l if t and t in lowered), default=0)
            return (exact, long_hits, best_len, all_hits)

        def _ranked(rows, key):
            if not terms_l:
                return rows
            scored = sorted(
                enumerate(rows),
                key=lambda pair: (tuple(-v for v in _term_score(key(pair[1]))), pair[0]),
            )
            return [row for _, row in scored]

        def _call_name(edge: Dict[str, Any]) -> str:
            caller = edge.get("caller") or {}
            callee = edge.get("callee") or {}
            return "%s %s" % (caller.get("symbol") or "", callee.get("symbol") or "")

        nodes = _ranked(nodes, lambda n: str(n.get("symbol") or ""))
        edges = _ranked(edges, _call_name)
        if not target_resolved and terms_l:
            has_match = any(
                _term_score(str(n.get("symbol") or "")) > (0, 0, 0, 0) for n in nodes
            ) or any(
                _term_score(_call_name(e)) > (0, 0, 0, 0) for e in edges
            )
            if not has_match:
                return {}
        return {
            "symbols": [
                {
                    "symbol": n.get("symbol"),
                    "file": n.get("file"),
                    "line": n.get("line"),
                    "kind": n.get("kind"),
                    "authority": n.get("authority"),
                }
                for n in nodes[:4]
            ],
            "calls": [
                {
                    "caller": {
                        "file": (e.get("caller") or {}).get("file"),
                        "line": (e.get("caller") or {}).get("line"),
                    },
                    "callee": (e.get("callee") or {}).get("symbol"),
                }
                for e in edges[:4]
            ],
            "symbol_count": len(nodes),
            "call_count": len(edges),
        }
    except Exception:
        return {}


def kernel_work(
    scan_root: str,
    task: str,
    target_files: Optional[List[str]] = None,
    goal: str = "auto",
    depth: str = "auto",
    budget_tokens: int = DEFAULT_BUDGET_TOKENS,
    max_hops: int = DEFAULT_MAX_HOPS,
    detail: str = "source",
    max_findings: int = 24,
    proactive_truth: bool = True,
    truth_scope: Optional[str] = None,
    ui_selector: Optional[str] = None,
    full_engine: bool = False,
    full_engine_edges: bool = False,
    frame_only: bool = False,
) -> Dict[str, Any]:
    """Build one adaptive, bounded work pack from one canonical graph snapshot.

    This is the preferred agent-facing entrypoint for ordinary repository work.
    It composes context, target briefs, analysis summary, and the existing proof
    gate without executing commands or mutating source.
    """
    if not ADAPTIVE_WORK_AVAILABLE:
        return _kernel_error(
            "adaptive_work_unavailable",
            "Adaptive work routing is not available.",
        )
    if not isinstance(task, str) or not task.strip():
        return _kernel_error(
            "empty_work_task",
            "Adaptive work requires a non-empty task.",
        )
    normalized_goal = str(goal or "auto").strip().lower()
    if normalized_goal not in WORK_GOALS:
        return _kernel_error(
            "invalid_work_goal",
            "Adaptive work goal is invalid.",
            requested_goal=goal,
            supported_goals=list(WORK_GOALS),
        )
    normalized_depth = str(depth or "auto").strip().lower()
    if normalized_depth not in WORK_DEPTHS:
        return _kernel_error(
            "invalid_work_depth",
            "Adaptive work depth is invalid.",
            requested_depth=depth,
            supported_depths=list(WORK_DEPTHS),
        )
    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    if target_files is not None and not isinstance(target_files, list):
        return _kernel_error(
            "invalid_work_targets",
            "Adaptive work target_files must be a list of paths.",
        )
    targets = list(target_files or [])
    if (
        len(targets) > 8
        or any(not isinstance(value, str) or not value.strip() for value in targets)
    ):
        return _kernel_error(
            "invalid_work_targets",
            "Adaptive work accepts at most eight non-empty target paths.",
            target_count=len(targets),
            maximum=8,
        )
    if (
        isinstance(max_findings, bool)
        or not isinstance(max_findings, int)
        or not 0 <= max_findings <= 100
    ):
        return _kernel_error(
            "invalid_work_finding_limit",
            "max_findings must be an integer between 0 and 100.",
            max_findings=max_findings,
            minimum=0,
            maximum=100,
        )
    if (
        isinstance(budget_tokens, bool)
        or not isinstance(budget_tokens, int)
        or not MIN_BUDGET_TOKENS <= budget_tokens <= MAX_BUDGET_TOKENS
    ):
        return _kernel_error(
            "invalid_context_budget",
            "Adaptive work budget is outside the context contract.",
            budget_tokens=budget_tokens,
            minimum=MIN_BUDGET_TOKENS,
            maximum=MAX_BUDGET_TOKENS,
        )
    if (
        isinstance(max_hops, bool)
        or not isinstance(max_hops, int)
        or not 0 <= max_hops <= MAX_HOPS
    ):
        return _kernel_error(
            "invalid_context_hops",
            "Adaptive work max_hops is outside the context contract.",
            max_hops=max_hops,
            minimum=0,
            maximum=MAX_HOPS,
        )
    if detail not in ("outline", "source"):
        return _kernel_error(
            "invalid_context_detail",
            "Adaptive work detail must be outline or source.",
            detail=detail,
            supported_details=["outline", "source"],
        )
    if not isinstance(proactive_truth, bool):
        return _kernel_error(
            "invalid_proactive_truth",
            "proactive_truth must be a literal boolean.",
        )
    if ui_selector is not None and (not isinstance(ui_selector, str) or not ui_selector.strip()):
        return _kernel_error("invalid_ui_selector", "ui_selector must be a non-empty selector.")

    initial_requested_claims: List[str] = []
    if CLAIM_OBLIGATIONS_AVAILABLE:
        claim_intent = classify_claim_intent(task)
        initial_requested_claims = [
            str(item.get("type"))
            for item in claim_intent.get("claims", []) or []
            if isinstance(item, dict) and item.get("type")
        ]
    initial_plan = build_adaptive_work_plan(
        task=task,
        requested_goal=normalized_goal,
        requested_depth=normalized_depth,
        requested_claims=initial_requested_claims,
        target_count=len(targets),
        max_findings=max_findings,
    )
    if initial_plan.get("error"):
        return _kernel_error(
            str(initial_plan.get("error")),
            "Adaptive work routing input is invalid.",
            **{key: value for key, value in initial_plan.items() if key != "error"},
        )
    planned_analyzers = list(initial_plan.get("finding_analyzers", []))
    analyzer_request = None if "*" in planned_analyzers else planned_analyzers

    # The graph and routed analyzer evidence are built exactly once.
    # kernel_context
    # receives these private immutable-by-contract objects rather than scanning
    # the same repository again.
    _bind_memory_scope_to_scan(scan_root)
    graph = _build_kernel_graph(scan_root)
    ui_source_handoff = (
        build_ui_agent_handoff(task, graph, selector=ui_selector)
        if build_ui_agent_handoff is not None else {"status": "UNAVAILABLE"}
    )
    target_resolution = (
        build_target_resolution(
            graph, task, explicit_targets=targets or None, top_n=8, neighborhood_limit=8
        )
        if TARGET_RESOLUTION_AVAILABLE else {}
    )
    engine_targets = _resolve_engine_target_files(
        scan_root,
        graph,
        explicit_targets=targets,
        target_resolution=target_resolution,
        full_engine=full_engine,
    )
    task_seed_block = (target_resolution or {}).get("task_seed") or {}
    work_seed_terms = (
        list(task_seed_block.get("terms") or [])
        + list(task_seed_block.get("path_or_identifier_hints") or [])
    ) if engine_targets is None else None
    engine_layer = _build_topology_engine_layer(
        scan_root,
        graph,
        target_files=engine_targets,
        full_engine=full_engine,
        full_engine_edges=full_engine_edges,
        seed_terms=work_seed_terms,
    )
    target_orientation = (
        build_target_topology_orientation(graph, top_n=8, include_edges=False, engine_layer=engine_layer)
        if TARGET_TOPOLOGY_AVAILABLE else {}
    )
    if targets and ui_source_handoff.get("source_target_hint"):
        selected_work_targets = list(
            (target_resolution.get("resolution") or {}).get("selected_targets", []) or []
        )
        hinted_target = ui_source_handoff["source_target_hint"]["component_file"]
        ui_source_handoff["explicit_target_alignment"] = {
            "status": "MATCH" if selected_work_targets == [hinted_target] else "MISMATCH",
            "selected_work_targets": selected_work_targets,
            "hinted_component_file": hinted_target,
            "scope": "source_identity_comparison_only",
        }
    evidence_need_derivation = (
        build_evidence_need_derivation(graph, task, target_resolution)
        if EVIDENCE_NEEDS_AVAILABLE else {}
    )
    capability_selection = (
        build_capability_selection(evidence_need_derivation)
        if CAPABILITY_SELECTION_AVAILABLE else {}
    )
    analyzer_output = _run_kernel_analyzers(graph, analyzer_request)
    context = kernel_context(
        scan_root=scan_root,
        query=task,
        target_files=targets or None,
        budget_tokens=budget_tokens,
        max_hops=max_hops,
        detail=detail,
        output_mode="prompt",
        proactive_truth=proactive_truth,
        truth_scope=truth_scope,
        _shared_graph=graph,
        _analyzer_output=analyzer_output,
    )
    if context.get("error"):
        semantics = (
            build_work_semantics(
                task, goal=initial_plan.get("goal", "understand"), work_status="blocked",
                target_resolution_state=str((target_resolution.get("resolution") or {}).get("state") or ""),
                evidence_need_stage=str(evidence_need_derivation.get("stage") or ""),
                capability_selection_stage=str(capability_selection.get("stage") or ""),
            )
            if SEMANTIC_AFFORDANCE_AVAILABLE else {}
        )
        blocked_readiness = {
            "reference_pack": "BLOCKED",
            "action": "NOT_READY",
            "task_postcondition": "UNPROVEN",
        }
        blocked_authority = {
            "execute_runtime": False,
            "mutate_source": False,
            "mutate_external_repository": False,
            "commit_truth": False,
        }
        if frame_only:
            handoff = dict(semantics.get("skill_handoff") or {})
            handoff_frame = {k: v for k, v in handoff.items() if k != "inline_contract"}
            res_block = target_resolution.get("resolution") or {}
            target_res_frame = {
                "schema_version": target_resolution.get("schema_version"),
                "stage": target_resolution.get("stage"),
                "resolution": {
                    "state": res_block.get("state"),
                    "selected_targets": list(res_block.get("selected_targets") or []),
                    "reason": res_block.get("reason"),
                },
                "authority": target_resolution.get("authority", {}),
            }
            return {
                **context,
                "mode": "work",
                "frame_only": True,
                "work_status": "blocked",
                "readiness": blocked_readiness,
                "task": task,
                "ui_source_handoff": ui_source_handoff,
                "skill_handoff": handoff_frame,
                "target_resolution": target_res_frame,
                "detail_contract": {
                    "level": "frame_only",
                    "omitted": ["target_orientation", "evidence_need_derivation", "capability_selection"],
                },
                "authority": blocked_authority,
            }
        return {
            **context,
            "mode": "work",
            "work_status": "blocked",
            "readiness": blocked_readiness,
            "task": task,
            "target_orientation": target_orientation,
            "ui_source_handoff": ui_source_handoff,
            "target_resolution": target_resolution,
            "evidence_need_derivation": evidence_need_derivation,
            "capability_selection": capability_selection,
            **semantics,
            "authority": blocked_authority,
        }

    requested_claims = list(
        (context.get("claim_obligations") or {}).get("requested_claims", []) or []
    )
    plan = build_adaptive_work_plan(
        task=task,
        requested_goal=normalized_goal,
        requested_depth=normalized_depth,
        requested_claims=requested_claims,
        target_count=len(targets),
        max_findings=max_findings,
    )
    if plan.get("error"):
        return _kernel_error(
            str(plan.get("error")),
            "Adaptive work routing input is invalid.",
            **{key: value for key, value in plan.items() if key != "error"},
        )
    plan["routing_consistency"] = {
        "initial_goal": initial_plan.get("goal"),
        "proof_gate_goal": plan.get("goal"),
        "stable": initial_plan.get("goal") == plan.get("goal"),
    }
    plan["analyzer_execution"] = {
        "selection": "all" if analyzer_request is None else "goal_specific_subset",
        "requested": list(analyzer_output.get("analyzers_run", [])),
        "single_execution_pass": True,
    }

    target_evidence: List[Dict[str, Any]] = []
    if plan.get("include_target_briefs"):
        for target in targets:
            target_evidence.append(query_brief(graph, target))
    # Resolve target matching from the exact briefs. Proactive truth targets in
    # context remain advisory and do not inflate caller-target telemetry.
    resolved_targets = [
        str(item.get("file"))
        for item in target_evidence
        if item.get("exists") is True and item.get("file")
    ]

    total_findings = sum(
        len(result.get("findings", []) or [])
        for result in (analyzer_output.get("results") or {}).values()
    )
    analysis_summary = {
        "scope": "all_analyzers" if analyzer_request is None else "adaptive_goal_subset",
        "total_files": (graph.get("summary") or {}).get("total_files", 0),
        "total_edges": (graph.get("summary") or {}).get("total_edges", 0),
        "total_boundaries": (graph.get("summary") or {}).get("total_boundaries", 0),
        "total_type_shapes": (graph.get("summary") or {}).get("total_type_shapes", 0),
        "entrypoint_count": (graph.get("summary") or {}).get("entrypoint_count", 0),
        "test_file_count": (graph.get("summary") or {}).get("test_file_count", 0),
        "total_findings": total_findings,
        "findings_by_severity": _count_findings_by_severity(analyzer_output),
        "analyzers_run": analyzer_output.get("analyzers_run", []),
        "analyzers_failed": analyzer_output.get("analyzers_failed", 0),
        "analyzer_errors": analyzer_output.get("errors", {}),
    }
    finding_projection = select_work_findings(
        analyzer_output,
        plan.get("finding_analyzers", []),
        resolved_targets,
        int(plan.get("finding_limit", 0)),
    )

    claim_status = str((context.get("claim_obligations") or {}).get("status", ""))
    truth_status = str((context.get("truth_floor") or {}).get("status", ""))
    recovery_required = (
        context.get("context_status") == "recovery_required"
        or claim_status == "recovery_required"
        or truth_status == "recovery_required"
    )
    preferred_transition = (
        (context.get("proof_transitions") or {}).get("preferred_transition")
    )
    stop_reason = (
        "valid_recovery_transition_available"
        if recovery_required and preferred_transition
        else "proof_recovery_required"
        if recovery_required
        else "bounded_reference_pack_ready"
    )

    full_detail = plan.get("depth") == "deep"
    context_projection = _work_context_projection(context, full_detail, scan_root)
    proof_projection = _work_proof_projection(
        context,
        stop_reason,
        preferred_transition,
        full_detail,
    )
    call_reduction = {
        **(plan.get("call_reduction") or {}),
        "graph_reused_by": ["target_orientation", "target_resolution", "evidence_need_derivation", "capability_selection", "context", "analysis_summary", "target_briefs"],
        "filesystem_rescans_inside_call": 0,
        "response_projection": "full" if full_detail else "compact_recoverable",
        "full_detail_available_with_depth": "deep",
    }
    semantics = (
        build_work_semantics(
            task, goal=str(plan.get("goal") or "understand"),
            work_status="recovery_required" if recovery_required else "ready",
            preferred_transition=preferred_transition,
            target_resolution_state=str((target_resolution.get("resolution") or {}).get("state") or ""),
            evidence_need_stage=str(evidence_need_derivation.get("stage") or ""),
            capability_selection_stage=str(capability_selection.get("stage") or ""),
        )
        if SEMANTIC_AFFORDANCE_AVAILABLE else {}
    )
    target_resolution_projection = _work_target_resolution_projection(target_resolution, full_detail)
    evidence_need_projection = _work_evidence_need_projection(evidence_need_derivation, full_detail)
    capability_selection_projection = _work_capability_selection_projection(capability_selection, full_detail)
    if not full_detail and isinstance(semantics.get("semantic_orientation"), dict):
        orientation = semantics["semantic_orientation"]
        semantics["semantic_orientation"] = {
            "schema_version": orientation.get("schema_version"),
            "policy": orientation.get("policy"),
            "current_epistemic_gap": orientation.get("current_epistemic_gap", {}),
            "canonical_concepts": orientation.get("canonical_concepts", []),
            "expected_information_gain": orientation.get("expected_information_gain", []),
            "does_not_prove": orientation.get("does_not_prove", []),
            "authority": orientation.get("authority"),
            "detail_contract": {
                "level": "compact_recoverable",
                "full_semantic_orientation_available_with_depth": "deep",
            },
        }
    if AGENT_COMMUNICATION_AVAILABLE:
        normalized_handoff = normalize_skill_handoff(
            semantics.get("skill_handoff", {}),
            capability_selection_stage=str(capability_selection.get("stage") or ""),
            target_resolution_state=str((target_resolution.get("resolution") or {}).get("state") or ""),
        )
        semantics["skill_handoff"] = normalized_handoff
        agent_decision_frame = build_agent_decision_frame(
            work_status="recovery_required" if recovery_required else "ready",
            target_resolution=target_resolution_projection,
            evidence_need_derivation=evidence_need_projection,
            capability_selection=capability_selection_projection,
            proof_gate=proof_projection,
            skill_handoff=normalized_handoff,
            engine_answer=_engine_answer_summary(
                target_orientation,
                terms=(
                    list((target_resolution.get("task_seed") or {}).get("terms") or [])
                    + list((target_resolution.get("task_seed") or {}).get("path_or_identifier_hints") or [])
                ),
                target_resolved=str(
                    (target_resolution.get("resolution") or {}).get("state") or ""
                ) in ("RESOLVED", "MULTI_TARGET_RESOLVED"),
            ),
        )
    else:
        agent_decision_frame = {}
    if frame_only:
        handoff = dict(semantics.get("skill_handoff") or {})
        handoff_frame = {k: v for k, v in handoff.items() if k != "inline_contract"}
        if isinstance(agent_decision_frame, dict) and isinstance(agent_decision_frame.get("skill_handoff"), dict):
            frame_handoff = dict(agent_decision_frame["skill_handoff"])
            delivery = dict(frame_handoff.get("inline_contract_delivery") or {})
            if delivery:
                delivery["status"] = "OMITTED_IN_FRAME_ONLY"
                delivery["detail_location"] = "omit --frame-only to retrieve inline_contract"
                frame_handoff["inline_contract_delivery"] = delivery
                agent_decision_frame = dict(agent_decision_frame)
                agent_decision_frame["skill_handoff"] = frame_handoff
        target_res_frame = {
            "schema_version": target_resolution.get("schema_version"),
            "stage": target_resolution.get("stage"),
            "resolution": {
                "state": (target_resolution.get("resolution") or {}).get("state"),
                "selected_targets": list((target_resolution.get("resolution") or {}).get("selected_targets") or []),
                "reason": (target_resolution.get("resolution") or {}).get("reason"),
            },
            "authority": target_resolution.get("authority", {}),
        }
        ui_handoff_frame = dict(ui_source_handoff) if isinstance(ui_source_handoff, dict) else ui_source_handoff
        if isinstance(ui_handoff_frame, dict) and isinstance(ui_handoff_frame.get("candidates"), list):
            raw_ui_cands = ui_handoff_frame["candidates"]
            if len(raw_ui_cands) > 2:
                ui_handoff_frame["candidates"] = raw_ui_cands[:2]
                ui_handoff_frame["candidates_omitted_in_frame"] = len(raw_ui_cands) - 2
        return {
            "schema_version": "4.2.0-agent-work",
            "mode": "work",
            "frame_only": True,
            "work_status": "recovery_required" if recovery_required else "ready",
            "work_status_scope": "reference_pack_status_only",
            "readiness": {
                "reference_pack": "RECOVERY_REQUIRED" if recovery_required else "READY",
                "action": agent_decision_frame.get("action_readiness", "NOT_ESTABLISHED"),
                "task_postcondition": "UNPROVEN",
            },
            "task": task,
            "scan_root": scan_root,
            "agent_decision_frame": agent_decision_frame,
            "ui_source_handoff": ui_handoff_frame,
            "skill_handoff": handoff_frame,
            "target_resolution": target_res_frame,
            "stop_reason": stop_reason,
            "authority": plan.get("authority", {}),
            "detail_contract": {
                "level": "frame_only",
                "full_work_pack_command": f"plw work {task} {scan_root} --json",
            },
        }
    return {
        "schema_version": "4.2.0-agent-work",
        "mode": "work",
        "work_status": "recovery_required" if recovery_required else "ready",
        "work_status_scope": "reference_pack_status_only",
        "readiness": {
            "reference_pack": "RECOVERY_REQUIRED" if recovery_required else "READY",
            "action": agent_decision_frame.get("action_readiness", "NOT_ESTABLISHED"),
            "task_postcondition": "UNPROVEN",
        },
        "task": task,
        "scan_root": scan_root,
        "agent_decision_frame": agent_decision_frame,
        "target_orientation": target_orientation,
        "ui_source_handoff": ui_source_handoff,
        "target_resolution": target_resolution_projection,
        "evidence_need_derivation": evidence_need_projection,
        "capability_selection": capability_selection_projection,
        **semantics,
        "adaptive_plan": plan,
        "call_reduction": call_reduction,
        "graph_cache": graph.get("cache", {}),
        "analyzer_cache": analyzer_output.get("cache", {}),
        "context": context_projection,
        "target_evidence": target_evidence,
        **(
            {"analysis_summary": analysis_summary}
            if plan.get("include_analysis_summary")
            else {}
        ),
        "finding_projection": finding_projection,
        "proof_gate": proof_projection,
        "state_effect_contract": plan.get("state_effect_contract", {}),
        "authority": plan.get("authority", {}),
    }


def kernel_establish(
    scan_root: str = ".",
    baseline_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Establish topological baseline via decoder_steering."""
    if not STEERING_AVAILABLE:
        return {"error": "steering module not available"}
    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    graph = _build_kernel_graph(scan_root)
    analyzer_output = _run_kernel_analyzers(
        graph,
        ["hott.manifold", "topo.test_reachability"],
    )
    result = establish_baseline(
        scan_root,
        baseline_path,
        shared_graph=graph,
        analyzer_output=analyzer_output,
    )
    return {
        "schema_version": "3.0.0-kernel",
        "graph_cache": graph.get("cache", {}),
        "analyzer_cache": analyzer_output.get("cache", {}),
        **result,
    }


def _compute_topological_health_score(analyzer_output: Dict[str, Any], total_files: int) -> float:
    """Hitung health score (0.0 to 1.0] dari seluruh 13 analyzer."""
    if total_files <= 0:
        return 1.0
    weights = {"high": 3, "medium": 2, "low": 1, "info": 0}
    weighted_sum = 0
    results = analyzer_output.get("results", {})
    for res in results.values():
        for finding in res.get("findings", []):
            sev = finding.get("severity", "info")
            weighted_sum += weights.get(sev, 0)

    pressure = weighted_sum / max(1, total_files)
    return round(1.0 / (1.0 + pressure), 3)


def _detect_cross_analyzer_correlations(
    graph: Dict[str, Any],
    analyzer_output: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Deteksi korelasi lintas analyzer (gluing synthesis)."""
    correlations: List[Dict[str, Any]] = []
    results = analyzer_output.get("results", {})

    # 1. Isomorphic types across boundaries
    iso_res = results.get("hott.isomorphism", {}).get("findings", [])
    if iso_res:
        for finding in iso_res:
            if finding.get("type") == "structural_isomorphism":
                file_a = finding.get("file", "")
                file_b = finding.get("file_b", "")
                space_a = finding.get("space_a", {})
                space_b = finding.get("space_b", {})
                correlations.append({
                    "type": "boundary_isomorphism",
                    "severity": "low",
                    "file": file_a,
                    "file_b": file_b,
                    "type_name_a": space_a.get("name", "unknown"),
                    "type_name_b": space_b.get("name", "unknown"),
                    "isomorphism_confidence": finding.get("isomorphism_confidence", 0.0),
                    "observation": (
                        f"Isomorphic types '{space_a.get('name')}' ({file_a}) and "
                        f"'{space_b.get('name')}' ({file_b}) reside in a boundary structure. "
                        f"Type duplication correlates with boundary surface."
                    ),
                })

    # 2. Orphan files with performance issues
    orphan_res = results.get("topo.orphan", {}).get("findings", [])
    orphan_files = {f.get("file") for f in orphan_res if f.get("file")}
    if orphan_files:
        for analyzer_name in ("perf.async", "perf.cache", "perf.deopt", "perf.gc", "topo.risk"):
            for finding in results.get(analyzer_name, {}).get("findings", []):
                f_path = finding.get("file")
                if f_path and f_path in orphan_files and finding.get("severity") in ("high", "medium"):
                    correlations.append({
                        "type": "orphan_with_issues",
                        "severity": finding.get("severity", "medium"),
                        "file": f_path,
                        "analyzer": analyzer_name,
                        "issue_type": finding.get("type"),
                        "observation": f"Orphan file '{f_path}' has high/medium finding ({finding.get('type')}) from '{analyzer_name}'.",
                    })

    # 3. Entrypoints with high risk or perf issues
    risk_res = results.get("topo.risk", {}).get("findings", [])
    for finding in risk_res:
        if finding.get("risk_level") == "high":
            f_path = finding.get("file")
            correlations.append({
                "type": "entrypoint_high_risk",
                "severity": "high",
                "file": f_path,
                "reasons": finding.get("reasons", []),
                "observation": f"High change risk detected on '{f_path}' affecting entrypoints.",
            })

    # 4. Change risk without a static test-import witness
    test_reachability = results.get("topo.test_reachability", {})
    unreachable_from_tests = set(test_reachability.get("unreachable_sources", []))
    for finding in risk_res:
        f_path = finding.get("file")
        risk_level = finding.get("risk_level")
        if f_path in unreachable_from_tests and risk_level in ("high", "medium"):
            correlations.append({
                "type": "change_risk_without_test_path",
                "severity": risk_level,
                "file": f_path,
                "risk_score": finding.get("risk_score", 0),
                "risk_reasons": finding.get("reasons", []),
                "test_model": "static_test_import_reachability",
                "observation": (
                    f"'{f_path}' has {risk_level} change risk but no static import "
                    "path from a supported test file. This is not runtime coverage evidence."
                ),
            })

    correlations.sort(key=lambda c: (c.get("severity", ""), c.get("type", ""), c.get("file", "")))
    return correlations


def kernel_synthesize(
    scan_root: str = ".",
    output_mode: str = "full",
    analyzer_names: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Synthesis: SEMUA 13 analyzer + fingerprint + health + correlations.
    Menggunakan analyzer_registry.
    """
    if not SHARED_GRAPH_AVAILABLE or not REGISTRY_AVAILABLE:
        return {"error": "required modules not available", "available": False}

    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    output_error = _validate_output_mode(
        output_mode,
        ("full", "summary", "findings"),
    )
    if output_error:
        return output_error

    # Step 1: Build SharedGraph (1x scan)
    graph = _build_kernel_graph(scan_root)

    # Step 2: Run ALL 13 analyzers
    analyzer_output = _run_kernel_analyzers(graph, analyzer_names)
    results = analyzer_output.get("results", {})

    # Step 3: Fingerprint via invariant_encoder
    fingerprint = None
    if ENCODER_AVAILABLE:
        enc_res = encode_topological_invariants(
            scan_root,
            shared_graph=graph,
            analyzer_output=analyzer_output,
        )
        if enc_res.get("available"):
            fingerprint = enc_res.get("topological_fingerprint")

    if not fingerprint and "hott.manifold" in results:
        manifold_data = results["hott.manifold"].get("manifold", {})
        fingerprint = {
            "signature_hash": "sha256:unknown",
            "complexity_score": manifold_data.get("complexity_score", 0.0),
            "structural_archetype": manifold_data.get("structural_archetype", "unknown"),
        }

    # Step 4: Compute health score & correlations
    total_files = graph.get("summary", {}).get("total_files", 0)
    health_score = _compute_topological_health_score(analyzer_output, total_files)
    correlations = _detect_cross_analyzer_correlations(graph, analyzer_output)

    # Step 5: Unified summary
    unified_summary = {
        "total_files": total_files,
        "total_edges": graph.get("summary", {}).get("total_edges", 0),
        "total_boundaries": graph.get("summary", {}).get("total_boundaries", 0),
        "total_type_shapes": graph.get("summary", {}).get("total_type_shapes", 0),
        "entrypoint_count": graph.get("summary", {}).get("entrypoint_count", 0),
        "test_file_count": graph.get("summary", {}).get("test_file_count", 0),
        "total_findings": sum(len(r.get("findings", [])) for r in results.values()),
        "findings_by_severity": _count_findings_by_severity(analyzer_output),
        "correlation_count": len(correlations),
        "analyzers_run": analyzer_output.get("analyzers_run", 0),
        "analyzers_failed": analyzer_output.get("analyzers_failed", 0),
        "topological_health_score": health_score,
        "analyzer_errors": analyzer_output.get("errors", {}),
        **_analysis_status(
            total_files,
            analyzer_output.get("analyzers_failed", 0),
        ),
    }

    if output_mode == "summary":
        return {
            "schema_version": "3.0.0-kernel",
            "mode": "synthesize",
            "scan_root": scan_root,
            "graph_cache": graph.get("cache", {}),
            "analyzer_cache": analyzer_output.get("cache", {}),
            "fingerprint": fingerprint,
            "topological_health_score": health_score,
            "correlations": correlations,
            "unified_summary": unified_summary,
        }
    elif output_mode == "findings":
        return {
            "schema_version": "3.0.0-kernel",
            "mode": "synthesize",
            "scan_root": scan_root,
            "graph_cache": graph.get("cache", {}),
            "analyzer_cache": analyzer_output.get("cache", {}),
            "fingerprint": fingerprint,
            "topological_health_score": health_score,
            "correlations": correlations,
            "unified_summary": unified_summary,
            "analyzers": analyzer_output,
        }
    else:  # "full"
        graph_output = {k: v for k, v in graph.items() if k != "file_map"}
        return {
            "schema_version": "3.0.0-kernel",
            "mode": "synthesize",
            "scan_root": scan_root,
            "graph_cache": graph.get("cache", {}),
            "analyzer_cache": analyzer_output.get("cache", {}),
            "shared_graph": graph_output,
            "fingerprint": fingerprint,
            "topological_health_score": health_score,
            "correlations": correlations,
            "unified_summary": unified_summary,
            "analyzers": analyzer_output,
        }


def kernel_steer(
    scan_root: str = ".",
    baseline_path: Optional[str] = None,
    output_mode: str = "full",
) -> Dict[str, Any]:
    """Topological decoder steering via decoder_steering."""
    if not STEERING_AVAILABLE:
        return {"error": "steering module not available"}

    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    output_error = _validate_output_mode(output_mode, ("full", "summary"))
    if output_error:
        return output_error

    graph = _build_kernel_graph(scan_root)
    analyzer_output = _run_kernel_analyzers(
        graph,
        ["hott.manifold", "topo.test_reachability"],
    )
    result = steer_decoder(
        scan_root,
        baseline_path,
        shared_graph=graph,
        analyzer_output=analyzer_output,
    )

    if output_mode == "summary":
        return {
            "schema_version": "3.0.0-kernel",
            "mode": "steer",
            "scan_root": scan_root,
            "graph_cache": graph.get("cache", {}),
            "analyzer_cache": analyzer_output.get("cache", {}),
            "baseline": result.get("baseline"),
            "summary": result.get("summary"),
            "steering_signals": result.get("steering_signals"),
            "cycle_semantics": result.get("cycle_semantics"),
            "test_topology": result.get("test_topology"),
            "steering_prompt_block": result.get("steering_prompt_block"),
        }

    return {
        "schema_version": "3.0.0-kernel",
        "mode": "steer",
        "graph_cache": graph.get("cache", {}),
        "analyzer_cache": analyzer_output.get("cache", {}),
        **result,
    }


# --- Task-pipeline receipts (B2-remainder: receipt bias) -------------------
# Every task-routing stage issues a receipt and names the next stage, so an
# agent can see the receipt exists and carry it forward. The next stage
# accepts --receipt and validates it (task + stage order + root). Receipts
# are deterministic (no timestamp): fingerprint = sha256 of
# stage + "\n" + task + "\n" + (scan_root or "").

_TASK_RECEIPT_SCHEMA = "plw-task-receipt-v1"

# stage -> (allowed previous stages, next stage or None)
_TASK_PIPELINE = {
    "orient": ((), "resolve-target"),
    "work": ((), "resolve-target"),
    "resolve-target": (("orient", "work", "semantic-route"), "evidence-needs"),
    "evidence-needs": (("resolve-target",), "capability-match"),
    "capability-match": (("evidence-needs",), "candidate-select"),
    "candidate-select": (("capability-match",), None),
    "candidate-capability-match": (("capability-match",), None),
    "semantic-route": (("orient", "work"), "resolve-target"),
}

_TASK_RECEIPT_COMMANDS = {
    "orient": "plw agent orient",
    "work": "plw work",
    "resolve-target": "plw resolve-target",
    "evidence-needs": "plw evidence-needs",
    "capability-match": "plw capability-match",
    "candidate-select": "plw candidate select",
    "candidate-capability-match": "plw candidate capability-match",
    "semantic-route": "plw semantic route",
}


_TASK_RECEIPT_SEAL_KEYS = (
    "schema_version",
    "stage",
    "task",
    "normalized_task",
    "scan_root",
    "resolved_scan_root",
    "fingerprint",
    "graph_signature",
    "result_digest",
)


def _normalize_receipt_task(task: Any) -> str:
    return " ".join(str(task or "").split())


def _extract_result_graph_signature(result: Optional[Dict[str, Any]]) -> Optional[str]:
    if not isinstance(result, dict):
        return None
    for candidate in (
        (result.get("graph_cache") or {}).get("graph_content_signature"),
        (result.get("target_orientation") or {}).get("graph_content_signature"),
        (result.get("target_resolution") or {}).get("graph_content_signature"),
        (result.get("evidence_need_derivation") or {}).get("graph_content_signature"),
        (result.get("discovery_binding") or {}).get("shared_graph_content_signature"),
    ):
        if isinstance(candidate, str) and candidate.startswith("sha256:"):
            return candidate
    return None


def _current_graph_signature(
    scan_root: Optional[str],
    result: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    if scan_root is None:
        return None
    from_result = _extract_result_graph_signature(result)
    if from_result:
        return from_result
    try:
        if GRAPH_CACHE_AVAILABLE:
            status = get_graph_cache_status(scan_root)
            sig = status.get("graph_content_signature")
            if status.get("status") == "valid" and isinstance(sig, str) and sig.startswith("sha256:"):
                return sig
        graph = _build_kernel_graph(scan_root)
        sig = (graph.get("cache") or {}).get("graph_content_signature")
        if isinstance(sig, str) and sig.startswith("sha256:"):
            return sig
        if graph_content_signature is not None:
            return graph_content_signature(graph)
    except Exception:
        return None
    return None


def _compute_stage_result_digest(
    stage: str,
    result: Optional[Dict[str, Any]],
) -> Optional[str]:
    if not isinstance(result, dict):
        return None
    if stage in ("orient", "work", "resolve-target"):
        res = (result.get("target_resolution") or {}).get("resolution") or {}
        core: Dict[str, Any] = {
            "stage": stage,
            "state": res.get("state"),
            "selected_targets": list(res.get("selected_targets") or []),
        }
    elif stage == "evidence-needs":
        deriv = result.get("evidence_need_derivation") or {}
        core = {
            "stage": stage,
            "needs": [
                row.get("need")
                for row in (deriv.get("evidence_needed") or [])
                if isinstance(row, dict)
            ],
        }
    elif stage == "capability-match":
        sel = result.get("capability_selection") or {}
        core = {
            "stage": stage,
            "candidates": [
                row.get("capability")
                for row in (sel.get("candidate_capabilities") or [])
                if isinstance(row, dict)
            ],
        }
    elif stage in ("candidate-select", "candidate-capability-match"):
        csel = result.get("candidate_selection") or {}
        core = {
            "stage": stage,
            "resolution": csel.get("resolution"),
            "selected_candidate_id": csel.get("selected_candidate_id"),
            "candidate_set_digest": csel.get("candidate_set_digest"),
        }
    elif stage == "semantic-route":
        core = {
            "stage": stage,
            "capability": result.get("capability"),
            "skill_path": result.get("skill_path"),
        }
    else:
        core = {"stage": stage}
    serialized = json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _task_receipt_seal_core(receipt_body: Dict[str, Any]) -> Dict[str, Any]:
    return {key: receipt_body.get(key) for key in _TASK_RECEIPT_SEAL_KEYS}


def _task_receipt_fingerprint(stage, task, scan_root):
    material = stage + "\n" + task + "\n" + (scan_root or "")
    return "sha256:" + hashlib.sha256(material.encode("utf-8")).hexdigest()


def _task_receipt(
    stage,
    task,
    scan_root,
    *,
    graph_signature: Optional[str] = None,
    result_digest: Optional[str] = None,
):
    resolved_scan_root = os.path.abspath(scan_root) if scan_root is not None else None
    norm_task = _normalize_receipt_task(task)
    fp = _task_receipt_fingerprint(stage, task, scan_root)
    if graph_signature is None and scan_root is not None:
        graph_signature = _current_graph_signature(scan_root)
    body: Dict[str, Any] = {
        "schema_version": _TASK_RECEIPT_SCHEMA,
        "stage": stage,
        "task": task,
        "normalized_task": norm_task,
        "scan_root": scan_root,
        "resolved_scan_root": resolved_scan_root,
        "fingerprint": fp,
        "graph_signature": graph_signature,
        "result_digest": result_digest,
    }
    try:
        from core.accountability_provenance import TASK_RECEIPT_ISSUER, seal_payload
        body["provenance"] = seal_payload(_task_receipt_seal_core(body), TASK_RECEIPT_ISSUER)
    except Exception:
        body["provenance"] = None
    return body


def _task_next(stage, task, scan_root):
    nxt = _TASK_PIPELINE[stage][1]
    if nxt is None:
        return None
    cmd = _TASK_RECEIPT_COMMANDS[nxt]
    args = [task] if scan_root is None else [task, scan_root]
    return {"command": cmd, "args": args, "stage": nxt}


def _attach_task_receipt(
    result,
    stage,
    task,
    scan_root,
    *,
    inherited_graph_signature: Optional[str] = None,
):
    """Add receipt+next to a successful stage result (new dict)."""
    if not isinstance(result, dict) or result.get("error"):
        return result
    out = dict(result)
    graph_sig = inherited_graph_signature or _current_graph_signature(scan_root, out)
    res_digest = _compute_stage_result_digest(stage, out)
    out["receipt"] = _task_receipt(
        stage,
        task,
        scan_root,
        graph_signature=graph_sig,
        result_digest=res_digest,
    )
    out["next"] = _task_next(stage, task, scan_root)
    return out


def kernel_task_chain(
    scan_root: str,
    task: str,
    *,
    target_files: Optional[List[str]] = None,
    top_n: int = 8,
    neighborhood_limit: int = 8,
    include_candidates: bool = False,
    goal: str = "auto",
    depth: str = "auto",
    ui_selector: Optional[str] = None,
    full_engine: bool = False,
    full_engine_edges: bool = False,
    frame_only: bool = False,
) -> Dict[str, Any]:
    """Execute the full task pipeline in-process with shared graph reuse and HMAC receipt chaining."""
    root_error = _validate_scan_root(scan_root)
    if root_error:
        return root_error
    if not isinstance(task, str) or not task.strip():
        return _kernel_error("empty_chain_task", "Task chain requires a non-empty task.")

    # Warm the SharedGraph once in-process so all stages reuse the same snapshot.
    graph = _build_kernel_graph(scan_root)
    graph_sig = (graph.get("cache") or {}).get("graph_content_signature") or (
        graph_content_signature(graph) if graph_content_signature is not None else None
    )

    orient_raw = kernel_work(
        scan_root=scan_root,
        task=task,
        target_files=target_files or None,
        goal=goal,
        depth=depth,
        ui_selector=ui_selector,
        full_engine=full_engine,
        full_engine_edges=full_engine_edges,
        frame_only=frame_only,
    )
    if orient_raw.get("error"):
        return orient_raw
    try:
        from core.portable_agent import (
            doctor as portable_doctor,
            dynamic_context as portable_dynamic_context,
            orientation_surface as portable_orientation_surface,
        )
        support = (portable_doctor(scan_root).get("target_support", {}) or {})
        orient_raw = dict(orient_raw)
        orient_raw["portable_agent_surface"] = portable_orientation_surface()
        orient_raw["target_support"] = support
        orient_raw["dynamic_context"] = portable_dynamic_context(scan_root)
        reason = str(support.get("reason") or "")
        if support.get("topology_ready"):
            portable_state = "TARGET_TOPOLOGY_READY"
        elif reason == "NO_STABLE_TOPOLOGY_SOURCE_FILES":
            portable_state = "TARGET_TOPOLOGY_LANGUAGE_UNSUPPORTED"
        else:
            portable_state = "TARGET_TOPOLOGY_UNAVAILABLE"
        orient_raw["portable_agent_state"] = portable_state
        orient_raw["portable_agent_reason"] = reason
    except Exception:
        pass
    orient_res = _attach_task_receipt(
        orient_raw, "orient", task, scan_root, inherited_graph_signature=graph_sig
    )

    resolve_raw = kernel_resolve_target(
        scan_root,
        task,
        target_files=target_files or None,
        top_n=top_n,
        neighborhood_limit=neighborhood_limit,
    )
    if resolve_raw.get("error"):
        return resolve_raw
    resolve_res = _attach_task_receipt(
        resolve_raw, "resolve-target", task, scan_root, inherited_graph_signature=graph_sig
    )

    evidence_raw = kernel_evidence_needs(
        scan_root,
        task,
        target_files=target_files or None,
        top_n=top_n,
        neighborhood_limit=neighborhood_limit,
    )
    if evidence_raw.get("error"):
        return evidence_raw
    evidence_res = _attach_task_receipt(
        evidence_raw, "evidence-needs", task, scan_root, inherited_graph_signature=graph_sig
    )

    cap_raw = kernel_capability_match(
        scan_root,
        task,
        target_files=target_files or None,
        top_n=top_n,
        neighborhood_limit=neighborhood_limit,
    )
    if cap_raw.get("error"):
        return cap_raw
    cap_res = _attach_task_receipt(
        cap_raw, "capability-match", task, scan_root, inherited_graph_signature=graph_sig
    )

    stages_executed = ["orient", "resolve-target", "evidence-needs", "capability-match"]
    receipt_chain = [
        orient_res.get("receipt"),
        resolve_res.get("receipt"),
        evidence_res.get("receipt"),
        cap_res.get("receipt"),
    ]
    final_receipt = cap_res.get("receipt")
    final_next = cap_res.get("next")
    cand_summary = None

    if include_candidates:
        try:
            from core.candidate_provenance import run_candidate_provenance
            cand_raw = run_candidate_provenance(
                scan_root,
                task,
                include_capability_match=True,
            )
            cand_res = _attach_task_receipt(
                cand_raw,
                "candidate-capability-match",
                task,
                scan_root,
                inherited_graph_signature=graph_sig,
            )
            stages_executed.append("candidate-capability-match")
            receipt_chain.append(cand_res.get("receipt"))
            final_receipt = cand_res.get("receipt")
            final_next = cand_res.get("next")
            cand_summary = {
                "candidate_selection": cand_res.get("candidate_selection"),
                "candidate_capability_match": cand_res.get("candidate_capability_match"),
                "discovery_binding": cand_res.get("discovery_binding"),
            }
        except Exception as exc:
            cand_summary = {"error": f"candidate_provenance_failed:{type(exc).__name__}:{exc}"}

    if frame_only:
        tr = resolve_res.get("target_resolution") or {}
        tr_res = tr.get("resolution") if isinstance(tr.get("resolution"), dict) else {}
        compact_tr = {
            "stage": tr.get("stage"),
            "status": tr_res.get("state") or tr.get("status") or tr.get("stage"),
            "reason": tr_res.get("reason") or tr.get("reason"),
            "targets": list(tr_res.get("selected_targets") or tr.get("targets") or []),
            "explicit_targets": list(tr_res.get("explicit_targets") or tr.get("explicit_targets") or []),
            "resolution": {
                "state": tr_res.get("state") or tr.get("status"),
                "reason": tr_res.get("reason") or tr.get("reason"),
                "selected_targets": list(tr_res.get("selected_targets") or tr.get("targets") or []),
                "explicit_targets": list(tr_res.get("explicit_targets") or tr.get("explicit_targets") or []),
            },
        }
        ev = evidence_res.get("evidence_need_derivation") or {}
        ev_needed = [row for row in (ev.get("evidence_needed") or []) if isinstance(row, dict)]
        compact_ev = {
            "stage": ev.get("stage"),
            "target_resolution_state": ev.get("target_resolution_state"),
            "task_intent": ev.get("task_intent") or ev.get("stage"),
            "required_evidence": ev.get("required_evidence") or [
                row.get("evidence_class") or row.get("need")
                for row in ev_needed
                if row.get("evidence_class") or row.get("need")
            ],
            "missing_evidence": ev.get("missing_evidence") or [
                row.get("need")
                for row in ev_needed
                if row.get("need")
            ],
            "evidence_needed": [
                {
                    "need": row.get("need"),
                    "evidence_class": row.get("evidence_class"),
                    "priority": row.get("priority"),
                }
                for row in ev_needed[:6]
            ],
        }
        cs = cap_res.get("capability_selection") or {}
        cand_caps = [row for row in (cs.get("candidate_capabilities") or []) if isinstance(row, dict)]
        rec_caps = [
            row.get("capability")
            for row in cand_caps
            if row.get("capability")
        ]
        cs_summary = cs.get("summary") if isinstance(cs.get("summary"), dict) else {}
        compact_cs = {
            "stage": cs.get("stage"),
            "status": cs.get("status") or cs_summary.get("status") or cs.get("stage"),
            "selected": cs.get("selected") if cs.get("selected") is not None else (rec_caps[0] if rec_caps else None),
            "recommended_capabilities": cs.get("recommended_capabilities") or rec_caps,
            "candidate_capabilities": [
                {
                    "capability": row.get("capability"),
                    "covers_evidence_classes": row.get("covers_evidence_classes"),
                    "aggregate_score": row.get("aggregate_score"),
                }
                for row in cand_caps[:6]
            ],
            "uncovered_needs": list(cs.get("uncovered_needs") or []),
        }
        return {
            "schema_version": "plw-task-chain-v1",
            "mode": "chain",
            "frame_only": True,
            "task": task,
            "normalized_task": _normalize_receipt_task(task),
            "scan_root": os.path.abspath(scan_root),
            "graph_signature": graph_sig,
            "stages_executed": stages_executed,
            "orient": {
                "portable_agent_state": orient_res.get("portable_agent_state"),
                "portable_agent_reason": orient_res.get("portable_agent_reason"),
                "agent_decision_frame": orient_res.get("agent_decision_frame"),
                "readiness": orient_res.get("readiness"),
            },
            "target_resolution": compact_tr,
            "evidence_need_derivation": compact_ev,
            "capability_selection": compact_cs,
            "receipt": final_receipt,
            "next": final_next,
            "detail_contract": {
                "frame_only": True,
                "omitted": ["receipt_chain", "orient.dynamic_context", "orient.skill_handoff", "orient.ui_source_handoff", "candidate_provenance"],
                "full_output_hint": "omit --frame-only to retrieve full chain payload",
            },
            "authority": {
                "read_only": True,
                "single_process_receipt_chained": True,
                "hmac_provenance_sealed": True,
                "execute_runtime": False,
                "mutate_source": False,
                "commit_truth": False,
            },
        }

    return {
        "schema_version": "plw-task-chain-v1",
        "mode": "chain",
        "task": task,
        "normalized_task": _normalize_receipt_task(task),
        "scan_root": os.path.abspath(scan_root),
        "graph_signature": graph_sig,
        "stages_executed": stages_executed,
        "receipt_chain": receipt_chain,
        "orient": {
            "portable_agent_state": orient_res.get("portable_agent_state"),
            "portable_agent_reason": orient_res.get("portable_agent_reason"),
            "dynamic_context": orient_res.get("dynamic_context"),
            "agent_decision_frame": orient_res.get("agent_decision_frame"),
            "skill_handoff": orient_res.get("skill_handoff"),
            "ui_source_handoff": orient_res.get("ui_source_handoff"),
            "readiness": orient_res.get("readiness"),
        },
        "target_resolution": resolve_res.get("target_resolution"),
        "evidence_need_derivation": evidence_res.get("evidence_need_derivation"),
        "capability_selection": cap_res.get("capability_selection"),
        "candidate_provenance": cand_summary,
        "receipt": final_receipt,
        "next": final_next,
        "authority": {
            "read_only": True,
            "single_process_receipt_chained": True,
            "hmac_provenance_sealed": True,
            "execute_runtime": False,
            "mutate_source": False,
            "commit_truth": False,
        },
    }


def _root_flag_from_argv(default: str) -> str:
    """--root DIR in sys.argv wins over the positional root (B1)."""
    for index, argument in enumerate(sys.argv):
        if argument == "--root" and index + 1 < len(sys.argv):
            return sys.argv[index + 1]
    return default


_KERNEL_MAIN_HELP = {
    "tool": "hott_kernel",
    "schema_version": "4.0.0-kernel",
    "global_options": {
        "cache_mode": "--cache-mode auto|refresh|off (or AI_STUDIO_GRAPH_CACHE)",
        "memory_project_root": "--memory-project-root PATH (or AI_STUDIO_PROJECT_ROOT)",
        "memory_scope": "--memory-scope NAME (or AI_STUDIO_MEMORY_SCOPE)",
        "memory_state_dir": "--memory-state-dir PATH (or AI_STUDIO_STATE_DIR)",
    },
    "usage": {
        "work": "python3 hott_kernel.py work <task> [root] [--root DIR] [--target file[,file]] [--goal auto|understand|change|architecture|performance|runtime|history] [--depth auto|quick|standard|deep] [--frame-only]",
        "analyze": "python3 hott_kernel.py analyze [root] [--root DIR] [--analyzers a,b] [--output full|summary|findings|graph]",
        "analyzers": "python3 hott_kernel.py analyzers",
        "cache": "python3 hott_kernel.py cache status|refresh|clear [root] [--root DIR]",
        "impact": "python3 hott_kernel.py impact <file> [root] [--root DIR] [--output full|summary]",
        "outline": "python3 hott_kernel.py outline <file> [root] [--root DIR]",
        "brief": "python3 hott_kernel.py brief <file> [root] [--root DIR] [--output full|summary]",
        "cycle_break": "python3 hott_kernel.py cycle-break [root] [--root DIR] [--target FILE] [--output full|summary]",
        "context": "python3 hott_kernel.py context <query> [root] [--root DIR] [--target file[,file]] [--budget-tokens 1200] [--max-hops 2] [--detail outline|source] [--output prompt|summary|full]",
        "establish": "python3 hott_kernel.py establish [root] [--root DIR] [--baseline path]",
        "synthesize": "python3 hott_kernel.py synthesize [root] [--root DIR] [--output full|summary]",
        "steer": "python3 hott_kernel.py steer [root] [--root DIR] [--output full|summary] [--baseline path]",
        "memory_store": "python3 hott_kernel.py memory_store <type> <content> [--source src] [--importance 0.5] [--tags t1,t2]",
        "memory_recall": "python3 hott_kernel.py memory_recall [query] [--type t] [--tags t1,t2] [--limit 20]",
        "memory_analyze": "python3 hott_kernel.py memory_analyze [--analyzers a,b] [--output full|summary] [--include-historical] [--include-provenance]",
        "memory_stats": "python3 hott_kernel.py memory_stats",
        "memory_associate": "python3 hott_kernel.py memory_associate <from_id> <to_id> <type> [--strength 0.7]",
        "memory_consolidate": "python3 hott_kernel.py memory_consolidate <id1,id2,...> --content '...' [--tags t1,t2]",
        "memory_steer": "python3 hott_kernel.py memory_steer [--output full|summary]",
        "memory_establish": "python3 hott_kernel.py memory_establish",
        "memory_drift": "python3 hott_kernel.py memory_drift",
        "memory_compact": "python3 hott_kernel.py memory compact [--consolidated|--all] [--type episodic] [--dry-run|--stats|--restore <id>|--restore-all]",
        "memory_bridge": "python3 hott_kernel.py memory bridge <from_id> <to_id> [type] [--strength 0.7] [--unsafe]",
        "memory_bridge_auto": "python3 hott_kernel.py memory bridge_auto [--min-shared-tags 1] [--type semantic] [--dry-run]",
        "memory_bridge_candidates": "python3 hott_kernel.py memory bridge_candidates [--min-shared-tags 1]",
        "memory_kan": "python3 hott_kernel.py memory kan <query> [--mode lan|ran|both] [--max-depth 2]",
        "fiber_init": "python3 hott_kernel.py fiber init <task> <focus>",
        "fiber_lift": "python3 hott_kernel.py fiber lift [--query q] [--type t] [--tags t1,t2] [--max 10]",
        "fiber_descend": "python3 hott_kernel.py fiber descend <memory_id> | --all [--reason r]",
        "fiber_status": "python3 hott_kernel.py fiber status",
        "fiber_section_start": "python3 hott_kernel.py fiber section_start <name> <narrative>",
        "fiber_section_add": "python3 hott_kernel.py fiber section_add <memory_id>",
        "fiber_section_status": "python3 hott_kernel.py fiber section_status",
        "fiber_switch": "python3 hott_kernel.py fiber switch <new_task> <new_focus>",
        "fiber_transport": "python3 hott_kernel.py fiber transport <source_fiber_id> <new_task> <new_focus> [--threshold 0.6] [--max 10] [--dry-run]",
        "fiber_list_archives": "python3 hott_kernel.py fiber list_archives",
        "xanalyze": "python3 hott_kernel.py xanalyze [root] [--root DIR] [--output summary|full] [--no-store] [--analyzers a,b]",
        "xsteer": "python3 hott_kernel.py xsteer [root] [--root DIR] [--output full|summary]",
        "xcontext": "python3 hott_kernel.py xcontext <file_path>",
    },
}


def _configure_cli_memory_runtime(argv: List[str]) -> None:
    global _MEMORY_SCOPE_EXPLICIT
    runtime_options: Dict[str, Optional[str]] = {
        "project_root": None,
        "scope": None,
        "state_dir": None,
    }
    runtime_flags = {
        "--memory-project-root": "project_root",
        "--memory-scope": "scope",
        "--memory-state-dir": "state_dir",
    }
    for index, argument in enumerate(argv):
        option_name = runtime_flags.get(argument)
        if option_name is None:
            continue
        if index + 1 >= len(argv) or argv[index + 1].startswith("--"):
            _emit_cli_result(_kernel_error(
                "missing_memory_runtime_option",
                f"{argument} requires a non-empty value.",
                option=argument,
            ))
        runtime_options[option_name] = argv[index + 1]
    if any(value is not None for value in runtime_options.values()):
        if not MEMORY_RUNTIME_AVAILABLE:
            _emit_cli_result(_kernel_error(
                "memory_runtime_unavailable",
                "Memory runtime configuration is not available.",
            ))
        configure_memory_runtime(**runtime_options)
        if runtime_options["project_root"] is not None or runtime_options["scope"] is not None:
            _MEMORY_SCOPE_EXPLICIT = True


def _configure_cli_cache_mode(argv: List[str]) -> None:
    requested_cache_mode = _ACTIVE_GRAPH_CACHE_MODE
    for index, argument in enumerate(argv):
        if argument == "--cache-mode":
            if index + 1 >= len(argv):
                _emit_cli_result(_kernel_error(
                    "missing_graph_cache_mode",
                    "--cache-mode requires auto, refresh, or off.",
                    supported_cache_modes=list(CACHE_MODES),
                ))
            requested_cache_mode = argv[index + 1]
    cache_mode_error = _set_graph_cache_mode(requested_cache_mode)
    if cache_mode_error:
        _emit_cli_result(cache_mode_error)


def _cli_positional_root(argv: List[str], idx: int = 2) -> str:
    root = argv[idx] if len(argv) > idx and not argv[idx].startswith("--") else "."
    return _root_flag_from_argv(root)


def _cli_flag_value(argv: List[str], *flags: str, default: Any = None) -> Any:
    value = default
    flag_set = set(flags)
    is_output_flag = "--output" in flag_set
    if is_output_flag:
        flag_set.add("--format")
    for i, arg in enumerate(argv):
        if arg in flag_set and i + 1 < len(argv):
            value = argv[i + 1]
        elif "=" in arg:
            flag_name, _, flag_val = arg.partition("=")
            if flag_name in flag_set:
                value = flag_val
    if is_output_flag and isinstance(value, str) and value.strip().lower() == "json":
        return "full"
    return value


def _cli_float_flag(argv: List[str], flag: str, default: float) -> float:
    raw = _cli_flag_value(argv, flag)
    if raw is None:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _cli_int_flag(argv: List[str], flag: str, default: int) -> int:
    raw = _cli_flag_value(argv, flag)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _cli_work(argv: List[str]) -> None:
    if len(argv) < 3 or argv[2].startswith("--"):
        _emit_cli_result(_kernel_error(
            "missing_work_task",
            "Usage: hott_kernel.py work <task> [root] [--target file[,file]] [--goal GOAL] [--depth DEPTH] [--frame-only]",
        ))
    task = argv[2]
    root = _cli_positional_root(argv, idx=3)
    targets: List[str] = []
    goal = "auto"
    depth = "auto"
    budget_tokens = DEFAULT_BUDGET_TOKENS
    max_hops = DEFAULT_MAX_HOPS
    detail = "source"
    max_findings = 24
    proactive_truth = True
    truth_scope = None
    ui_selector = None
    full_engine = False
    full_engine_edges = False
    frame_only = False
    receipt_arg = None
    parse_error = None
    for i, arg in enumerate(argv):
        if arg in ("--target", "--targets", "--target-file", "--target-files") and i + 1 < len(argv):
            targets.extend(value.strip() for value in argv[i + 1].split(",") if value.strip())
        elif arg == "--goal" and i + 1 < len(argv):
            goal = argv[i + 1]
        elif arg == "--depth" and i + 1 < len(argv):
            depth = argv[i + 1]
        elif arg in ("--frame-only", "--frame_only"):
            frame_only = True
        elif arg in ("--budget-tokens", "--budget_tokens", "--budget") and i + 1 < len(argv):
            try:
                budget_tokens = int(argv[i + 1])
            except ValueError:
                parse_error = _kernel_error(
                    "invalid_context_budget",
                    "--budget-tokens must be an integer.",
                    budget_tokens=argv[i + 1],
                )
        elif arg in ("--max-hops", "--max_hops") and i + 1 < len(argv):
            try:
                max_hops = int(argv[i + 1])
            except ValueError:
                parse_error = _kernel_error(
                    "invalid_context_hops",
                    "--max-hops must be an integer.",
                    max_hops=argv[i + 1],
                )
        elif arg == "--detail" and i + 1 < len(argv):
            detail = argv[i + 1]
        elif arg == "--max-findings" and i + 1 < len(argv):
            try:
                max_findings = int(argv[i + 1])
            except ValueError:
                parse_error = _kernel_error(
                    "invalid_work_finding_limit",
                    "--max-findings must be an integer.",
                    max_findings=argv[i + 1],
                )
        elif arg == "--truth-scope" and i + 1 < len(argv):
            truth_scope = argv[i + 1]
        elif arg == "--ui-selector" and i + 1 < len(argv):
            ui_selector = argv[i + 1]
        elif arg == "--no-proactive-truth":
            proactive_truth = False
        elif arg == "--full-engine":
            full_engine = True
        elif arg == "--full-engine-edges":
            full_engine_edges = True
        elif arg == "--receipt" and i + 1 < len(argv):
            receipt_arg = argv[i + 1]
    if receipt_arg is not None:
        _emit_cli_result(_kernel_error(
            "receipt_not_accepted",
            "plw work is an entry stage and takes no receipt; it issues the first receipt.",
        ))
    if parse_error:
        _emit_cli_result(parse_error)
    work_result = kernel_work(
        scan_root=root,
        task=task,
        target_files=targets or None,
        goal=goal,
        depth=depth,
        budget_tokens=budget_tokens,
        max_hops=max_hops,
        detail=detail,
        max_findings=max_findings,
        proactive_truth=proactive_truth,
        truth_scope=truth_scope,
        ui_selector=ui_selector,
        full_engine=full_engine,
        full_engine_edges=full_engine_edges,
        frame_only=frame_only,
    )
    _emit_cli_result(_attach_task_receipt(work_result, "work", task, root))


def _cli_analyze(argv: List[str]) -> None:
    root = _cli_positional_root(argv, idx=2)
    analyzers_raw = _cli_flag_value(argv, "--analyzers")
    analyzers = analyzers_raw.split(",") if analyzers_raw is not None else None
    include_perf = "--include-perf" in argv
    output_mode = _cli_flag_value(argv, "--output", default="full")
    if output_mode not in ("full", "summary", "findings", "graph"):
        _emit_cli_result(_kernel_error(
            "invalid_output_mode",
            f"Invalid output mode: {output_mode}",
            output_mode=output_mode,
            supported_output_modes=["full", "summary", "findings", "graph"],
        ))
    _emit_cli_result(kernel_analyze(root, analyzers, output_mode, include_perf=include_perf))


def _cli_analyzers(_argv: List[str]) -> None:
    if REGISTRY_AVAILABLE:
        all_names = get_available_analyzers()
        default_names = get_structural_analyzers()
        default_set = set(default_names)
        _emit_cli_result({
            "available_analyzers": all_names,
            "default_check_analyzers": default_names,
            "opt_in_analyzers": [name for name in all_names if name not in default_set],
        })
    else:
        _emit_cli_result(_kernel_error("registry_unavailable", "registry not available"))


def _cli_cache(argv: List[str]) -> None:
    if len(argv) < 3 or argv[2].startswith("--"):
        _emit_cli_result(_kernel_error(
            "missing_cache_action",
            "Usage: hott_kernel.py cache status|refresh|clear [root]",
            supported_actions=["status", "refresh", "clear"],
        ))
    action = argv[2]
    root = _cli_positional_root(argv, idx=3)
    _emit_cli_result(kernel_cache(action, root))


def _normalize_target_root_pair(argv: List[str]) -> tuple:
    target = argv[2]
    root = _cli_positional_root(argv, idx=3)
    if (
        len(argv) >= 4
        and not argv[3].startswith("--")
        and os.path.isdir(target)
        and not os.path.isdir(argv[3])
    ):
        root, target = target, argv[3]
    return root, target


def _cli_impact(argv: List[str]) -> None:
    if len(argv) < 3:
        _emit_cli_result(_kernel_error(
            "missing_argument",
            "Usage: hott_kernel.py impact <file> [root]",
        ))
    root, target = _normalize_target_root_pair(argv)
    output_mode = _cli_flag_value(argv, "--output", default="full")
    _emit_cli_result(kernel_impact(root, target, output_mode))


def _cli_outline(argv: List[str]) -> None:
    if len(argv) < 3:
        _emit_cli_result(_kernel_error(
            "missing_argument",
            "Usage: hott_kernel.py outline <file> [root]",
        ))
    root, target = _normalize_target_root_pair(argv)
    _emit_cli_result(kernel_outline(root, target))


def _cli_brief(argv: List[str]) -> None:
    if len(argv) < 3:
        _emit_cli_result(_kernel_error(
            "missing_argument",
            "Usage: hott_kernel.py brief <file> [root]",
        ))
    root, target = _normalize_target_root_pair(argv)
    output_mode = _cli_flag_value(argv, "--output", default="full")
    _emit_cli_result(kernel_brief(root, target, output_mode))


def _cli_cycle_break(argv: List[str]) -> None:
    target_file = _cli_flag_value(argv, "--target", "--target-file", "--file")
    output_mode = _cli_flag_value(argv, "--output", default="full")
    flag_root = _cli_flag_value(argv, "--root")
    pos_args: List[str] = []
    skip_next = False
    for idx in range(2, len(argv)):
        if skip_next:
            skip_next = False
            continue
        arg = argv[idx]
        if arg in ("--target", "--target-file", "--file", "--output", "--format", "--root", "--cache-mode"):
            skip_next = True
            continue
        if arg.startswith("-"):
            continue
        pos_args.append(arg)
    if flag_root:
        root = flag_root
        if target_file is None and pos_args:
            target_file = pos_args[0]
    elif len(pos_args) >= 2:
        p0, p1 = pos_args[0], pos_args[1]
        if os.path.isdir(p1) and not os.path.isdir(p0):
            root = p1
            if target_file is None:
                target_file = p0
        else:
            root = p0
            if target_file is None:
                target_file = p1
    elif len(pos_args) == 1:
        root = pos_args[0]
    else:
        root = "."
    _emit_cli_result(kernel_cycle_break(root, target_file, output_mode))


def _cli_context(argv: List[str]) -> None:
    if len(argv) < 3 or argv[2].startswith("--"):
        _emit_cli_result(_kernel_error(
            "missing_argument",
            "Usage: hott_kernel.py context <query> [root] [--target file[,file]] [--budget-tokens N] [--max-hops N] [--detail outline|source] [--truth-scope ID] [--no-proactive-truth] [--output prompt|summary|full]",
        ))
    root, query = _normalize_target_root_pair(argv)
    target_files: List[str] = []
    budget_tokens = DEFAULT_BUDGET_TOKENS
    max_hops = DEFAULT_MAX_HOPS
    detail = "source"
    output_mode = "prompt"
    proactive_truth = True
    truth_scope = None
    parse_error = None
    for i, arg in enumerate(argv):
        if arg in ("--target", "--targets", "--target-file", "--target-files") and i + 1 < len(argv):
            target_files.extend(
                value.strip()
                for value in argv[i + 1].split(",")
                if value.strip()
            )
        elif arg in ("--budget-tokens", "--budget_tokens") and i + 1 < len(argv):
            try:
                budget_tokens = int(argv[i + 1])
            except ValueError:
                parse_error = _kernel_error(
                    "invalid_context_budget",
                    "--budget-tokens must be an integer.",
                    budget_tokens=argv[i + 1],
                )
        elif arg in ("--max-hops", "--max_hops") and i + 1 < len(argv):
            try:
                max_hops = int(argv[i + 1])
            except ValueError:
                parse_error = _kernel_error(
                    "invalid_context_hops",
                    "--max-hops must be an integer.",
                    max_hops=argv[i + 1],
                )
        elif arg == "--detail" and i + 1 < len(argv):
            detail = argv[i + 1]
        elif arg == "--no-proactive-truth":
            proactive_truth = False
        elif arg == "--truth-scope" and i + 1 < len(argv):
            truth_scope = argv[i + 1]
        elif arg in ("--output", "--format") and i + 1 < len(argv):
            raw_out = argv[i + 1]
            output_mode = "full" if str(raw_out).strip().lower() == "json" else raw_out
        elif arg.startswith("--output=") or arg.startswith("--format="):
            raw_out = arg.split("=", 1)[1]
            output_mode = "full" if str(raw_out).strip().lower() == "json" else raw_out
    if parse_error:
        _emit_cli_result(parse_error)
    _emit_cli_result(kernel_context(
        root,
        query,
        target_files=target_files,
        budget_tokens=budget_tokens,
        max_hops=max_hops,
        detail=detail,
        output_mode=output_mode,
        proactive_truth=proactive_truth,
        truth_scope=truth_scope,
    ))


def _cli_establish(argv: List[str]) -> None:
    root = _cli_positional_root(argv, idx=2)
    baseline_path = _cli_flag_value(argv, "--baseline")
    _emit_cli_result(kernel_establish(root, baseline_path))


def _cli_synthesize(argv: List[str]) -> None:
    root = _cli_positional_root(argv, idx=2)
    output_mode = _cli_flag_value(argv, "--output", default="full")
    _emit_cli_result(kernel_synthesize(root, output_mode))


def _cli_steer(argv: List[str]) -> None:
    root = _cli_positional_root(argv, idx=2)
    output_mode = _cli_flag_value(argv, "--output", default="full")
    baseline_path = _cli_flag_value(argv, "--baseline")
    _emit_cli_result(kernel_steer(root, baseline_path, output_mode))


def _cli_memory_operation(op: str, argv: List[str], arg_offset: int) -> bool:
    """Shared CLI parser for both legacy `memory_<op>` and `memory <op>` commands."""
    usage_prefix = "hott_kernel.py memory_" if arg_offset == 2 else "memory "

    if op == "store":
        type_aliases = {
            "episodic": "episodic",
            "event": "episodic",
            "log": "episodic",
            "observation": "episodic",
            "semantic": "semantic",
            "architectural": "semantic",
            "architecture": "semantic",
            "fact": "semantic",
            "knowledge": "semantic",
            "note": "semantic",
            "design": "semantic",
            "procedural": "procedural",
            "workflow": "procedural",
            "skill": "procedural",
            "strategy": "procedural",
            "action": "procedural",
        }
        pos_args = []
        idx = arg_offset
        while idx < len(argv):
            tok = argv[idx]
            if tok.startswith("--"):
                if tok in ("--type", "--source", "--importance", "--tags", "--content") and idx + 1 < len(argv):
                    idx += 2
                else:
                    idx += 1
                continue
            pos_args.append(tok)
            idx += 1
        flag_type = _cli_flag_value(argv, "--type")
        flag_content = _cli_flag_value(argv, "--content")
        if len(pos_args) >= 2 and pos_args[0].lower() in type_aliases:
            mem_type = type_aliases[pos_args[0].lower()]
            content = pos_args[1]
        elif len(pos_args) >= 1:
            raw_t = (flag_type or "semantic").lower()
            mem_type = type_aliases.get(raw_t, raw_t)
            content = flag_content if (flag_content and pos_args[0].lower() in type_aliases) else pos_args[0]
        elif flag_content:
            raw_t = (flag_type or "semantic").lower()
            mem_type = type_aliases.get(raw_t, raw_t)
            content = flag_content
        else:
            _emit_cli_result({"error": f"Usage: {usage_prefix}store [<type>] <content> [--type episodic|semantic|procedural] [--source src] [--importance 0.5] [--tags t1,t2]"})
            return True
        _emit_cli_result(kernel_memory_store(
            mem_type,
            content,
            _cli_flag_value(argv, "--source", default="manual"),
            _cli_float_flag(argv, "--importance", 0.5),
            _cli_flag_value(argv, "--tags"),
        ))
        return True
    if op in ("recall", "list", "search"):
        raw_q = argv[arg_offset] if len(argv) > arg_offset and not argv[arg_offset].startswith("--") else None
        query = None if (raw_q is not None and op == "list" and os.path.isdir(raw_q)) else raw_q
        _emit_cli_result(kernel_memory_recall(
            query,
            _cli_flag_value(argv, "--type"),
            _cli_flag_value(argv, "--tags"),
            _cli_int_flag(argv, "--limit", 20),
        ))
        return True
    if op == "analyze":
        analyzers_raw = _cli_flag_value(argv, "--analyzers")
        _emit_cli_result(kernel_memory_analyze(
            analyzers_raw.split(",") if analyzers_raw is not None else None,
            _cli_flag_value(argv, "--output", default="full"),
            include_historical="--include-historical" in argv,
            include_provenance="--include-provenance" in argv,
        ))
        return True
    if op in ("stats", "status"):
        _emit_cli_result(kernel_memory_stats())
        return True
    if op == "associate":
        if len(argv) < arg_offset + 3:
            _emit_cli_result({"error": f"Usage: {usage_prefix}associate <from_id> <to_id> <type> [--strength 0.7]"})
            return True
        _emit_cli_result(kernel_memory_associate(
            argv[arg_offset],
            argv[arg_offset + 1],
            argv[arg_offset + 2],
            _cli_float_flag(argv, "--strength", 0.5),
        ))
        return True
    if op == "consolidate":
        content = _cli_flag_value(argv, "--content", default="")
        raw_ids = argv[arg_offset] if len(argv) > arg_offset and not argv[arg_offset].startswith("--") else None
        if not content and (raw_ids is None or os.path.isdir(raw_ids)):
            _emit_cli_result(kernel_memory_consolidate_auto(
                _cli_int_flag(argv, "--min-size", 3),
                _cli_float_flag(argv, "--importance", 0.9),
            ))
            return True
        if not raw_ids:
            _emit_cli_result({"error": f"Usage: {usage_prefix}consolidate [<id1,id2,...> --content '...'] [--min-size 3]"})
            return True
        if not content:
            _emit_cli_result({"error": "--content is required"})
            return True
        _emit_cli_result(kernel_memory_consolidate(
            raw_ids.split(","),
            content,
            _cli_flag_value(argv, "--tags"),
            _cli_float_flag(argv, "--importance", 0.9),
        ))
        return True
    if op == "steer":
        _emit_cli_result(kernel_memory_steer(_cli_flag_value(argv, "--output", default="full")))
        return True
    if op == "establish":
        _emit_cli_result(kernel_memory_establish())
        return True
    if op == "drift":
        _emit_cli_result(kernel_memory_drift())
        return True
    if op == "get":
        if len(argv) < 4:
            _emit_cli_result({"error": "Usage: memory get <memory_id>"})
            return True
        _emit_cli_result(kernel_memory_get(argv[3]))
        return True
    if op == "betti_breakdown":
        _emit_cli_result(kernel_memory_betti_breakdown())
        return True
    if op == "consolidate_by_tag":
        if len(argv) < 4:
            _emit_cli_result({"error": "Usage: memory consolidate_by_tag <tag> [--content '...'] [--importance 0.9]"})
            return True
        _emit_cli_result(kernel_memory_consolidate_by_tag(
            argv[3],
            _cli_flag_value(argv, "--content"),
            _cli_float_flag(argv, "--importance", 0.9),
        ))
        return True
    if op == "consolidate_auto":
        _emit_cli_result(kernel_memory_consolidate_auto(
            _cli_int_flag(argv, "--min-size", 3),
            _cli_float_flag(argv, "--importance", 0.9),
        ))
        return True
    if op == "unconsolidated_tags":
        _emit_cli_result(kernel_memory_unconsolidated_tags())
        return True
    if op == "compact":
        only_consolidated = True
        memory_type = "episodic"
        dry_run = False
        restore_all = False
        restore_id = None
        stats = False
        i = 3
        while i < len(argv):
            arg = argv[i]
            if arg == "--consolidated":
                only_consolidated = True
            elif arg == "--all":
                only_consolidated = False
            elif arg == "--type" and i + 1 < len(argv):
                memory_type = argv[i + 1]
                i += 1
            elif arg == "--dry-run":
                dry_run = True
            elif arg == "--restore-all":
                restore_all = True
            elif arg == "--restore" and i + 1 < len(argv):
                restore_id = argv[i + 1]
                i += 1
            elif arg == "--stats":
                stats = True
            i += 1
        _emit_cli_result(kernel_memory_compact(
            only_consolidated=only_consolidated,
            memory_type=memory_type,
            dry_run=dry_run,
            restore_id=restore_id,
            restore_all=restore_all,
            stats=stats,
        ))
        return True
    if op == "bridge":
        if len(argv) < 5:
            _emit_cli_result({"error": "Usage: memory bridge <from_id> <to_id> [type] [--strength 0.7]"})
            return True
        assoc_type = argv[5] if len(argv) > 5 and not argv[5].startswith("--") else "semantic"
        _emit_cli_result(kernel_memory_bridge(
            argv[3],
            argv[4],
            assoc_type,
            _cli_float_flag(argv, "--strength", 0.7),
            "--unsafe" not in argv,
        ))
        return True
    if op == "bridge_auto":
        _emit_cli_result(kernel_memory_bridge_auto(
            _cli_int_flag(argv, "--min-shared-tags", 1),
            _cli_flag_value(argv, "--type", default="semantic"),
            "--unsafe" not in argv,
            "--dry-run" in argv,
        ))
        return True
    if op == "bridge_candidates":
        _emit_cli_result(kernel_memory_bridge_candidates(
            _cli_int_flag(argv, "--min-shared-tags", 1)
        ))
        return True
    if op == "kan":
        if len(argv) < 4:
            _emit_cli_result({"error": "Usage: memory kan <query> [--mode lan|ran|both] [--max-depth 2]"})
            return True
        kan_mode = _cli_flag_value(argv, "--mode", default="both")
        if kan_mode not in ("lan", "ran", "both"):
            _emit_cli_result({"error": f"Invalid mode: {kan_mode}. Use lan, ran, or both."})
            return True
        _emit_cli_result(kernel_memory_kan(
            argv[3],
            kan_mode,
            _cli_int_flag(argv, "--max-depth", 2),
        ))
        return True
    return False


def _cli_memory(argv: List[str]) -> None:
    if len(argv) < 3 or argv[2] in ("-h", "--help", "help"):
        _emit_cli_result({
            "tool": "hott_kernel",
            "schema_version": "4.0.0-kernel",
            "mode": "memory",
            "usage": "plw memory <submode> [...]",
            "submodes": [
                "status", "stats", "list", "search", "recall", "store", "get",
                "associate", "consolidate", "consolidate-auto", "consolidate-by-tag",
                "compact", "drift", "establish", "analyze", "steer",
                "bridge", "bridge-candidates", "bridge-auto", "kan",
            ],
            "examples": [
                "plw memory status . --json",
                "plw memory list . --json",
                "plw memory store 'Note text' --type semantic --tags tag1,tag2 --json",
                "plw memory search 'query' --json",
                "plw memory get <memory_id> --json",
                "plw memory drift . --json",
                "plw memory consolidate . --json",
            ],
        })
        return
    submode = argv[2].lower().replace("-", "_")
    if not _cli_memory_operation(submode, argv, arg_offset=3):
        _emit_cli_result({"error": f"Unknown memory submode: {argv[2]}"})


def _cli_xanalyze(argv: List[str]) -> None:
    root = _cli_positional_root(argv, idx=2)
    analyzers_raw = _cli_flag_value(argv, "--analyzers")
    _emit_cli_result(kernel_xanalyze(
        root,
        analyzers_raw.split(",") if analyzers_raw is not None else None,
        _cli_flag_value(argv, "--output", default="summary"),
        "--no-store" not in argv,
    ))


def _cli_xsteer(argv: List[str]) -> None:
    root = _cli_positional_root(argv, idx=2)
    _emit_cli_result(kernel_xsteer(root, _cli_flag_value(argv, "--output", default="full")))


def _cli_xcontext(argv: List[str]) -> None:
    if len(argv) < 3:
        _emit_cli_result({"error": "Usage: hott_kernel.py xcontext <file_path>"})
        return
    _emit_cli_result(kernel_xcontext(argv[2]))


def _cli_fiber(argv: List[str]) -> None:
    cleaned: List[str] = []
    i = 2
    root_dir = None
    while i < len(argv):
        tok = argv[i]
        if tok == "--json":
            i += 1
            continue
        if tok == "--root" and i + 1 < len(argv):
            root_dir = argv[i + 1]
            i += 2
            continue
        if tok.startswith("--root="):
            root_dir = tok.split("=", 1)[1]
            i += 1
            continue
        cleaned.append(tok)
        i += 1
    if cleaned and os.path.isdir(cleaned[0]):
        root_dir = root_dir or cleaned.pop(0)
    elif len(cleaned) >= 2 and os.path.isdir(cleaned[-1]) and cleaned[0].replace("-", "_") in (
        "status", "stats", "info", "list", "archives", "list_archives", "section_status"
    ):
        root_dir = root_dir or cleaned.pop(-1)
    if root_dir:
        try:
            _bind_memory_scope_to_scan(root_dir)
        except Exception:
            pass
    if not cleaned:
        subcommand = "status"
        rest: List[str] = []
    else:
        subcommand = cleaned[0].lower().replace("-", "_")
        rest = cleaned[1:]
    alias_map = {
        "list": "list_archives",
        "archives": "list_archives",
        "stats": "status",
        "info": "status",
        "start_section": "section_start",
        "add_section": "section_add",
    }
    subcommand = alias_map.get(subcommand, subcommand)
    if subcommand in ("--help", "-h", "help"):
        _emit_cli_result({
            "mode": "fiber",
            "usage": "plw fiber [status|init|lift|descend|section-start|section-add|section-status|switch|transport|list-archives] [args] [--root DIR] [--json]",
        })
        return
    if subcommand == "transport":
        if len(rest) < 3:
            _emit_cli_result({
                "error": "Usage: fiber transport <source_fiber_id> <new_task> <new_focus> [--threshold 0.6] [--max 10] [--dry-run]"
            })
            return
        _emit_cli_result(kernel_fiber_transport(
            rest[0],
            rest[1],
            rest[2],
            _cli_float_flag(argv, "--threshold", 0.6),
            _cli_int_flag(argv, "--max", 10),
            "--dry-run" in argv,
        ))
    elif subcommand == "list_archives":
        _emit_cli_result(kernel_fiber_list_archives())
    else:
        _emit_cli_result(kernel_fiber(subcommand, rest))


def _memory_alias_handler(submode: str) -> Callable[[List[str]], None]:
    def _handler(argv: List[str]) -> None:
        _cli_memory_operation(submode, argv, arg_offset=2)
    return _handler


def _rewire_memory_submode_handler(submode: str) -> Callable[[List[str]], None]:
    def _handler(argv: List[str]) -> None:
        _cli_memory_operation(submode, [argv[0], "memory", submode, *argv[2:]], arg_offset=3)
    return _handler


_KERNEL_CLI_DISPATCH: Dict[str, Callable[[List[str]], None]] = {
    "work": _cli_work,
    "analyze": _cli_analyze,
    "analyzers": _cli_analyzers,
    "cache": _cli_cache,
    "impact": _cli_impact,
    "outline": _cli_outline,
    "brief": _cli_brief,
    "cycle_break": _cli_cycle_break,
    "context": _cli_context,
    "establish": _cli_establish,
    "synthesize": _cli_synthesize,
    "steer": _cli_steer,
    "memory_store": _memory_alias_handler("store"),
    "memory_recall": _memory_alias_handler("recall"),
    "memory_analyze": _memory_alias_handler("analyze"),
    "memory_stats": _memory_alias_handler("stats"),
    "memory_associate": _memory_alias_handler("associate"),
    "memory_consolidate": _memory_alias_handler("consolidate"),
    "memory_steer": _memory_alias_handler("steer"),
    "memory_establish": _memory_alias_handler("establish"),
    "memory_drift": _memory_alias_handler("drift"),
    "memory_compact": _rewire_memory_submode_handler("compact"),
    "memory_bridge": _rewire_memory_submode_handler("bridge"),
    "memory_bridge_auto": _rewire_memory_submode_handler("bridge_auto"),
    "memory_bridge_candidates": _rewire_memory_submode_handler("bridge_candidates"),
    "memory_kan": _rewire_memory_submode_handler("kan"),
    "memory": _cli_memory,
    "fiber": _cli_fiber,
    "xanalyze": _cli_xanalyze,
    "xsteer": _cli_xsteer,
    "xcontext": _cli_xcontext,
}


def main() -> None:
    if len(sys.argv) < 2 or sys.argv[1] in ("--help", "-h", "help"):
        print(json.dumps(_KERNEL_MAIN_HELP, indent=2))
        return

    _configure_cli_memory_runtime(sys.argv)
    _configure_cli_cache_mode(sys.argv)

    mode = {"cycle-break": "cycle_break"}.get(sys.argv[1], sys.argv[1])
    valid_modes = set(PUBLIC_KERNEL_MODES)
    if mode not in valid_modes:
        _emit_cli_result(_kernel_error(
            "unknown_mode",
            f"Unknown mode: '{mode}'.",
            valid_modes=sorted(valid_modes),
            suggested_fix=(
                "Use work for an ordinary agent task, or choose an explicit mode: analyze, context, synthesize, "
                "steer, impact, outline, brief, cache, memory_recall, memory_store, xanalyze, xsteer, xcontext."
            ),
        ))
        return

    if ("--help" in sys.argv[2:] or "-h" in sys.argv[2:]) and mode in _MODE_HELP_USAGE:
        print(json.dumps({
            "tool": "hott_kernel",
            "schema_version": "4.0.0-kernel",
            "mode": mode,
            "usage": _MODE_HELP_USAGE[mode],
        }, indent=2))
        return

    handler = _KERNEL_CLI_DISPATCH.get(mode)
    if handler is not None:
        handler(sys.argv)
        return

    _emit_cli_result(_kernel_error(
        "unknown_mode",
        f"Unknown mode: {mode}",
        mode=mode,
    ))



if __name__ == "__main__":
    try:
        main()
    except MemoryStateError as exc:
        _emit_cli_result(_kernel_error(
            getattr(exc, "error_code", "memory_state_error"),
            str(exc),
            **getattr(exc, "details", {}),
        ))
