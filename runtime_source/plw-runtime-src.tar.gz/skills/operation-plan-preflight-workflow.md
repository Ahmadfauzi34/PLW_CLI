# Operation Plan Preflight Workflow

**Load when:** an agent has discovered a public PLW capability and needs to bind one exact machine-readable operation contract before deciding whether to invoke it.

**Provides:** a read-only declarative preflight over `plw-operation-contract-v1` records. It validates operation identity and input bindings, preserves ambiguity, and can compile an argv list as a reference without executing it.

Plan document:

```json
{
  "schema_version": "plw-operation-plan-v1",
  "capability": "candidate",
  "operation_id": "candidate.select.v1",
  "inputs": {
    "task": "Select isOne in src/guards.js",
    "root": "/path/to/repo"
  }
}
```

Resolve from a file:
```bash
plw operation-plan resolve plan.json --json
```

or from stdin:

```bash
cat plan.json | plw operation-plan resolve - --json
```

Preflight states are deliberately separate from the eventual operation's domain outcomes:

- `RESOLVED`: exactly one public operation contract accepts the declared input binding;
- `AMBIGUOUS`: more than one operation accepts the binding and an exact operation ID is still required;
- `REJECTED`: no public operation binding accepts the plan, or its declarative schema/capability/inputs are invalid.

A resolved plan may contain `compiled_argv`, but that list is **reference data only**. Resolution grants no invocation authorization and does not execute the operation. The returned `possible_domain_outcomes` describe what a later invocation may report; preflight does not predict which outcome will occur.

The compiled list places `--json` before `--`, then preserves all positional
inputs after the delimiter. A task such as `-h` is therefore task data rather
than a CLI help flag. NUL and invalid Unicode are rejected as unrepresentable
in argv. The agent
must still decide whether to invoke the operation and inspect its domain result.

Do not convert `RESOLVED` into automatic execution. Do not guess through `AMBIGUOUS`. Do not reinterpret `REJECTED` as proof that the underlying task is impossible; it only rejects the current operation binding.
