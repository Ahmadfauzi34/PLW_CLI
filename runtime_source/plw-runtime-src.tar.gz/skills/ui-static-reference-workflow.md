# Browserless UI source reference

**Load when:** an agent has an Angular UI question but no verified browser or geometry snapshot.

```bash
plw capability describe ui-static --json
plw ui static "Sign in navigation link" /path/to/angular-project --json
plw ui static "Sign in" /path/to/angular-project --selector app-layout-header --json
plw agent orient /path/to/angular-project --task "Sign in navigation link" --json
plw agent orient /path/to/angular-project --task "Sign in navigation link" --ui-selector app-layout-header --json
```

The reference machine reuses the current TS/JS graph and Angular ownership
sidecar, reads only statically declared template resources, checks their exact
SHA-256 against the ownership result, then enumerates source text and control
attributes. Inline literal templates are checked against their source digest.
The returned `decision` is `RESOLVED` for a unique highest-scoring source
candidate, `AMBIGUOUS` for tied candidates, or `UNRESOLVED` when nothing
verified matches. Every candidate names the source owner, template, exact
digest, source line when external, and query terms that matched. A source
candidate is never a rendered element identity.

`agent orient` and `work` expose `ui_source_handoff` from the same graph
snapshot used for target resolution. Inspect `status`, `candidates`,
`unresolved_templates` and `next_ui_static_argv`. `AMBIGUOUS` and `UNRESOLVED`
have no target hint. For `RESOLVED`, check the selected template SHA-256 and
condition with `ui static`, then use `suggested_work_argv` or choose an explicit
target yourself. The hint names a component in the current TS/JS graph; it
does not silently select that target, change graph resolution, prove the
component renders, or make `work_status: ready` an action authorization. A
grounded `--ui-selector` narrows source candidates when multiple components
declare the same text. Re-run orientation after editing source to get fresh
digests.

`element.label_provenance` attributes direct text to its element and nested
text to the nearest interactive control. A layout parent does not inherit its
children's labels. `match_evidence` separates label terms, attribute terms,
and a complete label phrase in the query. Inspect `decision.selection_policy`,
`top_score_tie_count`, all `candidates`, and `omitted_candidate_count`: a
unique top score ranks source declarations, while lower-scoring controls may
still be relevant. Short query words distinguish labels such as “Sign in” and
“Sign up”; standalone short matches in attributes do not identify a control.

Read `unresolved_templates` and `omitted_candidate_count` before concluding
anything about absence. A file excluded from a bounded result may still
contain the relevant UI. A dynamic template or a changed resource remains
unresolved.

For an edit, inspect the selected template line, declared styles and relevant
global CSS. Angular control flow such as `@if`, routing, data and responsive
styles require their own witnesses. The output explicitly marks render
condition `UNPROVEN` and geometry `UNOBSERVED`. Before claiming overlap or
visual correctness, capture the exact route, viewport, UI state and fixture
with an external browser or another trusted geometry host, then use `plw ui
map` / `plw ui-reference` and runtime provenance as appropriate.

`template_condition` is a bounded source witness. It lists enclosing `@if`,
`@else`, `@for`, and `@empty` branches with their raw expressions and source
locations, plus inherited `*ngIf`, `*ngFor`, or `[hidden]` attributes. Its
branch delimiters are excluded from the source label used for ranking. Its
`CONDITIONAL_SOURCE` status means these declarations contain the candidate;
`NO_LOCAL_GUARD_FOUND` means this scan found no guard around it. Unsupported
blocks or malformed nesting return `UNRESOLVED_CONTROL_FLOW` with parse issues.
No status proves that a route was activated, an expression was true, a loop
had items, an element was visible, or the rendered DOM contained the control.
Confirm the route and state in a real scenario before those claims.

`style_reference` lists declared component and global stylesheets with exact
hashes when available, and bounded selector-rule candidates for the element's
literal tag, class, or ID. `LOCAL_COMPOUND_MATCH` relates a simple selector to
the source declaration; `POSSIBLE_CONTEXT` requires an unverified ancestor,
pseudo state, media context, or project scope. An inline CSS rule's `line` is
relative to the CSS literal, with the component decorator line recorded
separately. `UNKNOWN` lists missing stylesheets, imports, preprocessors,
unsupported syntax, or bounds in `issues`; known rules are still returned.
`BOUNDED_SOURCE` means all declared stylesheet source in this bounded scan was
read and parsed. Neither state proves the effective cascade, active media
query, inherited styles, computed style, missing-rule irrelevance, or geometry.

No browser, source mutation, runtime execution, action authority, or task
postcondition proof is granted by `ui static`.
