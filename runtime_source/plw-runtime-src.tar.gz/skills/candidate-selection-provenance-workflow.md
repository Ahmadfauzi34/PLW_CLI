# Candidate Selection Provenance Workflow

**Load when:** evidence-driven capability matching projects `candidate` for a resolved target and the agent needs to know whether one exact local simplification candidate is grounded by the task.

**Provides:** task-bound, revision-bound candidate identity from the complete current simplification candidate set. The result is one of `RESOLVED`, `AMBIGUOUS`, or `UNRESOLVED`; ambiguity is preserved rather than guessed away.

Use:

```bash
plw candidate select "<task>" <root> --json
```

The returned decision binds the target revision, shared-graph signature, candidate-set digest, discovery snapshot, candidate instance/source site, selection basis, rejected alternatives, and confidence boundary.

For a Git working tree with dirty tracked or untracked paths, the revision also
binds readable file bytes and symlink targets through `dirty_content_digest`.
Inspect `dirty_content_complete`: a false value means some dirty path could not
be bound. A downstream effectful path still requires a clean target and its
own exact provenance and authorization checks.

If and only if the agent needs to know whether a resolved candidate matches an internal bounded capability contract, use the separate read-only operation:

```bash
plw candidate capability-match "<task>" <root> --json
```

`CAPABILITY_MATCHED` is still only contract matching. It is not authorization and does not execute or mutate anything.

Do not use candidate selection as a replacement for target-file resolution. Do not convert `AMBIGUOUS` into a guess. Do not treat `RESOLVED` as correctness, semantic equivalence, evidence acceptance, mutation authority, stable promotion, or truth. Any later effectful path must independently revalidate the exact provenance artifact against the current clean target and consume its own authorization boundary.

**Return to:** the agent decision frame after reading the result. If selection is ambiguous/unresolved, gather additional target/task evidence. If resolved, decide which evidence gap remains; do not execute a capability merely because a candidate was selected.

**Related modules — load only when needed:** [Evidence-driven capability selection](evidence-driven-capability-selection-workflow.md), [Target resolution](target-resolution-workflow.md), [Code change/session workflow](code-change-and-session-workflow.md).
